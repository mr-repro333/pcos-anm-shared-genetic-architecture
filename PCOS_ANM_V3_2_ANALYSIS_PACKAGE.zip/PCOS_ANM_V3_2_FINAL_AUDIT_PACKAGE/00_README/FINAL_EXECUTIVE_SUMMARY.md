# FINAL_EXECUTIVE_SUMMARY (V3.1)

## What this round is

A validity repair of V3, limited to three blockers. No new outcome, no new endpoint, no new
instrument, no new family, no estimator switched for the sake of a result. The family
membership, the prevalence grid, the rho grid and the SD_ANM grid are the V3 ones.

## The three repairs

1. **Scale direction.** theta_L = theta_logOR / m(K), not x m(K); SE with the same reciprocal.
   The previous per-SD values were too small by 3.802 at K = 0.10.
2. **Signed Stouffer.** signed_Z = sign(beta) x Phi^-1(1 - P/2).
3. **MVMR covariance.** Bounded by Cauchy-Schwarz and walked, instead of asserted zero.

## The result

**Zero of the nine primary difference tests survive BH-FDR.** Under the previous multiplication
four appeared to pass. The corrected comparison is bounded by power: the PCOS arm has 80% power
to detect an ANM-sized systemic effect for 0 of the nine outcomes.

| outcome | power to detect an ANM-sized effect |
|---|---|
| HDL cholesterol | 0.05 |
| Body mass index | 0.05 |
| Type 2 diabetes | 0.06 |
| Coronary artery disease | 0.08 |
| Triglycerides | 0.08 |
| Waist-to-hip ratio adjusted for BMI | 0.08 |
| HbA1c | 0.09 |
| Heel bone mineral density | 0.32 |
| Forearm fracture | 0.34 |

## What stands, and at what grade

| finding | grade | number |
|---|---|---|
| Shared reproductive genetic architecture | ROBUST | r_g = +0.329; associated in both directions |
| PCOS liability associated with later ANM | ROBUST | +0.434 yr/log-OR (P = 3.05e-05) |
| ANM associated with PCOS liability | ROBUST | OR 1.100/yr, 95% CI 1.069-1.132 (P = 8.14e-11) |
| No formal systemic difference established | ROBUST (as a null) | 0/9 survive BH-FDR; min q = 0.1651 |
| Detection limit quantified | ROBUST | 0 of 9 outcomes at an ANM-sized effect |
| ANM skeletal signature, primary instrument A1 | ROBUST | signed Stouffer P = 0.0020 at rho = 0.5 |
| ANM associated with lower FSH, lower LH, higher estradiol, higher testosterone | ROBUST | FSH -0.175; LH -0.078; estradiol +0.022; testosterone +0.015 |
| Hormonal profiles separable | ROBUST | 2 of 5 endpoints: Estradiol, LH |
| FSHB shared regional signal | PROMISING_NEEDS_VALIDATION | PP.H4 = 0.998960 primary prior; tier A_ROBUST |
| PCOS liability associated with lower FSH | EXPLORATORY | q = 0.067; matched difference null |
| ANM skeletal replication in A2 | UNRESOLVED | signed P = 0.0566 at rho = 0.5 |
| Multivariable direct effects | UNRESOLVED | gate not identified in the covariance band |
| A shared gonadotropic mechanism at FSHB | WITHDRAWN | Layer 3 failed; no FSH-region coloc |
| Adiposity distribution hypothesis | WITHDRAWN | UNSUPPORTED in the primary design |

## The one sentence to take away

PCOS genetic liability and later menopause share reproductive genetic architecture, and their
systemic association patterns differ from outcome to outcome, but with the exposure scale
treated correctly those differences are **not formally distinguishable at the current PCOS
instrument strength**.
