# README_FIRST (V3.1)

**This package is a final validity repair of V3, not a new version. No outcome, endpoint,
instrument design, family member or estimator was added, removed or re-assigned. The three
repairs are: the direction of the binary-exposure liability conversion; the sign of the
Stouffer combination; and the justification of the multivariable covariance assumption.**

## 1. What was actually wrong

**(a) The scale conversion was applied in the wrong direction.** The SNP-exposure conversion
beta_L = m(K) x beta_logOR is correct, and it was stated correctly. But the quantity being
compared is an MR *ratio*, and a ratio scales by the reciprocal: theta_L = theta_logOR / m(K),
SE(theta_L) = SE(theta_logOR) / m(K). The previous version multiplied. At K = 0.10 this made
every per-SD PCOS effect, and its standard error, too small by m(K)^-2 = 3.802. A
unit test in `04_CODE/test_scale_reciprocity.py` establishes the reciprocity algebraically and
numerically and pins the factor.

**(b) A combination statistic had no signs.** The Stouffer combination built every Z from a
two-sided P value, so every Z was positive and the sum could only report agreement. Corrected
to signed_Z = sign(beta_aligned) x Phi^-1(1 - P/2).

**(c) gencov = 0 was justified by a non sequitur.** LD independence between SNPs is not zero
covariance between two SNP-exposure *estimates* from overlapping samples. Bounded by
Cauchy-Schwarz instead, and the bound decides the answer.

## 2. What that does to the headline

**0 of the nine primary difference tests survive Benjamini-Hochberg at 0.05.**
Smallest P = 0.0343 (Type 2 diabetes); smallest q =
0.1651. Under the previous multiplication four of nine appeared to pass; that result is
withdrawn. The count is 0 at every prevalence in 5-20% and 0 at every
SD_ANM in 3.5-4.2, so no conclusion depends on choosing K.

The analysis had 80% power to detect an ANM-sized effect for **0 of the nine
outcomes**, because the corrected standard error is larger by 1/m = 1.950. The previous
version claimed two; that claim is reversed.

## 3. What survives

* The shared reproductive genetic architecture: association in both directions and
  r_g = +0.329.
* The ANM skeletal signature in the **primary** instrument A1: signed Stouffer P =
  0.0020 at rho = 0.5 and
  0.0146 at rho = 0.9.
* Two hormonal endpoints separating the exposures, in opposite directions:
  **Estradiol, LH**.
* FSHB as a **shared regional signal under the single-signal colocalization model**:
  primary-prior PP.H4 = 0.998960, grid minimum
  0.989699, LD-pruned
  1.000000, tier A_ROBUST.

## 4. What is withdrawn

* "Separable systemic correlates for skeletal and glycaemic outcomes" - the corrected family is
  null.
* "Replication of the skeletal signature in the alternative ANM instrument" - A2 gives
  0.0566 at rho = 0.5 once the signs are carried.
* "Three of five hormonal endpoints separate the exposures" - it is
  **2 of five**; FSH does not survive (P
  0.1303-0.3318).
* "The PCOS arm had adequate power" - reversed.
* Any multivariable direct effect - the gate is not identified under the covariance band.
* Any mechanism wording at FSHB.

## 5. The claim matrix, counted once

The Claim-Evidence Matrix contains **14 claims**, of which **8 are
graded ROBUST** and **9 are safe for the abstract**. Those three numbers are stated
here and are re-checked against the matrix file by `08_QC/INTERNAL_CONSISTENCY_AUDIT.md`. There
is one count now, not the several the previous package carried.

## 6. Is the package actually reproducible?

Yes, and the claim is conditional on a test. `10_INPUTS/` holds the 1220 files the
shipped code reads (40.4 MB), with SHA-256 checksums. `v31_smoke.py` materialises a
fresh data root from the package alone, re-runs every analysis module against a fresh output
directory, and compares each result with the shipped file. The result is in
`08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md`. If any row of that table reads FAIL, the correct claim is
the weaker one and this README is wrong.

## 7. Where to look first

* `03_RESULTS/V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv` - the previous value, the corrected value,
  the change in P, the change in q, and the change in claim status, one row per outcome.
* `03_RESULTS/V3_1_MULTIPLIER_SITE_REGISTER.tsv` - every multiplier site in the project and what
  object it was applied to.
* `03_RESULTS/V3_1_SKELETAL_EVIDENCE.xlsx`, sheet `SIGNED_VS_V3UNSIGNED`.
* `03_RESULTS/V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx` - the band and what it does to the
  gate.
* `03_RESULTS/V3_1_HORMONAL_ENDPOINT_ACCOUNTING.xlsx` - six planned, five analysed, and the
  exact reason for the sixth.
* `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md`.

## 8. The scientific questions the repair was asked to answer

**A. How many of the nine formal systemic PCOS-vs-ANM differences survive BH-FDR?**
**Zero.** Smallest P = 0.0343, smallest q = 0.1651.

**B. Does any conclusion depend on choosing K within 5-20%?** No. The FDR-positive count is
0 at every K in the grid and 0 at every SD_ANM, so there is no positive
conclusion that K could carry.

**C. Which hormonal differences survive corrected scaling and FDR?**
**2: Estradiol, LH.** FSH, progesterone and testosterone do not.

**D. Does signed skeletal evidence remain significant for A1 and separately A2?**
A1: yes, at every rho up to 0.9 (6.546 x 10^-10 /
0.0020 / 0.0146).
A2: **no** at rho >= 0.5 (P = 0.0566 at 0.5, against
0.0072 from the unsigned version).

**E. Does any MVMR direct effect remain interpretable?** No. At gencov = 0 the rebuilt
restricted design passes both gates (13.83 /
12.02), but it fails both at tau = -0.5 and tau = -1.0, and Q_A is
significant in nearly every model. MVMR is retained as a design and sensitivity analysis only.

**F. What is the strongest defensible FSHB evidence tier?** Tier 1-2 of the ladder: a shared
FSHB-region signal, and under the single-signal colocalization model a likely shared causal
signal. Not a fine-mapped signal, not a resolved causal variant, not an FSH-mediated variant,
not a mechanism.

**G. What is the manuscript's final core claim?** PCOS genetic liability and later age at
natural menopause share reproductive genetic architecture; their systemic association patterns
differ for individual outcomes but are **not formally distinguishable at the current PCOS
instrument strength**; the hormonal contrast that survives correction separates them for
estradiol and LH in opposite directions; and FSHB carries a shared regional signal under a
single-signal colocalization model, without a resolved causal variant.

## 9. What this rebuild round changed, and what it did not

Nothing in the analysis changed. Every number in the rebuilt documents is read from the same
result files as before, and the fail-closed audit passes on the rebuilt set.

What changed is the presentation and two provenance records:

- the manuscript carries a reference list and in-text citations, which the previous round did
  not have at all;
- the abstract is inside the journal limit instead of four times over it;
- the six figures are cited in the text, which they previously were not;
- the instrument designs are named for their locus count and window rather than by the codes
  D1-D5 / A1-A2, which were internal;
- the correction narrative is one Methods subsection rather than the spine of the paper;
- Table 1b and the withdrawn-pooling column moved to the supplement; the main text is six
  tables;
- a large-language-model statement was added, as the journal requires;
- `07_PROVENANCE/GWAS_SOURCES.md` was rebuilt with accessions verified live, and two new records
  were added: `ACCESSION_RESOLUTION_AUDIT.md`, which records that the two primary PCOS
  accessions do not resolve, and `03_RESULTS/V3_1_OUTCOME_DATASET_REGISTRY.tsv`, which records
  that six of the nine primary outcome releases carry no identifiable study-level source.

The last two items are findings, not fixes. They are the two things that still need an author
decision before submission.

## 10. Round 2: what the independent review found, and what was done about it

The rebuilt manuscript was reviewed independently by a second reader who had not seen the
analysis. Nine substantive objections were raised. Six were accepted and fixed; one was
rejected after recomputation; two were carried as disclosures.

Accepted and fixed:

- Table 1 printed four rho* values above 1 under a column described as a correlation. A
  correlation above 1 means the test never reaches alpha, and the column now says so.
- The FSH value quoted in the Results comes from the discordance-rule arms, while the
  harmonisation section labelled a different range as "as shipped". The three rule sets are now
  named explicitly and the primary table is tied to the one that produced it.
- The earlier FSH arm could not be re-derived exactly from the deposited matrices (twenty
  matched variants against seventeen). That was recorded in the QC file but not in the
  manuscript. It is now in the Limitations.
- The hormonal arms carry seven to nine PCOS variants against 59 to 69 ANM variants. Now stated.
- Two of the three hormonal designs draw the PCOS instrument from the same study as the hormone
  outcomes, so exposure and outcome are estimated in overlapping participants. Now stated, with
  the consequence that the LH contrast is strongest in the design with the most overlap and is
  therefore reported as unconfirmed.
- Two references in the list were never cited. Both are now cited, and a gate now fails the
  package if any listed reference is uncited.

Rejected after recomputation: the claim that the power column does not match the stated formula.
The two-term two-sided non-central power reproduces all nine published values to three decimals
(T2D 0.0604 against 0.060; HDL 0.0503 against 0.050; BMI 0.0528 against 0.053). The review had
used a one-sided tail.

Carried as disclosures rather than fixed: the two unresolved PCOS accessions, and the fact that
six of the nine primary outcome releases carry no identifiable study-level source. Both are
recorded, both are stated in the manuscript, and neither can be resolved from inside the package.

