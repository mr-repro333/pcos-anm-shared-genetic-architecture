# V3.1 required deliverables - index

The repair was specified with fourteen deliverables. Each is listed here with its path, and a
machine-readable version of the same list is in `00_README/REQUIRED_DELIVERABLES.tsv`.

| # | deliverable | path |
|---|---|---|
| 1 | V3.1 scale-correction audit workbook | `03_RESULTS/V3_1_SCALE_CORRECTION_AUDIT.xlsx` |
| 2 | corrected primary nine-test difference table | `03_RESULTS/V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv` |
| 3 | corrected prevalence / rho / SD sensitivity tables | `03_RESULTS/V3_1_PREVALENCE_SENSITIVITY.tsv`, `V3_1_RHO_SENSITIVITY_GRID.tsv`, `V3_1_SD_ANM_SENSITIVITY.tsv` |
| 4 | corrected hormonal difference table | `03_RESULTS/V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv` |
| 5 | corrected MDE / power table | `03_RESULTS/V3_1_POWER_MDE_CORRECTED.tsv` |
| 6 | corrected signed skeletal-domain table | `03_RESULTS/V3_1_SKELETAL_EVIDENCE.xlsx` |
| 7 | MVMR covariance-assumption audit | `03_RESULTS/V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx` |
| 8 | complete instrument / harmonisation provenance | `03_RESULTS/V3_1_INSTRUMENT_PROVENANCE.tsv`, `V3_1_D4_UNION_INSTRUMENT_PROVENANCE.tsv`, `V3_1_HARMONIZATION_PROVENANCE.xlsx`, `V3_1_HARMONIZATION_AUDIT_RECOUNT.tsv` |
| 9 | revised Claim-Evidence Matrix | `03_RESULTS/V3_1_CLAIM_EVIDENCE_MATRIX.xlsx` |
| 10 | revised manuscript | `01_MANUSCRIPT/V3_1_manuscript.md` (+ `.docx`) |
| 11 | revised supplement | `06_SUPPLEMENT/*.md` (+ two `.docx`) |
| 12 | machine-readable V3 to V3.1 change log | `00_README/V3_TO_V31_CHANGELOG.json` (human-readable `.md` alongside) |
| 13 | self-contained reproducibility package | `99_PACKAGE/PCOS_ANM_V3_1_FINAL_AUDIT_PACKAGE.zip` with `SHA256SUMS.txt` and `MANIFEST.tsv` |
| 14 | final fail-closed audit | `08_QC/V3_1_FINAL_FAILCLOSED_AUDIT.md`, `03_RESULTS/V3_1_FINAL_FAILCLOSED_AUDIT.xlsx` |

## Supporting artefacts the fourteen depend on

| artefact | path |
|---|---|
| the scale law unit test | `04_CODE/test_scale_reciprocity.py` |
| multiplier site register and scan | `03_RESULTS/V3_1_MULTIPLIER_SITE_REGISTER.tsv`, `V3_1_MULTIPLIER_USE_AUDIT.tsv` |
| side-by-side V3 vs V3.1 comparison | `03_RESULTS/V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv` |
| hormonal endpoint accounting (six planned) | `03_RESULTS/V3_1_HORMONAL_ENDPOINT_ACCOUNTING.xlsx` |
| harmonisation-rule sensitivity | `03_RESULTS/V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv`, `V3_1_HORMONE_RULE_SENSITIVITY_ARMS.tsv` |
| FSHB evidence tier and PP4 reconciliation | `03_RESULTS/V3_1_FSHB_EVIDENCE_AUDIT.xlsx` |
| master results with both scales | `03_RESULTS/V3_1_MASTER_RESULTS_long.tsv` |
| programmatic consistency audit | `08_QC/INTERNAL_CONSISTENCY_AUDIT.md`, `03_RESULTS/V3_1_CONSISTENCY_AUDIT.xlsx` |
| clean-environment smoke test | `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md` |
| input manifest and bootstrap | `03_RESULTS/V3_1_INPUT_MANIFEST.tsv`, `04_CODE/bootstrap_data_root.py` |
| what is deliberately not shipped | `03_RESULTS/V3_1_NOT_SHIPPED_AND_WHY.tsv` |
| corrected provenance folder | `07_PROVENANCE/` |
| figures, rebuilt from the corrected results | `05_FIGURES/` with `source_data/` |

## Stop condition

The repair's instruction was: once these errors are corrected and the manuscript is aligned to
the corrected results, stop analysis and move to submission polishing. Nothing in this package
adds an analysis beyond the three repairs; the fail-closed audit
(`08_QC/V3_1_FINAL_FAILCLOSED_AUDIT.md`, 59 gates) is the check that this is true.
