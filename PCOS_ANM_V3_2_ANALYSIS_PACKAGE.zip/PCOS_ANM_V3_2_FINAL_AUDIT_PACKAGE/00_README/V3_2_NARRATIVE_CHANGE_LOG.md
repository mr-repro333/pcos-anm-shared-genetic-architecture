# V3.2 narrative change log

**What this version is.** A repositioning of the manuscript, not a new analysis. The
analysis, the nine-outcome family, the instruments, the endpoints and every result
value are exactly the V3.1 ones: `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md` reports 12 of 12
steps reproduced from the package alone against the rebuilt code, and the six figure
source-data files are byte-identical to the V3.1 ones.

**What changed.** The paper used to read as a report of an audit of an earlier version of
itself. It now reads as a standalone study that asked one question and returned a bounded
answer. Nothing was deleted that a reader needs to understand, replicate or doubt the
result.

## 1. The repositioning, in one paragraph

The question the paper asks is whether a systemic effect attributed to PCOS is formally
distinguishable from one attributed to age at natural menopause when both are estimated
against the same outcome data. The answer the design returns is bounded: at the current
strength of the PCOS instrument the two traits' systemic association patterns are not
formally distinguishable, and the analysis has no power to detect an ANM-sized effect for
any of the nine outcomes. The one domain that does separate the two exposures is the
reproductive hormone axis, where estradiol and LH move in opposite directions and hold
across the whole covariance range. That is now the shape of the abstract, the
introduction, the section headings and the discussion. It was already the shape of the
results.

## 2. What was removed, and why it is not information loss

| removed | where it was | why | where the content still lives |
|---|---|---|---|
| the defect-by-defect account of the earlier scale | Introduction paragraphs 3-5 | a reader who never saw the earlier version cannot use it; it made the first impression a list of corrections | this log; `00_README/V3_TO_V31_CHANGELOG.md`; `03_RESULTS/V3_1_SCALE_CORRECTION_AUDIT.xlsx` |
| the conditional-F figures of the earlier multivariable design (11.0-15.2, 6.92-10.42) | Results 3.8 | they describe a design that is not the one reported | `03_RESULTS/V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx` |
| the paragraph describing the MR-Egger re-implementation search | Methods 2.3 | the estimator-orientation point takes one sentence; the 20-parameterisation search is a supplement table | Supplementary Table S16; `07_PROVENANCE/V3_1_EGGER_PARAMETER_IDENTIFICATION.tsv` |
| the eight-sentence Strengths section | Discussion 4.4 | it defended the design instead of stating what it supports, which is three features | Discussion 4.4, now three sentences |
| version labels on the figure panels (`V3.1 corrected`, `V3 as shipped`, `unsigned (V3, defect)`) | Figures 2-5 | an axis legend that names a version the reader has not seen is not a legend | replaced by `reciprocal scale` / `multiplicative scale` / `signed` / `unsigned` |
| the sentence asking the reader to trust the correction | Results 3.2 and 3.3 | the correction is now stated as a property of the method and carried by the unit test | Methods 2.4; `04_CODE/test_scale_reciprocity.py` |

## 3. What was added

| added | where | why |
|---|---|---|
| the clinical consequence in the first sentence of the question paragraph | Introduction | the attribution question is only worth a paper because it changes who is screened for what |
| the answer in brief at the end of the Introduction | Introduction | the old version ended with a roadmap of its own sections |
| a sentence on the 2026 renaming of PCOS | Introduction | an international consensus renamed the condition in May 2026 and left the diagnostic criteria unchanged; a 2026 submission that does not acknowledge it invites the question. The exposure datasets were defined under the old name, so the old name is used throughout |
| a clinical reading of the bound, and its caveat | Discussion 4.3 | the paper said what would follow if the pattern resolved but not what follows from the fact that it did not |
| six figure legends, in the manuscript file | before the reference list | the journal requires the captions in the text file, not in the figure file |
| doi.org links on every reference entry | reference list | the journal asks for a DOI as a full link wherever one exists |

## 4. Measurements

| measure | V3.1 | V3.2 |
|---|---|---|
| abstract, journal counter (limit 250) | 246 | **246** |
| body words, Introduction to Discussion | 9917 | 10308 |
| sentences in the body | 291 | 298 |
| mean sentence length | 34.1 | **34.6** |
| longest sentence | 478 | **481** |
| sentences over 45 words | 53 | **64** |
| hedging density (narrow list, per 1000 words) | 12.1 | **12.0** |
| version-history phrases in the reader-facing text | 11 | **0** |

## 5. The four self-proofs

**5.1 The analysis is unchanged.** `v31_smoke.py` materialised a fresh data root from
`10_INPUTS/` alone, re-ran all eleven analysis modules plus the R covariance sensitivity
against it and compared every produced file with the shipped one: **12 of 12 PASS**.
All six `05_FIGURES/source_data/*.csv` are byte-identical to their V3.1 counterparts.

**5.2 Numbers.** Comparing the body of the manuscript (reference list excluded) between
V3.1 and V3.2: **no result token was introduced**, and five tokens left with the two
paragraphs named in section 2 above (`11.0`, `15.2`, `6.92`, `10.42` are the superseded
conditional-F figures; `226` was the complement of the 18-of-244 that is still stated).
Every headline value is still present and the fail-closed gate that re-derives each of
them from the shipped result files passes.

**5.3 Gates.** 81 of 81 fail-closed gates PASS, 17 of 17 compliance checks PASS, the
consistency audit PASSes. Two gates were **strengthened** rather than relaxed, because a
DOI link and a version-free text are what the change requires:

* `no DOI token appears in the manuscript` became `DOI links appear only in the
  reference list` (>=30 in the list, 0 anywhere else), and the numeric scan now excludes
  the reference block instead of relying on the absence of DOIs to keep it clean;
* `the withdrawn comparison remains clearly marked as withdrawn` became `no superseded
  quantity is presented as a result`, which requires the reason for not pooling to be
  stated, forbids a pooled P value from being presented and forbids the word
  'withdrawn' anywhere.

**5.4 Reproducibility of this version.** The zip uses a fixed entry timestamp. The
document chain (`v31_docs_extra.py`, `v31_docs_round2.py`) regenerates 19 of 19
documents byte-identically from the V3.1 package, which is how the rewrite was shown to
touch only the files it claims to touch.

## 6. Defects fixed in the same pass (found while auditing V3.1)

| defect | effect | fix |
|---|---|---|
| LD-pruned PP.H4 hard-coded as `0.999990` | the supplement contradicted the table it describes (true value 0.999999987988659) | both sites read the value from `03_RESULTS/V3_1_FSHB_EVIDENCE_AUDIT.xlsx` |
| the changelog printed the file list under `consequence` and then iterated the consequence string character by character | all 20 rows of the `files touched` table were unusable | field order corrected at both the markdown and the JSON writer |
| `KNOWN_LIMITATIONS.md` item 12 carried the withdrawn MR-Egger objection as open while the same file records it as closed | a QC document contradicting itself | item 12 rewritten |
| Figure 2A annotation overlapped the m(K) curve | legibility at print size | moved into the empty band between the curves, darker ink |
| the two x-axis labels of Figure 3 collided | legibility | both shortened |

## 7. Deliberately not changed

* the title. It already states the repositioned message ('an unresolved systemic
  signature') and the fail-closed gate that forbids an unqualified indistinguishability
  claim passes on it unchanged;
* every number, table, figure panel and figure source value;
* every limitation and every provenance disclosure, including the two unresolved PCOS
  accessions and the two outcome releases with no primary study publication;
* the disclosure that two of the three hormonal designs draw exposure and outcome from
  overlapping participants, and that LH is therefore reported as unconfirmed;
* the ethics, consent, LLM-use and data-availability statements, which are
  journal-mandated wording;
* the internal artifact file names (`V3_1_*.tsv`, `V3_1_manuscript.docx`). They are the
  frozen analysis names and are referenced by dozens of documents, tables and result
  files; renaming them would break the cross-references for no scientific gain. The
  package, the manuscript and this log carry the version the reader needs.

## 8. Known issue carried forward

The manuscript still has no title page: this package contains no author names,
affiliations, corresponding-author address or ORCID anywhere, and no cover letter. That
is a submission blocker independent of the narrative and is recorded here rather than
silently left out.
