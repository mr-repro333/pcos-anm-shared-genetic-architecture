# V3 to V3.1 change log

Machine-readable copy: `00_README/V3_TO_V31_CHANGELOG.json`.

| id | blocker | kind | item | before | after | consequence |
|---|---|---|---|---|---|---|
| V31-01 | PRIORITY 0 | correctness | binary-exposure liability conversion applied to an MR ratio | pcos_perSD = ivw * m(K); se = ivw_se * m(K). Every per-SD PCOS effect was too small by m(K)^-2 = 3.802428 at K = 0.10. | theta_L = theta_logOR / m(K); SE likewise (Equations 3-4). | 0 of 9 primary difference tests survive BH-FDR; the previous version reported 4. |
| V31-02 | PRIORITY 0 | scope | project-wide audit of every place a liability multiplier is applied | no such audit existed | 9 sites registered and classified by object type; 4 were applied to an MR ratio or an MR-ratio SE and are cancelled | the same error existed in three other files, all repaired |
| V31-03 | PRIORITY 0 | test | no algebraic or numerical evidence for the scale law | none | test_scale_reciprocity.py: algebraic proof, 200-vector numerical test, and a regression guard pinning the previous factor at m(K)^-2 | the correction is demonstrated, not asserted |
| V31-04 | PRIORITY 0 | correctness | matched hormonal differences and MDE/power used the same wrong direction | three of five endpoints appeared to separate the exposures | two of five (Estradiol, LH); FSH matched difference 1.7e-07 -> 0.130; every MDE larger by 1/m; power 0 of 9 instead of 2 of 9 | the hormonal and power claims are rewritten |
| V31-05 | PRIORITY 1 | correctness | Stouffer combination built all-positive Z from two-sided P values | z_i = Phi^-1(1 - p_i/2) for every i | signed_Z_i = sign(beta_aligned_i) x Phi^-1(1 - p_i/2) | A1 stays significant at every rho up to 0.9; A2 does not at rho >= 0.5 (0.00717 -> 0.05659) |
| V31-06 | PRIORITY 1 | structure | skeletal evidence reported as one domain number | a single Stouffer row per design | five separated tiers and A1/A2 never pooled | no domain-level sentence can be written that the endpoints do not support |
| V31-07 | PRIORITY 2 | justification | gencov = 0 defended by 'the instruments are mutually LD-independent' | asserted; no sensitivity | bounded by Cauchy-Schwarz: gencov = tau se1 se2 with tau in [-1, +1]; conditional F recomputed at 11 values of tau for all 46 models | the gate flips inside the band; MVMR demoted out of the biological headline |
| V31-08 | PRIORITY 2 | interpretation | ANM->BMD attenuation read as a caution about mediation/sharing | stated with a caveat | withdrawn entirely | no mediation or sharing sentence is licensed |
| V31-09 | PRIORITY 3 | reproducibility | code referenced absolute paths that were not in the package | the audit ZIP shipped scripts whose inputs were not shipped, so 'fully reproducible' was unverifiable | 1220 input files shipped with a SHA-256 manifest; DATA_ROOT configurable; bootstrap --restore; clean-environment smoke test | the reproducibility claim is now conditional on a test that passes |
| V31-10 | PRIORITY 3 | provenance | per-variant instrument provenance absent | design-level counts only | per-variant provenance for D1, D3, D4, D5, D6, A1 and A2, including the coefficient source GWAS, whether the variant was selected in that same GWAS, ancestry, participant-overlap considerations, palindromic status, harmonisation action and proxy status | D4 remains union/power sensitivity only and never supersedes D1 |
| V31-11 | harmonisation | documentation | two incompatible palindrome rules described as one | the provenance note said the 0.42-0.58 band; the per-pair audit said |dEAF| > 0.05 | both rules named and documented separately with the matrices each produced; the audit regenerated from the deposited records (247 pairs, 515 drops) | the band rule is the hormone path only; the divergence is quantified |
| V31-12 | harmonisation | sensitivity | the rule divergence was unmeasured | not quantified | both hormone arms re-derived under as-shipped, discordance-rule and no-exclusion variant sets; the surviving endpoints are the same two under all three | the inconsistency is real but not load-bearing |
| V31-13 | endpoints | accounting | the planned six-endpoint hormonal family was reported as five without the reason for the sixth | the family-size file said five; the changelog explained progesterone by build order | all six visible with exact retrieval/QC evidence: five analysed and tested, SHBG not retrievable and recorded as a deviation | no planned endpoint is silently reduced; the progesterone wording is corrected from a build-order fact to a retrieval outcome |
| V31-14 | FSHB | claim tier | PP4 quoted as one number and FSHB called 'the only shared signal' | 0.999 in three documents, 0.9990 in one, computed as %.3f in the matrix; DENND1A and IRF1 also colocalise | primary-prior PP4 = 0.998960, grid minimum = 0.989699, LD-pruned = 1.000000, stated separately in every document; 'only' is stated as an evidence-tier claim | PP.H4 is reconciled across abstract, Results, Discussion, tables, supplement and the claim matrix |
| V31-15 | FSHB | wording | mechanism wording at FSHB | 'biologically concordant triangulation' and a shared-gonadotropic-mechanism claim | enforced ladder: shared regional signal; likely shared causal signal under the single-signal colocalization model. Mechanism wording withdrawn. SuSiE not re-run. | no sentence may exceed what a single-signal coloc supports |
| V31-16 | numbers | consistency | ANM->PCOS confidence interval reported on the log-OR scale beside an odds ratio | OR 1.100 per year, 95% CI +0.067 to +0.124 | OR 1.100 per year, 95% CI 1.069 to 1.132 on the OR scale | the interval is on the same scale as the estimate it accompanies |
| V31-17 | numbers | consistency | claim-matrix counts disagreed between documents | one document said 6 of 10, another 7 of 11 or 7 of 12 | one count, computed from the matrix and re-checked by the consistency audit: 14 claims, 8 ROBUST, 9 safe for the abstract | README, executive summary, manuscript and QC carry the same count |
| V31-18 | numbers | regeneration | figures and tables carrying the incorrect liability-scaled effects | Figures 2, 3, 5 and 6 and the main difference table | all six figures regenerated from the corrected result files; Figure 2 plots both conversion directions and Figure 4 shows signed versus unsigned | no figure or table carries a pre-correction number |
| V31-19 | claims | reclassification | previous ROBUST/PROMISING labels inherited | 7 ROBUST claims including separable systemic profiles and adequate power | no label inherited; 14 claims re-graded from the corrected numbers | systemic separability WITHDRAWN, A2 skeletal UNRESOLVED, FSH EXPLORATORY, MVMR out of the headline, power REVERSED |
| V31-20 | narrative | manuscript | manuscript built around 'separable systemic correlates' | 'their systemic correlates are separable for skeletal and glycaemic outcomes ... Neither trait should be used as a proxy for the systemic risk carried by the other' | rebuilt around shared reproductive genetic architecture with exposure-specific association patterns that are not formally distinguishable at the current PCOS instrument strength | the banned phrasings (systemic decoupling, established systemic differences, separable systemic profiles, proxy for the other's systemic risk) do not appear as assertions |

## Files touched by each entry

| id | files |
|---|---|
| V31-01 | `V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv`; `V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv` |
| V31-02 | `V3_1_MULTIPLIER_SITE_REGISTER.tsv`; `V3_1_MULTIPLIER_USE_AUDIT.tsv` |
| V31-03 | `test_scale_reciprocity.py` |
| V31-04 | `V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv`; `V3_1_POWER_MDE_CORRECTED.tsv` |
| V31-05 | `V3_1_SKELETAL_EVIDENCE.xlsx (SIGNED_VS_V3UNSIGNED)` |
| V31-06 | `V3_1_SKELETAL_EVIDENCE.xlsx` |
| V31-07 | `V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv`; `V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx` |
| V31-08 | `V3_1_CLAIM_EVIDENCE_MATRIX.xlsx` |
| V31-09 | `V3_1_INPUT_MANIFEST.tsv`; `bootstrap_data_root.py`; `v31_smoke.py`; `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md` |
| V31-10 | `V3_1_INSTRUMENT_PROVENANCE.tsv`; `V3_1_D4_UNION_INSTRUMENT_PROVENANCE.tsv` |
| V31-11 | `V3_1_HARMONIZATION_PROVENANCE.xlsx`; `V3_1_HARMONIZATION_AUDIT_RECOUNT.tsv` |
| V31-12 | `V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv`; `V3_1_HORMONE_RULE_SENSITIVITY_ARMS.tsv` |
| V31-13 | `V3_1_HORMONAL_ENDPOINT_ACCOUNTING.xlsx` |
| V31-14 | `V3_1_FSHB_EVIDENCE_AUDIT.xlsx` |
| V31-15 | `V3_1_FSHB_EVIDENCE_AUDIT.xlsx (WORDING_LADDER)` |
| V31-16 | `01_MANUSCRIPT/V3_1_manuscript.md` |
| V31-17 | `V3_1_CLAIM_EVIDENCE_MATRIX.xlsx`; `README_FIRST.md` |
| V31-18 | `05_FIGURES/` |
| V31-19 | `V3_1_CLAIM_EVIDENCE_MATRIX.xlsx` |
| V31-20 | `01_MANUSCRIPT/V3_1_manuscript.md` |

## Rules this repair was bound by

* Do not add a new broad outcome, do not search for a new positive result, do not switch instrument, outcome or estimator to rescue the narrative.
* Do not change the family when the corrected results come out null.
* Do not create an alternative family; do not substitute an alternative outcome release; do not use D3/D4/D5 to rescue the primary conclusion.
* If the corrected family has zero FDR-positive differences, report zero.
* Do not rerun SuSiE to obtain a positive result.
* No new MVMR outcome.
* No 'fully reproducible from the package' claim until the smoke test passes.
