# DECISION_LOG (V3.1)

| # | decision | alternative considered | why this one |
|---|---|---|---|
| 1 | Apply the reciprocal conversion and leave the family untouched | re-define the family so a difference survives | the plan forbids it, and a family chosen after seeing the numbers is not a family |
| 2 | Report zero FDR-positive differences | report the raw P values and let the reader judge | the fail-closed rule is explicit, and the raw P values are in Table 1 anyway |
| 3 | Bound gencov instead of estimating it | use the LDSC r_g as the covariance | r_g is a genetic correlation, not the sampling covariance of two effect estimates; using it would be inventing a number |
| 4 | Keep MVMR in the package but out of the headline | drop MVMR entirely | the design audit is real evidence about the earlier multivariable claims; the effects are not interpretable |
| 5 | Do not re-run SuSiE | re-run with a different marker set | a marker set chosen to produce a credible set is a fabricated result; no ancestry-matched reference is available within scope |
| 6 | Ship the harmonised matrices and not the raw deposits | ship everything | the headline numbers are all re-derived from the harmonised matrices; the raw deposits are hundreds of MB and are public by accession |
| 7 | Regenerate the harmonisation audit from the implementation | trust the two prose descriptions | the prose descriptions contradict each other, which is the problem being fixed |
| 8 | Re-derive both hormone arms under three palindrome rules | document the divergence and stop | the divergence could in principle change the hormonal conclusion, so it had to be measured |
| 9 | Report A1 and A2 separately rather than pooling the ANM arms | pool for power | the two instruments disagree, and pooling would hide exactly the finding |
| 10 | Split the single-domain Stouffer row into separated tiers | keep one number per design | the tiers disagree, and the disagreement is the result |
| 11 | Correct the progesterone wording to a retrieval outcome | leave the build-order explanation | a build-order fact is not a scientific or retrieval justification and reads as an exclusion |
| 12 | Rebuild Figures 2-6 rather than patching labels | patch the two mislabelled panels | every panel that carried a pre-correction liability-scaled effect had to be regenerated, not relabelled |
