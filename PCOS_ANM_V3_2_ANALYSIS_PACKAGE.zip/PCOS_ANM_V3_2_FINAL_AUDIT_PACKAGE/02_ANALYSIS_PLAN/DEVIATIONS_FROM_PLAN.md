# DEVIATIONS_FROM_PLAN (V3.1)

Recorded honestly; a deviation that is not recorded is indistinguishable from a silent failure.

| # | deviation | reason | consequence |
|---|---|---|---|
| D1 | The package also ships the V3 result files it compares against | the V3-vs-V3.1 side-by-side table is a required deliverable and cannot be reproduced without them | the package is larger by under 1 MB; no scientific effect |
| D2 | The hormone-path sensitivity needed the raw FSH outcome file (5.7 KB) | FSH is the one endpoint whose matrix is the V2-deposited one, so it cannot be re-derived from the V3 harmonised files alone | FSH's as-shipped arm reproduces to 1e-9 on 9 of 10 arm checks; its ANM arm does not (20 matched variants against 17 shipped), so the FSH row of the rule sensitivity is computed on a re-derived arm. Both versions are non-significant under every rule, so the conclusion is unaffected, and the discrepancy is stated rather than smoothed |
| D3 | The progesterone wording was corrected beyond the letter of the instruction | the instruction asked for the exact retrieval/QC failure; the evidence shows there was none, only a build-order artefact | the endpoint stays in the tested family and the correction is recorded as a wording repair, not an exclusion |
| D4 | `gencov` is bounded, not estimated | the required quantity is not in the deposited data | this is what the plan prescribes for that case, not a deviation from the science |
| D5 | SHBG remains unanalysed | the release publishes no tabix index | recorded as a deviation, not dropped |
| D6 | The manuscript's table numbering was rebuilt | the previous numbering mapped to quantities that changed meaning | no number was altered; only the mapping from table to quantity |
