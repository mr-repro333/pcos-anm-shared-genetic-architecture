# V3.1 REPAIR PLAN (LOCKED)

Fixed before the corrected numbers were computed. Reproduced here so that family membership,
grids and the fail-closed rule can be checked against what was actually done.

## Scope

V3.1 is a final validity repair and **not** a new version. Excluded by construction: no new
broad outcome; no search for a new positive finding; no switching of instrument, outcome
release or estimator to rescue the narrative; no alternative family if the corrected family
comes out null; no D3/D4/D5 rescue of a primary conclusion; no new MVMR outcome; no SuSiE
re-run in pursuit of a positive result.

## Priority 0 - the reciprocal scale

    PCOS arm : theta_L = theta_logOR / m(K), SE likewise   (K = 0.10 primary)
    ANM arm  : theta_perSD = theta_per_year * SD_ANM       (SD_ANM = 3.8 primary)

Frozen: nine outcomes, one primary dataset each (D1 for PCOS, A1 for ANM); K grid
{0.05, 0.06, 0.08, 0.1, 0.12, 0.15, 0.2};
SD_ANM grid {3.5, 3.8, 4.2}; rho grid
{-1, -0.75, -0.5, -0.25, 0, +0.25, +0.5, +0.75, +1}; BH within the nine tests only.

**Fail-closed rule.** If the corrected nine-test family has zero FDR-positive differences, the
manuscript reports zero. It does not report a re-defined family, does not substitute an
alternative outcome release, and does not substitute a different instrument.

## Priority 1 - signed Stouffer

    signed_Z_i = sign(beta_aligned_i) * Phi^-1(1 - P_i/2)
    Z          = sum signed_Z_i / sqrt(k + k(k-1) rho)

Existing endpoint set and rho grid only. A1 and A2 reported separately. A significant A1 does
not make the domain replicated.

## Priority 2 - MVMR covariance

Either a defensible covariance estimate or a bounded sensitivity; if neither, state that
gencov = 0 is unverified, move MVMR out of the biological headline and claim no direct effect.
**No covariance was invented**: the bound is Cauchy-Schwarz, |Cov| <= se1 se2.

## Priority 3 - auditability

Ship every input the code reads; one configurable DATA_ROOT; checksum manifest; a
clean-environment smoke test. No "fully reproducible" claim before the smoke test passes.

## Harmonisation

Determine which rule was actually used; document one exact algorithm per code path; regenerate
the audit from the implementation; quantify the consequence of the divergence.

## Hormonal accounting

Keep all six planned endpoints visible; exact retrieval/QC evidence for progesterone and SHBG;
distinguish planned, analysed, tested and non-entering.

## FSHB

No SuSiE re-run. Enforce the wording ladder. Reconcile PP4 and separate the primary-prior value
from the grid minimum.

## Claim reclassification

No label is inherited. Formal systemic differences are withdrawn if the corrected FDR does not
support them; MVMR direct effects remain unresolved; FSHB may not exceed the tier a
single-signal colocalization supports; the skeletal evidence is graded after the signed
correction.

## Freeze evidence, stated precisely

This plan fixes the nine outcomes, the primary dataset per outcome, the prevalence grid, the
SD_ANM grid, the covariance grid and the fail-closed rule. It is dated 2026-09-25 and it was written
before the corrected estimates were computed.

It is not, however, independently verifiable as a pre-registration. The file carries no hash
chain, no external anchor and no third-party timestamp, so a reader cannot verify from the
package alone that the plan preceded the corrected numbers. The manuscript therefore states the
freeze as a record of the analysis rather than as a fact that the package proves. Anchoring the
plan externally is the single change that would convert this from a stated practice into a
verifiable one.

