# READ_ME_SUPPLEMENT (V3.1)

The supplement is part of the same generation chain as the manuscript: every number in it is
read from a file in `03_RESULTS/` by `04_CODE/v31_docs.py` and `04_CODE/v31_docs_extra.py`, and
`v31_consistency.py` re-checks the quantity list independently.

* `Supplementary_Methods.md` - the algebra of the correction, the multiplier-site audit, the
  signed combination, the covariance bound, both harmonisation rules, and the smoke test.
* `Supplementary_Tables.md` - thirteen tables.
* `Supplementary_Figure_Legends.md` - six figure legends.

## Added in the provenance round

Table S14 now carries a real accession or institution-level source for all 25 datasets, re-resolved
live against the GWAS Catalog; Table S15 records the resolving identifier for every reference;
Table S16 records the search that identified the packaged MR-Egger parameterisation. The previous
round shipped S14 as a list of unidentified labels and asked the author to supply the sources.
