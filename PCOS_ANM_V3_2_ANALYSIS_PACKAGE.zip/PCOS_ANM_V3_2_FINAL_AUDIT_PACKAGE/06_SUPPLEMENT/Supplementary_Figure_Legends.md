# Supplementary Figure Legends (V3.1)

**Figure 1. PCOS and ANM instrument designs.** Independent locus counts per design at a fixed
P < 5 x 10^-8 threshold; only the LD independence window and the deposition stratum vary
between designs.

**Figure 2. The liability-scale conversion, both directions.** Panel A plots m(K) (blue), the
factor that converts a SNP-exposure coefficient to the liability scale, and 1/m(K) (red), the
factor that converts an MR ratio, over the plausible prevalence range; the horizontal line marks
a multiplier of 1, which neither conversion uses. Panel B plots the difference-test P value
against PCOS prevalence for five outcomes; no outcome crosses alpha at any point of the grid.

**Figure 3. The primary family and its covariance sensitivity.** Panel A shows the nine
difference estimates with 95% intervals at rho = 0; no outcome is marked as passing, because
none does. Panel B shows the P value against the assumed correlation rho over [-1, +1]; no curve
crosses alpha anywhere in the grid.

**Figure 4. Skeletal domain evidence with a signed combination.** Panel A shows the seven
polarity-aligned ANM skeletal endpoints in the primary instrument. Panel B contrasts the signed
Stouffer combination with an unsigned one at the same rho grid: the signed statistic is the one
the stated hypothesis requires, and it is the difference between the two that keeps the
alternative ANM instrument from reading as a domain-level replication.

**Figure 5. Multivariable instrument strength and the detection limit.** Panel A plots the
conditional F statistics for both exposures at four positions in the covariance bound; the
pre-specified gate of 10 is drawn, and the interval in which both gates pass is not the whole
band. Panel B plots the minimum detectable effect at 80% power against the ANM-sized effect for
each outcome.

**Figure 6. FSHB evidence and its tier.** Panel A shows every PCOS-ANM locus with a colocalised
verdict at the primary prior, its PP.H4 before and after LD pruning, and its evidence tier.
Panel B keeps four posterior quantities apart: the primary-prior value, the minimum over the
prior grid, the LD-pruned value, and the 0.75 tier threshold.
