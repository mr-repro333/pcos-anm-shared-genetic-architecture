# Supplementary Methods (V3.1)

## S1 The liability-scale correction, in full

Let K be the population prevalence and t = Phi^-1(1-K). Under the liability-threshold model a
per-allele log-odds coefficient b and a per-allele shift beta_L of the latent liability
satisfy b = phi(t) beta_L / (K(1-K)), hence

    beta_L = m(K) * b,        m(K) = K(1-K) / phi(Phi^-1(1-K)).                     (S1)

Equation S1 is a statement about a **SNP-exposure coefficient**. An MR estimate is a ratio,

    theta = beta_Y / beta_X.                                                        (S2)

Because beta_X,L = m(K) * beta_X,logOR, the liability-scale ratio is

    theta_L = beta_Y / beta_X,L = theta_logOR / m(K),                               (S3)
    SE(theta_L) = SE(theta_logOR) / m(K).                                           (S4)

Equivalently: rescaling an exposure coefficient by c rescales an MR ratio and its standard
error by 1/c. The previous version multiplied by m(K) in Equations S3 and S4, i.e. signed the
conversion backwards; at K = 0.10 that makes every per-SD PCOS effect, and its standard
error, too small by m(K)^-2 = 3.802428.

m(K) at the primary prevalence is 0.512825; over the grid 5-20% it runs from
0.460559 to 0.571506; 1/m
at K = 0.10 is 1.949981.

The closed form was checked against exact numerical inversion of the threshold model for
three effect sizes (log-OR 0.02, 0.10 and 0.30) at every prevalence in the grid; the maximum
relative error over the whole comparison is 1.7%.

**Unit test.** `04_CODE/test_scale_reciprocity.py` establishes the reciprocity three ways:
(i) algebraically, theta' = beta_Y/(c beta_X) = theta/c; (ii) numerically, by pushing 200
random instrument vectors through an IVW ratio under a rescaling c drawn from [0.3, 3.0] and
asserting that both the estimate and its standard error move by exactly 1/c to 1e-10; and
(iii) as a regression guard, by reproducing the frozen worked example and showing that the
previous per-SD value differs from the correct one by exactly m(K)^-2 = 3.802428.

## S2 The multiplier site audit

Every place in the project where a liability multiplier is applied was registered and
classified by *what object it is applied to*, not by file name. Four sites applied it to an
MR ratio or an MR-ratio standard error and are cancelled in V3.1:

| site | object it was applied to | verdict |
|---|---|---|
| `v3_diff.py: difference_rows()` | MR ratio (outcome per unit log-OR) | wrong direction - cancelled |
| `v3_hormonal_diff.py` | MR ratio, PCOS arm | wrong direction - cancelled |
| `v3_coloc_power.py: mde()` SE | MR-ratio standard error | wrong direction - cancelled |
| `v3_coloc_power.py: mde()` effect | MR ratio | wrong direction - cancelled |

Three sites are correct as written or descriptive only: the definition of m(K); its use in
`scaling_table()` on a SNP-exposure coefficient; and the claim matrix, where m(K) is quoted as
a description of scale rather than applied to an effect. Two sites are new in V3.1:
`mr_ratio_to_liability()` (divide) and `snp_exposure_to_liability()` (multiply, the only
admissible multiplication). The register is in `V3_1_MULTIPLIER_SITE_REGISTER.tsv`.

## S3 The signed Stouffer combination

    signed_Z_i = sign(beta_aligned_i) * Phi^-1(1 - P_i/2)                            (S5)
    Z          = sum_i signed_Z_i / sqrt(k + k(k-1) rho)                             (S6)

with rho the assumed average pairwise endpoint correlation over {0, 0.25, 0.5, 0.75, 0.9}.
The previous version built every z_i as Phi^-1(1 - p_i/2) from a two-sided p and therefore
summed k positive terms. The endpoint set and the rho grid are unchanged; only the sign is
restored. Table S1 gives both versions side by side.

## S4 The MVMR covariance bound

    gencov_l = tau * se_betaX1(l) * se_betaX2(l),      tau in [-1, +1]               (S7)

The band is not a modelling choice: |Cov| <= se1 se2 by Cauchy-Schwarz, so tau is a
dimensionless position in a permitted interval and no value of it is asserted as true. The
true sampling covariance is the correlation between the two exposure traits among overlapping
participants; the deposited summary statistics do not contain it, and the LDSC genetic
correlation (r_g = +0.329) is a different quantity, so nothing was invented. The conditional F
was recomputed at tau in {-1, -0.5, -0.33, -0.2, -0.1, 0, +0.1, +0.2, +0.33, +0.5, +1} for
every multivariable design on disk, using the `MVMR::strength_mvmr` estimator itself.

## S5 Harmonisation: both rules, exactly

**Rule A - `HARM_EAF_DISCORD`.** Used for **every headline harmonised matrix**.
1. Match the instrument variant to the outcome file by rsID first, then by chr:pos only when
   the empirical rsID agreement for that outcome file is >= 0.5, or use the file's recorded
   build when it carries no rsIDs.
2. Align alleles to a single reference pair: direct, flipped, strand-complement, or
   complement+flip.
3. For a palindromic exposure allele pair (A/T, T/A, C/G, G/C): drop when either EAF is
   missing; drop when |EAF_exposure - EAF_outcome| > 0.05; otherwise align by EAF.
4. Non-palindromic variants are never dropped for allele reasons.
5. Record per variant: match key, action, note, both allele pairs, both EAFs, raw and signed
   outcome beta, and SE.

The literal band 0.42-0.58 does not occur anywhere in this path.

**Rule B - `HARM_PALINDROME_BAND`.** Used for **the recovered-hormone path only** (LH,
estradiol, progesterone, testosterone) and for FSH only in the sense that FSH's V2 matrix was
not re-harmonised. Drop a variant when its exposure allele pair is palindromic AND the
*outcome* EAF lies in [0.42, 0.58]. The exposure EAF is not consulted, so this rule cannot
detect a discordant palindrome whose outcome EAF sits outside the band.

The audit was regenerated from the deposited per-variant records: 247 pairs,
515 drops, of which
512 palindromic-EAF-discordant. For
162 of 247 pairs the two rules
would have dropped a different count. The consequence is measured in section S6.

## S5b The FSHB PP4 reconciliation

One posterior carried five different renderings. V3.1 states, in every document, the
primary-prior value and the grid minimum separately:

| quantity | value |
|---|---|
| PP.H4 at the primary prior (p12 = 1e-5) | 0.998960 |
| minimum PP.H4 over the prior grid | 0.989699 |
| PP.H4 after LD pruning | 1.000000 (full precision 0.999999988) |
| evidence tier | A_ROBUST |

## S6 The harmonisation-rule sensitivity

Both arms of every hormonal comparison were re-derived from the deposited matrices under three
variant sets - as shipped, rule A applied to every arm, and no palindrome exclusion - and the
matched differences recomputed on the corrected scale. The endpoints surviving correction are
**Estradiol, LH** under all three rule sets. The full table is in
`V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv`; the arm-level detail, including the
reproduction of the shipped values (9 of 10 arms reproduced to 1e-9), is in
`V3_1_HORMONE_RULE_SENSITIVITY_ARMS.tsv`.

## S7 Reproduction and the smoke test

`10_INPUTS/` contains the 1220 input files the shipped code reads
(40.4 MB), with a SHA-256 manifest. `bootstrap_data_root.py --restore <dir>`
materialises a working data root from the package alone; set `PCOS_ANM_DATA_ROOT` to it and
every module runs unchanged. `v31_smoke.py` does exactly that in a temporary directory,
re-runs every analysis module against a fresh output directory, and compares each produced
table field by field with the shipped file (1e-9 tolerance) and each workbook cell by cell.
The result is in `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md`, and the "fully reproducible from the
package" statement is conditional on that table being all-PASS.


## S8 Permitted and prohibited phrasings at the FSHB locus

The colocalization analysis in the manuscript fits a single causal variant per region and fails
its own consistency diagnostics under multi-signal fine-mapping. The vocabulary that follows is
therefore fixed in advance of the claim, so that the claim cannot drift with the wording.

Permitted, because the analyses reported support them:

- a *shared FSHB-region signal* between PCOS and ANM;
- a *likely shared causal signal* under the single-signal colocalization model.

Not permitted by these analyses, and not asserted anywhere in the manuscript:

- a fine-mapped shared signal (not permitted: the fine-mapping route closed on its own
  diagnostics, minimum singular value 0.295 and a best-matching reference LD profile explaining
  at most 28% of the association profile);
- a resolved causal variant as an established fact (not permitted: no credible set was usable);
- an FSH-mediated shared causal variant (not permitted: no PCOS-FSH or ANM-FSH regional
  colocalization was performed);
- a mechanistic mediator of any kind (not permitted: the design cannot separate mediation from
  correlated pleiotropy);
- any statement of FSHB mechanism (not permitted: the evidence is regional and model-dependent).

PCOS-ANM single-signal colocalization at FSHB is not the same analysis as PCOS-FSH or ANM-FSH
locus-specific colocalization, and the two are not conflated in the text.
