# Supplementary Tables (V3.1)

## Table S1. Skeletal combination: signed (V3.1) versus the previous unsigned implementation

| instrument | endpoints | direction consistency | endpoint-FDR passes | signed Stouffer P (rho=0) | (rho=0.5) | (rho=0.9) | unsigned P (rho=0.5) | withdrawn pooled P |
|---|---|---|---|---|---|---|---|---|
| primary ANM 213-locus | 7 | 0.86 | 4 | 6.546 x 10^-10 | 0.0020 | 0.0146 | 0.0015 | 2.712 x 10^-5 |
| alternative ANM 77-locus | 7 | 0.71 | 2 | 1.373 x 10^-4 | 0.0566 | 0.1318 | 0.0072 | 0.0414 |
| primary 19-locus (1 Mb) | 7 | 0.57 | 0 | 0.6052 | 0.7960 | 0.8381 | 0.4340 | 0.5860 |
| 10 Mb 18-locus | 7 | 0.57 | 0 | 0.6276 | 0.8084 | 0.8479 | 0.4434 | 0.6423 |
| second study 25-locus | 7 | 1.00 | 0 | 0.0045 | 0.1560 | 0.2620 | 0.1560 | 0.0051 |
| union 29-locus | 7 | 0.71 | 0 | 0.1136 | 0.4288 | 0.5317 | 0.3215 | 0.1343 |
| all-ancestry 22-locus | 7 | 0.71 | 0 | 0.5550 | 0.7679 | 0.8155 | 0.4526 | 0.5274 |

## Table S2. Primary nine-test family, corrected reciprocal scale

| outcome | n SNP PCOS | n SNP ANM | PCOS per SD (corrected) | ANM per SD | difference | 95% CI (rho=0) | P (rho=0) | q (BH) | P at rho=-1 | rho* | passes BH? |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Type 2 diabetes | 17 | 176 | +0.2526 | -0.0409 | +0.2935 | +0.0217 to +0.5654 | 0.0343 | 0.1651 | 0.0718 | -0.434 | **no** |
| HbA1c | 19 | 209 | +0.0186 | -0.0073 | +0.0259 | +0.0016 to +0.0501 | 0.0367 | 0.1651 | 0.0970 | -0.233 | **no** |
| Body mass index | 17 | 176 | +0.1154 | -0.0149 | +0.1303 | -0.0582 to +0.3188 | 0.1755 | 0.3518 | 0.2211 | >+1 (unreachable) | **no** |
| Waist-to-hip ratio adjusted for BMI | 19 | 193 | +0.0278 | +0.0095 | +0.0183 | -0.0220 to +0.0586 | 0.3736 | 0.5604 | 0.5076 | +0.988 | **no** |
| Triglycerides | 18 | 196 | +0.0154 | +0.0133 | +0.0021 | -0.0570 to +0.0613 | 0.9436 | 0.9436 | 0.9580 | >+1 (unreachable) | **no** |
| HDL cholesterol | 18 | 196 | -0.0458 | -0.0013 | -0.0445 | -0.0988 to +0.0098 | 0.1080 | 0.3240 | 0.2201 | +0.456 | **no** |
| Coronary artery disease | 18 | 189 | +0.0124 | -0.0252 | +0.0376 | -0.0767 to +0.1519 | 0.5188 | 0.5836 | 0.6190 | >+1 (unreachable) | **no** |
| Heel bone mineral density | 19 | 184 | +0.0253 | +0.0476 | -0.0222 | -0.0890 to +0.0446 | 0.5140 | 0.5836 | 0.6130 | >+1 (unreachable) | **no** |
| Forearm fracture | 18 | 173 | -0.0098 | -0.0884 | +0.0786 | -0.0404 to +0.1977 | 0.1954 | 0.3518 | 0.3078 | +0.922 | **no** |

## Table S3. Side by side: the incorrect multiplication versus the reciprocal scaling

| outcome | PCOS per SD, multiplicative | PCOS per SD, reciprocal | P, multiplicative | P, reciprocal | change in P | q, multiplicative | q, reciprocal | verdict, multiplicative | verdict, reciprocal |
|---|---|---|---|---|---|---|---|---|---|
| Type 2 diabetes | +0.0664 | +0.2526 | 0.0166 | 0.0343 | +0.0177 | 0.0374 | 0.1651 | passed BH | not established |
| HbA1c | +0.0049 | +0.0186 | 0.0130 | 0.0367 | +0.0236 | 0.0374 | 0.1651 | passed BH | not established |
| Body mass index | +0.0304 | +0.1154 | 0.0988 | 0.1755 | +0.0766 | 0.1779 | 0.3518 | not established | not established |
| Waist-to-hip ratio adjusted for BMI | +0.0073 | +0.0278 | 0.8320 | 0.3736 | -0.4584 | 0.8320 | 0.5604 | not established | not established |
| Triglycerides | +0.0041 | +0.0154 | 0.5469 | 0.9436 | +0.3966 | 0.6153 | 0.9436 | not established | not established |
| HDL cholesterol | -0.0121 | -0.0458 | 0.3977 | 0.1080 | -0.2897 | 0.5113 | 0.3240 | not established | not established |
| Coronary artery disease | +0.0033 | +0.0124 | 0.2681 | 0.5188 | +0.2507 | 0.4021 | 0.5836 | not established | not established |
| Heel bone mineral density | +0.0067 | +0.0253 | 0.0055 | 0.5140 | +0.5085 | 0.0248 | 0.5836 | passed BH | not established |
| Forearm fracture | -0.0026 | -0.0098 | 5.282 x 10^-4 | 0.1954 | +0.1949 | 0.0048 | 0.3518 | passed BH | not established |

## Table S4. Minimum detectable effect and prospective power, corrected

| outcome | n SNP | corrected SE | MDE (alpha=0.05) | MDE (alpha=0.05/9) | ANM effect (magnitude) | detectable? | power |
|---|---|---|---|---|---|---|---|
| Type 2 diabetes | 17 | 0.13605 | 0.38115 | 0.49175 | 0.04089 | **no** | 0.06 |
| HbA1c | 19 | 0.01178 | 0.03301 | 0.04259 | 0.00730 | **no** | 0.09 |
| Body mass index | 17 | 0.09554 | 0.26767 | 0.34534 | 0.01488 | **no** | 0.05 |
| Waist-to-hip ratio adjusted for BMI | 19 | 0.01837 | 0.05147 | 0.06640 | 0.00953 | **no** | 0.08 |
| Triglycerides | 18 | 0.02696 | 0.07553 | 0.09744 | 0.01329 | **no** | 0.08 |
| HDL cholesterol | 18 | 0.02552 | 0.07149 | 0.09223 | 0.00130 | **no** | 0.05 |
| Coronary artery disease | 18 | 0.05424 | 0.15196 | 0.19606 | 0.02524 | **no** | 0.08 |
| Heel bone mineral density | 19 | 0.03185 | 0.08924 | 0.11514 | 0.04755 | **no** | 0.32 |
| Forearm fracture | 18 | 0.05749 | 0.16106 | 0.20780 | 0.08844 | **no** | 0.34 |

## Table S5. Skeletal evidence tiers in the primary ANM instrument (A1)

| tier | endpoint | n SNP | aligned beta | SE | P | endpoint-FDR | pass |
|---|---|---|---|---|---|---|---|
| 1. primary eBMD / primary fracture | BMD | 184 | +0.0125 | 0.0032 | 8.753 x 10^-5 | 3.064 x 10^-4 | yes |
| 1. primary eBMD / primary fracture | Fracture | 173 | +0.0233 | 0.0052 | 6.588 x 10^-6 | 4.612 x 10^-5 | yes |
| 3-4. osteoporosis and site-specific fracture | Fracture_femur_FINNGEN | 176 | +0.0117 | 0.0090 | 0.1900 | 0.2660 | no |
| 3-4. osteoporosis and site-specific fracture | Fracture_forearm_FINNGEN | 176 | +0.0170 | 0.0068 | 0.0130 | 0.0227 | yes |
| 3-4. osteoporosis and site-specific fracture | Fracture_lowerleg_FINNGEN | 176 | -0.0014 | 0.0067 | 0.8329 | 0.8329 | no |
| 3-4. osteoporosis and site-specific fracture | Fracture_lumbarspine_FINNGEN | 176 | +0.0119 | 0.0103 | 0.2445 | 0.2853 | no |
| 3-4. osteoporosis and site-specific fracture | Osteoporosis_FINNGEN | 176 | +0.0305 | 0.0096 | 0.0016 | 0.0036 | yes |

## Table S6. Hormonal endpoint accounting: six planned, five analysed

| planned endpoint | accession | N | analysed | instruments (primary / second study / ANM) | in tested family | retrieval / QC |
|---|---|---|---|---|---|---|
| FSH | GCST90483475 | 51396 | YES | 8.0/6.0/17.0 | YES | downloaded in V2; gzip/bgzf integrity verified; V2-deposited aligned matrix reused and re-run in. |
| LH | GCST90483478 | 41650 | YES | 8.0/9.0/66.0 | YES | V2 failed with WinError 10060 against the remote tabix index (recorded in the V2 fetch log); recovered in V3 by plain HTTP range reads over the harmonised release; integrity. |
| Estradiol | GCST90483481 | 92969 | YES | 7.0/9.0/60.0 | YES | regional tabix range reads; 92 of 318 instrument alleles present in the harmonised release; integrity. |
| Progesterone | GCST90483484 | 16313 | YES | 8.0/9.0/69.0 | YES - as the fifth member of the tested family | regional tabix range reads; 108 of 318 instrument alleles present in the harmonised release; integrity verified. No endpoint was withdrawn on scientific. |
| Testosterone | GCST90483486 | 235579 | YES | 7.0/9.0/59.0 | YES | regional tabix range reads; 92 of 318 instrument alleles present; integrity verified. A second release (GCST90012112) exists and was not. |
| SHBG | GCST90012107 | 189473 | NO | n/a | NO | the EBI harmonised release for this study publishes no .tbi index (HTTP 404 on the index path), so tabix random access is impossible; the whole file is 641 MB and the measured transfer rate. |

## Table S7. Matched hormonal difference tests, corrected scale

| endpoint | design | PCOS per SD (corrected) | ANM per SD | difference | P (rho=0) | q (BH within design) | P at rho=-1 | opposite direction | P at the multiplicative scale |
|---|---|---|---|---|---|---|---|---|---|
| Estradiol | primary 19-locus (1 Mb) | -0.2260 | +0.0823 | -0.3084 | 3.661 x 10^-8 | 1.831 x 10^-7 | 2.885 x 10^-5 | **yes** | 5.967 x 10^-8 |
| Estradiol | second study 25-locus | -0.1218 | +0.0823 | -0.2042 | 2.444 x 10^-5 | 1.222 x 10^-4 | 0.0018 | **yes** | 5.132 x 10^-6 |
| Estradiol | union 29-locus | -0.1191 | +0.0823 | -0.2014 | 2.753 x 10^-6 | 1.376 x 10^-5 | 6.491 x 10^-4 | **yes** | 3.180 x 10^-6 |
| FSH | primary 19-locus (1 Mb) | -0.3647 | -0.6640 | +0.2993 | 0.1303 | 0.1629 | 0.2680 | no | 1.694 x 10^-7 |
| FSH | second study 25-locus | -0.4379 | -0.6640 | +0.2261 | 0.3318 | 0.3318 | 0.4655 | no | 1.282 x 10^-6 |
| FSH | union 29-locus | -0.3823 | -0.6640 | +0.2817 | 0.1395 | 0.1395 | 0.2820 | no | 1.693 x 10^-7 |
| LH | primary 19-locus (1 Mb) | +0.1960 | -0.2965 | +0.4925 | 0.0173 | 0.0434 | 0.0478 | **yes** | 9.666 x 10^-7 |
| LH | second study 25-locus | +0.1828 | -0.2965 | +0.4794 | 0.0099 | 0.0247 | 0.0347 | **yes** | 2.572 x 10^-7 |
| LH | union 29-locus | +0.1402 | -0.2965 | +0.4367 | 0.0057 | 0.0142 | 0.0274 | **yes** | 6.625 x 10^-8 |
| Progesterone | primary 19-locus (1 Mb) | -0.1733 | +0.0216 | -0.1949 | 0.0442 | 0.0736 | 0.1197 | **yes** | 0.1119 |
| Progesterone | second study 25-locus | -0.1246 | +0.0216 | -0.1462 | 0.1167 | 0.1459 | 0.2283 | **yes** | 0.1921 |
| Progesterone | union 29-locus | -0.1086 | +0.0216 | -0.1302 | 0.1166 | 0.1395 | 0.2375 | **yes** | 0.2117 |
| Testosterone | primary 19-locus (1 Mb) | +0.1300 | +0.0557 | +0.0743 | 0.2640 | 0.2640 | 0.3738 | no | 0.4094 |
| Testosterone | second study 25-locus | +0.1283 | +0.0557 | +0.0726 | 0.1058 | 0.1459 | 0.2282 | no | 0.3332 |
| Testosterone | union 29-locus | +0.1276 | +0.0557 | +0.0719 | 0.0706 | 0.1176 | 0.1865 | no | 0.3145 |

## Table S8. MVMR conditional F across the covariance band

| tau = Cov/(se1 se2) | min condF PCOS | max condF PCOS | min condF ANM | max condF ANM | models passing both gates |
|---|---|---|---|---|---|
| +1.00 | 0.572 | 19084.129 | 2.162 | 1619.322 | 18 / 46 |
| +0.50 | 0.539 | 27.322 | 1.762 | 52.290 | 18 / 46 |
| +0.33 | 0.528 | 20.518 | 1.657 | 39.470 | 18 / 46 |
| +0.20 | 0.520 | 17.235 | 1.586 | 33.303 | 18 / 46 |
| +0.10 | 0.514 | 15.347 | 1.535 | 29.731 | 18 / 46 |
| +0.00 | 0.509 | 13.831 | 1.487 | 26.850 | 9 / 46 |
| -0.10 | 0.503 | 12.588 | 1.442 | 24.479 | 9 / 46 |
| -0.20 | 0.497 | 11.550 | 1.399 | 22.492 | 9 / 46 |
| -0.33 | 0.491 | 10.432 | 1.348 | 20.346 | 9 / 46 |
| -0.50 | 0.482 | 9.260 | 1.286 | 18.088 | 0 / 46 |
| -1.00 | 0.458 | 6.959 | 1.133 | 13.638 | 0 / 46 |

## Table S9. PCOS-ANM colocalization at the loci with a COLOCALISED verdict

| PCOS vs ANM locus | primary-prior PP.H4 | PP.H4 after LD pruning | underpowered? | tier |
|---|---|---|---|---|
| FSHB | 0.998960 | 1.000000 | no | A_ROBUST |
| DENND1A | 0.987840 | 0.633739 | no | B_MODERATE |
| IRF1 | 0.924456 | 0.961067 | yes | B_MODERATE |

FSHB: primary-prior PP.H4 = 0.998960; minimum over the prior grid = 0.989699; after LD pruning = 1.000000. The grid minimum and the LD-pruned value are reported separately because they are different quantities.

## Table S10. Prevalence and SD sensitivity of the corrected family

At every K in {0.05, 0.06, 0.08, 0.1, 0.12, 0.15, 0.2}
the number of FDR-positive differences is 0; at every SD_ANM in
{3.5, 3.8, 4.2} it
is 0. Sources: `V3_1_PREVALENCE_SENSITIVITY.tsv`,
`V3_1_SD_ANM_SENSITIVITY.tsv`.

## Table S11. Instrument provenance summary

| design | n variants | min F | median F | any F < 10 | window | role |
|---|---|---|---|---|---|---|
| D1 | 19 | 29.95 | 37.76 | no | 1 Mb | primary |
| D2 | 18 | 29.95 | 38.52 | no | 10 Mb | V1-comparable sensitivity |
| D3 | 25 | 29.88 | 41.39 | no | 1 Mb | alternative-study sensitivity |
| D4 | 29 | 29.88 | 41.39 | no | 1 Mb | union, power sensitivity only |
| D5 | 22 | 30.07 | 42.63 | no | 1 Mb | ancestry sensitivity |
| D6 | 20 | 30.07 | 42.63 | no | 10 Mb | excluded from inference |
| A1 | 213 | 29.72 | 54.58 | no | 10 Mb | primary ANM |
| A2 | 77 | 27.54 | 50.52 | no | 10 Mb | alternative ANM |

Full per-variant provenance is in `V3_1_INSTRUMENT_PROVENANCE.tsv`.

Instrument codes used in the result files and provenance tables: A1 = primary ANM 213-locus; A2 = alternative ANM 77-locus; D1 = primary 19-locus (1 Mb); D2 = 10 Mb 18-locus; D3 = second study 25-locus; D4 = union 29-locus; D5 = all-ancestry 22-locus; D6 = all-ancestry 20-locus (excluded).

## Table S12. Input inventory

1220 files, 40.4 MB, each with a SHA-256 in `V3_1_INPUT_MANIFEST.tsv`.
Files that are deliberately not shipped (the raw GWAS deposits) are listed with their
accessions and the reason in `V3_1_NOT_SHIPPED_AND_WHY.tsv`.

## Table S13. Claim-evidence matrix, counted once

14 claims, 8 graded ROBUST, 9 safe for the abstract.
Source: `V3_1_CLAIM_EVIDENCE_MATRIX.xlsx`.

## Table S14. Outcome and exposure dataset registry

Every dataset the analysis uses, with the accession or institution-level source
and the study that resolved it. Accessions were resolved live; see
`07_PROVENANCE/ACCESSION_RESOLUTION_AUDIT.md`.

| dataset label | trait | role | accession / source | source study | basis |
|---|---|---|---|---|---|
| T2D | Type 2 diabetes | primary family | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| HbA1c_MAGIC | HbA1c | primary family | GCST90002244 | Chen et al., 2021 (PMID 34059833) | resolved live; catalog trait Glycated hemoglobin levels, 146806 European individuals, linked to PMID 34059833 |
| BMI_FINNGEN | Body mass index | primary family | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| WHRadjBMI_Pulit_dense_combined | Waist-to-hip ratio adjusted for BMI | primary family | GCST008999 | Pulit et al., 2019 (PMID 30239722) | resolved live; catalog trait Waist-to-hip ratio adjusted for BMI, 694649 European individuals, linked to PMID 30239722 |
| WHRadjBMI_Pulit_dense_females | Waist-to-hip ratio adjusted for BMI, female-only | sensitivity | GCST008994 | Pulit et al., 2019 (PMID 30239722) | resolved live; catalog trait Waist-to-hip ratio adjusted for BMI, 379501 European female individuals |
| TG | Triglycerides (log) | primary family | GCST90239664 | Graham et al., 2021 (PMID 34887591) | resolved live; catalog trait Triglyceride levels |
| HDL | HDL cholesterol | primary family | GCST90239652 | Graham et al., 2021 (PMID 34887591) | resolved live; catalog trait High density lipoprotein cholesterol levels |
| CAD | Coronary artery disease | primary family | GCST90132314 | Aragam et al., 2022 (PMID 36474045) | resolved live; catalog trait Coronary artery disease, 181522 cases |
| BMD | Heel bone mineral density | primary family | GCST90029004 | no primary study publication; the catalog links only the mixed-model method paper (PMID 29892013) | resolved live as Heel bone mineral density, 583314 European individuals and 12006792 variants, UK recruitment on an Affymetrix array; the distributed file carries a per-variant n of 445921. The canonical heel-eBMD atlas (Morris et al., 2019, PMID 30598549) is a separate record, GCST006979 (426824 British individuals), and was not used here |
| Fracture | Forearm fracture | primary family | GCST90281273 | Nethander et al., 2023 (PMID 37919453) | resolved live; catalog trait Fracture of forearm, 50471 European cases |
| T2D_FINNGEN | Type 2 diabetes, sensitivity release | sensitivity | FinnGen, release not distinguished in the deposited record | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| HbA1c | HbA1c, alternate release | sensitivity | GCST90025974 | Barton et al., 2021 (PMID 34226706) | resolved live; catalog trait Hemoglobin A1c levels, 437749 European individuals; a UK Biobank whole-exome release whose sparser variant coverage is why it is a sensitivity rather than a primary arm |
| HbA1c_PanUKB | HbA1c, Pan-UKB release | sensitivity | GCST90691576 | Karczewski et al., 2025 (PMID 40968291) | resolved live; catalog trait Glycated hemoglobin HbA1c levels, 400825 European individuals |
| BMI_combined | Body mass index, combined-sex release | sensitivity | GIANT + UKB 2018 | Yengo et al., 2018 (PMID 30124842) | release named in the deposited record |
| BMI_females | Body mass index, female-only release | sensitivity | GIANT + UKB 2018 | Yengo et al., 2018 (PMID 30124842) | release named in the deposited record |
| WHRadjBMI_yengo_combined | WHR adjusted for BMI, alternate release | sensitivity | GIANT adjusted waist-to-hip ratio release labelled for a Yengo-led analysis | not resolved to a publication in the deposited record | dataset label names a lead analyst only |
| WHRadjBMI_yengo_females | WHR adjusted for BMI, female-only alternate | sensitivity | GIANT adjusted waist-to-hip ratio release labelled for a Yengo-led analysis | not resolved to a publication in the deposited record | dataset label names a lead analyst only |
| WHRadjBMI_combined | Waist-to-hip ratio, combined | sensitivity | GCST008996 | GIANT waist-to-hip ratio release | resolved live; catalog trait Waist-hip ratio, 697734 individuals |
| WHRadjBMI_women | Waist-to-hip ratio, women | sensitivity | GCST008997 | GIANT waist-to-hip ratio release | resolved live; catalog trait Waist-hip ratio, 381152 female individuals |
| CAD_FINNGEN | Coronary artery disease, FinnGen release | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Osteoporosis_FINNGEN | Osteoporosis, FinnGen release | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Fracture_forearm_FINNGEN | Forearm fracture, FinnGen release | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Fracture_femur_FINNGEN | Femur fracture, FinnGen release | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Fracture_lowerleg_FINNGEN | Lower-leg fracture, FinnGen release | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Fracture_lumbarspine_FINNGEN | Lumbar-spine fracture, FinnGen release | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |

Two outcome releases carry no primary study publication. The GWAS Catalog record
for `GCST90029004` (heel bone mineral density, 583,314 European-ancestry
individuals, 12,006,792 variants, per-variant n 445,921 in the distributed
file) links only the mixed-model method paper (PMID 29892013), and the record
for `GCST90029037` (age at onset of menopause, 156,364 individuals) links the
same paper. The canonical heel-eBMD atlas (Morris et al., 2019; PMID 30598549)
is a separate UK Biobank record held under `GCST006979` (426,824 British-ancestry
individuals) and was not used here. The release identity is fixed by byte-level
retrieval: 278,979,845 bytes, FTP md5 `ed6e7f87af4009ba4bd35bb40f00b8c3`. The
unresolved item is the study of origin, not the data. This is stated in the
manuscript as well.

## Table S15. Reference audit

Every reference in the manuscript, with the live identifier that resolved it.

| key | in text | reference | resolving identifier |
|---|---|---|---|
| pmos2026 | Teede et al., 2026 | Teede HJ, Khomami MB, Morman R, Laven JSE, Joham AE, Costello MF, et al (2026) Polyendocrine metabolic ovarian syndrome, the new name for polycystic ovary syndrome: a multistep global consensus process. Lancet 407:2329-2339 | PMID 42119588 |
| g1k2015 | 1000 Genomes Project Consortium et al., 2015 | 1000 Genomes Project Consortium, Auton A, Brooks LD, Durbin RM, Garrison EP, Kang HM, et al (2015) A global reference for human genetic variation. Nature 526:68-74 | PMID 26432245 |
| bh1995 | Benjamini & Hochberg, 1995 | Benjamini Y, Hochberg Y (1995) Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc Series B Stat Methodol 57:289-300 | CrossRef 10.1111/j.2517-6161.1995.tb02031.x |
| bowden2015 | Bowden et al., 2015 | Bowden J, Davey Smith G, Burgess S (2015) Mendelian randomization with invalid instruments: effect estimation and bias detection through Egger regression. Int J Epidemiol 44:512-525 | PMID 26050253 |
| bowden2016 | Bowden et al., 2016 | Bowden J, Davey Smith G, Haycock PC, Burgess S (2016) Consistent estimation in Mendelian randomization with some invalid instruments using a weighted median estimator. Genet Epidemiol 40:304-314 | PMID 27061298 |
| bowden2017 | Bowden et al., 2017 | Bowden J, Del Greco M F, Minelli C, Davey Smith G, Sheehan N, Thompson J (2017) A framework for the investigation of pleiotropy in two-sample summary data Mendelian randomization. Stat Med 36:1783-1802 | PMID 28114746 |
| ldsc2015 | Bulik-Sullivan et al., 2015 | Bulik-Sullivan BK, Loh PR, Finucane HK, Ripke S, Yang J, Patterson N, et al (2015) LD Score regression distinguishes confounding from polygenicity in genome-wide association studies. Nat Genet 47:291-295 | PMID 25642630 |
| burgess2013 | Burgess et al., 2013 | Burgess S, Butterworth A, Thompson SG (2013) Mendelian randomization analysis with multiple genetic variants using summarized data. Genet Epidemiol 37:658-665 | CrossRef 10.1002/gepi.21758 |
| burgess2016 | Burgess et al., 2016 | Burgess S, Davies NM, Thompson SG (2016) Bias due to participant overlap in two-sample Mendelian randomization. Genet Epidemiol 40:597-608 | PMID 27625185 |
| falconer1965 | Falconer, 1965 | Falconer DS (1965) The inheritance of liability to certain diseases, estimated from the incidence among relatives. Ann Hum Genet 29:51-76 | CrossRef 10.1111/j.1469-1809.1965.tb00500.x |
| coloc2014 | Giambartolomei et al., 2014 | Giambartolomei C, Vukcevic D, Schadt EE, Franke L, Hingorani AD, Wallace C, et al (2014) Bayesian test for colocalisation between pairs of genetic association studies using summary statistics. PLoS Genet 10:e1004383 | PMID 24830394 |
| hartwig2017 | Hartwig et al., 2017 | Hartwig FP, Davey Smith G, Bowden J (2017) Robust inference in summary data Mendelian randomization via the zero modal pleiotropy assumption. Int J Epidemiol 46:1985-1998 | PMID 29040600 |
| finn2023 | Kurki et al., 2023 | Kurki MI, Karjalainen J, Palta P, Sipilä TP, Kristiansson K, Donner KM, et al (2023) FinnGen provides genetic insights from a well-phenotyped isolated population. Nature 613:508-518 | PMID 36653562 |
| lee2011 | Lee et al., 2011 | Lee SH, Wray NR, Goddard ME, Visscher PM (2011) Estimating missing heritability for disease from genome-wide association studies. Am J Hum Genet 88:294-305 | PMID 21376301 |
| lo2023 | Lo et al., 2023 | Lo ACQ, Lo CCW, Oliver-Williams C (2023) Cardiovascular disease risk in women with hyperandrogenism, oligomenorrhea/menstrual irregularity or polycystic ovaries. Eur Heart J Open 3:oead061 | PMID 37404840 |
| moolhuijsen2026 | Moolhuijsen et al., 2026 | Moolhuijsen LME, Zhu J, Mullin BH, Pujol-Gualdo N, Actkins KV, Mack JA, et al (2026) Genomic analyses implicate hormonal and metabolic dysregulation in polycystic ovary syndrome. Nat Genet 58:1040-1050 | PMID 42026183 |
| neven2026 | Neven et al., 2026 | Neven ACH, Forslund M, Ranasinha S, Sethi P, Dhungana RR, Mousa A, et al (2026) Prevalence of polycystic ovary syndrome: a global and regional systematic review and meta-analysis. Hum Reprod Update 32:277-312 | PMID 41528735 |
| pulit2019 | Pulit et al., 2019 | Pulit SL, Stoneman C, Morris AP, Wood AR, Glastonbury CA, Tyrrell J, et al (2019) Meta-analysis of genome-wide association studies for body fat distribution in 694 649 individuals of European ancestry. Hum Mol Genet 28:166-174 | PMID 30239722 |
| rotterdam2004 | Rotterdam ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group, 2004 | Rotterdam ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group (2004) Revised 2003 consensus on diagnostic criteria and long-term health risks related to polycystic ovary syndrome. Fertil Steril 81:19-25 | PMID 14711538 |
| ruth2020 | Ruth et al., 2020 | Ruth KS, Day FR, Tyrrell J, Thompson DJ, Wood AR, Mahajan A, et al (2020) Using human genetics to understand the disease impacts of testosterone in men and women. Nat Med 26:252-258 | PMID 32042192 |
| ruth2021 | Ruth et al., 2021 | Ruth KS, Day FR, Hussain J, Martínez-Marchal A, Aiken CE, Azad A, et al (2021) Genetic insights into biological mechanisms governing human ovarian ageing. Nature 596:393-397 | PMID 34349265 |
| sanderson2019 | Sanderson et al., 2019 | Sanderson E, Davey Smith G, Windmeijer F, Bowden J (2019) An examination of multivariable Mendelian randomization in the single-sample and two-sample summary data settings. Int J Epidemiol 48:713-727 | PMID 30535378 |
| strobemr2021 | Skrivankova et al., 2021 | Skrivankova VW, Richmond RC, Woolf BAR, Yarmolinsky J, Davies NM, Swanson SA, et al (2021) Strengthening the Reporting of Observational Studies in Epidemiology Using Mendelian Randomization: the STROBE-MR statement. JAMA 326:1614-1621 | PMID 34698778 |
| stouffer1949 | Stouffer et al., 1949 | Stouffer SA, Suchman EA, DeVinney LC, Star SA, Williams RM Jr (1949) The American Soldier: Adjustment During Army Life. Princeton University Press, Princeton | CrossRef 10.2307/2087216 (volume record) |
| venkatesh2025 | Venkatesh et al., 2025 | Venkatesh SS, Wittemans LBL, Palmer DS, Baya NA, Ferreira T, Hill B, et al (2025) Genome-wide analyses identify 25 infertility loci and relationships with reproductive traits across the allele frequency spectrum. Nat Genet 57:1107-1118 | PMID 40229599 |
| susie2020 | Wang et al., 2020 | Wang G, Sarkar A, Carbonetto P, Stephens M (2020) A simple new approach to variable selection in regression, with application to genetic fine mapping. J R Stat Soc Series B Stat Methodol 82:1273-1300 | PMID 37220626 |
| yavorska2017 | Yavorska & Burgess, 2017 | Yavorska OO, Burgess S (2017) MendelianRandomization: an R package for performing Mendelian randomization analyses using summarized data. Int J Epidemiol 46:1734-1739 | PMID 28398548 |
| zhao2025 | Zhao et al., 2025 | Zhao H, Xu Y, Xue B, Zhao S, Zhang M, Wu XK, et al (2025) Multi-ancestry genome-wide association analyses of polycystic ovary syndrome. Nat Genet 57:2669-2681 | PMID 41188533 |
| bowden2016i2 | Bowden et al., 2016b | Bowden J, Del Greco M F, Minelli C, Davey Smith G, Sheehan NA, Thompson JR (2016) Assessing the suitability of summary data for two-sample Mendelian randomization analyses using MR-Egger regression: the role of the I2 statistic. Int J Epidemiol 45:1961-1974 | PMID 27616674 |
| barton2021 | Barton et al., 2021 | Barton AR, Sherman MA, Mukamel RE, Loh PR (2021) Whole-exome imputation within UK Biobank powers rare coding variant association and fine-mapping analyses. Nat Genet 53:1260-1269 | PMID 34226706 |
| chen2021 | Chen et al., 2021 | Chen J, Spracklen CN, Marenne G, Varshney A, Corbin LJ, Luan J, et al (2021) The trans-ancestral genomic architecture of glycemic traits. Nat Genet 53:840-860 | PMID 34059833 |
| graham2021 | Graham et al., 2021 | Graham SE, Clarke SL, Wu KH, Kanoni S, Zajac GJM, Ramdas S, et al (2021) The power of genetic diversity in genome-wide association studies of lipids. Nature 600:675-679 | PMID 34887591 |
| aragam2022 | Aragam et al., 2022 | Aragam KG, Jiang T, Goel A, Kanoni S, Wolford BN, Atri DS, et al (2022) Discovery and systematic characterization of risk variants and genes for coronary artery disease in over a million participants. Nat Genet 54:1803-1815 | PMID 36474045 |
| morris2019 | Morris et al., 2019 | Morris JA, Kemp JP, Youlten SE, Laurent L, Logan JG, Chai RC, et al (2019) An atlas of genetic influences on osteoporosis in humans and mice. Nat Genet 51:258-266 | PMID 30598549 |
| nethander2023 | Nethander et al., 2023 | Nethander M, Movérare-Skrtic S, Kämpe A, Coward E, Reimann E, Grahnemo L, et al (2023) An atlas of genetic determinants of forearm fracture. Nat Genet 55:1820-1830 | PMID 37919453 |
| karczewski2025 | Karczewski et al., 2025 | Karczewski KJ, Gupta R, Kanai M, Lu W, Tsuo K, Wang Y, et al (2025) Pan-UK Biobank genome-wide association analyses enhance discovery and resolution of ancestry-enriched effects. Nat Genet 57:2408-2417 | PMID 40968291 |
| loh2018 | Loh et al., 2018 | Loh PR, Kichaev G, Gazal S, Schoech AP, Price AL (2018) Mixed-model association for biobank-scale datasets. Nat Genet 50:906-908 | PMID 29892013 |
| yengo2018 | Yengo et al., 2018 | Yengo L, Sidorenko J, Kemper KE, Zheng Z, Wood AR, Weedon MN, et al (2018) Meta-analysis of genome-wide association studies for height and body mass index in ~700 000 individuals of European ancestry. Hum Mol Genet 27:3641-3649 | PMID 30124842 |

## Table S16. MR-Egger parameterisation identification

20 candidate parameterisations were scored by how many of the 244 pairs each reproduces to within 1e-8. The packaged values are reproduced by the estimator that recodes both effects so that the SNP-exposure association is positive; that recoding is a stated assumption of the MR-Egger estimator.

| parameterisation | pairs reproduced | of | percent |
|---|---|---|---|
| WLS(by~bx, 1/seY2), outcome and exposure both recoded positive | 244 | 244 | 100.0 |
| WLS(|by|~|bx|, 1/seY2) | 18 | 244 | 7.4 |
| WLS(by~bx, 1/seY2)  [unoriented] | 9 | 244 | 3.7 |
| WLS(by~bx, unweighted)  [unoriented] | 7 | 244 | 2.9 |
| WLS(by~bx, 1/seY2) through origin  [unoriented] | 7 | 244 | 2.9 |
| IVW of the ratio, delta-method weights | 7 | 244 | 2.9 |
| WLS(by~bx, bx2/seY2)  [unoriented] | 7 | 244 | 2.9 |
| WLS(by~bx, 1/(seY2/bx2))  [unoriented] | 7 | 244 | 2.9 |
| WLS(by~bx, 1/(seY2+bx2 seX2))  [unoriented] | 7 | 244 | 2.9 |
| WLS(bx~by, 1/seX2)  [reversed] | 7 | 244 | 2.9 |
| WLS(bx~by, 1/seY2)  [reversed] | 7 | 244 | 2.9 |
| WLS(by~bx, 1/seX2)  [unoriented] | 7 | 244 | 2.9 |
| WLS(by~bx, unweighted) through origin  [unoriented] | 7 | 244 | 2.9 |
| WLS(by~bx, bx2)  [unoriented] | 7 | 244 | 2.9 |
| median of the ratio | 7 | 244 | 2.9 |
| WLS(by~|bx|, 1/seY2) | 1 | 244 | 0.4 |
| WLS(|by|~bx, 1/seY2) | 1 | 244 | 0.4 |
| WLS(by/bx~bx, 1/seY2) | 0 | 244 | 0.0 |
| WLS(by/bx~bx, bx2/seY2) | 0 | 244 | 0.0 |
| WLS(by/bx~|bx|, bx2/seY2) | 0 | 244 | 0.0 |

Source: `07_PROVENANCE/V3_1_EGGER_PARAMETER_IDENTIFICATION.tsv`. The identification is also recorded in `08_QC/MR_EGGER_ENGINE_IDENTIFICATION.md`.
