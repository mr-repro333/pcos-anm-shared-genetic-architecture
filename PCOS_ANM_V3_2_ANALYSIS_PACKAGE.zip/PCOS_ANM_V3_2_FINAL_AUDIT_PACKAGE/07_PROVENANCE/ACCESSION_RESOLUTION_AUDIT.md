# ACCESSION_RESOLUTION_AUDIT (V3.1, rebuilt)

Two independent resolutions were run on 2026-09-25.

**(a) Index lookup.** `https://www.ebi.ac.uk/gwas/rest/api/studies/<accession>` for every
accession the analysis uses, plus the publication index
(`.../studies/search/findByPublicationIdPubmedId`).

**(b) Payload lookup.** An HTTP range request against the GWAS Catalog FTP path, which encodes
the accession range and therefore proves existence independently of the index.

| accession | role | N recorded in the package | resolution |
|---|---|---|---|
| GCST90570579 | PCOS, primary European stratum | 420,703 | HTTP 404 - not resolvable in the GWAS Catalog REST API |
| GCST90570580 | PCOS, all-ancestry stratum | 456,570 | HTTP 404 - not resolvable in the GWAS Catalog REST API |
| GCST90483500 | PCOS, alternative European study | 14,467 / 430,267 | HTTP 200 - resolved by Venkatesh et al. 2025 (PMID 40229599) |
| GCST90483475 | FSH, European females | 51,396 | HTTP 200 - resolved by Venkatesh et al. 2025 (PMID 40229599) |
| GCST90483478 | LH, European females | 41,650 | HTTP 200 - resolved by Venkatesh et al. 2025 (PMID 40229599) |
| GCST90483481 | Estradiol, European females | 92,969 | HTTP 200 - resolved by Venkatesh et al. 2025 (PMID 40229599) |
| GCST90483484 | Progesterone, European females | 16,313 | HTTP 200 - resolved by Venkatesh et al. 2025 (PMID 40229599) |
| GCST90483486 | Testosterone, European females | 235,579 | HTTP 200 - resolved by Venkatesh et al. 2025 (PMID 40229599) |
| GCST90012107 | SHBG, European women (not retrieved) | 189,473 | HTTP 200 - resolved by Ruth et al. 2020 (PMID 32042192) |
| GCST90012112 | Testosterone, European women (not used) | 230,454 | HTTP 200 - resolved by Ruth et al. 2020 (PMID 32042192) |
| GCST90029037 | ANM, alternative release | not recorded in the package | HTTP 200 - resolved; publication link is to the BOLT-LMM method paper (PMID 29892013) |
| GCST90320256 | ANM, primary release (Ruth 2021) | not recorded in the package | HTTP 200 - resolved by Ruth et al. 2021 (PMID 34349265) |

## Outcome layer: what publication does the catalog link to each accession?

The same two resolutions were run for every outcome accession, and the publication the catalog
links to it was compared with what the manuscript says. This is a separate axis from sample
size: an accession can resolve perfectly and still be attributed to the wrong paper.

| accession | role | catalog trait | recorded N | catalog-linked publication | manuscript status |
|---|---|---|---|---|---|
| `GCST90002244` | HbA1c, primary | Glycated hemoglobin levels | 146,806 European | Chen J, Nat Genet, PMID 34059833 | confirmed |
| `GCST90025974` | HbA1c, sensitivity | Hemoglobin A1c levels | 437,749 European | Barton AR, Nat Genet, PMID 34226706 | confirmed |
| `GCST90691576` | HbA1c, sensitivity (Pan-UKB) | Glycated hemoglobin HbA1c levels | 400,825 European | Karczewski KJ, Nat Genet, PMID 40968291 | confirmed |
| `GCST008999` | WHRadjBMI, primary | Waist-to-hip ratio adjusted for BMI | 694,649 European | Pulit SL, Hum Mol Genet, PMID 30239722 | confirmed |
| `GCST008994` | WHRadjBMI, sensitivity | Waist-to-hip ratio adjusted for BMI | 379,501 European female | Pulit SL, Hum Mol Genet, PMID 30239722 | confirmed |
| `GCST90239664` | Triglycerides, primary | Triglyceride levels | 1,320,016 European | Graham SE, Nature, PMID 34887591 | confirmed |
| `GCST90239652` | HDL cholesterol, primary | High density lipoprotein cholesterol levels | 1,320,016 European | Graham SE, Nature, PMID 34887591 | confirmed |
| `GCST90132314` | Coronary artery disease, primary | Coronary artery disease | 181,522 European cases | Aragam KG, Nat Genet, PMID 36474045 | confirmed |
| `GCST90029004` | Heel bone mineral density, primary | Heel bone mineral density | 583,314 European (per-variant n 445,921) | Loh PR, Nat Genet, PMID 29892013 - the mixed-model METHOD paper; no primary study publication is registered | no study of origin; release identity fixed by payload |
| `GCST90281273` | Forearm fracture, primary | Fracture of forearm | 50,471 European cases, 969,623 controls | Nethander M, Nat Genet, PMID 37919453 | confirmed |
| `GCST90029037` | ANM, alternative | Menopause (age at onset) | 156,364 European | Loh PR, Nat Genet, PMID 29892013 - the mixed-model METHOD paper; no primary study publication is registered | no study of origin; release identity fixed by payload |
| `GCST006979` | heel eBMD atlas, NOT USED | Heel bone mineral density | 426,824 British | Morris JA, Nat Genet, PMID 30598549 | the record that had been conflated with GCST90029004 |

Three entries returned a method or infrastructure paper rather than a study of origin. The
distinction matters because a reader treating the linked paper as the data source would be
misled: the heel-eBMD release `GCST90029004` and the alternative ANM release `GCST90029037`
both link only the mixed-model method paper, and the manuscript now says so. The analysis uses
`GCST90029004` as deposited - no accession was swapped - and the release is fixed by byte count
and md5, so what is unresolved is the study of origin, not the identity of the data.

The audit also caught one conflation that had reached the manuscript. The heel-eBMD release was
attributed to Morris et al. 2019, but that study's heel-eBMD record is `GCST006979` (426,824
British-ancestry individuals, PMID 30598549), a different accession; the two had been merged.
The attribution has been removed from the manuscript, the registry and the limitations, and the
corrected record names `GCST006979` as a separate release that was not used. The audit is
shipped as `07_PROVENANCE/V3_1_ACCESSION_PUBLICATION_AUDIT.tsv`.

## Result

Nine of the eleven exposure and hormone records resolved through the index with a sample size
identical to the one the package records. `GCST90320256` resolved as the primary ANM release
with n = 201,323, the figure the manuscript states, so the ANM data identity is exact even
though the package recorded the source as `reprogen.org` rather than by accession; and
`GCST90029037` resolved with n = 156,364, which the package had left blank. Both are now recorded
by accession.

**The two primary PCOS accessions do not appear in the index but both exist on the FTP:**

| accession | FTP path | range request | payload |
|---|---|---|---|
| GCST90570579 | `.../GCST90570001-GCST90571000/GCST90570579/GCST90570579.tsv.gz` | HTTP 206, `Content-Range: bytes 0-511/175116342` | gzip, 175,116,342 bytes |
| GCST90570580 | `.../GCST90570001-GCST90571000/GCST90570580/GCST90570580.tsv.gz` | HTTP 206, `Content-Range: bytes 0-511/215507686` | gzip, 215,507,686 bytes |

The harmonised companion of `GCST90570579` also resolved (HTTP 206,
`Content-Range: bytes 0-511/235581242`). Both byte counts are identical to the counts the
deposited retrieval record gives, so the files the analysis used are the files at those paths.
The index returns 404 because it does not yet cover this accession range, and the catalog links
no publication to either accession; the attribution to the 16-to-29-locus analysis of 544,513
individuals therefore rests on the accessions appearing in that paper's own text, which is how
the deposited record made it.

The manuscript states this in section 2.2 and repeats it in the limitations. No accession string
was changed and none was substituted.
