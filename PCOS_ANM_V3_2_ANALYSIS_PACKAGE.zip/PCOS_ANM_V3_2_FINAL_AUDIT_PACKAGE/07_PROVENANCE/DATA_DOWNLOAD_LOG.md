# DATA_DOWNLOAD_LOG.md (V3.1)

| dataset | channel | outcome |
|---|---|---|
| PCOS GCST90570579 / GCST90570580 | GWAS Catalog harmonised release | success; instruments built at P < 5e-8 |
| PCOS GCST90483500 | GWAS Catalog harmonised release | success |
| ANM Ruth 2021 | reprogen.org | success |
| ANM GCST90029037 | GWAS Catalog harmonised release | success |
| FSH GCST90483475 | GWAS Catalog, regional tabix range reads | success |
| LH GCST90483478 | GWAS Catalog, plain HTTP range reads | success in V3 after a V2 tabix-index failure (WinError 10060) |
| Estradiol GCST90483481 | regional tabix range reads | success |
| Progesterone GCST90483484 | regional tabix range reads | success (after the first V3 hormonal build had closed) |
| Testosterone GCST90483486 | regional tabix range reads | success |
| SHBG GCST90012107 | GWAS Catalog harmonised release | **FAILED** - no `.tbi` index published (HTTP 404); whole file 641 MB at a measured ~5 KB/s |
| 1000 Genomes Phase 3 EUR | plink reference panel | success (used for clumping and reference LD) |
| LDSC (europepmc / GitHub release) | used for r_g | success; see LDSC_RG_PCOS_ANM.log |

Outcome GWAS (type 2 diabetes, HbA1c, body mass index, waist-to-hip ratio adjusted for BMI,
triglycerides, HDL cholesterol, coronary artery disease, heel bone mineral density, fracture)
are listed by accession in `GWAS_SOURCES.md` and in `03_RESULTS/V3_1_MASTER_RESULTS.xlsx`,
sheet `DESIGN_MAP` and the outcome columns.
