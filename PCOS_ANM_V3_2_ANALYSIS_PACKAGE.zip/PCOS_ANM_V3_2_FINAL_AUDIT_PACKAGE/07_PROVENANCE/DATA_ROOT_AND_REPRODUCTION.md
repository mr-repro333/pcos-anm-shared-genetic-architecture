# DATA_ROOT and reproduction

## The one knob

Every path in the shipped code is resolved from the environment variable
`PCOS_ANM_DATA_ROOT`, whose default is the original project root. Inside the package the
inputs live under `10_INPUTS/` in the same relative layout the code expects.

    python 04_CODE/bootstrap_data_root.py --restore <dir>
    set PCOS_ANM_DATA_ROOT=<dir>
    python 04_CODE/v31_diff.py

`bootstrap_data_root.py --check <dir>` verifies the restored tree against
`03_RESULTS/V3_1_INPUT_MANIFEST.tsv` (path, byte size and SHA-256 per file).

Outputs are written next to the code, or to `PCOS_ANM_V31_OUT` if that variable is set.

## What is shipped

1220 files, 40.4 MB. Categories: instrument tables for every design;
the harmonised SNP matrices and their per-variant audit records; the MR master input; the
multivariable input matrices and the MVMR tool source; the colocalization result tables and
the regional extracts they were computed from; the FSHB fine-mapping inputs and LD matrices;
the LDSC logs; the V3 result files that V3.1 compares against.

## What is not shipped, and why that is safe

| item | size | why not |
|---|---|---|
| Raw PCOS GCST90570579 / GCST90570580 / GCST90483500 full summary statistics | hundreds of MB | the harmonised instrument+outcome matrices derived from them are included, so every headline estimate is re-derivable without them |
| Raw ANM Ruth 2021 and GCST90029037 full summary statistics | hundreds of MB | as above - the harmonised matrices are included |
| Raw LH deposit GCST90483478 (V3_2026/01_RAW_NEW/GCST90483478.h.tsv.gz) | 108 MB | the harmonised regional hormone matrix is included; only whole-file re-extraction needs the raw deposit |
| SHBG GCST90012107 (Ruth 2020) harmonised release | 641 MB, no tabix index published | never retrieved - retrieval failed; see the endpoint accounting |
| 1000 Genomes Phase 3 EUR reference panel (n = 489) | ~1 GB | used for clumping and reference LD only; the resulting instrument sets and LD matrices are included |

Every headline estimate in this package is re-derived from the harmonised matrices, which ARE
shipped, so the raw deposits are needed only to rebuild those matrices from scratch.

## The smoke test

`04_CODE/v31_smoke.py` materialises a fresh data root in a temporary directory from
`10_INPUTS/` alone, re-runs every analysis module against a fresh output directory, and
compares each produced file with the shipped file of the same name (tables field by field at
1e-9; workbooks cell by cell). The result is in `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md`.

**No "fully reproducible from the package" statement is made anywhere unless that table is
all-PASS.** The currently shipped table reports
all steps passing; see the file for the authoritative record.
