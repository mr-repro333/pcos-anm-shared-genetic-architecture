# GWAS_SOURCES.md (V3.1, rebuilt)

Two resolutions were run on 2026-09-25: an index lookup against the GWAS Catalog REST API and
an HTTP range request against the GWAS Catalog FTP path. Both are recorded in
`ACCESSION_RESOLUTION_AUDIT.md`.

## Exposures and hormones

| role | accession | N recorded | index |
|---|---|---|---|
| PCOS, primary European stratum | GCST90570579 | 420,703 | 404 |
| PCOS, all-ancestry stratum | GCST90570580 | 456,570 | 404 |
| PCOS, alternative European study | GCST90483500 | 14,467 / 430,267 | 200 |
| FSH, European females | GCST90483475 | 51,396 | 200 |
| LH, European females | GCST90483478 | 41,650 | 200 |
| Estradiol, European females | GCST90483481 | 92,969 | 200 |
| Progesterone, European females | GCST90483484 | 16,313 | 200 |
| Testosterone, European females | GCST90483486 | 235,579 | 200 |
| SHBG, European women (not retrieved) | GCST90012107 | 189,473 | 200 |
| Testosterone, European women (not used) | GCST90012112 | 230,454 | 200 |
| ANM, alternative release | GCST90029037 | not recorded in the package | 200 |
| ANM, primary release (Ruth 2021) | GCST90320256 | not recorded in the package | 200 |

The two PCOS accessions return 404 from the index and 206 from the FTP. The
underlying study is the 16-to-29-locus analysis of 544,513 individuals
(Moolhuijsen et al. 2026, PMID 42026183).

## Outcome datasets

The registry below is also shipped as
`03_RESULTS/V3_1_OUTCOME_DATASET_REGISTRY.tsv` and as Supplementary Table S14.

| dataset label | role | accession / source | source study | basis |
|---|---|---|---|---|
| T2D | primary family | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| HbA1c_MAGIC | primary family | GCST90002244 | Chen et al., 2021 (PMID 34059833) | resolved live; catalog trait Glycated hemoglobin levels, 146806 European individuals, linked to PMID 34059833 |
| BMI_FINNGEN | primary family | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| WHRadjBMI_Pulit_dense_combined | primary family | GCST008999 | Pulit et al., 2019 (PMID 30239722) | resolved live; catalog trait Waist-to-hip ratio adjusted for BMI, 694649 European individuals, linked to PMID 30239722 |
| WHRadjBMI_Pulit_dense_females | sensitivity | GCST008994 | Pulit et al., 2019 (PMID 30239722) | resolved live; catalog trait Waist-to-hip ratio adjusted for BMI, 379501 European female individuals |
| TG | primary family | GCST90239664 | Graham et al., 2021 (PMID 34887591) | resolved live; catalog trait Triglyceride levels |
| HDL | primary family | GCST90239652 | Graham et al., 2021 (PMID 34887591) | resolved live; catalog trait High density lipoprotein cholesterol levels |
| CAD | primary family | GCST90132314 | Aragam et al., 2022 (PMID 36474045) | resolved live; catalog trait Coronary artery disease, 181522 cases |
| BMD | primary family | GCST90029004 | no primary study publication; the catalog links only the mixed-model method paper (PMID 29892013) | resolved live as Heel bone mineral density, 583314 European individuals and 12006792 variants, UK recruitment on an Affymetrix array; the distributed file carries a per-variant n of 445921. The canonical heel-eBMD atlas (Morris et al., 2019, PMID 30598549) is a separate record, GCST006979 (426824 British individuals), and was not used here |
| Fracture | primary family | GCST90281273 | Nethander et al., 2023 (PMID 37919453) | resolved live; catalog trait Fracture of forearm, 50471 European cases |
| T2D_FINNGEN | sensitivity | FinnGen, release not distinguished in the deposited record | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| HbA1c | sensitivity | GCST90025974 | Barton et al., 2021 (PMID 34226706) | resolved live; catalog trait Hemoglobin A1c levels, 437749 European individuals; a UK Biobank whole-exome release whose sparser variant coverage is why it is a sensitivity rather than a primary arm |
| HbA1c_PanUKB | sensitivity | GCST90691576 | Karczewski et al., 2025 (PMID 40968291) | resolved live; catalog trait Glycated hemoglobin HbA1c levels, 400825 European individuals |
| BMI_combined | sensitivity | GIANT + UKB 2018 | Yengo et al., 2018 (PMID 30124842) | release named in the deposited record |
| BMI_females | sensitivity | GIANT + UKB 2018 | Yengo et al., 2018 (PMID 30124842) | release named in the deposited record |
| WHRadjBMI_yengo_combined | sensitivity | GIANT adjusted waist-to-hip ratio release labelled for a Yengo-led analysis | not resolved to a publication in the deposited record | dataset label names a lead analyst only |
| WHRadjBMI_yengo_females | sensitivity | GIANT adjusted waist-to-hip ratio release labelled for a Yengo-led analysis | not resolved to a publication in the deposited record | dataset label names a lead analyst only |
| WHRadjBMI_combined | sensitivity | GCST008996 | GIANT waist-to-hip ratio release | resolved live; catalog trait Waist-hip ratio, 697734 individuals |
| WHRadjBMI_women | sensitivity | GCST008997 | GIANT waist-to-hip ratio release | resolved live; catalog trait Waist-hip ratio, 381152 female individuals |
| CAD_FINNGEN | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Osteoporosis_FINNGEN | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Fracture_forearm_FINNGEN | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Fracture_femur_FINNGEN | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Fracture_lowerleg_FINNGEN | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |
| Fracture_lumbarspine_FINNGEN | sensitivity | FinnGen R12 | FinnGen (Kurki et al., 2023) | resource named in the deposited record |

D4 is the union of the primary and second-study instruments, jointly re-clumped, and is a power sensitivity only.

Per-variant provenance is in `03_RESULTS/V3_1_INSTRUMENT_PROVENANCE.tsv`.

Every reference named in this file is in the manuscript reference list, and `V3_1_REFERENCE_AUDIT.tsv` gives the identifier that resolved it.
