# HARMONIZATION_LOG.md (V3.1, corrected)

The previous version of this file described one palindrome rule as if it applied to the whole
project. Two rules are in force, one per code path, and both are documented here exactly.

## Rule A - `HARM_EAF_DISCORD`

**Applies to: every headline harmonised matrix** in `V2_2026/06_HARMONIZED`, i.e. every
systemic and skeletal result, plus the instrument files.

Implementation: `V2_2026/work/v2_harmonise.py`, `EAF_TOL = 0.05`.

1. Match the instrument variant to the outcome file by rsID first; fall back to chr:pos only
   when the empirical rsID agreement for that outcome file is >= 0.5, or use the file's
   recorded build when it carries no rsIDs.
2. Align alleles to a single reference pair per locus: direct, flipped, strand-complement, or
   complement+flip.
3. If the exposure allele pair is palindromic (A/T, T/A, C/G, G/C): drop when either EAF is
   missing (`palindromic_EAF_missing`); drop when
   |EAF_exposure - EAF_outcome| > 0.05 (`palindromic_EAF_discordant`); otherwise align by EAF.
4. Non-palindromic variants are never dropped for allele reasons.
5. Record per variant: match key, action, note, both allele pairs, both EAFs, raw and signed
   outcome beta, and SE.

The literal band `0.42` does not occur anywhere in this code path.

## Rule B - `HARM_PALINDROME_BAND`

**Applies to: the V3 recovered-hormone re-harmonisation path only** (LH, estradiol,
progesterone, testosterone) in `V3_2026/04_CODE/v3_hormones.py`. It does **not** apply to any
systemic or skeletal matrix, and FSH uses the V2-deposited matrix rather than this path.

Drop a variant when its exposure allele pair is palindromic AND the **outcome** EAF lies in
[0.42, 0.58]. The exposure EAF is not consulted, so this rule cannot detect a discordant
palindrome whose outcome EAF sits outside the band.

## Which rule was actually used, established from the code rather than the prose

Rule A produced every headline matrix. Rule B produced the V3 hormone matrices. The previous
provenance note generalised Rule B to the project, which is what made the two shipped
descriptions mutually exclusive.

## Regenerated audit

Re-derived from the deposited per-variant records (`V2_2026/06_HARMONIZED/*_audit.csv`):

| quantity | value |
|---|---|
| pairs recounted | 247 |
| variants dropped in total | 515 |
| dropped as palindromic-EAF-discordant | 512 |
| pairs whose drop count would differ under the band rule | 162 of 247 |

In the hormone path the band rule dropped
1 variant(s) in total, whereas the discordance rule
would have dropped 8-9 in the primary ANM arm. The consequence is measured in the sensitivity
described below and in Supplementary Methods S6.

## Distilled rules for readers

* One algorithm per matrix; no matrix is described by a rule it was not built under.
* No variant is ever removed mechanically on allele grounds outside these two rules.
* No proxy substitution is used anywhere in this study.
