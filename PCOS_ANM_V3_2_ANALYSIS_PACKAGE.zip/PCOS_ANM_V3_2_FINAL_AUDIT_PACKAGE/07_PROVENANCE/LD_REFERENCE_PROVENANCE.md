# LD reference provenance

| use | reference | n | source |
|---|---|---|---|
| instrument clumping | 1000 Genomes Phase 3, EUR superpopulation | 489 | plink 1.9 `--clump`; one variant per locus |
| FSHB reference LD (fine mapping) | same panel | 489 | restricted to the 94-variant pruned marker set; the attempt was withdrawn on diagnostics |

The panel is small, and its smallness is the stated reason the FSHB fine-mapping route is
closed: `susie_rss` returned a Lambda diagnostic of 0.986-1.000 and singleton credible sets
for every trait and marker set, and the best-matching reference LD profile explained at most
28% of the association profile. No ancestry-matched reference of higher quality is available
within the scope of this repair, and the fit was therefore not retried until it succeeded.

Colocalization regional extracts and the LD matrices used for the FSHB attempt are shipped
under `10_INPUTS/09_COLOCALIZATION/regions/` and `10_INPUTS/V3_2026/09_FSHB/`.
