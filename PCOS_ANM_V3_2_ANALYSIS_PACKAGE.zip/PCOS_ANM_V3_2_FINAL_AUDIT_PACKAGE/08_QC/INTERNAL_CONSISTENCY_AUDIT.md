# INTERNAL_CONSISTENCY_AUDIT (V3.1)

Programmatic. `04_CODE/v31_consistency.py` reads the finished documents and the
result files, derives each canonical quantity from the file that owns it, and
searches every document for it. It does not read the generator's variables.

## Quantity presence

| check | value tokens | documents containing | ok |
|---|---|---|---|
| FDR-positive count of nine is zero | 0 of the nine tests survive | Zero of the nine primary difference tests | 0 of 9 primary difference tests | 0 of 9 survive | 5 | PASS |
| smallest corrected P | 0.0343 | 0.03433 | 17 | PASS |
| smallest corrected q | 0.1651 | 0.16506 | 15 | PASS |
| multiplier at K = 0.10 | 0.512825 | 0.5128 | 13 | PASS |
| reciprocal 1/m | 1.9500 | 1.950 | 3 | PASS |
| the factor by which V3's values were too small | 3.802 | 3.8024 | 13 | PASS |
| power: none of nine | 0 of the nine outcomes | 0 of 9 outcomes | 5 | PASS |
| PP4 primary prior | 0.998960 | 12 | PASS |
| PP4 grid minimum | 0.989699 | 9 | PASS |
| surviving hormonal endpoints | Estradiol, LH | estradiol and LH | 10 | PASS |
| instrument display names are used in the documents | primary 19-locus (1 Mb) | alternative ANM 77-locus | 5 | PASS |
| every primary outcome release is identified in a shipped file | GCST90002244 | GCST008999 | GCST90029004 | GCST90281273 | GCST90239664 | GCST90239652 | GCST90132314 | 5 | PASS |
| every secondary outcome release is identified in a shipped file | GCST90025974 | GCST90691576 | GCST008994 | GCST90029037 | 14 | PASS |
| the heel-eBMD release is marked as having no primary study publication | no primary study publication | 7 | PASS |
| the unused heel-eBMD atlas is named so the conflation cannot recur | GCST006979 | 5 | PASS |
| the accession non-resolution is recorded | ACCESSION_RESOLUTION_AUDIT | 5 | PASS |
| the title states an unresolved signature | unresolved systemic signature | 4 | PASS |

## Co-occurrence requirements

| requirement | ok | detail |
|---|---|---|
| PP4 primary and grid minimum together in the abstract [01_MANUSCRIPT\V3_1_manuscript.md] | PASS |  |
| PP4 primary and grid minimum together in the supplementary tables [06_SUPPLEMENT\Supplementary_Tables.md] | PASS |  |
| PP4 primary and grid minimum together in the supplementary methods [06_SUPPLEMENT\Supplementary_Methods.md] | PASS |  |
| PP4 primary and grid minimum together in the README [00_README\README_FIRST.md] | PASS |  |
| PP4 primary and grid minimum together in the claim matrix [claim_matrix] | PASS |  |
| PP4 primary and grid minimum together in the claim matrix [claim_matrix_safe] | PASS |  |
| ANM->PCOS CI on the OR scale in the manuscript [01_MANUSCRIPT\V3_1_manuscript.md] | PASS |  |
| the outcome registry is cited in the Methods and the Data availability statement [01_MANUSCRIPT\V3_1_manuscript.md] | PASS |  |
| the heel-eBMD accession and the unattributed disclosure appear in the same document [01_MANUSCRIPT\V3_1_manuscript.md] | PASS |  |
| the HbA1c accession appears with the publication that resolves it [01_MANUSCRIPT\V3_1_manuscript.md] | PASS |  |
| the WHRadjBMI accession appears in the Methods [01_MANUSCRIPT\V3_1_manuscript.md] | PASS |  |
| the corrected attribution reaches the supplement registry [06_SUPPLEMENT\Supplementary_Tables.md] | PASS |  |
| every primary outcome accession appears in the supplementary registry [06_SUPPLEMENT\Supplementary_Tables.md] | PASS |  |
| every secondary outcome accession appears in the supplementary registry [06_SUPPLEMENT\Supplementary_Tables.md] | PASS |  |
| the registry marks the heel-eBMD release as unattributed [result/V3_1_OUTCOME_DATASET_REGISTRY.tsv] | PASS |  |
| claim counts stated once in the README [00_README\README_FIRST.md] | PASS |  |

## Withdrawn phrasings

19 occurrences of a withdrawn phrase were found; 0 of them are asserted rather than named as withdrawn.

## Locations audited

Abstract; main Results; Discussion; main tables; figures and figure source data; supplement; MASTER_RESULTS; the difference tables; the hormonal tables; the power tables; the Claim-Evidence Matrix; the README.

**Overall: PASS**