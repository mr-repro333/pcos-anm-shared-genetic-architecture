# KNOWN_LIMITATIONS (V3.1)

1. **Power.** After the corrected reciprocal scaling the PCOS arm has 80% power to detect an
   ANM-sized effect for 0 of nine outcomes (range 0.05-0.34).
   The null in the primary family is a statement about instrument strength, not about biology.
2. **Non-independence.** Every comparator dataset overlaps the primary datasets to an unknown
   degree. No result here is independent replication.
3. **Instrument inflation.** Instrument effects are taken from the GWAS that selected the
   variants, which biases MR towards the null.
4. **Unestimated covariance.** The covariance between the two exposure estimates is bounded but
   not estimated, because the deposited data contain no sample-overlap information. The
   multivariable gate therefore has no identified answer.
5. **Heterogeneity.** Q_A is significant in nearly every multivariable model, so the
   conditioning model is not validated independently of the covariance issue.
6. **Colocalization reference.** The LD reference is small; the fine-mapping attempt failed its
   own diagnostics and was withdrawn. FSHB is unresolved at the variant level.
7. **Sex mismatch.** Sex-combined outcome GWAS are used against female-only exposures for type
   2 diabetes, HbA1c, coronary artery disease, bone mineral density and fracture.
8. **Adiposity.** Direct fat-depot traits are unavailable, so the level-versus-distribution
   hypothesis is untestable with these releases rather than merely unsupported.
9. **SHBG.** Could not be read at all (no published tabix index), so the planned six-endpoint
   hormonal family was five in practice.
10. **Harmonisation.** Two palindrome rules remain in the code base, one per code path. Their
    divergence was measured and does not change any conclusion, but a single rule would be
    better.
11. **D4.** The union design mixes exposure effects from two overlapping studies. It is a power
    sensitivity only and never supersedes D1 anywhere in this package.
12. **MR-Egger.** Closed in the rebuild rounds: the packaged estimator is the orientation-
    compliant one and reproduces 244 of 244 pairs exactly. MR-Egger is carried as a
    sensitivity statistic because its InSIDE assumption is untestable in these data.
13. **FSH as-shipped arm.** The FSH ANM arm could not be re-derived exactly from the shipped
    matrices (20 matched variants against 17 as deposited); the alternative derivation is
    non-significant in the same way, but the discrepancy is recorded rather than smoothed.

## Added in the rebuild rounds (2026-09-25)

**Outcome provenance.** Closed. Every one of the 25 outcome and exposure releases the analysis
uses now carries an accession or an institution-level source, taken from the project's own
deposited record and re-resolved live (Supplementary Table S14,
`03_RESULTS/V3_1_OUTCOME_DATASET_REGISTRY.tsv`). The V3.1 rewrite had dropped the outcome half of
the record; it has been restored.

**Two releases carry no primary study publication.** The GWAS Catalog record for the heel bone
mineral density release (`GCST90029004`) reports 583,314 European-ancestry individuals and
12,006,792 variants, records UK recruitment on an Affymetrix array, and links only the
mixed-model method paper (PMID 29892013); the distributed file carries a per-variant n of
445,921. The second ANM release (`GCST90029037`, 156,364 individuals) links the same paper. The
2019 heel-eBMD atlas (Morris et al., 2019; PMID 30598549) is a separate record, `GCST006979`
(426,824 British-ancestry individuals), and the analysis did not use it. The affected primary
result is the skeletal endpoint. The release identity itself is not in doubt - it is fixed by
byte-level retrieval (278,979,845 bytes, FTP md5 `ed6e7f87af4009ba4bd35bb40f00b8c3`) - so the
open item is the study of origin, not the data.

**Primary PCOS accessions.** Resolved, and no string was changed. Both payloads exist on the GWAS
Catalog FTP with HTTP 206 and byte sizes identical to the deposited record (175,116,342 and
215,507,686 bytes), and the harmonised companion of the first also resolves; the REST index
returns 404 for both because it does not cover that accession range, and the catalog links no
publication. The limitation is therefore an index-coverage limitation, not a data-identity
limitation, and the manuscript says so. See `07_PROVENANCE/ACCESSION_RESOLUTION_AUDIT.md`.

**MR-Egger.** Closed, and the V3 finding is withdrawn. The discrepancy was not a weighting
difference: the packaged value is reproduced exactly on 244 of 244 pairs by weighted least
squares on the recoded effects, with both effects recoded so that the SNP-exposure association
is positive. That recoding is a stated assumption of the estimator (Bowden et al. 2016, Int J
Epidemiol 45:1961-1974), so the packaged values are the orientation-compliant ones and the
re-implementation that omitted the step was the one that departed from the definition. The
shipped values are retained unchanged; see `08_QC/MR_EGGER_ENGINE_IDENTIFICATION.md`.

**Freeze evidence.** Unchanged and still open. The analysis plan that fixes the outcome family
and the sensitivity grids is a dated file, but it carries no hash, no external anchor and no
third-party timestamp, so the precedence of the plan over the corrected estimates rests on the
file's own record rather than on an independently verifiable artefact.

