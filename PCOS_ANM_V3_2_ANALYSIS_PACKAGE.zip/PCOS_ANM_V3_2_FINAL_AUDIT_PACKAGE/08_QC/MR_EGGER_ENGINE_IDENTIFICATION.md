# MR_EGGER_ENGINE_IDENTIFICATION.md (V3.1)

## The finding V3 recorded

V3 reported that the packaged MR-Egger output "is not the estimator described by Bowden and
colleagues", that the two differed by up to 0.876 in slope across 244 pairs, and that the
package's internal weighting convention "was not identifiable by testing the obvious candidate
weight vectors", and it therefore substituted a hand-written estimator.

## What it actually is

The difference is not a weighting difference. The packaged value is reproduced exactly by
weighted least squares of the outcome effect on the **recoded** exposure effect, with weights
1/se_Y^2, where both effects are recoded so that the SNP-exposure association is positive.

That recoding is not an implementation detail; it is a stated assumption of the estimator.
Bowden et al. 2016 (Int J Epidemiol 45:1961-1974, PMID 27616674), whose models the MR-Egger
estimator is defined by, state: "we assume that the genetic data have been coded so that
SNP-exposure associations are all positive." The packaged implementation applies it; the
re-implementation that V3 used did not, and therefore departed from the definition it claimed
to be following.

## Evidence

20 candidate parameterisations were scored by how many of the 244 pairs each reproduces to
within 1e-8. The recoded estimator reproduces **244 of 244**; the next best reproduces 18, and the
unoriented form reproduces 9. The full table is
`07_PROVENANCE/V3_1_EGGER_PARAMETER_IDENTIFICATION.tsv` and Supplementary Table S16.

Nothing else in the package is affected: the same rederivation reproduces the packaged IVW,
weighted median, weighted mode, Cochran's Q and F statistics to below 1e-15 on the same variant
counts.

## Consequence

The shipped MR-Egger values are the orientation-compliant estimates and are retained unchanged.
The manuscript reports the identification in Methods 2.3 and no longer describes a discrepancy.
MR-Egger remains a sensitivity statistic because its InSIDE assumption is untestable in these
data, not because its definition was in doubt.
