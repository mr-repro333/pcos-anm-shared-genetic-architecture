# STATISTICAL_AUDIT (V3.1)

## The three repairs, with the evidence for each

### 1. The scale conversion

Correct: beta_L = m(K) beta_logOR for a SNP-exposure coefficient; theta_L = theta_logOR / m(K)
for an MR ratio, with the standard error scaled identically.

Evidence:
* algebraic: theta' = beta_Y/(c beta_X) = theta/c;
* numerical: 200 random instrument vectors through an IVW ratio, both the estimate and the SE
  moving by exactly 1/c to 1e-10 (`test_scale_reciprocity.py`);
* regression guard: the previously shipped per-SD value for the frozen worked example is
  smaller than the correct one by exactly m(K)^-2 = 3.802428;
* site audit: 9 registered multiplier sites, 4 of them applied to an MR ratio or an MR-ratio
  SE, all cancelled.

Consequence: 0 of 9 primary difference tests survive BH-FDR (min q =
0.1651). The previous version reported 4 of 9.

### 2. The signed combination

Every previously computed Z was positive. Corrected, A1 stays significant at every rho up to
0.9 (0.002013 at rho = 0.5) while A2 does not
(0.05658 at rho = 0.5, from
0.007166 in the unsigned version).

### 3. The covariance bound

At gencov = 0 the rebuilt restricted design passes both gates
(13.83 / 12.02); at tau = -0.5 it
fails both (9.26 / 9.22) and at tau = -1.0 it fails both (6.96 / 7.48). The gate outcome is not
identified, and no direct effect is claimed.

## Internal consistency checks

| check | expectation | result |
|---|---|---|
| primary family size | exactly 9 | 9 |
| FDR-positive differences on the corrected scale | reported as computed | 0 |
| FDR-positive differences at each K in the grid | constant, reported | 0 |
| FDR-positive differences at each SD_ANM in the grid | constant, reported | 0 |
| power to detect an ANM-sized effect | reported as computed | 0 of 9 |
| hormonal endpoints planned / analysed / tested | 6 / 5 / 5 with the sixth's reason | see the endpoint accounting |
| endpoints separating the exposures | reported as computed | 2 (Estradiol, LH) |
| PP4 primary prior vs grid minimum | both stated, never merged | 0.998960 vs 0.989699 |
| harmonisation rules | one documented algorithm per code path | done; consequence measured |
| claims | graded from the corrected numbers only | 14 claims, 8 ROBUST |
| input inventory | every file the code reads is shipped | 1220 files |
| clean-environment smoke test | all steps PASS | see `V3_1_CLEAN_ENV_SMOKE_TEST.md` |

## Withdrawn quantities

| quantity | status |
|---|---|
| per-SD PCOS effect computed as ivw x m(K) | WITHDRAWN - wrong direction |
| its standard error computed as ivw_se x m(K) | WITHDRAWN - wrong direction |
| MDE and power computed from that SE | WITHDRAWN |
| unsigned Stouffer p per design | WITHDRAWN - not a test of the stated hypothesis |
| gencov = 0 as a justified assumption | REPLACED by a bounded sensitivity |
| MVMR direct-effect interpretation | WITHDRAWN |
| naive random-effects skeletal pool | WITHDRAWN - retained as a labelled descriptive |
| 'FSHB is the only shared PCOS-ANM signal' | RESTATED as an evidence-tier claim |
