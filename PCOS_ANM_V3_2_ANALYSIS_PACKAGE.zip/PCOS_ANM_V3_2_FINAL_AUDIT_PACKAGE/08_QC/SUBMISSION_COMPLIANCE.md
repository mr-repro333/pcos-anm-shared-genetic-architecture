# SUBMISSION_COMPLIANCE.md (V3.1, rebuilt)

Requirements for a Human Genetics (Springer) research article, measured against the
rebuilt manuscript. This file reports; the fail-closed audit in
`V3_1_FINAL_FAILCLOSED_AUDIT.md` decides. Both are generated, neither is typed.

| requirement | limit | measured | result |
|---|---|---|---|
| Abstract length | 150-250 words | 246 words | PASS |
| Keywords | 4-6 | 5 keywords | PASS |
| Title word count | no explicit limit | 23 words | PASS |
| Title states an unresolved, not absent, signature | must not assert indistinguishability | Shared reproductive genetic architecture with an unresolved systemic signature in polycystic ovary syndrome and age at n | PASS |
| Reference list | present, name-year | 38 entries | PASS |
| In-text citations | present | 41 citation instances | PASS |
| DOI links in the reference list | one per entry that has one | 37 in the list, 0 anywhere else | PASS |
| Figures cited in the text | 6 of 6 | 6 of 6 -> [1, 2, 3, 4, 5, 6] | PASS |
| Tables in the main text | reduced from 9 to 6 | 6 table captions | PASS |
| Statements and Declarations | after the reference list | after the reference list | PASS |
| Large-language-model use documented | required by Springer | present | PASS |
| Target-journal / version working header | must not be left in the file | absent | PASS |
| Data availability names the outcome registry | present | present | PASS |
| Every primary outcome release named with its source | 8 of 8 | 8 of 8 | PASS |
| The heel-eBMD release is not attributed to a study | no attribution | no attribution | PASS |
| Releases without a primary study publication disclosed | present | present | PASS |
| Fail-closed audit | all gates pass | 81 of 81 gates | PASS |

**17 of 17 checks pass.**
