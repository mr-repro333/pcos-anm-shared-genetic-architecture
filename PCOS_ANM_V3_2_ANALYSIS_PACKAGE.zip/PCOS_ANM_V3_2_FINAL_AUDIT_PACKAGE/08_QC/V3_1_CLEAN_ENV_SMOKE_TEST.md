# V3.1 clean-environment smoke test

A fresh temporary data root was materialised from `10_INPUTS/` alone and every
shipped analysis module was re-run against it with a fresh output directory.
Each produced result file was then compared with the shipped file of the same
name: text tables field by field with a 1e-9 numeric tolerance, workbooks by
byte size.

| step | result | detail |
|---|---|---|
| `test_scale_reciprocity.py` | PASS | ALL CHECKS PASSED |
| `v31_mvmr_covariance_sensitivity.R` | PASS | reproduced |
| `v31_diff.py` | PASS | reproduced |
| `v31_domains.py` | PASS | reproduced |
| `v31_hormonal.py` | PASS | reproduced |
| `v31_fshb.py` | PASS | reproduced |
| `v31_harmonization.py` | PASS | reproduced |
| `v31_harmone_rule_sensitivity.py` | PASS | reproduced |
| `v31_multiplier_audit.py` | PASS | reproduced |
| `v31_master.py` | PASS | reproduced |
| `v31_claims.py` | PASS | reproduced |
| `bootstrap --check` | PASS | manifest check against <temp-dir>\v31_smoke_udiu9zni\DATA_ROOT: 1220 OK, 0 mismatched, 0 missing |

**12 of 12 steps passed.**

The "fully reproducible from the package" statement is allowed only while this
table is all-PASS. If any row fails, the correct claim is the weaker one: the
package contains the inputs, but a specific module did not reproduce.
