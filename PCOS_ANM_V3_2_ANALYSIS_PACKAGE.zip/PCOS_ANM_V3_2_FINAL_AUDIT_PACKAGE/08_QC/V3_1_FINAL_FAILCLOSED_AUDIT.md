# FINAL FAIL-CLOSED AUDIT (V3.1)

81 gates; 81 passed; **0 failed**.

A single FAIL means the package is not ready and the gate is named below.

| group | gate | result | detail |
|---|---|---|---|
| A SCOPE | primary family is exactly nine tests | PASS | n = 9 |
| A SCOPE | the nine outcomes are the frozen ones | PASS | ['BMD', 'BMI_FINNGEN', 'CAD', 'Fracture', 'HDL', 'HbA1c_MAGIC', 'T2D', 'TG', 'WHRadjBMI_Pulit_dense_combined'] |
| A SCOPE | primary datasets are D1 and A1 for every row | PASS |  |
| A SCOPE | no alternative release is inside the primary family | PASS |  |
| A SCOPE | prevalence grid is the frozen seven-point grid | PASS |  |
| A SCOPE | SD_ANM grid is the frozen three-point grid | PASS |  |
| A SCOPE | rho grid is the frozen nine-point grid | PASS |  |
| B P0 SCALE | every corrected PCOS per-SD value equals the previous value x 1/m^2 | PASS | ratio range 3.802428-3.802428 vs 3.802428 |
| B P0 SCALE | multiplier site register records 4 wrong-direction sites | PASS |  |
| B P0 SCALE | multiplier site register records the corrected divide site | PASS |  |
| B P0 SCALE | unit test file is shipped | PASS |  |
| C P1 SIGNED | skeletal summary carries signed Stouffer columns | PASS |  |
| C P1 SIGNED | the previous unsigned values are retained as a comparison column | PASS |  |
| C P1 SIGNED | A1 and A2 are reported separately, never pooled | PASS |  |
| C P1 SIGNED | A1 signed significant at rho = 0.5 | PASS | 0.002013 |
| C P1 SIGNED | A2 signed NOT significant at rho = 0.5 | PASS | 0.05658 |
| D P2 MVMR | covariance sensitivity spans at least 11 values of tau | PASS | n_tau = 11 |
| D P2 MVMR | tau = 0 and tau = -1 are both present | PASS |  |
| D P2 MVMR | the gate flips inside the covariance band (so it is not identified) | PASS | tau=0 -> True, tau=-1 -> False |
| D P2 MVMR | no MVMR outcome beyond the V3 set | PASS |  |
| D P2 MVMR | no direct effect is claimed safe for the abstract | PASS |  |
| E P3 AUDIT | input inventory is non-trivial | PASS | 1220 files |
| E P3 AUDIT | every inventoried input is present at its relative path | PASS | 0 missing |
| E P3 AUDIT | clean-environment smoke test is present and all-PASS | PASS |  |
| E P3 AUDIT | DATA_ROOT is configurable and defaults are documented | PASS |  |
| E P3 AUDIT | instrument provenance covers D1, D3, D4, D5, A1, A2 | PASS | ['A1', 'A2', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6'] |
| E P3 AUDIT | per-variant provenance has column genome_wide_significance_status | PASS |  |
| E P3 AUDIT | per-variant provenance has column ld_independent | PASS |  |
| E P3 AUDIT | per-variant provenance has column palindromic_status | PASS |  |
| E P3 AUDIT | per-variant provenance has column harmonization_action | PASS |  |
| E P3 AUDIT | per-variant provenance has column proxy_status | PASS |  |
| E P3 AUDIT | per-variant provenance has column gwas | PASS |  |
| E P3 AUDIT | per-variant provenance has column selected_in_same_gwas_as_coefficient | PASS |  |
| E P3 AUDIT | per-variant provenance has column ancestry | PASS |  |
| E P3 AUDIT | per-variant provenance has column participant_overlap_consideration | PASS |  |
| E P3 AUDIT | per-variant provenance has column f_statistic | PASS |  |
| F FAIL-CLOSED | the corrected nine-test family has zero FDR-positive differences | PASS | n = 0 |
| F FAIL-CLOSED | the manuscript states zero explicitly | PASS |  |
| F FAIL-CLOSED | the README states zero explicitly | PASS |  |
| F FAIL-CLOSED | the count of FDR-positive differences is zero at every K | PASS |  |
| F FAIL-CLOSED | the count of FDR-positive differences is zero at every SD_ANM | PASS |  |
| F FAIL-CLOSED | no alternative family file exists in the results set | PASS |  |
| F FAIL-CLOSED | no alternative outcome release enters the primary table | PASS | intersection: [] |
| G CLAIMS | the systemic-separability claim is reworded to the null and graded ROBUST | PASS |  |
| G CLAIMS | the grade-change table records WITHDRAWN for systemic separability | PASS |  |
| G CLAIMS | the power claim is recorded as REVERSED | PASS |  |
| G CLAIMS | the FSHB mechanism claim is WITHDRAWN | PASS |  |
| G CLAIMS | the adiposity hypothesis is WITHDRAWN | PASS |  |
| G CLAIMS | MVMR direct effects are UNRESOLVED and not safe for the abstract | PASS |  |
| G CLAIMS | no claim at FSHB exceeds PROMISING_NEEDS_VALIDATION | PASS |  |
| G CLAIMS | README claim counts match the matrix exactly | PASS | 14 claims / 8 ROBUST / 9 safe |
| H NUMBERS | every headline number in the manuscript is a shipped value | PASS | missing: [] |
| H NUMBERS | every 4-6 decimal number in the manuscript is a rounding of a shipped result value | PASS | unmatched: [] ; matched only as an absolute value: 0 |
| I NARRATIVE | banned phrasings do not appear as assertions | PASS | [] |
| I NARRATIVE | the manuscript carries the new core claim | PASS |  |
| I NARRATIVE | PCOS->ANM is described as an MR association | PASS |  |
| I NARRATIVE | ANM->PCOS is not given a temporal causal reading | PASS |  |
| I NARRATIVE | horizontal/correlated pleiotropy is offered as an alternative | PASS |  |
| J PRESENTATION | abstract is within the journal limit of 250 words | PASS | 246 words |
| J PRESENTATION | abstract is above the journal floor of 150 words | PASS | 246 words |
| J PRESENTATION | keyword count is between 4 and 6 | PASS | 5 keywords |
| J PRESENTATION | the title carries no unqualified indistinguishability claim | PASS | # Shared reproductive genetic architecture with an unresolved systemic signature in polycystic ovary |
| J PRESENTATION | the title names both traits | PASS | # Shared reproductive genetic architecture with an unresolved systemic signature in polycystic ovary |
| J PRESENTATION | the title states an unresolved rather than an absent signature | PASS | # Shared reproductive genetic architecture with an unresolved systemic signature in polycystic ovary |
| J PRESENTATION | a single reference list is present with at least 20 entries | PASS | 38 entries |
| J PRESENTATION | in-text citations are present | PASS | 41 occurrences |
| J PRESENTATION | every reference in the list is cited in the text | PASS | uncited: [] |
| J PRESENTATION | DOI links appear only in the reference list | PASS | in body: 0 ; in list: 37 |
| J PRESENTATION | all six figures are cited in the text | PASS | [1, 2, 3, 4, 5, 6] |
| J PRESENTATION | the declarations section follows the reference list | PASS |  |
| J PRESENTATION | the declarations heading is 'Statements and Declarations' | PASS |  |
| J PRESENTATION | large-language-model use is disclosed in the manuscript | PASS |  |
| J PRESENTATION | every primary outcome release is named with an accession or resource | PASS | missing: [] |
| J PRESENTATION | every outcome release carries a resolved accession in the registry | PASS | missing from registry: [] |
| J PRESENTATION | the heel-eBMD accession is never attributed to a study in the text | PASS | heel bone mineral density uses the UK Biobank heel-ultrasoun / Two outcome releases carry no primary study publication,  |
| J PRESENTATION | the manuscript discloses that two releases have no primary study publication | PASS |  |
| J PRESENTATION | the registry marks the heel-eBMD release unattributed and names the unused atlas | PASS |  |
| J PRESENTATION | the accession-resolution audit is referred to by the manuscript | PASS |  |
| J PRESENTATION | the permitted-phrasing list is referred to, not asserted inline | PASS |  |
| J PRESENTATION | no superseded quantity is presented as a result | PASS | reason for not pooling stated: True |
| E P3 AUDIT | manuscript, supplement, README, plan and QC documents all exist | PASS |  |

**OVERALL: PASS**