# PCOS / reproductive genetics reviewer simulation (V3.1)

**1. "Does the paper still say the two traits' systemic profiles are different?"**
No. It says their systemic association patterns differ from outcome to outcome in direction and
magnitude, and that those differences are not formally distinguishable at the current instrument
strength. That is a weaker and more accurate sentence.

**2. "Does the paper use PCOS as a proxy for menopause or vice versa?"**
No. The reverse-direction estimate is described as a genetic association between ANM liability
and PCOS liability, with the temporal reading explicitly excluded because ANM occurs decades
after the window in which PCOS liability is expressed.

**3. "What happened to the FSH story?"**
It was one of the strongest-looking results and it does not survive. FSH falls with both
exposures, so the corrected scaling moves the PCOS arm towards the ANM arm and the matched
difference becomes non-significant (P = 0.130-0.332 across the three European designs, against
1.7e-07 to 1.3e-06 before). FSH is retained as a documented null and as an exploratory
single-arm finding.

**4. "Is PCOS to FSH still reported?"**
Yes, as EXPLORATORY: direction replicates across two instrument designs, neither survives the
family correction, and the matched difference is null.

**5. "Does the adiposity claim come back?"**
No. It is UNSUPPORTED in the primary design under a rule locked before the numbers, and the
manuscript additionally states that direct fat-depot traits are unavailable, so the hypothesis
is untestable with these releases.

**6. "Is the FSHB result still the headline shared locus?"**
It is the only locus in the top evidence tier, and the manuscript states exactly what that
means: verdict stable under the prior grid and LD pruning, both traits genome-wide significant
in the window. DENND1A and IRF1 also colocalise at the primary prior and are listed.
