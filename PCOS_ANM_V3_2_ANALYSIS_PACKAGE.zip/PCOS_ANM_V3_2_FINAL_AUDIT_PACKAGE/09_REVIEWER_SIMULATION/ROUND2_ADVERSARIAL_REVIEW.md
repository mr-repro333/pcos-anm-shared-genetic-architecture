# Round-2/3 adversarial review (V3.1, rebuilt)

Written against the rebuilt manuscript, then updated after the provenance round. Each item is the
strongest objection a statistical geneticist or a reproductive endocrinologist would raise.

**1. "You renamed the paper and removed the word decoupling. Did the science change?"**
No. The title states an unresolved systemic signature rather than unqualified
indistinguishability, because the analysis is power-bounded; the body claim is unchanged and
still carries the qualifier "at the current PCOS instrument strength". Every number is read from
the same result files as before the rebuild.

**2. "The abstract is 250 words. What did you lose?"**
Design detail and two numeric values that remain in the body. The abstract keeps the
bidirectional estimates, the direction of the scale correction, the zero-difference result with
its smallest P and q, the power bound, the estradiol/LH contrast and the FSHB tier.

**3. "Two of nine outcomes are nominally significant. Why is the paper not about them?"**
Because the family correction is the pre-specified analysis and both fail it. They are now stated
in the Results in those terms, including that their 95% intervals exclude zero.

**4. "Your outcome provenance is incomplete. Should I trust the numbers?"**
That objection no longer applies. All 24 outcome and exposure releases now carry an accession or
an institution-level source, re-resolved live; the earlier version of the registry was a list of
unidentified labels because the V3.1 rewrite had dropped the outcome half of the deposited
record. One attribution remains unconfirmed and is stated: the heel-BMD release carries a catalog
sample size that does not match the atlas it is attributed to.

**5. "The two primary PCOS accessions do not resolve."**
They do. Both payloads are on the GWAS Catalog FTP with HTTP 206 and byte sizes identical to the
deposited record, and the harmonised companion of the first resolves as well. The REST index
returns 404 because it does not cover that accession range, which is an index-coverage
limitation. The manuscript states this in section 2.2 and in the limitations; no accession string
was changed.

**6. "You explain the estradiol and LH contrast biologically. Is that not overreach?"**
It is labelled an interpretation of direction, it is tied to the two traits' known
hypothalamic-pituitary-ovarian biology, and the paper states that the analysis tests whether the
per-SD effects differ rather than why. Three fragilities are now stated in the same section: the
PCOS hormonal arms carry only seven to nine variants; two of the three designs estimate exposure
and outcome in overlapping participants; and PCOS diagnostic content overlaps the gonadotropin
measures, so the informative part is the direction of the contrast. LH is reported as an
unconfirmed second signal.

**7. "You claim an MR-Egger discrepancy against a published package."**
That claim is withdrawn, and the package is exonerated. The packaged value is reproduced exactly
on 244 of 244 pairs by the estimator that recodes both effects so that the SNP-exposure
association is positive, which is a stated assumption of the MR-Egger estimator; the
re-implementation omitted the step. The shipped MR-Egger values are retained unchanged and the
identification is shipped as a provenance table, a QC file and Supplementary Table S16. This was
the weakest claim in the previous round and it no longer exists.

**8. "The multivariable analysis is in the paper and supports nothing. Why keep it?"**
Because it is a design statement with a bounded and reported outcome, and removing it would hide
the covariance-band behaviour that makes the gate non-identifiable. It is labelled sensitivity
only and no direct effect is claimed.

**9. "What is still the weakest part?"**
Three things. The heel-BMD attribution is unconfirmed. The freeze record is unanchored, so the
precedence of the plan over the corrected estimates rests on the file's own record. And the
reference LD panel behind the FSHB tier is small. Each is disclosed; none is fixed.
