# Statistical genetics reviewer simulation (V3.1)

Written adversarially, then answered. Each item states the strongest objection a statistical
geneticist would raise against **this** package, and what the package does about it.

**1. "You changed the scaling and it flipped your conclusion. Which version is right?"**
Theta_L = theta_logOR / m(K) is forced by the definition of a ratio; the unit test proves the
reciprocity for arbitrary c and the regression guard shows the previous factor is exactly
m(K)^-2 = 3.802. There is no version question: one of the two is arithmetically
wrong, and it is the one that multiplied. What a reviewer *should* check is not the algebra but
whether the family was re-chosen afterwards. It was not: the nine outcomes, the primary dataset
per outcome, the prevalence grid, the rho grid and the SD grid are the previous ones, and the
fail-closed rule was written before the corrected numbers existed.

**2. "Zero of nine is a null. Why should I believe a null from an instrument with 19 loci?"**
You should not, and the paper does not ask you to. The claim is a **power** claim: with the
corrected standard error the arm has 80% power for 0 of nine outcomes at an
ANM-sized effect, i.e. for none. The correct reading is that the comparison is unresolvable, and
the manuscript says so.

**3. "Your two exposure GWAS overlap, so every estimate is biased."**
Yes, towards the null, and it is stated. It also means the covariance between the two exposure
estimates is non-zero, which is why the multivariable gate is reported as unidentified rather
than passed.

**4. "The signed Stouffer is just a different statistic. Why is one right?"**
Because the documentation of the original said the sign was carried, and the implementation did
not carry it. A combination that cannot represent disagreement is not a combination statistic
for polarity-aligned endpoints. Both versions are reported so the difference is auditable.

**5. "gencov = 0 is standard practice."**
It is common, and common is not justified. The band shows the gate flips inside it, so the
practice would have produced an unearned result here.

**6. "You report A1 as coherent and A2 as not. Isn't that cherry-picking?"**
The two instruments were pre-specified as primary and alternative, they are reported
separately, and the alternative one is graded as unresolvable rather than discarded. What would
be cherry-picking is reporting the unsigned A2 value of
0.007166 instead of the signed
0.05658.

**7. "You still have two harmonisation rules in the code."**
Yes. The repair's instruction was to determine which rule was used and document one exact
algorithm; both are now documented per code path, and the divergence is measured on the actual
hormonal conclusions rather than argued away. Unifying the code would change the hormone
matrices, which is outside a validity repair.

**8. "PH4 = 0.999 is high. Why not claim the causal variant?"**
Because SuSiE failed its own consistency diagnostics on the only available reference and was
withdrawn, and because a single-signal colocalization posterior is a statement about a model,
not about a variant. The permitted vocabulary is in the wording ladder.

**9. "Is anything here still overstated?"**
Not knowingly. The strongest remaining statements are the bidirectional association, the
shared genetic architecture, the primary ANM skeletal signature under the signed combination,
the estradiol and LH contrasts, and FSHB at tier 1-2. Each is tied to a named result file and
to a stated family.
