# -*- coding: utf-8 -*-
"""V3 PRIORITY 0G + 1D.

0G  Assemble COLOC_STRESS_TESTS: for every headline locus x trait pair, the full-region
    coloc.abf posterior, the prior grid, the LD-pruning stress test, the SNP counts, the
    region minimum p in each trait, whether both traits are genome-wide significant, the
    verdict and whether it is stable.

1D  Minimum detectable effects and prospective power for the primary PCOS instrument against
    the primary systemic outcomes. This turns "the PCOS arm is underpowered" from an assertion
    into a number. Post-hoc observed power is NOT reported (it is a monotone function of the
    observed p-value and carries no independent information).

    MDE(alpha, power) = (z_{1-alpha/2} + z_{power}) * SE_MR

    SE_MR is taken from the actual analysis (it is a design property: instrument count and
    per-variant strength, not an outcome of the realised effect), so this is an analytical
    power calculation, not a retrospective one. Two alpha levels are reported: the nominal
    0.05 and the family-adjusted 0.05/9 for the nine-trait primary family.
"""
import io, json, math, os, sys
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v3_core import ROOT, V3, RES, LOGD, MRV2, PANEL9, PANEL9_LABEL, DESIGNS, ALIAS2CANON
from v3_diff import liability_multiplier, PREV_PRIMARY

COLOCC = os.path.join(ROOT, "09_COLOCALIZATION")
PRIORITY_LOCI = {"L02_chr11_30226356_rs11031005": "FSHB",
                 "L01_chr9_126535553_rs3945628": "DENND1A",
                 "L16_chr5_131813219_rs4705862": "RAD50_IRF1",
                 "L04_chr2_213361634_rs74690816": "ERBB4",
                 "L07_chr16_53798622_rs8047587": "FTO",
                 "L17_chr2_145797185_rs6430076": "THADA_region",
                 "L11_chr12_75911400_rs1824982": "chr12_locus"}
ALPHA = 0.05
POWER = 0.80


def coloc_stress():
    r = pd.read_csv(os.path.join(COLOCC, "COLOC_RESULTS.tsv"), sep="\t")
    prior = pd.read_csv(os.path.join(COLOCC, "COLOC_PRIOR_SENSITIVITY.tsv"), sep="\t")
    pvp = pd.read_csv(os.path.join(COLOCC, "COLOC_PRUNED_SENSITIVITY.tsv"), sep="\t")
    pvp = pvp.rename(columns={"PP.H4": "PP.H4_pruned"})
    sets = pd.read_csv(os.path.join(COLOCC, "COLOC_PRUNE_SETS.tsv"), sep="\t")
    tiers = pd.read_csv(os.path.join(COLOCC, "COLOC_EVIDENCE_TIERS.tsv"), sep="\t")
    diag = pd.read_csv(os.path.join(COLOCC, "COLOC_REGION_DIAGNOSTICS.tsv"), sep="\t")

    g = prior.groupby(["locus", "trait1", "trait2"])
    pri = g.agg(n_prior_combinations=("p12", "size"),
                p12_min=("p12", "min"), p12_max=("p12", "max"),
                PP_H4_at_p12_min=("PP.H4", "min"), PP_H4_at_p12_max=("PP.H4", "max"),
                n_grid_points_PP_H4_ge_075=("PP.H4", lambda s: int((s >= 0.75).sum()))).reset_index()

    out = r.merge(pvp[["locus", "trait1", "trait2", "nsnp_pruned", "PP.H4_pruned",
                       "verdict_pruned"]], on=["locus", "trait1", "trait2"], how="left")
    out = out.merge(sets[["locus", "n_full", "frac_kept"]].drop_duplicates("locus"),
                    on="locus", how="left")
    out = out.merge(tiers[["locus", "trait1", "trait2", "evidence_tier", "multisignal_either_trait",
                           "nearest_gene"]], on=["locus", "trait1", "trait2"], how="left")
    out = out.merge(pri, on=["locus", "trait1", "trait2"], how="left")
    out["both_traits_genome_wide_significant"] = ~out["underpowered_flag"].astype(bool)
    out["stable"] = (out["verdict"] == out["verdict_pruned"]).fillna(False)
    out["verdict_stable_under_LD_pruning"] = out["stable"]
    out["verdict_stability"] = np.where(out["stable"], "stable", "FLIPS under LD pruning")
    out["ld_pruning_note"] = ("pruned marker subset: " + out["nsnp_pruned"].astype("Int64").astype(str)
                              + " variant(s)")
    out["locus_gene"] = out["locus"].map(PRIORITY_LOCI).fillna(out.get("nearest_gene"))
    out["headline_priority"] = out["locus"].isin(PRIORITY_LOCI)
    cols = ["locus", "locus_gene", "headline_priority", "trait1", "trait2", "nsnp_matched", "nsnp_coloc",
            "PP.H0", "PP.H1", "PP.H2", "PP.H3", "PP.H4", "n_prior_combinations",
            "p12_min", "p12_max", "PP_H4_at_p12_min", "PP_H4_at_p12_max",
            "n_grid_points_PP_H4_ge_075", "n_full", "frac_kept", "nsnp_pruned",
            "PP.H4_pruned", "minP_trait1", "minP_trait2",
            "both_traits_genome_wide_significant", "multisignal_either_trait",
            "verdict", "verdict_pruned", "verdict_stability", "evidence_tier",
            "underpowered_flag", "top_snp", "top_snp_PP_H4", "ld_pruning_note"]
    out = out[[c for c in cols if c in out.columns]]
    return out


def mde():
    m = pd.read_csv(os.path.join(MRV2, "_MR_MASTER_SUMMARY.tsv"), sep="\t")
    m["exposure_raw"] = m["pair"].str.split("__").str[0]
    m["outcome"] = m["pair"].str.split("__").str[1]
    m["design"] = m["exposure_raw"].map(ALIAS2CANON)
    m = m.sort_values(["design", "outcome", "pair"]).drop_duplicates(["design", "outcome"])
    mult = liability_multiplier(PREV_PRIMARY)
    za = stats.norm.ppf(1 - ALPHA / 2)
    zf = stats.norm.ppf(1 - 0.05 / 2 / len(PANEL9))     # Bonferroni-style family adjusted
    zb = stats.norm.ppf(POWER)
    rows = []
    for out in PANEL9:
        p = m[(m["design"] == "D1") & (m["outcome"] == out)]
        a = m[(m["design"] == "A1") & (m["outcome"] == out)]
        if p.empty:
            continue
        p = p.iloc[0]
        se_logOR = float(p["ivw_se"])
        se = se_logOR * mult                     # per-SD-liability SE of the PCOS arm
        row = dict(outcome=out, outcome_label=PANEL9_LABEL.get(out, out),
                   pcos_design="D1", n_snp=int(p["nsnp"]),
                   se_perSD=se,
                   observed_perSD=float(p["ivw"]) * mult,
                   observed_p=float(p["ivw_p"]),
                   MDE80_alpha005=(za + zb) * se,
                   MDE80_alpha_family=(zf + zb) * se,
                   MDE90_alpha005=(za + stats.norm.ppf(0.90)) * se,
                   power_to_detect_ANM_effect=np.nan,
                   anm_effect_perSD=np.nan, anm_effect_detectable=np.nan)
        if not a.empty:
            a = a.iloc[0]
            bA = float(a["ivw"]) * 3.8
            row["anm_effect_perSD"] = bA
            row["anm_effect_detectable"] = bool(abs(bA) >= row["MDE80_alpha005"])
            row["power_to_detect_ANM_effect"] = float(
                stats.norm.cdf(abs(bA) / se - za) + stats.norm.cdf(-abs(bA) / se - za))
        rows.append(row)
    d = pd.DataFrame(rows)
    return d


def main():
    log = io.open(os.path.join(LOGD, "v3_coloc_power.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    cs = coloc_stress()
    md = mde()
    log.close()

    with pd.ExcelWriter(os.path.join(RES, "V3_COLOC_STRESS_TESTS.xlsx"), engine="openpyxl") as w:
        cs[cs["headline_priority"]].to_excel(w, sheet_name="HEADLINE_LOCI", index=False)
        cs.to_excel(w, sheet_name="ALL_PAIRS", index=False)
        pd.DataFrame([
            dict(item="full-region coloc.abf PP0-PP4", source="COLOC_RESULTS.tsv",
                 meaning="single-causal-variant posterior at the primary prior"),
            dict(item="prior combination", source="COLOC_PRIOR_SENSITIVITY.tsv",
                 meaning="PP.H4 over a grid of p12; a verdict confined to one p12 is not a verdict"),
            dict(item="LD pruning stress test", source="COLOC_PRUNED_SENSITIVITY.tsv",
                 meaning="PP.H4 recomputed on an LD-pruned marker subset; verdicts that flip are "
                         "reported as unstable rather than as the favourable half"),
            dict(item="both traits genome-wide significant?",
                 source="COLOC_REGION_DIAGNOSTICS.tsv / underpowered_flag",
                 meaning="where one arm is not genome-wide significant in the window, a low PP.H4 "
                         "is absence of evidence and is NOT reported as evidence of separation"),
            dict(item="multi-signal screening", source="MULTISIGNAL_SCREEN.tsv",
                 meaning="a second independent peak in either trait means single-variant "
                         "colocalization cannot settle the question"),
            dict(item="credible sets", source="NOT AVAILABLE in V2 or V3",
                 meaning="V2 ran no credible-set analysis, so no V2 wording may imply one. V3 "
                         "attempted reference-LD fine-mapping at FSHB and withdrew it: see "
                         "V3_FSHB_SUSIE_DIAGNOSTICS.tsv"),
        ]).to_excel(w, sheet_name="COLUMN_SOURCES", index=False)

    with pd.ExcelWriter(os.path.join(RES, "V3_POWER_MINIMUM_DETECTABLE_EFFECTS.xlsx"),
                        engine="openpyxl") as w:
        md.to_excel(w, sheet_name="MDE_PRIMARY_PANEL", index=False)
        pd.DataFrame([
            dict(quantity="MDE80_alpha005", definition="(z_0.975 + z_0.80) x SE of the PCOS arm, "
                                                       "in units of the outcome per 1 SD of PCOS "
                                                       "genetic liability"),
            dict(quantity="MDE80_alpha_family", definition="as above with alpha = 0.05/9, the "
                                                           "Bonferroni-equivalent level for the "
                                                           "nine-trait primary family"),
            dict(quantity="se_perSD", definition="SE of the PCOS per-SD effect, from the D1 "
                                                 "instrument; a design property (locus count and "
                                                 "per-variant F), not a function of the observed "
                                                 "effect"),
            dict(quantity="power_to_detect_ANM_effect", definition="power of the PCOS arm to "
                                                                   "detect the magnitude the ANM "
                                                                   "arm actually shows for the same "
                                                                   "outcome - the sharpest available "
                                                                   "statement of what the PCOS null "
                                                                   "does and does not exclude"),
            dict(quantity="post-hoc observed power", definition="NOT reported: it is a monotone "
                                                                "function of the observed p-value "
                                                                "and adds no information"),
        ]).to_excel(w, sheet_name="DEFINITIONS", index=False)
    print("coloc rows:", len(cs), " headline:", int(cs["headline_priority"].sum()))
    print(md[["outcome", "n_snp", "observed_perSD", "MDE80_alpha005", "MDE80_alpha_family",
              "anm_effect_perSD", "anm_effect_detectable", "power_to_detect_ANM_effect"]]
          .round(5).to_string(index=False))


if __name__ == "__main__":
    main()
