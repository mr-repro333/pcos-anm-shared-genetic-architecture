# -*- coding: utf-8 -*-
"""V3 core: independent re-implementation of the univariable MR engine and the V3 data model.

Why an independent re-implementation
------------------------------------
The V2 analysis-plan audit rule requires that every number be traceable *and* that the
inverse-variance-weighted estimate be re-derived independently from the harmonised data,
because that is the only check able to detect an error inside the MR engine itself.
V2's engine was R/MendelianRandomization; V3's is Python/numpy, written from the
published formulas. Agreement between the two is therefore a genuine cross-check and
disagreement is a finding.

Canonical design names
----------------------
The V2 tree contains alias arms that are the same design under two labels
(`PCOS_EUR_1Mb` = `PCOS_EUR_GCST90570579`, `PCOS_ALL_1Mb` = `PCOS_ALL_GCST90570580`).
V3 collapses aliases to one canonical design and records the collapse in the audit.
"""
import glob, io, json, math, os, re, sys
import numpy as np
import pandas as pd
from scipy import stats

ROOT = r"E:\PCOS_ANM_Genetic_Decoupling"
V2 = os.path.join(ROOT, "V2_2026")
V3 = os.path.join(ROOT, "V3_2026")
HARM = os.path.join(V2, "06_HARMONIZED")
MRV2 = os.path.join(V2, "07_MR_RESULTS_V2")
CODE = os.path.join(V3, "04_CODE")
RES = os.path.join(V3, "03_RESULTS")
LOGD = os.path.join(V3, "07_LOGS")
for d in (CODE, RES, LOGD):
    os.makedirs(d, exist_ok=True)

# ------------------------------------------------------------------ design map
# NOTE (V3 provenance finding). The V2 tree labels two DIFFERENT instrument designs with
# accession-looking names that read like aliases of the D1 design:
#   `PCOS_EUR_1Mb`            = 19 loci, 1 Mb  (V2 primary, D1)
#   `PCOS_EUR_GCST90570579`   = 18 loci, 10 Mb (== V1's published design, i.e. D2)
#   `PCOS_ALL_1Mb`            = 22 loci, 1 Mb  (V2 ancestry sensitivity, D5)
#   `PCOS_ALL_GCST90570580`   = 20 loci, 10 Mb (== V1's all-ancestry design, D6)
# Verified by intersecting the instrument key sets: PCOS_EUR_1Mb vs PCOS_EUR_GCST90570579
# share 18 of 19 and differ by exactly 12:66447376, the locus the 10 Mb window merged away.
# V2's domain tables list each of the four as a separate `exposure`, so every PCOS design was
# double-counted in the domain-level pooling. V3 collapses them to one canonical design each.
DESIGNS = {
    "D1": dict(alias=["PCOS_EUR_1Mb"], window=1000,
               source="GCST90570579 (European, age-adjusted)", role="primary", n_loci=19),
    "D2": dict(alias=["PCOS_EUR_10Mb", "PCOS_EUR_GCST90570579"], window=10000,
               source="GCST90570579 (European, age-adjusted)", role="V1-comparable sensitivity",
               n_loci=18),
    "D3": dict(alias=["PCOS_ALT_Venkatesh_1Mb"], window=1000,
               source="GCST90483500 (European, Venkatesh 2025)",
               role="alternative-study sensitivity", n_loci=25),
    "D4": dict(alias=["PCOS_UNION_D4_1Mb"], window=1000,
               source="D1 union D3, jointly re-clumped", role="union-of-studies power sensitivity",
               n_loci=29),
    "D5": dict(alias=["PCOS_ALL_1Mb"], window=1000,
               source="GCST90570580 (all-ancestry, age-adjusted)", role="ancestry sensitivity",
               n_loci=22),
    "D6": dict(alias=["PCOS_ALL_GCST90570580"], window=10000,
               source="GCST90570580 (all-ancestry, age-adjusted)",
               role="V1-window all-ancestry sensitivity (not re-derived in V2; excluded from "
                    "V3 inference)", n_loci=20),
    "A1": dict(alias=["ANM_RUTH2021"], window=10000,
               source="Ruth 2021 (reprogen.org)", role="primary ANM", n_loci=213),
    "A2": dict(alias=["ANM_UKB_GCST90029037"], window=10000,
               source="GCST90029037", role="alternative ANM", n_loci=77),
}
ALIAS2CANON = {}
for _c, _v in DESIGNS.items():
    for _a in _v["alias"]:
        ALIAS2CANON[_a] = _c
CANON_ORDER = ["D1", "D2", "D3", "D4", "D5", "D6", "A1", "A2"]
# designs admissible for inference in V3 (D6 excluded: its instrument set is the V1 window
# design and was not re-derived; D2 is retained as the V1-comparability sensitivity)
INFERENCE_DESIGNS = ["D1", "D2", "D3", "D4", "D5", "A1", "A2"]

# The nine-trait matched panel of F1 (unchanged from V1). Primary working file per trait.
PANEL9 = ["T2D", "HbA1c_MAGIC", "BMI_FINNGEN", "WHRadjBMI_Pulit_dense_combined",
          "TG", "HDL", "CAD", "BMD", "Fracture"]
PANEL9_LABEL = {
    "T2D": "Type 2 diabetes", "HbA1c_MAGIC": "HbA1c", "BMI_FINNGEN": "Body mass index",
    "WHRadjBMI_Pulit_dense_combined": "Waist-to-hip ratio adjusted for BMI",
    "TG": "Triglycerides", "HDL": "HDL cholesterol", "CAD": "Coronary artery disease",
    "BMD": "Heel bone mineral density", "Fracture": "Forearm fracture",
}
PANEL9_SUBEFF = {   # alternative / same-trait files -> replication & sensitivity only
    "T2D_FINNGEN": "T2D", "HbA1c": "HbA1c_MAGIC", "HbA1c_PanUKB": "HbA1c_MAGIC",
    "BMI_combined": "BMI_FINNGEN", "WHRadjBMI_yengo_combined": "WHRadjBMI_Pulit_dense_combined",
    "CAD_FINNGEN": "CAD", "Osteoporosis_FINNGEN": "BMD",
    "Fracture_forearm_FINNGEN": "Fracture",
}

SKELETAL = {  # polarity: +1 = better bone status after alignment
    "BMD": +1, "Osteoporosis_FINNGEN": -1, "Fracture": -1,
    "Fracture_forearm_FINNGEN": -1, "Fracture_femur_FINNGEN": -1,
    "Fracture_lowerleg_FINNGEN": -1, "Fracture_lumbarspine_FINNGEN": -1,
}
SKELETAL_PRIMARY = ["BMD", "Fracture"]          # pre-specified primary endpoints
SKELETAL_ALT = ["Osteoporosis_FINNGEN", "Fracture_forearm_FINNGEN",
                "Fracture_femur_FINNGEN", "Fracture_lowerleg_FINNGEN",
                "Fracture_lumbarspine_FINNGEN"]

ADIPOSITY_LEVEL = {"BMI_FINNGEN": "primary", "BMI_combined": "alternative", "BMI_females": "alternative"}
ADIPOSITY_DIST = {"WHRadjBMI_Pulit_dense_combined": "primary",
                  "WHRadjBMI_Pulit_dense_females": "alternative",
                  "WHRadjBMI_yengo_combined": "alternative",
                  "WHRadjBMI_yengo_females": "alternative",
                  "WHRadjBMI_combined": "alternative", "WHRadjBMI_women": "alternative"}

HORMONAL = ["FSH_FEMALE", "LH_FEMALE", "E2_FEMALE", "PROG_FEMALE", "TESTO_FEMALE_ALT", "SHBG_FEMALE"]
HORMONAL_LABEL = {"FSH_FEMALE": "FSH", "LH_FEMALE": "LH", "E2_FEMALE": "Estradiol",
                  "PROG_FEMALE": "Progesterone", "TESTO_FEMALE_ALT": "Testosterone",
                  "SHBG_FEMALE": "SHBG"}


# ------------------------------------------------------------------ estimators
def _zp(z):
    return float(2 * stats.norm.sf(abs(z)))


def ivw_pkg(bx, bxse, by, byse, model="random"):
    """IVW exactly as `MendelianRandomization::mr_ivw` (v0.10.0) computes it, established from
    the package itself on this machine rather than from documentation:

      * point estimate : weighted mean of the ratio estimates with **first-order** weights
                         w_i = 1 / (se_Yi^2 / beta_Xi^2)
                         -> identical for model="fixed" and model="random" (verified)
      * SE (fixed)     : 1 / sqrt(sum w_i)
      * SE (random)    : SE_fixed * sqrt(Q / (k - 1)),  Q = sum w_i (ratio_i - estimate)^2
                         i.e. the multiplicative random-effects model (Thompson & Sharp),
                         NOT the DerSimonian-Laird additive-tau^2 model.
                         Verified against the package output to 1e-10.
      * F statistic    : mean(beta_Xi^2 / se_Xi^2)
    """
    bx, bxse, by, byse = map(lambda a: np.asarray(a, float), (bx, bxse, by, byse))
    r = by / bx
    w = 1.0 / (byse ** 2 / bx ** 2)
    b = float(np.sum(w * r) / np.sum(w))
    q = float(np.sum(w * (r - b) ** 2))
    df = len(r) - 1
    se_f = float(math.sqrt(1.0 / np.sum(w)))
    se = se_f * math.sqrt(q / df) if model == "random" and df > 0 else se_f
    return dict(estimate=b, se=se, se_fixed=se_f, p=_zp(b / se), nsnp=len(r),
                q=q, q_df=df, q_p=float(stats.chi2.sf(q, df)) if df > 0 else np.nan)


def ivw_dl(bx, bxse, by, byse):
    """DerSimonian-Laird additive-tau^2 random-effects IVW, reported as a V3 sensitivity.

    V2 called its primary estimator 'IVW (random effects)' but the implementation used the
    multiplicative model, whose point estimate is the fixed-effects estimate. With the
    heterogeneity observed here (Q = 1550 on 183 df for one pair) the two random-effects
    models can disagree, so V3 reports both and flags any pair where they differ in
    significance.
    """
    bx, bxse, by, byse = map(lambda a: np.asarray(a, float), (bx, bxse, by, byse))
    r = by / bx
    sr = np.sqrt(byse ** 2 / bx ** 2 + (by ** 2) * bxse ** 2 / bx ** 4)
    w = 1.0 / sr ** 2
    bf = float(np.sum(w * r) / np.sum(w))
    q = float(np.sum(w * (r - bf) ** 2))
    df = len(r) - 1
    c = float(np.sum(w) - np.sum(w ** 2) / np.sum(w))
    tau2 = max(0.0, (q - df) / c) if (df > 0 and c > 0) else 0.0
    wr = 1.0 / (sr ** 2 + tau2)
    b = float(np.sum(wr * r) / np.sum(wr))
    se = float(math.sqrt(1.0 / np.sum(wr)))
    return dict(estimate=b, se=se, p=_zp(b / se), tau2=tau2, nsnp=len(r))


def weighted_median(bx, bxse, by, byse, n_boot=10000, seed=20260924):
    bx, bxse, by, byse = map(lambda a: np.asarray(a, float), (bx, bxse, by, byse))
    r = by / bx
    sr = np.sqrt(byse ** 2 / bx ** 2 + (by ** 2) * bxse ** 2 / bx ** 4)
    w = 1.0 / sr ** 2
    order = np.argsort(r)
    r, w = r[order], w[order]
    cw = np.cumsum(w) / np.sum(w)

    def med(ro, wo):
        c = np.cumsum(wo) / np.sum(wo)
        return float(ro[np.searchsorted(c, 0.5)])

    b = med(r, w)
    # parametric bootstrap on the SNP effects (Bowden et al. 2016)
    rng = np.random.default_rng(seed)
    k = len(r)
    s = np.empty(n_boot)
    for i in range(n_boot):
        bxs = rng.normal(bx, bxse); bys = rng.normal(by, byse)
        rr = bys / bxs
        srr = np.sqrt(byse ** 2 / bxs ** 2 + (bys ** 2) * bxse ** 2 / bxs ** 4)
        o = np.argsort(rr)
        s[i] = med(rr[o], (1.0 / srr ** 2)[o])
    se = float(np.std(s, ddof=1))
    return dict(estimate=b, se=se, p=_zp(b / se), nsnp=k)


def weighted_mode(bx, bxse, by, byse, phi=1.0, seed=42):
    bx, bxse, by, byse = map(lambda a: np.asarray(a, float), (bx, bxse, by, byse))
    r = by / bx
    sr = np.sqrt(byse ** 2 / bx ** 2 + (by ** 2) * bxse ** 2 / bx ** 4)
    w = 1.0 / sr ** 2
    w = w / np.sum(w)
    mu = float(np.sum(w * r))
    sdr = float(np.sqrt(np.sum(w * (r - mu) ** 2)))
    h = max(phi * sdr, 1e-8)
    f = lambda b: float(np.sum(w * stats.norm.pdf((r - b) / h) / h))
    b = float(_golden(f, float(np.min(r) - 3 * h), float(np.max(r) + 3 * h)))
    rng = np.random.default_rng(seed)
    bs = np.empty(200)
    for i in range(200):
        idx = rng.integers(0, len(r), len(r))
        rr, ww = r[idx], w[idx]; ww = ww / np.sum(ww)
        m = float(np.sum(ww * rr)); s = float(np.sqrt(np.sum(ww * (rr - m) ** 2)))
        hh = max(phi * s, 1e-8)
        bs[i] = _golden(lambda bb: float(np.sum(ww * stats.norm.pdf((rr - bb) / hh) / hh)),
                        float(np.min(rr) - 3 * hh), float(np.max(rr) + 3 * hh))
    se = float(np.std(bs, ddof=1))
    return dict(estimate=b, se=se, p=_zp(b / se), nsnp=len(r))


def _golden(f, lo, hi, tol=1e-10, it=200):
    gr = (math.sqrt(5) - 1) / 2
    a, b = lo, hi
    c, d = b - gr * (b - a), a + gr * (b - a)
    for _ in range(it):
        if f(c) > f(d):
            b, d = d, c; c = b - gr * (b - a)
        else:
            a, c = c, d; d = a + gr * (b - a)
        if abs(b - a) < tol:
            break
    return (a + b) / 2


def mr_egger_manual(bx, bxse, by, byse):
    """MR-Egger as originally specified (Bowden, Davey Smith & Burgess 2015): weighted least
    squares of beta_Y on beta_X with weights 1/se_Y^2; the intercept estimates directional
    pleiotropy.

    NOTE, recorded as an audit finding: `MendelianRandomization::mr_egger` (v0.10.0) returns a
    different slope and intercept on identical input (for ANM->BMD: package slope 0.0151221 /
    intercept -0.0004757 versus textbook 0.0123673 / +0.0002261). The package's internal
    weighting convention is not documented and was not identifiable by testing the obvious
    candidate weight vectors, so V3 reports the textbook estimator, states the discrepancy, and
    does not use MR-Egger as a load-bearing statistic.
    """
    bx, bxse, by, byse = map(lambda a: np.asarray(a, float), (bx, bxse, by, byse))
    w = 1.0 / byse ** 2
    X = np.column_stack([np.ones(len(bx)), bx])
    XtWX = X.T @ (w[:, None] * X)
    try:
        beta = np.linalg.solve(XtWX, X.T @ (w * by))
        cov = np.linalg.inv(XtWX)
    except np.linalg.LinAlgError:
        return dict(estimate=np.nan, se=np.nan, p=np.nan, intercept=np.nan, intercept_p=np.nan)
    resid = by - X @ beta
    dof = len(bx) - 2
    s2 = float((resid * w * resid).sum() / dof) if dof > 0 else np.nan
    se = np.sqrt(np.diag(cov) * s2)
    return dict(estimate=float(beta[1]), se=float(se[1]), p=_zp(beta[1] / se[1]),
                intercept=float(beta[0]), intercept_se=float(se[0]),
                intercept_p=_zp(beta[0] / se[0]), nsnp=len(bx))


def mr_all(d):
    """d: DataFrame with beta_exp, se_exp, beta_out, se_out."""
    bx, bxse = d["beta_exp"].values, d["se_exp"].values
    by, byse = d["beta_out"].values, d["se_out"].values
    ok = np.isfinite(bx) & np.isfinite(by) & np.isfinite(bxse) & np.isfinite(byse) & (bxse > 0) & (byse > 0)
    bx, bxse, by, byse = bx[ok], bxse[ok], by[ok], byse[ok]
    if len(bx) < 3:
        return None
    out = {}
    iv = ivw_pkg(bx, bxse, by, byse, "random")
    out.update(ivw=iv["estimate"], ivw_se=iv["se"], ivw_se_fixed=iv["se_fixed"], ivw_p=iv["p"],
               q=iv["q"], q_df=iv["q_df"], q_p=iv["q_p"])
    dl = ivw_dl(bx, bxse, by, byse)
    out.update(ivw_dl=dl["estimate"], ivw_dl_se=dl["se"], ivw_dl_p=dl["p"], tau2_dl=dl["tau2"])
    try:
        wm = weighted_median(bx, bxse, by, byse); out.update(wm=wm["estimate"], wm_se=wm["se"], wm_p=wm["p"])
    except Exception:
        out.update(wm=np.nan, wm_se=np.nan, wm_p=np.nan)
    try:
        wd = weighted_mode(bx, bxse, by, byse); out.update(wmode=wd["estimate"], wmode_p=wd["p"])
    except Exception:
        out.update(wmode=np.nan, wmode_p=np.nan)
    try:
        eg = mr_egger_manual(bx, bxse, by, byse)
        out.update(egger=eg["estimate"], egger_p=eg["p"],
                   egger_int=eg["intercept"], egger_int_p=eg["intercept_p"])
    except Exception:
        out.update(egger=np.nan, egger_p=np.nan, egger_int=np.nan, egger_int_p=np.nan)
    out["nsnp"] = len(bx)
    out["F_mean"] = float(np.mean(bx ** 2 / bxse ** 2))
    out["F_min"] = float(np.min(bx ** 2 / bxse ** 2))
    out["ivw_p_fixed"] = _zp(iv["estimate"] / iv["se_fixed"])
    return out


# ------------------------------------------------------------------ data loading
def load_harmonised(include_new_hormones=True):
    """Return {canonical_exposure: {outcome: DataFrame}}."""
    files = sorted(glob.glob(os.path.join(HARM, "*.tsv")))
    files = [f for f in files if not f.endswith("_audit.csv")]
    store = {}
    for f in files:
        base = os.path.basename(f)[:-4]
        if "__" not in base:
            continue
        exp, out = base.split("__", 1)
        can = ALIAS2CANON.get(exp)
        if can is None:
            continue
        d = pd.read_csv(f, sep="\t")
        need = {"beta_exp", "se_exp", "beta_out", "se_out"}
        if not need.issubset(d.columns):
            continue
        store.setdefault(can, {})[out] = d
    # new hormones recovered in V3
    newdir = os.path.join(V3, "02_HARMONIZED")
    for f in sorted(glob.glob(os.path.join(newdir, "*.tsv"))):
        base = os.path.basename(f)[:-4]
        if "__" in base:
            continue
        out = base
        for can, dd in store.items():
            if out in dd:
                continue
            # raw new file: needs harmonisation against each exposure -> skip here
            pass
    return store


if __name__ == "__main__":
    store = load_harmonised()
    print("canonical exposures:", {k: len(v) for k, v in store.items()})
