# -*- coding: utf-8 -*-
"""V3 PRIORITY 0A / 0B / 0C - the formal PCOS-vs-ANM effect comparison, rebuilt.

0A  Liability-scale conversion of the binary PCOS exposure.
0B  A frozen primary family of exactly NINE difference tests, one primary dataset per
    phenotype; every alternative dataset is demoted to replication / sensitivity; BH-FDR
    within that family only.
0C  A covariance sensitivity over rho in [-1, +1] (nine points), replacing the two-point
    "covariance = 0 vs covariance = 1" description.

--------------------------------------------------------------------------------------
0A. The liability-scale conversion, derived rather than assumed
--------------------------------------------------------------------------------------
The latent-liability model sets L ~ N(0,1) in the population, with the disease present when
L exceeds the threshold t = Phi^{-1}(1 - K), K = population prevalence. Then

  (i)  E[Y | g] = K + phi(t) * beta_L * g          (Y the 0/1 phenotype, g a standardised
                                                    allele count, beta_L the per-allele
                                                    shift of the latent liability)
       -> with z = phi(t), a per-allele log-odds coefficient b satisfies, to first order,
          b = z * beta_L / (K (1 - K)), because the derivative of the logit at the
          population mean is 1/(K(1-K)) and dP/dbeta_L = z.
       -> hence  beta_L = b * K (1 - K) / z .                                        (A)
    This multiplier does NOT depend on the case fraction P of the source GWAS: the odds
    ratio is invariant to case-control ascertainment, so no ascertainment correction enters
    a coefficient conversion. (P enters only the variance/observed-scale-heritability
    conversion kappa = K^2 (1-K)^2 / (P(1-P) z^2) given by Lee et al. 2011, and V3 keeps
    that use of it separate.)
    The same relation follows from the reverse direction: writing the logistic model as a
    probit with the usual scale 1.702 gives beta_L ~= b/1.702, and z/(K(1-K)) -> 1/1.596 as
    K -> 0.5, so the two derivations agree where both are valid.

  (ii) The first-order expression (A) is exact only in the small-effect limit. V3 therefore
       also solves for beta_L exactly: for a per-allele shift beta_L, the residual liability
       variance is 1 - V_g with V_g = 2p(1-p) beta_L^2 and
          P(case | x) = 1 - Phi( (t - beta_L x) / sqrt(1 - V_g) ),
          log-OR      = logit P(case|1) - logit P(case|0),
       which is inverted numerically. V3 reports both, and the closed form is used in the
       tables only after the two are shown to agree.

Consequence, stated plainly: the V2 assumption ("the liability log-odds coefficient is
already a per-SD-of-liability effect") is not the liability-threshold convention. Under (A)
the multiplier is K(1-K)/z, which is 0.46-0.57 across any defensible PCOS prevalence, i.e.
always materially below 1. V2 therefore over-stated the PCOS per-SD effect by roughly a
factor of two relative to its own stated framing.

The comparison is also run on the V2 scale, so that the reader sees exactly what the
correction does and can check that no conclusion was manufactured by it.
"""
import io, json, math, os, sys
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v3_core import RES, LOGD, V3, PANEL9, PANEL9_LABEL, PANEL9_SUBEFF

SD_ANM_PRIMARY = 3.8
SD_ANM_GRID = [3.5, 3.8, 4.2]
PREV_PRIMARY = 0.10
PREV_GRID = [0.05, 0.06, 0.08, 0.10, 0.12, 0.15, 0.20]
RHO_GRID = [-1.0, -0.75, -0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0]
ALPHA = 0.05

V2_SCALE_NOTE = ("V2 assumption: the liability log-odds coefficient is already a per-SD "
                 "effect (multiplier = 1). Retained in the table for comparison only.")


def zp(z):
    return float(2 * stats.norm.sf(abs(z)))


def bh(p):
    p = np.asarray(p, float)
    out = np.full_like(p, np.nan)
    ok = np.isfinite(p)
    pv = p[ok]; n = len(pv)
    if n == 0:
        return out
    o = np.argsort(pv); r = pv[o]
    q = r * n / (np.arange(n) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    t = np.empty(n); t[o] = np.clip(q, 0, 1)
    out[ok] = t
    return out


# --------------------------------------------------------------------- 0A scaling
def liability_multiplier(K):
    """Closed-form multiplier m(K) = K(1-K)/phi(Phi^{-1}(1-K)) with beta_L = m * logOR."""
    t = stats.norm.ppf(1 - K)
    z = stats.norm.pdf(t)
    return K * (1 - K) / z


def liability_multiplier_exact(logOR, eaf, K, hi=2.0):
    """Numerically invert the exact liability-threshold model for beta_L given a log-OR.

    Returns beta_L such that the liability-threshold model reproduces the observed log-OR at
    the given allele frequency. Solves the scalar equation by bisection on [0, hi].
    """
    t = stats.norm.ppf(1 - K)

    def logor_of(bL):
        vg = 2 * eaf * (1 - eaf) * bL ** 2
        d = math.sqrt(max(1e-12, 1 - vg))
        p1 = 1 - stats.norm.cdf((t - bL) / d)
        p0 = 1 - stats.norm.cdf(t / d)
        lo = lambda q: math.log(max(q, 1e-15) / max(1 - q, 1e-15))
        return lo(p1) - lo(p0)

    lo_, hi_ = 0.0, hi
    for _ in range(200):
        mid = (lo_ + hi_) / 2
        if logor_of(mid) < logOR:
            lo_ = mid
        else:
            hi_ = mid
    return (lo_ + hi_) / 2


def scaling_table():
    rows = []
    for K in PREV_GRID:
        m = liability_multiplier(K)
        # exact multiplier for a representative top-locus log-OR and an average log-OR
        for lo, eaf, tag in [(0.30, 0.20, "large-effect locus (logOR 0.30, EAF 0.20)"),
                             (0.10, 0.30, "typical locus (logOR 0.10, EAF 0.30)"),
                             (0.02, 0.30, "small-effect locus (logOR 0.02, EAF 0.30)")]:
            bL = liability_multiplier_exact(lo, eaf, K)
            rows.append(dict(K=K, closed_form_multiplier=m, logOR=lo, eaf=eaf, case=tag,
                             exact_beta_L=bL, exact_multiplier=bL / lo,
                             closed_form_beta_L=m * lo,
                             relative_error=abs(m * lo - bL) / bL))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------- 0B / 0C
def load_arms():
    """Read the V2 per-pair master (verified reproducible to 1e-15 by v3_qc2_full_rederive.R)
    and collapse the exposure arms onto canonical designs.

    The collapse is deterministic (first alias listed in DESIGNS wins) and is validated: the
    only true aliases are D2's two labels, which must agree numerically.
    """
    from v3_core import ALIAS2CANON, DESIGNS, MRV2
    m = pd.read_csv(os.path.join(MRV2, "_MR_MASTER_SUMMARY.tsv"), sep="\t")
    m["exposure_raw"] = m["pair"].str.split("__").str[0]
    m["outcome"] = m["pair"].str.split("__").str[1]
    m["design"] = m["exposure_raw"].map(ALIAS2CANON)
    m = m[m["design"].notna()].copy()
    rank = {}
    for c, v in DESIGNS.items():
        for i, a in enumerate(v["alias"]):
            rank[a] = i
    m["alias_rank"] = m["exposure_raw"].map(rank)
    m = m.sort_values(["design", "outcome", "alias_rank", "pair"])
    return m, pd.DataFrame()


def alias_report(master):
    from v3_core import DESIGNS
    rows = []
    for c, v in DESIGNS.items():
        if len(v["alias"]) < 2:
            continue
        for out, g in master[master["design"] == c].groupby("outcome"):
            if len(g) < 2:
                continue
            rows.append(dict(design=c, aliases="|".join(v["alias"]), outcome=out,
                             n_records=len(g),
                             d_ivw=float(g["ivw"].max() - g["ivw"].min()),
                             d_se=float(g["ivw_se"].max() - g["ivw_se"].min()),
                             d_nsnp=int(g["nsnp"].max() - g["nsnp"].min()),
                             identical=bool(abs(g["ivw"].max() - g["ivw"].min()) < 1e-12
                                            and int(g["nsnp"].max() - g["nsnp"].min()) == 0)))
    return pd.DataFrame(rows)


def difference_rows(master, outcome, pcos_design, anm_design, K, sd_anm,
                    scale="liability", label=None):
    def rec(design):
        r = master[(master["design"] == design) & (master["outcome"] == outcome)]
        return None if r.empty else r.iloc[0]
    p, a = rec(pcos_design), rec(anm_design)
    if p is None or a is None:
        return None
    mult = liability_multiplier(K) if scale == "liability" else 1.0
    bP = float(p["ivw"]) * mult
    sP = float(p["ivw_se"]) * mult
    bA = float(a["ivw"]) * sd_anm
    sA = float(a["ivw_se"]) * sd_anm
    row = dict(outcome=outcome, outcome_label=PANEL9_LABEL.get(outcome, outcome),
               pcos_design=pcos_design, anm_design=anm_design,
               n_snp_pcos=int(p["nsnp"]), n_snp_anm=int(a["nsnp"]),
               pcos_logOR=float(p["ivw"]), pcos_logOR_se=float(p["ivw_se"]),
               p_pcos_raw=float(p["ivw_p"]),
               pcos_perSD=bP, pcos_perSD_se=sP,
               anm_per_year=float(a["ivw"]), anm_per_year_se=float(a["ivw_se"]),
               p_anm_raw=float(a["ivw_p"]),
               anm_perSD=bA, anm_perSD_se=sA,
               difference=bP - bA, multiplier=mult, K=K, sd_anm=sd_anm,
               scale=scale, v2_scale_note=V2_SCALE_NOTE)
    se0 = math.sqrt(sP ** 2 + sA ** 2)
    row["se_rho0"] = se0
    row["p_rho0"] = zp((bP - bA) / se0)
    row["se_rho1"] = abs(sP - sA)
    row["p_rho1"] = 2 * stats.norm.sf(abs((bP - bA) / abs(sP - sA))) if abs(sP - sA) > 0 else 0.0
    row["se_rho_minus1"] = sP + sA
    row["p_rho_minus1"] = zp((bP - bA) / (sP + sA))
    for r in RHO_GRID:
        se = math.sqrt(sP ** 2 + sA ** 2 - 2 * r * sP * sA)
        row[f"se_rho_{r:+.2f}"] = se
        row[f"p_rho_{r:+.2f}"] = zp((bP - bA) / se)
    row["ci_lower_rho0"] = bP - bA - 1.96 * se0
    row["ci_upper_rho0"] = bP - bA + 1.96 * se0
    # rho needed for significance; the test is significant when rho > rho_star
    dz = abs(bP - bA) / stats.norm.ppf(1 - ALPHA / 2)
    num = sP ** 2 + sA ** 2 - dz ** 2
    row["rho_star_for_significance"] = num / (2 * sP * sA) if sP * sA > 0 else np.nan
    row["significant_at_rho_minus1"] = row["p_rho_minus1"] < ALPHA
    row["significant_at_rho0"] = row["p_rho0"] < ALPHA
    row["significant_over_all_plausible_rho"] = bool(row["p_rho0"] < ALPHA
                                                     and row["rho_star_for_significance"] <= 0)
    return row


def main():
    master_raw, _ = load_arms()
    log = io.open(os.path.join(LOGD, "v3_diff.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    al = alias_report(master_raw)
    al.to_csv(os.path.join(RES, "V3_EXPOSURE_ALIAS_AUDIT.tsv"), sep="\t", index=False)
    L("true alias groups (D2 has two labels); identical for every outcome:",
      bool(al["identical"].all()) if len(al) else "n/a", f"(n={len(al)} outcome-level checks)")
    # deterministic collapse: first alias wins
    master = master_raw.drop_duplicates(subset=["design", "outcome"], keep="first")
    L("arm records before collapse: %d ; after: %d" % (len(master_raw), len(master)))

    # ---------- 0A: the scaling table and its validation -----------------------
    st = scaling_table()
    st.to_csv(os.path.join(RES, "V3_SCALING_DERIVATION.tsv"), sep="\t", index=False)
    m10 = liability_multiplier(PREV_PRIMARY)
    L(f"closed-form multiplier at K={PREV_PRIMARY}: {m10:.6f}")
    L("multiplier range over prevalence grid: %.4f - %.4f"
      % (liability_multiplier(min(PREV_GRID)), liability_multiplier(max(PREV_GRID))))
    L("exact vs closed form, max relative error: %.4f" % st["relative_error"].max())

    # ---------- 0B: frozen primary family -------------------------------------
    rows, rows_v2 = [], []
    for out in PANEL9:
        r = difference_rows(master, out, "D1", "A1", PREV_PRIMARY, SD_ANM_PRIMARY, "liability")
        if r:
            rows.append(r)
        rv = difference_rows(master, out, "D1", "A1", PREV_PRIMARY, SD_ANM_PRIMARY, "v2_assumption")
        if rv:
            rows_v2.append(rv)
    prim = pd.DataFrame(rows)
    prim_v2 = pd.DataFrame(rows_v2)
    if len(prim) != 9:
        L(f"WARNING: primary family has {len(prim)} rows, expected 9")

    prim["q_BH_primary"] = bh(prim["p_rho0"].values)
    prim_v2["q_BH_primary"] = bh(prim_v2["p_rho0"].values)

    def verdict(r):
        if r["p_rho0"] < ALPHA and r["significant_over_all_plausible_rho"]:
            return "difference supported (rho >= 0 and rho >= rho_star)"
        if r["p_rho0"] < ALPHA and not r["significant_over_all_plausible_rho"]:
            return "conditional on non-negative covariance only (rho_star > 0)"
        if r["p_rho1"] >= ALPHA:
            return "no detectable difference (even at rho = +1)"
        return "difference not established: not resolvable from summary statistics"

    prim["verdict"] = prim.apply(verdict, axis=1)
    prim["multiplicity_pass"] = prim["q_BH_primary"] < 0.05
    prim["nominal_pass"] = prim["p_rho0"] < 0.05
    prim_v2["verdict"] = prim_v2.apply(verdict, axis=1)
    prim_v2["multiplicity_pass"] = prim_v2["q_BH_primary"] < 0.05
    prim_v2["nominal_pass"] = prim_v2["p_rho0"] < 0.05

    order = ["outcome", "outcome_label", "n_snp_pcos", "n_snp_anm", "pcos_perSD",
             "pcos_perSD_se", "anm_perSD", "anm_perSD_se", "difference", "se_rho0",
             "p_rho0", "q_BH_primary", "p_rho1", "p_rho_minus1",
             "rho_star_for_significance", "significant_over_all_plausible_rho",
             "nominal_pass", "multiplicity_pass", "verdict"]
    for frame, path in ((prim, "V3_DIFFERENCE_PRIMARY9_LIABILITY.tsv"),
                        (prim_v2, "V3_DIFFERENCE_PRIMARY9_V2SCALE.tsv")):
        cols = [c for c in order if c in frame.columns] + \
               [c for c in frame.columns if c not in order]
        frame[cols].to_csv(os.path.join(RES, path), sep="\t", index=False)

    # ---------- 0C: rho grid, tidy ------------------------------------------
    grid = []
    for _, r in prim.iterrows():
        for rho in RHO_GRID:
            grid.append(dict(outcome=r["outcome"], outcome_label=r["outcome_label"], rho=rho,
                             se_difference=r[f"se_rho_{rho:+.2f}"],
                             p_difference=r[f"p_rho_{rho:+.2f}"],
                             significant=bool(r[f"p_rho_{rho:+.2f}"] < ALPHA)))
    pd.DataFrame(grid).to_csv(os.path.join(RES, "V3_RHO_SENSITIVITY_GRID.tsv"), sep="\t", index=False)

    # ---------- prevalence and SD grids -------------------------------------
    prevrows = []
    for K in PREV_GRID:
        for out in PANEL9:
            r = difference_rows(master, out, "D1", "A1", K, SD_ANM_PRIMARY, "liability")
            if r:
                prevrows.append(dict(outcome=out, K=K, multiplier=r["multiplier"],
                                     difference=r["difference"], se_rho0=r["se_rho0"],
                                     p_rho0=r["p_rho0"],
                                     q_BH=np.nan, rho_star=r["rho_star_for_significance"]))
    pv = pd.DataFrame(prevrows)
    for K, g in pv.groupby("K"):
        pv.loc[g.index, "q_BH"] = bh(g["p_rho0"].values)
    pv.to_csv(os.path.join(RES, "V3_PREVALENCE_SENSITIVITY.tsv"), sep="\t", index=False)

    sdrows = []
    for sd in SD_ANM_GRID:
        for out in PANEL9:
            r = difference_rows(master, out, "D1", "A1", PREV_PRIMARY, sd, "liability")
            if r:
                sdrows.append(dict(outcome=out, sd_anm=sd, difference=r["difference"],
                                   p_rho0=r["p_rho0"]))
    sd = pd.DataFrame(sdrows)
    for s, g in sd.groupby("sd_anm"):
        sd.loc[g.index, "q_BH"] = bh(g["p_rho0"].values)
    sd.to_csv(os.path.join(RES, "V3_SD_ANM_SENSITIVITY.tsv"), sep="\t", index=False)

    # ---------- alternative datasets: replication / sensitivity --------------
    altrows = []
    ALT = {"T2D_FINNGEN": "T2D", "HbA1c": "HbA1c_MAGIC", "HbA1c_PanUKB": "HbA1c_MAGIC",
           "BMI_combined": "BMI_FINNGEN", "BMI_females": "BMI_FINNGEN",
           "WHRadjBMI_yengo_combined": "WHRadjBMI_Pulit_dense_combined",
           "WHRadjBMI_yengo_females": "WHRadjBMI_Pulit_dense_combined",
           "CAD_FINNGEN": "CAD", "Osteoporosis_FINNGEN": "BMD",
           "Fracture_forearm_FINNGEN": "Fracture", "Fracture_femur_FINNGEN": "Fracture"}
    for alt, parent in ALT.items():
        for design, role in [("D1", "primary exposure x alternative outcome"),
                             ("D3", "alternative exposure x primary outcome"),
                             ("D4", "union exposure x primary outcome")]:
            r = difference_rows(master, alt, design, "A1", PREV_PRIMARY, SD_ANM_PRIMARY, "liability")
            if r:
                r.update(parent_phenotype=parent, role=role, family="replication_or_sensitivity")
                altrows.append(r)
    alt = pd.DataFrame(altrows)
    if len(alt):
        alt["q_BH_within_alt_family"] = np.nan
        alt.to_csv(os.path.join(RES, "V3_DIFFERENCE_ALTERNATIVES_SENSITIVITY.tsv"),
                   sep="\t", index=False)

    L("\n=== primary family (liability scale, K=0.10) ===")
    L(prim[["outcome", "pcos_perSD", "anm_perSD", "difference", "se_rho0", "p_rho0",
            "q_BH_primary", "p_rho_minus1", "rho_star_for_significance",
            "multiplicity_pass", "verdict"]].to_string(index=False))
    L("\n=== primary family under the V2 (unscaled) assumption ===")
    L(prim_v2[["outcome", "pcos_perSD", "difference", "p_rho0", "q_BH_primary",
               "multiplicity_pass"]].to_string(index=False))
    L(f"\npassing BH<0.05 on the corrected scale: {int(prim['multiplicity_pass'].sum())}/9")
    L(f"passing BH<0.05 on the V2 scale:        {int(prim_v2['multiplicity_pass'].sum())}/9")

    json.dump(dict(multiplier_K010=liability_multiplier(PREV_PRIMARY),
                   multiplier_range=[liability_multiplier(min(PREV_GRID)),
                                     liability_multiplier(max(PREV_GRID))],
                   max_rel_error_exact_vs_closed=float(st["relative_error"].max()),
                   n_primary=len(prim),
                   n_pass_bh_corrected=int(prim["multiplicity_pass"].sum()),
                   n_pass_bh_v2scale=int(prim_v2["multiplicity_pass"].sum()),
                   alias_collapse_duplicates=int(len(master_raw) - len(master))),
              io.open(os.path.join(LOGD, "v3_diff_summary.json"), "w"), indent=2)
    log.close()
    print("done")


if __name__ == "__main__":
    main()
