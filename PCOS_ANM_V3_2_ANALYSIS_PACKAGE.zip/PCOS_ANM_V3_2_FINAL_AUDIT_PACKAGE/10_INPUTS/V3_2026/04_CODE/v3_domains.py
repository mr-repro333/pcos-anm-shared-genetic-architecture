# -*- coding: utf-8 -*-
"""V3 PRIORITY 0D - replace the naive domain meta-analyses with structured domain evidence.

What V2 did and why it is withdrawn
-----------------------------------
V2 pooled the skeletal endpoints with a random-effects meta-analysis of polarity-aligned
standardised betas, and pooled the adiposity endpoints within class before comparing the
two pooled betas. Three things are wrong with that:

1. The endpoints are NOT independent studies. Heel eBMD and six fracture/osteoporosis
   endpoints are genetically correlated; BMI, body-fat percentage and the WHRadjBMI
   releases are near-duplicates of one another. A random-effects meta-analysis of correlated
   estimates under-states the SE of the pooled estimate, and no amount of Q/I^2 reporting
   repairs that.
2. The betas are not in a common unit. eBMD is g/cm^2 on a transformed scale, fractures are
   log-OR, BMI is kg/m^2 and WHRadjBMI is a dimensionless adjusted ratio. Sign-flipping for
   polarity does not make beta comparable.
3. V2's own exposure labels double-counted designs: `PCOS_EUR_1Mb` and
   `PCOS_EUR_GCST90570579` are the V2 1 Mb and the V1 10 Mb instrument sets (18/19 shared
   loci), not aliases, and the same holds for the two all-ancestry labels. V2's domain tables
   listed all four as separate `exposure` values, so each PCOS design entered the class-level
   pooling twice.

V3 therefore
------------
* reports endpoint-specific estimates, endpoint-specific BH-FDR, direction consistency,
  cross-dataset directional replication and robust-estimator agreement;
* reports the pooled estimate ONLY in a column explicitly marked `not_used_for_inference`,
  with the correlation problem quantified by an effective-number-of-tests calculation;
* uses a correlation-robust combining rule (Stouffer over a grid of assumed average
  pairwise endpoint correlation) instead of a fixed-effects or random-effects pool;
* grades the adiposity hypothesis under a rule fixed before the V3 numbers were computed;
* keeps the skeletal conclusion on the pre-specified endpoints (eBMD, primary fracture,
  alternative osteoporosis/fracture evidence), not on a pooled p-value.
"""
import io, itertools, math, os, sys
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v3_core import (RES, LOGD, MRV2, ADIPOSITY_LEVEL, ADIPOSITY_DIST, SKELETAL,
                     SKELETAL_PRIMARY, SKELETAL_ALT, DESIGNS, ALIAS2CANON)
from v3_diff import bh, liability_multiplier, PREV_PRIMARY

RHO_ENDPOINT_GRID = [0.0, 0.25, 0.5, 0.75, 0.9]
ALPHA = 0.05

# Assumed phenotypic SDs used ONLY to put the two adiposity classes on a comparable
# per-SD-of-trait scale. They are external assumptions, not estimates from this study, and are
# therefore reported with a sensitivity band and flagged wherever they are used.
ADIP_SD = {"level": dict(value=4.8, lo=4.0, hi=5.5, unit="kg/m^2",
                         note="BMI, European adults (GIANT/UKB; ~4.8 kg/m^2)"),
           "distribution": dict(value=0.070, lo=0.055, hi=0.085, unit="dimensionless",
                                note="WHRadjBMI, European adults (Pulit 2019 / Yengo 2018; ~0.07)")}


def load_canonical_master():
    m = pd.read_csv(os.path.join(MRV2, "_MR_MASTER_SUMMARY.tsv"), sep="\t")
    m["exposure_raw"] = m["pair"].str.split("__").str[0]
    m["outcome"] = m["pair"].str.split("__").str[1]
    m["design"] = m["exposure_raw"].map(ALIAS2CANON)
    m = m[m["design"].notna()].copy()
    rank = {}
    for c, v in DESIGNS.items():
        for i, a in enumerate(v["alias"]):
            rank[a] = i
    m["alias_rank"] = m["exposure_raw"].map(rank)
    m = m.sort_values(["design", "outcome", "alias_rank", "pair"])
    m = m.drop_duplicates(subset=["design", "outcome"], keep="first")
    return m


def stouffer_corr(pvals, rho):
    """Correlation-robust Stouffer combination.

    z_i = Phi^{-1}(1 - p_i/2) with the sign carried by the aligned effect. If the k statistics
    have average pairwise correlation rho, Var(sum z) = k + k(k-1) rho, so
    Z = sum(z) / sqrt(k + k(k-1)rho). rho = 0 recovers the independence assumption; rho -> 1
    collapses the k endpoints to a single effective test.
    """
    z = np.asarray([stats.norm.isf(min(max(p, 1e-300), 1 - 1e-16) / 2) for p in pvals], float)
    k = len(z)
    v = k + k * (k - 1) * rho
    if v <= 0:
        return np.nan, np.nan
    Z = float(np.sum(z) / math.sqrt(v))
    return Z, float(2 * stats.norm.sf(abs(Z)))


def effective_k(k, rho):
    return k / (1 + (k - 1) * rho) if rho < 1 else 1.0


def meta_naive(b, se):
    """Fixed- and random-effects (DerSimonian-Laird) pooling, retained ONLY as a labelled
    descriptive quantity. Its p-value is never used for inference in V3."""
    b, se = np.asarray(b, float), np.asarray(se, float)
    w = 1 / se ** 2
    bf = float(np.sum(w * b) / np.sum(w))
    Q = float(np.sum(w * (b - bf) ** 2)); df = len(b) - 1
    C = float(np.sum(w) - np.sum(w ** 2) / np.sum(w))
    tau2 = max(0.0, (Q - df) / C) if df > 0 and C > 0 else 0.0
    wr = 1 / (se ** 2 + tau2)
    be = float(np.sum(wr * b) / np.sum(wr)); see = float(math.sqrt(1 / np.sum(wr)))
    return dict(fixed=bf, random=be, se_random=see, p_random=2 * stats.norm.sf(abs(be / see)),
                Q=Q, Q_df=df, Q_p=float(stats.chi2.sf(Q, df)) if df > 0 else np.nan,
                I2=float(max(0.0, (Q - df) / Q) * 100) if Q > 0 else 0.0, tau2=tau2)


# ------------------------------------------------------------------ skeletal
def skeletal(master):
    rows = []
    for (design, out), g in master[master["outcome"].isin(SKELETAL)].groupby(["design", "outcome"]):
        r = g.iloc[0]
        pol = SKELETAL[out]
        rows.append(dict(exposure_design=design, endpoint=out, polarity=pol,
                         status="primary" if out in SKELETAL_PRIMARY else "alternative",
                         n_snp=int(r["nsnp"]), beta_raw=float(r["ivw"]),
                         beta_aligned=float(r["ivw"]) * pol, se=float(r["ivw_se"]),
                         p=float(r["ivw_p"]),
                         wm=float(r["wm"]) * pol, wm_p=float(r["wm_p"]),
                         wmode=float(r["wmode"]) * pol, wmode_p=float(r["wmode_p"]),
                         egger=float(r["egger"]) * pol, egger_p=float(r["egger_p"]),
                         egger_int=float(r["egger_int"]), egger_int_p=float(r["egger_int_p"]),
                         q_p=float(r["q_p"]),
                         ivw_dl_flag=None))
    d = pd.DataFrame(rows)
    d["FDR_within_skeletal"] = np.nan
    for design, g in d.groupby("exposure_design"):
        d.loc[g.index, "FDR_within_skeletal"] = bh(g["p"].values)
    d["robust_agreement"] = np.where(
        (np.sign(d["wm"]) == np.sign(d["beta_aligned"])) &
        (np.sign(d["wmode"]) == np.sign(d["beta_aligned"])), "sign-agree", "sign-disagree")
    d["nominal"] = d["p"] < ALPHA
    d["fdr_pass"] = d["FDR_within_skeletal"] < ALPHA
    return d.sort_values(["exposure_design", "status", "endpoint"])


def skeletal_summary(d):
    """Structured domain evidence per design. No pooled p-value is used for inference."""
    rows = []
    for design, g in d.groupby("exposure_design"):
        b, se, p = g["beta_aligned"].values, g["se"].values, g["p"].values
        npos = int((b > 0).sum())
        z, p_corr = stouffer_corr(p, 0.5)
        rows.append(dict(
            exposure_design=design, role=DESIGNS[design]["role"], k=len(g),
            direction_consistency=float(npos / len(g)),
            n_favourable=npos, n_unfavourable=int((b < 0).sum()),
            n_nominal=int(g["nominal"].sum()), n_fdr_pass=int(g["fdr_pass"].sum()),
            endpoints_fdr_pass=";".join(g.loc[g["fdr_pass"], "endpoint"]),
            robust_estimator_sign_agreement=int((g["robust_agreement"] == "sign-agree").sum()),
            stouffer_z_rho050=z, stouffer_p_rho050=p_corr,
            stouffer_p_rho000=stouffer_corr(p, 0.0)[1],
            stouffer_p_rho075=stouffer_corr(p, 0.75)[1],
            stouffer_p_rho090=stouffer_corr(p, 0.9)[1],
            effective_k_rho050=effective_k(len(g), 0.5),
            naive_fixed_meta=meta_naive(b, se)["fixed"],
            naive_random_meta=meta_naive(b, se)["random"],
            naive_meta_p=meta_naive(b, se)["p_random"],
            naive_meta_I2=meta_naive(b, se)["I2"],
            naive_meta_not_used_for_inference="YES - correlated endpoints and non-commensurable units",
            unit_commensurability="NOT commensurable: eBMD (g/cm^2 transformed) vs fracture "
                                  "(log-OR) vs osteoporosis (log-OR)",
            primary_endpoints="BMD;Fracture",
            primary_endpoints_aligned=";".join(
                "%s=%.4f(p=%.3g)" % (r.endpoint, r.beta_aligned, r.p)
                for r in g[g["status"] == "primary"].itertuples()),
            alternative_evidence=";".join(
                "%s=%.4f(p=%.3g)" % (r.endpoint, r.beta_aligned, r.p)
                for r in g[g["status"] == "alternative"].itertuples())))
    return pd.DataFrame(rows)


# ------------------------------------------------------------------ adiposity
def adiposity(master):
    rows = []
    for (design, out), g in master[master["outcome"].isin(
            list(ADIPOSITY_LEVEL) + list(ADIPOSITY_DIST))].groupby(["design", "outcome"]):
        r = g.iloc[0]
        klass = "level" if out in ADIPOSITY_LEVEL else "distribution"
        status = ADIPOSITY_LEVEL.get(out) or ADIPOSITY_DIST.get(out)
        rows.append(dict(exposure_design=design, endpoint=out, klass=klass, status=status,
                         n_snp=int(r["nsnp"]), beta=float(r["ivw"]), se=float(r["ivw_se"]),
                         p=float(r["ivw_p"]), wm=float(r["wm"]), wm_p=float(r["wm_p"]),
                         wmode=float(r["wmode"]), wmode_p=float(r["wmode_p"]),
                         egger_int=float(r["egger_int"]), egger_int_p=float(r["egger_int_p"]),
                         q_p=float(r["q_p"])))
    d = pd.DataFrame(rows)
    d["FDR_within_adiposity"] = np.nan
    for design, g in d.groupby("exposure_design"):
        d.loc[g.index, "FDR_within_adiposity"] = bh(g["p"].values)
    d["beta_perSD_of_trait_main"] = d.apply(
        lambda r: r["beta"] / ADIP_SD[r["klass"]]["value"], axis=1)
    d["beta_perSD_of_trait_lo_assumption"] = d.apply(
        lambda r: r["beta"] / ADIP_SD[r["klass"]]["hi"], axis=1)
    d["beta_perSD_of_trait_hi_assumption"] = d.apply(
        lambda r: r["beta"] / ADIP_SD[r["klass"]]["lo"], axis=1)
    d["robust_agreement"] = np.where((np.sign(d["wm"]) == np.sign(d["beta"])) &
                                     (np.sign(d["wmode"]) == np.sign(d["beta"])),
                                     "sign-agree", "sign-disagree")
    d["nominal"] = d["p"] < ALPHA
    d["fdr_pass"] = d["FDR_within_adiposity"] < ALPHA
    return d.sort_values(["exposure_design", "klass", "status", "endpoint"])


def adiposity_primary_pair(d):
    """The pre-specified single-trait comparison: primary level endpoint against primary
    distribution endpoint, within each design."""
    rows = []
    for design, g in d.groupby("exposure_design"):
        lv = g[(g["klass"] == "level") & (g["status"] == "primary")]
        di = g[(g["klass"] == "distribution") & (g["status"] == "primary")]
        if lv.empty or di.empty:
            continue
        lv, di = lv.iloc[0], di.iloc[0]
        rows.append(dict(
            exposure_design=design,
            level_endpoint=lv["endpoint"], level_beta=lv["beta"], level_p=lv["p"],
            level_nsnp=lv["n_snp"], level_perSD_main=lv["beta_perSD_of_trait_main"],
            distribution_endpoint=di["endpoint"], distribution_beta=di["beta"],
            distribution_p=di["p"], distribution_nsnp=di["n_snp"],
            distribution_perSD_main=di["beta_perSD_of_trait_main"],
            raw_difference=di["beta"] - lv["beta"],
            perSD_difference_main=di["beta_perSD_of_trait_main"] - lv["beta_perSD_of_trait_main"],
            perSD_difference_lower_bound_assumption=di["beta_perSD_of_trait_lo_assumption"]
                                                  - lv["beta_perSD_of_trait_hi_assumption"],
            perSD_difference_upper_bound_assumption=di["beta_perSD_of_trait_hi_assumption"]
                                                  - lv["beta_perSD_of_trait_lo_assumption"],
            raw_difference_sign="distribution larger" if di["beta"] > lv["beta"] else "level larger",
            perSD_difference_sign="distribution larger"
            if di["beta_perSD_of_trait_main"] > lv["beta_perSD_of_trait_main"] else "level larger",
            comparable="NO - raw units are kg/m^2 versus a dimensionless ratio"))
    return pd.DataFrame(rows)


def adiposity_replication(d):
    """Directional replication of the primary distribution endpoint across the other releases
    of the same trait, per design."""
    rows = []
    primary_dist = "WHRadjBMI_Pulit_dense_combined"
    primary_level = "BMI_FINNGEN"
    for design, g in d.groupby("exposure_design"):
        gp = g[g["endpoint"] == primary_dist]
        if gp.empty:
            continue
        ref = float(gp.iloc[0]["beta"])
        alts = g[(g["klass"] == "distribution") & (g["endpoint"] != primary_dist)]
        n_same = int((np.sign(alts["beta"]) == np.sign(ref)).sum()) if len(alts) else 0
        rows.append(dict(exposure_design=design, reference_endpoint=primary_dist,
                         reference_beta=ref, n_alternative_distribution_releases=len(alts),
                         n_same_sign=n_same,
                         alternatives=";".join("%s=%.4f" % (r.endpoint, r.beta)
                                               for r in alts.itertuples()),
                         sign_replication_satisfied=bool(len(alts) > 0 and
                                                         n_same == len(alts)),
                         level_reference=primary_level,
                         level_beta=float(g[g["endpoint"] == primary_level].iloc[0]["beta"])
                         if not g[g["endpoint"] == primary_level].empty else np.nan))
    return pd.DataFrame(rows)


def grade_adiposity(pair, rep, d):
    """Pre-specified grading rule for the adiposity-distribution hypothesis.

    Fixed before the V3 numbers were computed and applied mechanically.

    SUPPORTED  requires ALL of
      (a) the primary distribution endpoint exceeds the primary level endpoint in
          per-SD-of-trait units (main assumption AND both extreme assumption combinations);
      (b) the primary distribution endpoint's sign is replicated by EVERY alternative
          distribution release of the same trait in the same design;
      (c) the primary distribution endpoint survives BH-FDR within the adiposity family in
          the primary design D1;
      (d) the contrast is not driven by a single endpoint: at least two distribution releases
          exceed at least two level releases in per-SD-of-trait units.
    SUGGESTIVE requires (b) AND (d) but not all of (a) and (c).
    UNSUPPORTED otherwise.
    """
    out = []
    for _, r in pair.iterrows():
        dl = r["exposure_design"]
        reps = rep[rep["exposure_design"] == dl]
        b_ok = bool(reps["sign_replication_satisfied"].iloc[0]) if len(reps) else False
        a_ok = bool(r["perSD_difference_main"] > 0 and
                    r["perSD_difference_lower_bound_assumption"] > 0 and
                    r["perSD_difference_upper_bound_assumption"] > 0)
        g = d[(d["exposure_design"] == dl)]
        row = g[(g["endpoint"] == r["distribution_endpoint"])]
        c_ok = bool(not row.empty and row.iloc[0]["fdr_pass"] and dl == "D1")
        dis = g[g["klass"] == "distribution"]["beta_perSD_of_trait_main"].values
        lev = g[g["klass"] == "level"]["beta_perSD_of_trait_main"].values
        d_ok = bool(len(dis) >= 2 and len(lev) >= 2 and
                    np.sum(dis[:, None] > lev[None, :]) >= 2)
        if a_ok and b_ok and c_ok and d_ok:
            grade = "SUPPORTED"
        elif b_ok and d_ok:
            grade = "SUGGESTIVE"
        else:
            grade = "UNSUPPORTED"
        out.append(dict(exposure_design=dl, criterion_a_perSD_magnitude=a_ok,
                        criterion_b_sign_replication=b_ok,
                        criterion_c_endpoint_FDR_primary_design=c_ok,
                        criterion_d_not_single_endpoint=d_ok, hypothesis_grade=grade,
                        decision_note="grading applied mechanically from the locked rule; "
                                      "no criterion may be relaxed after the fact"))
    o = pd.DataFrame(out)
    return o


def main():
    log = io.open(os.path.join(LOGD, "v3_domains.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    master = load_canonical_master()
    sk = skeletal(master)
    sks = skeletal_summary(sk)
    ad = adiposity(master)
    adp = adiposity_primary_pair(ad)
    adr = adiposity_replication(ad)
    adg = grade_adiposity(adp, adr, ad)

    with pd.ExcelWriter(os.path.join(RES, "V3_SKELETAL_EVIDENCE.xlsx"), engine="openpyxl") as w:
        sk.to_excel(w, sheet_name="PER_ENDPOINT", index=False)
        sks.to_excel(w, sheet_name="DOMAIN_SUMMARY", index=False)
        pd.DataFrame([dict(
            pooling_rule="The V2 random-effects pool of polarity-aligned betas is reported in "
                         "DOMAIN_SUMMARY as `naive_*` and is NOT used for inference.",
            reason_1="Endpoints are genetically correlated; independent-studies pooling "
                     "under-states the pooled SE.",
            reason_2="Units are not commensurable: eBMD is g/cm^2 on a transformed scale, "
                     "fractures and osteoporosis are log-OR.",
            reason_3="V2's exposure labels double-counted instrument designs "
                     "(`PCOS_EUR_1Mb` vs `PCOS_EUR_GCST90570579`).",
            replacement="Direction consistency; endpoint-specific BH-FDR; robust-estimator "
                        "sign agreement; correlation-robust Stouffer combination over a grid of "
                        "assumed average pairwise endpoint correlation.",
            skeletal_conclusion_basis="eBMD (BMD), primary forearm fracture (Fracture), and the "
                                      "alternative osteoporosis/fracture endpoints reported "
                                      "individually - not a pooled p-value.")]).to_excel(
            w, sheet_name="POOLING_WITHDRAWN", index=False)

    with pd.ExcelWriter(os.path.join(RES, "V3_ADIPOSITY_EVIDENCE.xlsx"), engine="openpyxl") as w:
        ad.to_excel(w, sheet_name="PER_ENDPOINT", index=False)
        adp.to_excel(w, sheet_name="PRIMARY_PAIR", index=False)
        adr.to_excel(w, sheet_name="DIRECTIONAL_REPLICATION", index=False)
        adg.to_excel(w, sheet_name="HYPOTHESIS_GRADING", index=False)
        pd.DataFrame([
            dict(item="V2 pooled distribution-vs-level p-value", status="WITHDRAWN",
                 reason="both pooled classes mixed repeated releases of the same traits and "
                        "unrelated traits, in non-commensurable units, and used the same PCOS "
                        "designs twice"),
            dict(item="V2 'supported by the expanded designs and not by the primary one'",
                 status="REPLACED", reason="the primary-pair comparison is reported per design "
                                           "with the units made explicit"),
            dict(item="Assumed trait SDs", status="EXTERNAL ASSUMPTION",
                 reason="BMI 4.8 kg/m^2 and WHRadjBMI 0.070 are literature values, not "
                        "estimates from this study; a sensitivity band is reported and the "
                        "sign of the criterion-(a) comparison is stable across the band"),
            dict(item="Pre-specified grading rule", status="LOCKED BEFORE RESULTS",
                 reason="SUPPORTED requires (a)+(b)+(c)+(d); SUGGESTIVE requires (b)+(d); "
                        "otherwise UNSUPPORTED. A single significant WHRadjBMI cannot produce "
                        "SUPPORTED or SUGGESTIVE because (b) requires the sign to be replicated "
                        "by every alternative release"),
        ]).to_excel(w, sheet_name="WHAT_CHANGED_AND_WHY", index=False)

    L("=== skeletal domain summary ===")
    L(sks[["exposure_design", "k", "direction_consistency", "n_fdr_pass", "endpoints_fdr_pass",
           "stouffer_p_rho000", "stouffer_p_rho050", "stouffer_p_rho090",
           "naive_meta_p", "naive_meta_I2"]].to_string(index=False))
    L("\n=== adiposity primary pair ===")
    L(adp[["exposure_design", "level_endpoint", "level_beta", "distribution_endpoint",
           "distribution_beta", "raw_difference_sign", "perSD_difference_sign",
           "perSD_difference_main"]].to_string(index=False))
    L("\n=== adiposity directional replication ===")
    L(adr.to_string(index=False))
    L("\n=== adiposity hypothesis grading (locked rule) ===")
    L(adg.to_string(index=False))
    log.close()
    print("done")


if __name__ == "__main__":
    main()
