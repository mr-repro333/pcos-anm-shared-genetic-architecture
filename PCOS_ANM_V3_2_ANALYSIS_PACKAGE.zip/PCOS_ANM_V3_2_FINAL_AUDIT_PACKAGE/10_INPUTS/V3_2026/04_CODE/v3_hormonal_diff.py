# -*- coding: utf-8 -*-
"""Matched between-exposure difference tests for the hormonal domain.

Each hormone is one outcome file, used for both exposures, so the comparison is matched: a
difference cannot be a between-dataset difference. The same rho grid and rho* threshold as the
systemic domain are applied, so the hormonal claim is graded on the same terms as the rest of
the paper rather than on a bare significance contrast.
"""
import io, math, os, sys
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v3_core import RES, V3, LOGD
from v3_diff import bh, liability_multiplier, PREV_PRIMARY, RHO_GRID, zp

SD_ANM = 3.8


def main():
    f4 = pd.read_csv(os.path.join(RES, "V3_HORMONAL_RESULTS_F4.tsv"), sep="\t")
    mult = liability_multiplier(PREV_PRIMARY)
    rows = []
    for ep, g in f4.groupby("endpoint"):
        armA = g[g["exposure_design"] == "A1"]
        if armA.empty:
            continue
        arow = armA.iloc[0]
        for pd_design in ["D1", "D3", "D4"]:
            armP = g[g["exposure_design"] == pd_design]
            if armP.empty:
                continue
            prow = armP.iloc[0]
            p, a = prow, arow
            bP, sP = float(p["ivw"]) * mult, float(p["ivw_se"]) * mult
            bA, sA = float(a["ivw"]) * SD_ANM, float(a["ivw_se"]) * SD_ANM
            d = bP - bA
            se0 = math.sqrt(sP ** 2 + sA ** 2)
            row = dict(endpoint=ep, pcos_design=pd_design,
                       n_snp_pcos=int(p["n_instruments"]), n_snp_anm=int(a["n_instruments"]),
                       pcos_perSD=bP, pcos_perSD_se=sP, pcos_p=float(p["ivw_p"]),
                       anm_perSD=bA, anm_perSD_se=sA, anm_p=float(a["ivw_p"]),
                       difference=d, se_rho0=se0, p_rho0=zp(d / se0),
                       same_sign=bool(np.sign(bP) == np.sign(bA)))
            for r in RHO_GRID:
                se = math.sqrt(sP ** 2 + sA ** 2 - 2 * r * sP * sA)
                row["p_rho_%+.2f" % r] = zp(d / se)
            row["p_rho_minus1"] = zp(d / (sP + sA))
            dz = abs(d) / stats.norm.ppf(0.975)
            if sP * sA > 0:
                row["rho_star_for_significance"] = (sP ** 2 + sA ** 2 - dz ** 2) / (2 * sP * sA)
            else:
                row["rho_star_for_significance"] = np.nan
            row["significant_at_rho0"] = row["p_rho0"] < 0.05
            rows.append(row)
    out = pd.DataFrame(rows)
    out["q_BH_within_hormonal_family"] = np.nan
    for tag, g in out.groupby("pcos_design"):
        out.loc[g.index, "q_BH_within_hormonal_family"] = bh(g["p_rho0"].values)
    out.to_csv(os.path.join(RES, "V3_HORMONAL_DIFFERENCE.tsv"), sep="\t", index=False)

    # append a sheet to the hormonal audit workbook
    p = os.path.join(RES, "V3_HORMONAL_ENDPOINT_AUDIT.xlsx")
    xl = pd.read_excel(p, sheet_name=None)
    xl["MATCHED_DIFFERENCE_TESTS"] = out
    with pd.ExcelWriter(p, engine="openpyxl") as w:
        for k, v in xl.items():
            v.to_excel(w, sheet_name=k[:31], index=False)
    print(out[["endpoint", "pcos_design", "pcos_perSD", "anm_perSD", "difference",
               "p_rho0", "q_BH_within_hormonal_family", "p_rho_minus1", "same_sign"]]
          .round(5).to_string(index=False))


if __name__ == "__main__":
    main()
