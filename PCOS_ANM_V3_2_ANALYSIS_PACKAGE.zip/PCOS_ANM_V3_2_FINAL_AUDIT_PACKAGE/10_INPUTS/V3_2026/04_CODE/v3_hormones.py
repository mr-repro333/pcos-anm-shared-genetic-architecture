# -*- coding: utf-8 -*-
"""V3 PRIORITY 0E (analysis step) - the hormonal (F4) family, rebuilt and completed.

V2's plan pre-specified six sex-matched hormonal endpoints and analysed one (FSH). V3
recovers what the connection allows, records what it does not, and recomputes the F4
multiple-testing family over the endpoints that are genuinely analysable under the plan.

Method
------
For each exposure design, the instrument variants' exposure effects come from
05_INSTRUMENTS/<design>_instruments.tsv and the hormone effects from the recovered regional
extraction (rsID-matched, aligned to a common reference allele, palindromes dropped where the
allele frequency is uninformative). The estimator is the V3 Python engine, whose IVW was
verified to reproduce MendelianRandomization::mr_ivw to 1e-10 in v3_qc1/2.
"""
import glob, io, json, math, os, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v3_core import (ROOT, V2, V3, RES, LOGD, DESIGNS, HORMONAL_LABEL)
from v3_core import ivw_pkg, ivw_dl, weighted_median, weighted_mode, mr_egger_manual
from v3_diff import bh

INS_V2 = os.path.join(V2, "05_INSTRUMENTS")
INS_V1 = os.path.join(ROOT, "05_INSTRUMENTS")
RAW = os.path.join(V2, "06_RAW_OUTCOMES")
NEW = os.path.join(V3, "02_HARMONIZED")
LOGF = io.open(os.path.join(LOGD, "v3_hormones.log"), "w", encoding="utf-8")
COMP = {"A": "T", "T": "A", "C": "G", "G": "C"}

# endpoint -> (file, release, planned dataset, sample size, sex, source kind)
ENDPOINTS = {
    "FSH_FEMALE": dict(path=os.path.join(RAW, "FSH_FEMALE.tsv"), acc="GCST90483475",
                       label="FSH", n=51396, status="analysed",
                       note="extracted in V2; V3 re-harmonised and re-run"),
    "LH_FEMALE": dict(path=os.path.join(NEW, "LH_FEMALE.tsv"), acc="GCST90483478",
                      label="LH", n=41650, status="recovered_in_V3",
                      note="V2 logged WinError 10060 against the remote tabix index; "
                           "recovered in V3 over plain HTTP range reads"),
    "TESTO_FEMALE_ALT": dict(path=os.path.join(NEW, "TESTO_FEMALE_ALT.tsv"), acc="GCST90483486",
                             label="Testosterone", n=235579, status="pending",
                             note="recovered in V3 if the file is present"),
    "E2_FEMALE": dict(path=os.path.join(NEW, "E2_FEMALE.tsv"), acc="GCST90483481",
                      label="Estradiol", n=92969, status="pending",
                      note="recovered in V3 if the file is present"),
    "PROG_FEMALE": dict(path=os.path.join(NEW, "PROG_FEMALE.tsv"), acc="GCST90483484",
                        label="Progesterone", n=16313, status="pending",
                        note="recovered in V3 if the file is present"),
    "SHBG_FEMALE": dict(path=os.path.join(NEW, "SHBG_FEMALE.tsv"), acc="GCST90012107",
                        label="SHBG", n=189473, status="NOT_RECOVERED",
                        note="the EBI harmonised release for this study publishes no .tbi "
                             "index (HTTP 404), so random access is impossible, and the whole "
                             "file is 641 MB and the measured transfer rate on this connection "
                             "is ~5 KB/s"),
}


def load_instruments(design):
    for base in (INS_V2, INS_V1):
        for a in DESIGNS[design]["alias"]:
            for fn in (f"{a}_instruments.tsv",):
                p = os.path.join(base, fn)
                if os.path.exists(p):
                    d = pd.read_csv(p, sep="\t")
                    d["key"] = d["key"].astype(str)
                    return d
    return None


def align(ref_ea, ref_oa, ea, oa, beta, eaf):
    ea, oa = str(ea).upper(), str(oa).upper()
    R, O = str(ref_ea).upper(), str(ref_oa).upper()
    if ea == R and oa == O:
        return beta, eaf
    if ea == O and oa == R:
        return (-beta if beta == beta else np.nan), (1 - eaf if eaf == eaf else np.nan)
    ce, co = COMP.get(ea, ""), COMP.get(oa, "")
    if ce == R and co == O:
        return beta, eaf
    if ce == O and co == R:
        return (-beta if beta == beta else np.nan), (1 - eaf if eaf == eaf else np.nan)
    return np.nan, np.nan


def mr(d):
    bx, bxse = d["beta_exp"].values.astype(float), d["se_exp"].values.astype(float)
    by, byse = d["beta_out"].values.astype(float), d["se_out"].values.astype(float)
    ok = np.isfinite(bx) & np.isfinite(by) & np.isfinite(bxse) & np.isfinite(byse) & (bxse > 0) & (byse > 0)
    if ok.sum() < 3:
        return None
    bx, bxse, by, byse = bx[ok], bxse[ok], by[ok], byse[ok]
    r = dict(nsnp=int(ok.sum()))
    iv = ivw_pkg(bx, bxse, by, byse, "random")
    r.update(ivw=iv["estimate"], ivw_se=iv["se"], ivw_p=iv["p"], q_p=iv["q_p"])
    dl = ivw_dl(bx, bxse, by, byse)
    r.update(ivw_dl=dl["estimate"], ivw_dl_p=dl["p"])
    try:
        wm = weighted_median(bx, bxse, by, byse); r.update(wm=wm["estimate"], wm_p=wm["p"])
    except Exception:
        r.update(wm=np.nan, wm_p=np.nan)
    try:
        wd = weighted_mode(bx, bxse, by, byse); r.update(wmode=wd["estimate"], wmode_p=wd["p"])
    except Exception:
        r.update(wmode=np.nan, wmode_p=np.nan)
    eg = mr_egger_manual(bx, bxse, by, byse)
    r.update(egger=eg["estimate"], egger_p=eg["p"], egger_int=eg["intercept"],
             egger_int_p=eg["intercept_p"])
    r["F_mean"] = float(np.mean(bx ** 2 / bxse ** 2))
    r["F_min"] = float(np.min(bx ** 2 / bxse ** 2))
    return r


def main():
    log = LOGF

    def L(*a):
        s = " ".join(str(x) for x in a); print(s, flush=True); log.write(s + "\n"); log.flush()

    audit, results = [], []
    audit_rows = []
    # reconciled audit table (independent of whether recovery succeeded)
    recov = json.load(io.open(os.path.join(LOGD, "v3_hormone_extract_status.json"), encoding="utf-8")) \
        if os.path.exists(os.path.join(LOGD, "v3_hormone_extract_status.json")) else []
    recov_map = {}
    for r in recov:
        recov_map[r.get("dataset")] = r
    for key, meta in ENDPOINTS.items():
        present = os.path.exists(meta["path"])
        n_variants = None
        if present:
            d = pd.read_csv(meta["path"], sep="\t")
            n_variants = len(d)
        st = meta["status"]
        if present and st == "pending":
            st = "recovered_in_V3"
        if not present and st == "pending":
            st = "NOT_RECOVERED"
        audit_rows.append(dict(
            endpoint=meta["label"], endpoint_key=key, planned_dataset=meta["acc"],
            accession=meta["acc"], sample_size=meta["n"], sex="female",
            download_status=("file present" if present else
                             ("no tabix index published" if key == "SHBG_FEMALE" else "not retrieved")),
            file_integrity=("gzip/bgzf verified" if present else "not applicable"),
            instrument_coverage_D1=None, instrument_coverage_D3=None,
            instrument_coverage_ANM=None, harmonized_N=n_variants,
            analysis_possible=bool(present),
            reason_not_analysed=(None if present else meta["note"]),
            result_if_analysed=(None if not present else "see V3_HORMONAL_RESULTS.tsv"),
            recovery_status=st, v3_note=meta["note"]))
        if not present:
            L(f"[{meta['label']}] NOT ANALYSED - {meta['note']}")

    for key, meta in ENDPOINTS.items():
        if not os.path.exists(meta["path"]):
            continue
        out = pd.read_csv(meta["path"], sep="\t")
        out = out.dropna(subset=["key37"]) if "key37" in out.columns else out
        if "key37" not in out.columns:
            L(f"[{meta['label']}] no key37 column; cannot harmonise"); continue
        out["key37"] = out["key37"].astype(str)
        out = out.drop_duplicates("key37")
        for design in ["D1", "D2", "D3", "D4", "D5", "A1", "A2"]:
            # Prefer the deposited V2 harmonised matrix when it exists: it is the exact input
            # V1/V2 used and V3 has verified it reproduces their estimates to 1e-15. Only the
            # newly recovered endpoints are harmonised here.
            hpath = None
            for a in DESIGNS[design]["alias"]:
                p = os.path.join(V2, "06_HARMONIZED", f"{a}__{key}.tsv")
                if os.path.exists(p):
                    hpath = p
                    break
            if hpath is not None:
                hh = pd.read_csv(hpath, sep="\t")
                j2 = hh[["beta_exp", "se_exp", "beta_out", "se_out"]].apply(
                    pd.to_numeric, errors="coerce").dropna()
                rr = mr(j2)
                if rr is not None:
                    results.append(dict(endpoint=meta["label"], endpoint_key=key,
                                        accession=meta["acc"], exposure_design=design,
                                        role=DESIGNS[design]["role"],
                                        harmonisation_source="V2_deposited_aligned_matrix", **rr))
                continue
            ins = load_instruments(design)
            if ins is None or ins.empty:
                continue
            # Match on rsID, not on coordinate. The deposited regional extraction and the
            # instrument build disagree by 1-2 bp at some loci (e.g. rs80337039 is
            # 19:4105091 in the extraction and 19:4105089 in the instrument file), and
            # coordinate matching therefore silently discards most instruments.
            ins2 = ins.copy()
            ins2["rsid"] = ins2["rsid"].astype(str)
            out2 = out.copy(); out2["rsid"] = out2["rsid"].astype(str)
            j = ins2.merge(out2[["rsid", "ea", "oa", "eaf", "beta", "se", "p"]],
                           on="rsid", how="inner", suffixes=("_exp", "_out"))
            if len(j) < 3:
                continue
            # explicit, collision-free column construction
            hz = pd.DataFrame({
                "key": j["rsid"].values,
                "ea_exp": j["ea_exp"].values, "oa_exp": j["oa_exp"].values,
                "beta_exp": pd.to_numeric(j["beta_exp"], errors="coerce").values,
                "se_exp": pd.to_numeric(j["se_exp"], errors="coerce").values,
                "ea_out": j["ea_out"].values, "oa_out": j["oa_out"].values,
                "eaf_out": pd.to_numeric(j["eaf_out"], errors="coerce").values,
                "beta_out_raw": pd.to_numeric(j["beta_out"], errors="coerce").values,
                "se_out": pd.to_numeric(j["se_out"], errors="coerce").values,
                "p_out": pd.to_numeric(j["p_out"], errors="coerce").values,
            })
            # palindrome handling: drop uninformative palindromes
            pal = {(a, COMP[a]) for a in "ACGT"}
            keep = []
            for r in hz.itertuples():
                ispal = (str(r.oa_exp).upper(), str(r.oa_out).upper()) in pal
                if ispal and 0.42 <= float(r.eaf_out) <= 0.58:
                    continue
                keep.append(r.Index)
            j2 = hz.loc[keep].copy() if keep else hz.iloc[0:0].copy()
            b, ee = [], []
            for r in j2.itertuples():
                bb, e2 = align(r.ea_exp, r.oa_exp, r.ea_out, r.oa_out, r.beta_out_raw, r.eaf_out)
                b.append(bb); ee.append(e2)
            j2["beta_out"] = b
            j2 = j2.dropna(subset=["beta_out", "se_out", "beta_exp", "se_exp"])
            rr = mr(j2)
            if rr is None:
                continue
            rec = dict(endpoint=meta["label"], endpoint_key=key, accession=meta["acc"],
                       exposure_design=design, role=DESIGNS[design]["role"],
                       n_instruments=rr["nsnp"], harmonisation_source=locals().get("harmonisation_source","V3_reharmonised"), **rr)
            results.append(rec)
    res = pd.DataFrame(results)
    if len(res):
        res["n_instruments"] = res["n_instruments"].fillna(res["nsnp"])
        res["FDR_within_F4"] = np.nan
        for design, g in res.groupby("exposure_design"):
            res.loc[g.index, "FDR_within_F4"] = bh(g["ivw_p"].values)
        res["nominal"] = res["ivw_p"] < 0.05
        res["fdr_pass"] = res["FDR_within_F4"] < 0.05
        res = res.sort_values(["exposure_design", "endpoint"])
        res.to_csv(os.path.join(RES, "V3_HORMONAL_RESULTS_F4.tsv"), sep="\t", index=False)
        L("\n== F4 hormonal family, per exposure design (BH within design) ==")
        L(res[["exposure_design", "endpoint", "n_instruments", "ivw", "ivw_se", "ivw_p",
               "FDR_within_F4", "wm", "wmode", "egger_int_p", "q_p"]].round(6).to_string(index=False))
        counts = res.groupby("exposure_design").agg(
            n_endpoints=("endpoint", "size"), n_analysable=("endpoint", "nunique"),
            n_fdr_pass=("fdr_pass", "sum")).reset_index()
        L("\n== F4 family size actually corrected over ==")
        L(counts.to_string(index=False))
        counts.to_csv(os.path.join(RES, "V3_F4_FAMILY_SIZE.tsv"), sep="\t", index=False)

    aud = pd.DataFrame(audit_rows)
    # instrument coverage per design for the endpoints that were analysed
    if len(res):
        res["n_instruments"] = res["n_instruments"].fillna(res["nsnp"])
        cov = res.pivot_table(index="endpoint", columns="exposure_design",
                             values="n_instruments", aggfunc="max")
        for c in ("D1", "D3", "A1"):
            if c in cov.columns:
                aud[c.replace("D1", "instrument_coverage_D1").replace("D3", "instrument_coverage_D3")
                    .replace("A1", "instrument_coverage_ANM")] = aud["endpoint"].map(cov[c])
    aud.to_csv(os.path.join(RES, "V3_HORMONAL_ENDPOINT_AUDIT.tsv"), sep="\t", index=False)
    L("\n== hormonal endpoint audit ==")
    L(aud[["endpoint", "accession", "sample_size", "recovery_status", "analysis_possible",
           "harmonized_N", "reason_not_analysed"]].to_string(index=False))
    log.close()


if __name__ == "__main__":
    main()
