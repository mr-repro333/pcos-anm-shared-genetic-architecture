# -*- coding: utf-8 -*-
"""Materialise a working DATA_ROOT from the shipped package alone.

    python bootstrap_data_root.py --restore <target-dir>
    python bootstrap_data_root.py --check   <target-dir>

``--restore`` copies everything under ``10_INPUTS/`` into <target-dir>, preserving the
relative layout the code expects (``V2_2026/06_HARMONIZED``, ``05_INSTRUMENTS``,
``09_COLOCALIZATION``, ...). Point the environment variable ``PCOS_ANM_DATA_ROOT`` at
<target-dir> and every module in ``04_CODE`` runs unchanged.

``--check`` verifies an existing <target-dir> against ``V3_1_INPUT_MANIFEST.tsv``.

Nothing is deleted: the restore overlays. Re-running is idempotent.
"""
import argparse, hashlib, io, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
INP = os.path.join(PKG, "10_INPUTS")
MANIFEST = os.path.join(PKG, "03_RESULTS", "V3_1_INPUT_MANIFEST.tsv")


def restore(target):
    if not os.path.isdir(INP):
        raise SystemExit("10_INPUTS/ is not present next to 04_CODE/ - cannot restore")
    n = 0
    for root, dirs, files in os.walk(INP):
        for fn in files:
            s = os.path.join(root, fn)
            rel = os.path.relpath(s, INP)
            t = os.path.join(target, rel)
            os.makedirs(os.path.dirname(t), exist_ok=True)
            if (not os.path.exists(t)) or os.path.getsize(t) != os.path.getsize(s):
                shutil.copy2(s, t)
                n += 1
    print("restored %d file(s) into %s" % (n, target))
    return n


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def check(target):
    if not os.path.exists(MANIFEST):
        raise SystemExit("V3_1_INPUT_MANIFEST.tsv is missing; run v31_provenance.py first")
    import csv
    ok = bad = miss = 0
    rows = []
    with io.open(MANIFEST, encoding="utf-8") as fh:
        for r in csv.DictReader(fh, delimiter="\t"):
            rel = r["relative_path_in_package"].replace("10_INPUTS/", "", 1)
            p = os.path.join(target, rel)
            if not os.path.exists(p):
                miss += 1; rows.append(("MISSING", rel)); continue
            if os.path.getsize(p) != int(r["bytes"]) or sha256(p) != r["sha256"]:
                bad += 1; rows.append(("MISMATCH", rel)); continue
            ok += 1
    print("manifest check against %s: %d OK, %d mismatched, %d missing" % (target, ok, bad, miss))
    for s, rel in rows[:20]:
        print("  %-9s %s" % (s, rel))
    return 0 if (bad == 0 and miss == 0) else 1


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--restore", metavar="DIR")
    ap.add_argument("--check", metavar="DIR")
    a = ap.parse_args()
    if a.restore:
        restore(a.restore)
    if a.check:
        sys.exit(check(a.check))
    if not (a.restore or a.check):
        ap.print_help()
