# -*- coding: utf-8 -*-
"""V3.2 patch A - generators and gates.

Five edits, none of which touches the analysis or any result value:

  1. v31_refs.py      : print the verified DOI of every reference entry (Springer "always
                        include DOIs"), add the 2026 renaming consensus, and update the module
                        note that used to explain why DOIs were omitted.
  2. v31_validate.py  : upgrade the two gates the DOI change invalidates - the old gate demanded
                        that no DOI token appear anywhere, the new one requires DOIs to appear
                        only in the reference list and excludes the reference block from the
                        numeric scan instead.
  3. v31_docs_extra.py / v31_fshb.py : the LD-pruned PP.H4 was hard-coded as 0.999990, which
                        contradicts the table it is meant to describe. Both sites now read the
                        value from the result file.
  4. v31_docs_extra.py: the changelog printed the file list in the "consequence" column and then
                        iterated the consequence string character by character under "files
                        touched". Field order corrected.
  5. v31_docs_round2.py: KNOWN_LIMITATIONS still carried the withdrawn MR-Egger objection as an
                        open limitation while the same file records it as closed further down.

Every replacement asserts that it matched exactly once.
"""
import ast, io, os

HERE = os.path.dirname(os.path.abspath(__file__))


def sub(path, old, new, tag):
    p = os.path.join(HERE, path)
    src = io.open(p, encoding="utf-8").read()
    n = src.count(old)
    if n != 1:
        raise SystemExit("PATCH ABORT [%s]: matched %d times (expected 1)\n--- old ---\n%s"
                         % (tag, n, old[:400]))
    src = src.replace(old, new, 1)
    ast.parse(src)
    io.open(p, "w", encoding="utf-8", newline="\n").write(src)
    print("  ok  %-30s %s" % (tag, path))


# --------------------------------------------------------------- 1. references + DOI
DOI_BLOCK = '''
# --------------------------------------------------------------------------- DOIs
# Resolved live from the Europe PMC "core" record of each PMID (the `doi` field) in the same
# session that produced the reference list; the CrossRef entries carry their DOI in the
# resolving identifier above. Springer asks for DOIs as full links wherever they exist, so
# `render_references` appends one to every entry that has one. Two entries have none: a 1949
# book, and one 2026 article whose PubMed record carries no DOI field yet.
DOI = {
    "g1k2015": "10.1038/nature15393",
    "bh1995": "10.1111/j.2517-6161.1995.tb02031.x",
    "bowden2015": "10.1093/ije/dyv080",
    "bowden2016": "10.1002/gepi.21965",
    "bowden2017": "10.1002/sim.7221",
    "bowden2016i2": "10.1093/ije/dyw220",
    "ldsc2015": "10.1038/ng.3211",
    "burgess2013": "10.1002/gepi.21758",
    "burgess2016": "10.1002/gepi.21998",
    "chen2021": "10.1038/s41588-021-00852-9",
    "falconer1965": "10.1111/j.1469-1809.1965.tb00500.x",
    "coloc2014": "10.1371/journal.pgen.1004383",
    "graham2021": "10.1038/s41586-021-04064-3",
    "hartwig2017": "10.1093/ije/dyx102",
    "karczewski2025": "10.1038/s41588-025-02335-7",
    "finn2023": "10.1038/s41586-022-05473-8",
    "lee2011": "10.1016/j.ajhg.2011.02.002",
    "lo2023": "10.1093/ehjopen/oead061",
    "loh2018": "10.1038/s41588-018-0144-6",
    "moolhuijsen2026": "10.1038/s41588-026-02543-9",
    "morris2019": "10.1038/s41588-018-0302-x",
    "nethander2023": "10.1038/s41588-023-01527-3",
    "neven2026": "10.1093/humupd/dmaf030",
    "pulit2019": "10.1093/hmg/ddy327",
    "rotterdam2004": "10.1016/j.fertnstert.2003.10.004",
    "ruth2020": "10.1038/s41591-020-0751-5",
    "ruth2021": "10.1038/s41586-021-03779-7",
    "sanderson2019": "10.1093/ije/dyy262",
    "strobemr2021": "10.1001/jama.2021.18236",
    "venkatesh2025": "10.1038/s41588-025-02156-8",
    "susie2020": "10.1111/rssb.12388",
    "yavorska2017": "10.1093/ije/dyx034",
    "yengo2018": "10.1093/hmg/ddy271",
    "zhao2025": "10.1038/s41588-025-02393-x",
    "aragam2022": "10.1038/s41588-022-01233-6",
    "barton2021": "10.1038/s41588-021-00892-1",
    "pmos2026": "10.1016/S0140-6736(26)00717-8",
}


def entry_with_doi(key, full):
    d = DOI.get(key)
    return full if not d else "%s. https://doi.org/%s" % (full.rstrip("."), d)


'''

NEW_REFS_HEAD = '''REFS = [
    ("pmos2026",
     "Teede et al., 2026",
     "Teede HJ, Khomami MB, Morman R, Laven JSE, Joham AE, Costello MF, et al (2026) "
     "Polyendocrine metabolic ovarian syndrome, the new name for polycystic ovary syndrome: "
     "a multistep global consensus process. Lancet 407:2329-2339",
     "PMID 42119588"),
'''

OLD_RENDER = '''def render_references():
    """Alphabetical reference list, as Springer Basic requires."""
    ordered = sorted(REFS, key=lambda r: r[2].lower())
    lines = ["## References", ""]
    for _k, _ny, full, _rid in ordered:
        lines.append(full)
        lines.append("")
    return "\\n".join(lines).rstrip() + "\\n"'''

NEW_RENDER = '''def render_references():
    """Alphabetical reference list with DOI links, as Springer Basic requires."""
    ordered = sorted(REFS, key=lambda r: r[2].lower())
    lines = ["## References", ""]
    for _k, _ny, full, _rid in ordered:
        lines.append(entry_with_doi(_k, full))
        lines.append("")
    return "\\n".join(lines).rstrip() + "\\n"'''

OLD_NOTE = """Author lists are truncated at six names followed by "et al", which is the Springer Basic
convention. DOIs are deliberately not printed in the manuscript: the fail-closed numeric gate
scans the manuscript for any 4-6 decimal token and requires each to be a rounding of a shipped
result value, and a DOI such as 10.1038/... would collide with that gate. The resolving
identifier for every entry is carried in REF_AUDIT below and in
03_RESULTS/V3_1_REFERENCE_AUDIT.tsv instead."""

NEW_NOTE = """Author lists are truncated at six names followed by "et al", which is the Springer Basic
convention, and every entry that has a DOI carries it as a full https://doi.org/ link, which the
journal asks for. The resolving identifier for every entry is additionally carried in REF_AUDIT
below and in 03_RESULTS/V3_1_REFERENCE_AUDIT.tsv.

The numeric gate in v31_validate.py scans the manuscript for 4-6 decimal tokens and requires
each to be a rounding of a shipped result value, and a DOI suffix looks exactly like such a
token. That gate now excludes the reference block, rather than the reference list being kept
free of DOIs to protect the gate."""


def patch_refs():
    p = os.path.join(HERE, "v31_refs.py")
    src = io.open(p, encoding="utf-8").read()
    for old, new, tag in [(OLD_NOTE, NEW_NOTE, "refs note"),
                          ("\nC = {k: \"(%s)\" % ny for k, ny, _full, _rid in REFS}",
                           DOI_BLOCK + "\nC = {k: \"(%s)\" % ny for k, ny, _full, _rid in REFS}",
                           "doi block"),
                          ("REFS = [\n", NEW_REFS_HEAD, "pmos2026 entry"),
                          (OLD_RENDER, NEW_RENDER, "render with DOI")]:
        n = src.count(old)
        if n != 1:
            raise SystemExit("PATCH ABORT [%s]: %d matches" % (tag, n))
        src = src.replace(old, new, 1)
    ast.parse(src)
    io.open(p, "w", encoding="utf-8", newline="\n").write(src)
    print("  ok  %-30s %s" % ("refs + DOI", "v31_refs.py"))


# --------------------------------------------------------------- 2. gates
def patch_gates():
    sub("v31_validate.py",
        '''    gate("J PRESENTATION", "no DOI token appears in the manuscript, so the numeric gate stands",
         not re.search(r"\\b10\\.\\d{4,5}/", man))''',
        '''    # DOI links are required in the reference list. The gate now checks placement rather than
    # absence: no DOI may appear anywhere the numeric scan reads as body text.
    _ref_i = man.find("\\n## References\\n")
    _body_only = man[:_ref_i] if _ref_i >= 0 else man
    _ref_only = man[_ref_i:] if _ref_i >= 0 else ""
    _d_body = re.findall(r"\\b10\\.\\d{4,5}/[^\\s)]+", _body_only)
    _d_list = re.findall(r"https://doi\\.org/10\\.\\d{4,5}/", _ref_only)
    gate("J PRESENTATION", "DOI links appear only in the reference list",
         (not _d_body) and len(_d_list) >= 30,
         "in body: %d ; in list: %d" % (len(_d_body), len(_d_list)))''',
        "gate: DOI placement")
    sub("v31_validate.py",
        '''    suspicious, abs_matched = [], 0
    for tok in sorted(set(re.findall(r"\\b\\d+\\.\\d{4,6}\\b", man))):''',
        '''    # The reference block is excluded: a publisher DOI suffix is formatted like a 6-decimal
    # result value and is not one. This narrows the scan to what it was always about - numbers in
    # the body text, the tables and the figure legends.
    _ri = man.find("\\n## References\\n")
    _scan = (man[:_ri] + man[man.find("\\n## Statements and Declarations\\n"):]
             if _ri >= 0 else man)
    suspicious, abs_matched = [], 0
    for tok in sorted(set(re.findall(r"\\b\\d+\\.\\d{4,6}\\b", _scan))):''',
        "gate: numeric scan excludes refs")


# --------------------------------------------------------------- 3. LD-pruned PP.H4
def patch_pp4():
    sub("v31_docs_extra.py",
        "| PP.H4 after LD pruning | 0.999990 |",
        "| PP.H4 after LD pruning | {F['fshb']['pp4_after_LD_pruning']:.6f} "
        "(full precision {F['fshb']['pp4_after_LD_pruning']:.9f}) |",
        "supplement LD-pruned value")
    sub("v31_fshb.py",
        'v31_required="0.998960 / 0.989699-0.999896 / 0.999990",',
        'v31_required=("0.998960 / 0.989699-0.999896 / %.6f (full precision %.9f)"\n'
        '                          % (facts["pp4_after_LD_pruning"], facts["pp4_after_LD_pruning"])),',
        "fshb required string")


# --------------------------------------------------------------- 4. changelog columns
def patch_changelog():
    sub("v31_docs_extra.py",
        '''    for e in E:
        md.append("| %s | %s | %s | %s | %s | %s | %s |" % e[:7])
    md += ["", "## Files touched by each entry", "", "| id | files |", "|---|---|"]
    for e in E:
        md.append("| %s | %s |" % (e[0], "; ".join("`%s`" % f for f in e[7])))''',
        '''    # each entry is (id, blocker, kind, item, before, after, [files], consequence). The two
    # trailing members were printed into the opposite columns, which put the file list under
    # "consequence" and then iterated the consequence string character by character below.
    for e in E:
        md.append("| %s | %s | %s | %s | %s | %s | %s |"
                  % (e[0], e[1], e[2], e[3], e[4], e[5], e[7]))
    md += ["", "## Files touched by each entry", "", "| id | files |", "|---|---|"]
    for e in E:
        md.append("| %s | %s |" % (e[0], "; ".join("`%s`" % f for f in e[6])))''',
        "changelog columns")
    sub("v31_docs_extra.py",
        '''        entries=[dict(id=e[0], blocker=e[1], kind=e[2], item=e[3], before=e[4], after=e[5],
                      consequence=e[6], files=e[7]) for e in E],''',
        '''        entries=[dict(id=e[0], blocker=e[1], kind=e[2], item=e[3], before=e[4], after=e[5],
                      consequence=e[7], files=e[6]) for e in E],''',
        "changelog json fields")


# --------------------------------------------------------------- 5. KNOWN_LIMITATIONS
def patch_kl():
    sub("v31_docs_round2.py",
        "12. **MR-Egger.** The packaged estimator does not reproduce the textbook estimator on "
        "identical input; the discrepancy is reported and MR-Egger carries no conclusion.",
        "12. **MR-Egger.** Closed in the rebuild rounds: the packaged estimator is the "
        "orientation-compliant one and reproduces 244 of 244 pairs exactly. MR-Egger is carried as "
        "a sensitivity statistic because its InSIDE assumption is untestable in these data.",
        "KNOWN_LIMITATIONS MR-Egger")


if __name__ == "__main__":
    print("V3.2 patch A")
    patch_refs()
    patch_gates()
    patch_pp4()
    patch_changelog()
    # patch_kl() applied directly to v31_docs_extra.py qc() (see build log)
    print("done")
