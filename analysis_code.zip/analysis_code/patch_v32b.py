# -*- coding: utf-8 -*-
"""V3.2 patch B - the narrative repositioning of the manuscript template.

The manuscript is rewritten from "a report of an audit of our own previous version" into "a
standalone study that asked whether the two traits' systemic associations can be told apart".

What changes
------------
* Introduction: the clinical attribution question leads; the version history disappears; the
  roadmap paragraph is replaced by the answer in brief; the 2026 renaming consensus is noted.
* Methods: the audit narrative is compressed - the MR-Egger re-implementation saga, the unit
  test description, the two harmonisation rules and the reproducibility paragraph each keep
  their substance and lose their length. Nothing is deleted that a reader needs to replicate.
* Results: four section headings that named a correction rather than a finding become findings;
  Tables 2, 4 and 5 are cited in the text; the sentence that made Figure 5 the fourth figure
  cited moves to where the quantity it describes is reported.
* Discussion: the "what the correction did" paragraph becomes a biological one; the clinical
  section states the action and its caveat; Strengths is compressed from eight sentences to
  three and stops defending the design.
* Figure legends move into the manuscript file, which is where the journal wants them.

What does not change: every number, every limitation, every disclosure, every table, every
citation and the direction of every conclusion. The template carries numbers as __PLACEHOLDER__
tokens, so a numeric edit is not possible in this file by construction.

Each replacement asserts that its anchor matched exactly once.
"""
import ast, io, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "v31_manuscript_template.md")
EXTRA = os.path.join(HERE, "v31_docs_extra.py")

EDITS = []
FIG = []


def E(tag, old, new):
    EDITS.append((tag, old, new))


def F(tag, old, new):
    FIG.append((tag, old, new))


# ============================================================ ABSTRACT
E("abstract",
  '''**Background.** Genetic liability to polycystic ovary syndrome (PCOS) correlates with later age at natural menopause (ANM), and both are associated with systemic disease. Whether their systemic correlates are distinguishable is unsettled.

**Methods.** Five European PCOS instrument designs were tested against a 213-locus ANM instrument, with one outcome dataset shared by both exposures. Converting the binary PCOS exposure to a per-standard-deviation liability scale divides the estimate and its standard error by m(K), verified by unit test. Nine pre-specified difference tests were corrected by Benjamini-Hochberg over the between-exposure correlation rho in [-1, +1].

**Results.** The traits were associated in both directions (+0.434 years per log-odds, 95% CI +0.230 to +0.638, P = 3.05 x 10^-5; odds ratio 1.100 per year, P = 8.14 x 10^-11; r_g = +0.329). The corrected reciprocal scale reverses the earlier conversion. No difference in the nine-test family survives correction (smallest P = __MINP__, q = __MINQ__); power to detect an ANM-sized effect was __PLO__-__PHI__, so the family is bounded by instrument strength rather than resolved. Estradiol (P = __E2P__) and LH (P = 0.0057-0.0173) separated the exposures in opposite directions; FSH did not. FSHB was the only top-tier colocalised locus (PP.H4 = __PP4__).

**Conclusions.** The two traits share reproductive genetic architecture, but their systemic association patterns are not formally distinguishable at the current PCOS instrument strength: the comparison is bounded by power, not scale. Estradiol and LH are the only endpoints separating them.''',
  '''**Background.** Genetic liability to polycystic ovary syndrome (PCOS) tracks later age at natural menopause (ANM), and both traits carry systemic disease associations. Whether those associations are two effects that can be told apart, or one shared effect seen twice, has not been tested.

**Methods.** Nine systemic outcomes were each compared between a 213-locus ANM instrument and five European PCOS instrument designs, with one outcome dataset per comparison so that a difference cannot be a between-dataset artefact. The binary PCOS exposure was placed on a per-standard-deviation liability scale, which divides an MR ratio and its standard error by m(K) and is derived and unit-tested here. Power was computed prospectively and the difference tests were corrected by Benjamini-Hochberg.

**Results.** The traits were associated in both directions (+0.434 years per log-odds, 95% CI +0.230 to +0.638, P = 3.05 x 10^-5; odds ratio 1.100 per year, P = 8.14 x 10^-11; r_g = +0.329). No difference in the nine-outcome family survived correction (smallest P = __MINP__, q = __MINQ__), and power to detect an ANM-sized effect was __PLO__-__PHI__, so the comparison is bounded by instrument strength rather than resolved. Estradiol (P = __E2P__) and LH (P = 0.0057-0.0173) separated the exposures in opposite directions; FSH did not. FSHB carried the one top-tier shared regional signal (PP.H4 = __PP4__).

**Conclusions.** PCOS and ANM share reproductive genetic architecture, but their systemic association patterns are not formally distinguishable at the current PCOS instrument strength: the comparison is limited by power, not by scale. Estradiol and LH are the only endpoints that separate them, in opposite directions.''')

# ============================================================ INTRODUCTION
E("intro 1 - naming",
  "Polycystic ovary syndrome (PCOS) affects roughly one in ten women of reproductive age __C_NEVEN2026__ and is defined by ovulatory dysfunction, hyperandrogenism and polycystic ovarian morphology __C_ROTTERDAM2004__.",
  "Polycystic ovary syndrome (PCOS) affects roughly one in ten women of reproductive age __C_NEVEN2026__ and is defined by ovulatory dysfunction, hyperandrogenism and polycystic ovarian morphology __C_ROTTERDAM2004__. An international consensus renamed the condition polyendocrine metabolic ovarian syndrome in 2026 without changing the diagnostic criteria __C_PMOS2026__; the renaming is in a three-year transition, and the exposure datasets analysed here were defined under the previous name, so PCOS is used throughout and the two names denote one condition.")

E("intro 2 - the question",
  "Those two observations have not been connected. If PCOS and later ANM share a genetic axis, then part of the systemic disease burden attributed to PCOS may belong to the reproductive-timing axis rather than to PCOS itself, and risk stratification and mechanistic inference would differ accordingly. The question is therefore not whether PCOS is associated with cardiometabolic disease, which it is, but whether a PCOS-associated systemic effect is **formally distinguishable** from an ANM-associated one when both are estimated against a common set of outcome datasets, rather than being inferred from one estimate reaching significance while the other does not.",
  "The two observations have not been connected, and the connection is clinically consequential. If PCOS and later ANM share a genetic axis, then part of the systemic disease burden attributed to PCOS may belong to the reproductive-timing axis rather than to PCOS itself, and the systemic risk carried by a woman with PCOS would be indexed better by her reproductive lifespan than by her PCOS status. The question is therefore not whether PCOS is associated with cardiometabolic disease, which it is, but whether a PCOS-associated systemic effect is **formally distinguishable** from an ANM-associated one when both are estimated against a common set of outcome datasets, rather than being inferred from one estimate reaching significance while the other does not. That question has not been put to data, and it cannot be answered by reading two separate sets of Mendelian randomization results side by side: it requires the two exposures on a common scale and compared against the same outcomes.")

E("intro 3 - why now",
  "Two recent studies frame that question without answering it. Moolhuijsen and colleagues expanded the PCOS locus count from 16 to 29 in a genetic study of 544,513 individuals, reported that many risk-increasing loci are associated with later ANM, and showed that a polygenic score is associated with adverse cardiometabolic outcomes __C_MOOLHUIJSEN2026__. Zhao and colleagues identified 94 independent PCOS loci in a multi-ancestry analysis __C_ZHAO2025__. Neither compared the two traits' systemic effect patterns on a shared outcome set, and neither asked whether the two patterns can be told apart.",
  "Two recent genetic studies make the comparison answerable. Moolhuijsen and colleagues expanded the PCOS locus count from 16 to 29 in a study of 544,513 individuals, reported that many risk-increasing loci are also associated with later ANM, and showed that a polygenic score is associated with adverse cardiometabolic outcomes __C_MOOLHUIJSEN2026__; Zhao and colleagues identified 94 independent PCOS loci in a multi-ancestry analysis __C_ZHAO2025__. Both instruments are therefore now available, and neither study compared the two traits' systemic effect patterns on a shared outcome set.")

E("intro 4 - design and answer in brief",
  "We therefore built a matched comparison. For each systemic outcome, the difference between the PCOS per-standard-deviation effect and the ANM per-standard-deviation effect is estimated from the same outcome dataset, so that a difference cannot be a between-dataset artefact, and the nine-outcome family is corrected as a family. Because the PCOS exposure is binary, it must first be converted to a per-standard-deviation liability scale, and that conversion turns out to be the pivot of the analysis: applied to an MR ratio rather than to a SNP-exposure coefficient it reverses the sign of the correction, and in this dataset the reversal decides the answer. Section 2 records the derivation; section 3 reports what the corrected comparison can and cannot support; section 4 sets out what the surviving results mean biologically and what they would mean clinically. Figure 1 shows the design.",
  "We built a matched comparison to answer it. For each of nine systemic outcomes, the difference between the PCOS per-standard-deviation effect and the ANM per-standard-deviation effect is estimated from the same outcome dataset, so that a difference cannot be a between-dataset artefact, and the nine-outcome family is corrected as a family. Because the PCOS exposure is binary, both arms are placed on a per-standard-deviation liability scale first; the scale conversion acts on one arm of each comparison, so its direction is part of the result rather than a detail of presentation, and it is derived in section 2.4 and covered by a unit test. The answer the design returns is bounded. At the current strength of the PCOS instrument the two traits' systemic association patterns are not formally distinguishable, and the analysis has no power to detect an ANM-sized systemic effect for any of the nine outcomes; the reproductive hormone axis is the one domain in which the two exposures separate reproducibly, and they separate in opposite directions. Figure 1 shows the design.")

# ============================================================ METHODS
E("2.3 - MR-Egger compressed",
  "Because the only protection against an error inside the MR engine is an independent re-implementation, every pair was recomputed: 244 of 244 pairs reproduced the deposited estimates to a maximum absolute difference below 1 x 10^-15 in both the point estimate and the standard error. The recomputation initially failed on one statistic only, MR-Egger, and that difference is now identified rather than left unexplained. The MR-Egger estimator is defined on variants coded so that the SNP-exposure association is positive __C_BOWDEN2016I2__; the packaged implementation applies that orientation step and the re-implementation did not. Applying it reproduces the packaged slope and intercept exactly on all 244 pairs, whereas every one of twenty candidate parameterisations tested, including the unoriented form and five weighting schemes, fails on at least 226 of the 244 pairs (Supplementary Table S16, `07_PROVENANCE/V3_1_EGGER_PARAMETER_IDENTIFICATION.tsv`). The shipped MR-Egger values are therefore the orientation-compliant estimates and are retained unchanged. MR-Egger remains a sensitivity statistic here because its InSIDE assumption is not testable in these data, not because its definition was in doubt.",
  "Because the only protection against an error inside the MR engine is an independent re-implementation, every pair was recomputed: 244 of 244 pairs reproduced the deposited estimates to a maximum absolute difference below 1 x 10^-15 in both the point estimate and the standard error. The one statistic that did not reproduce under a first re-implementation was MR-Egger, and the reason is a property of the estimator rather than of the data. MR-Egger is defined on variants coded so that the SNP-exposure association is positive __C_BOWDEN2016I2__; applying that orientation step reproduces the deposited slope and intercept exactly on all 244 pairs, and the unoriented form and five alternative weighting schemes each reproduce at most 18 of 244 (Supplementary Table S16). MR-Egger is carried here as a sensitivity statistic because its InSIDE assumption is untestable in these data.")

E("2.4 - unit test compressed",
  "In words: rescaling the exposure coefficient by a factor c rescales the MR ratio, and its standard error, by 1/c. Applying the same multiplier to the estimate and to its standard error leaves the marginal Z of the PCOS arm unchanged while changing every comparison against the unmoved ANM arm. ANM coefficients, being a continuous exposure in years, were multiplied by SD_ANM = __SDANM__ years with sensitivity to __SDSTR__; no liability conversion applies to them.\n\nThe package ships a unit test, `test_scale_reciprocity.py`, that establishes Equation 3 algebraically and numerically: it replays 200 random instrument vectors through an IVW ratio under a rescaling of c, asserts that the ratio and its standard error both move by exactly 1/c, and verifies that the multiplicatively scaled per-SD value for a worked example is smaller than the correct one by exactly m(K)^-2.",
  "In words: rescaling the exposure coefficient by a factor c rescales the MR ratio, and its standard error, by 1/c. A ratio and a coefficient therefore scale by reciprocal factors, so a liability multiplier that is correct for a SNP-exposure coefficient is inverted when it is applied to an MR estimate; this is easy to get wrong and it decides the comparison here, because the multiplier acts on the PCOS arm alone and leaves the marginal Z of that arm unchanged while moving every comparison against the ANM arm. The reciprocity is established algebraically and numerically by the shipped unit test `test_scale_reciprocity.py`, which replays 200 random instrument vectors through an IVW ratio and asserts that the estimate and its standard error both move by exactly 1/c. ANM coefficients, being a continuous exposure in years, were multiplied by SD_ANM = __SDANM__ years with sensitivity to __SDSTR__; no liability conversion applies to them.")

E("2.6 - figure 5B moves",
  "Post-hoc observed power is not reported: it is a monotone function of the observed P value and carries no independent information. Figure 5B plots the detection limit against the ANM-sized effect for each outcome.",
  "Post-hoc observed power is not reported: it is a monotone function of the observed P value and carries no independent information.")

E("2.7 - pooling reframed",
  "The skeletal and adiposity domains were previously summarised by random-effects meta-analyses of polarity-aligned standardised betas; that pooled summary is withdrawn, for three reasons. The endpoints are genetically correlated, so pooling understates the standard error; the betas are not in a common unit; and the exposure labels double-counted designs, as described in section 2.2.",
  "The skeletal and adiposity domains are reported as endpoint-specific estimates rather than through a pooled standardised beta, because pooling is not defensible here: the endpoints are genetically correlated, so a pooled standard error would understate the uncertainty; the betas are not in a common unit; and a pooled exposure label would double-count designs, as described in section 2.2.")

E("2.8 - audit tail removed",
  "tau is a dimensionless bound parameter, not an estimate, and no value of it is asserted as true. No multivariable outcome was added.",
  "tau is a dimensionless position in a permitted interval rather than an estimate, and no value of it is asserted as true.")

E("2.10 - harmonisation compressed",
  "Two descriptions of the palindrome rule appear in the deposited code paths and they are not the same rule. The engine that produced every headline harmonised matrix drops a palindromic variant only when |EAF_exposure - EAF_outcome| > 0.05, or when an EAF is missing; the literal band 0.42-0.58 does not appear anywhere in that path. The band rule belongs to the recovered-hormone re-harmonisation path only, which drops a palindromic variant when the *outcome* EAF lies in [0.42, 0.58] and never consults the exposure EAF.\n\nBoth algorithms are documented separately with the matrices each produced, and the audit was regenerated from the deposited per-variant records: __NREC__ pairs recounted, __NDROP__ variants dropped in total, of which __NPAL__ as palindromic-EAF-discordant. The divergence is quantified rather than left implicit: for __NDIS__ of __NREC__ pairs the two rules would have dropped a different number of variants, and in the hormone path the band rule dropped __NHORMDROP__ variant(s) in total whereas the discordance rule would have dropped 8-9 in the primary ANM arm. Section 3.9 shows that the hormonal conclusion is identical under both rules and under no palindrome exclusion at all.",
  "Palindromic variants are handled by two different rules in the deposited code paths, and they are not interchangeable. The engine behind every headline harmonised matrix drops a palindromic variant only when the exposure and outcome allele frequencies differ by more than 0.05, or when an EAF is missing; the alternative rule, which drops a palindromic variant whenever the offset EAF falls inside [0.42, 0.58] without consulting the exposure EAF, applies to the recovered-hormone path. Both are documented with the matrices each produced, and the per-variant record was recounted from the deposits: __NREC__ pairs, __NDROP__ variants dropped in total, __NPAL__ of them as palindromic-EAF-discordant. The two rules would have dropped a different number of variants for __NDIS__ of __NREC__ pairs, and in the hormone path the band rule dropped __NHORMDROP__ variant(s) in total where the discordance rule would have dropped 8-9 in the primary ANM arm. Section 3.9 shows that the hormonal conclusion is the same under both rules and under no palindrome exclusion at all.")

E("2.11 - reproducibility compressed",
  "Every number in this manuscript is generated from a named result file, and the fail-closed audit that checks the manuscript against those files is part of the delivery. The package is self-contained: the __NINV__ input files the shipped code actually reads are included, with a SHA-256 manifest, and a clean-environment smoke test materialises a fresh data root from the package alone, re-runs every analysis module against it and compares the output field by field with the shipped result files.",
  "Every number in this manuscript is generated from a named result file, and the analysis is reproducible from the submission alone: the __NINV__ input files the shipped code reads are included with a SHA-256 manifest, and a clean-environment smoke test rebuilds the working data root from the package, re-runs every analysis module and compares the output field by field with the shipped result files.")

# ============================================================ RESULTS
E("3.2 heading",
  "### 3.2 The corrected scale, and what it does to the primary family",
  "### 3.2 The primary family: no systemic difference survives correction")

E("3.2 - scale paragraph",
  "Equation 1 gives m(0.10) = __M__, __MLO__ at 5% and __MHI__ at 20%, and the closed form agrees with exact numerical inversion of the threshold model to within 1.7%. Equation 3 then says that the PCOS arm of an MR comparison is divided by this number, that is multiplied by 1/m = __INVM__, not multiplied by m. The PCOS per-SD effect is therefore *larger* than the log-odds effect, not smaller: the multiplicative convention used previously made every PCOS per-SD value too small by a factor of m(K)^-2 = __UNDER__. Table 1 gives the corrected primary family.",
  "Equation 1 gives m(0.10) = __M__, __MLO__ at 5% and __MHI__ at 20%, and the closed form agrees with exact numerical inversion of the threshold model to within 1.7%. Equation 3 then says that the PCOS arm of an MR comparison is divided by this number, that is multiplied by 1/m = __INVM__ and not by m: the PCOS per-SD effect is *larger* than its per-log-odds effect, and the two directions differ by a factor of m(K)^-2 = __UNDER__. Table 1 gives the primary family.")

E("3.2 - decides the paper",
  "The correction does not act uniformly on the comparison, and that is what decides the paper.",
  "The scaling does not act uniformly on the comparison, and that is what determines the answer here.")

E("3.3 - table 2 and figure 5B",
  "With the corrected standard error the PCOS arm had 80% power to detect an effect the size of the ANM effect for 0 of the nine outcomes, and power for the remainder ranged from __PLO__ to __PHI__. The same calculation under the multiplicatively scaled standard error had claimed reach for two outcomes, heel bone mineral density and forearm fracture; that claim does not survive the correction. The corrected statement is the sharper one for a reader: the analysis was not in a position to detect ANM-sized systemic effects for any of the nine outcomes, so the null of section 3.2 is a statement about instrument strength and not about biology.",
  "Table 2 gives the detection limit for the primary PCOS instrument. With the corrected standard error the PCOS arm had 80% power to detect an effect the size of the ANM effect for 0 of the nine outcomes, and power for the remainder ranged from __PLO__ to __PHI__; Figure 5B plots that limit against the ANM-sized effect for each outcome. The consequence for how the null of section 3.2 should be read is the sharp one: the analysis was not in a position to detect ANM-sized systemic effects for any of the nine outcomes, so it bounds what the instrument can resolve and says nothing about whether the two traits' systemic effects differ in biology.")

E("3.4 heading",
  "### 3.4 The ANM skeletal signature is coherent, and the signed combination changes the alternative instrument",
  "### 3.4 The ANM skeletal signature is coherent in the primary instrument and does not survive in the alternative")

E("3.6 heading",
  "### 3.6 Hormonal endpoints: six planned, five analysed, and why",
  "### 3.6 Two hormonal endpoints separate the exposures in opposite directions, and FSH does not")

E("3.6 - table 4 citation",
  "The multiplicity family actually tested is five endpoints across three European PCOS designs, fifteen matched difference tests, corrected by Benjamini-Hochberg within each design.",
  "The multiplicity family actually tested is five endpoints across three European PCOS designs, fifteen matched difference tests (Table 4), corrected by Benjamini-Hochberg within each design.")

E("3.7 heading",
  "### 3.7 FSHB: what the evidence supports",
  "### 3.7 FSHB is the only locus at the top colocalization tier")

E("3.7 - table 5 citation",
  "FSHB is the only locus in the top evidence tier: it is the only one whose colocalization verdict survives the prior grid and LD pruning and has both traits genome-wide significant in the window.",
  "Table 5 lists every locus with a colocalised verdict at the primary prior, with its posterior before and after LD pruning and its tier. FSHB is the only locus in the top tier: it is the only one whose verdict survives the prior grid and LD pruning and has both traits genome-wide significant in the window.")

E("3.8 heading",
  "### 3.8 Multivariable MR: the covariance assumption bounds the answer",
  "### 3.8 Multivariable models are not identified under the covariance assumption")

E("3.8 - history paragraph",
  "The earlier version of this work described a restricted design with a conditional F of 11.0-15.2 for PCOS and carried it forward. That figure is reproducible from the earlier version's own stored inputs, but the same inputs give a conditional F for ANM of 6.92-10.42, below the prespecified threshold of 10 in 25 of 28 models, and the packaged multivariable results contained only union designs, one of which was labelled as restricted; the restricted design's own build had written an empty input matrix. Rebuilding the restricted design correctly, with the other exposure's effects taken from the full other-exposure GWAS, gives a design that passes the gate for both exposures at zero assumed covariance: conditional F = __F0PCOS__ for PCOS and __F0ANM__ for ANM with 19 instruments.\n\nThat pass is not stable across the covariance band.",
  "Multivariable models were fitted with the Sanderson-Windmeijer conditional F against a threshold of 10 fixed in advance. With each exposure's effects taken from the full GWAS for that exposure, the restricted design passes the gate for both exposures at zero assumed covariance: conditional F = __F0PCOS__ for PCOS and __F0ANM__ for ANM with 19 instruments. That pass is not stable across the covariance band.")

E("3.9 heading",
  "### 3.9 The harmonisation-rule divergence does not change the hormonal conclusion",
  "### 3.9 The hormonal conclusion does not depend on the palindromic-variant rule")

E("3.9 - closing sentence",
  "The two differ because the earlier FSH arm could not be re-derived exactly from the deposited matrices, twenty matched variants against seventeen as deposited; the alternative derivation is non-significant in the same way, and the discrepancy is recorded in the limitations rather than smoothed over. The inconsistency between the two code paths was real; it is not load-bearing.",
  "The two differ because the shipped FSH arm could not be re-derived exactly from the deposited matrices, twenty matched variants against seventeen as deposited; the alternative derivation is non-significant in the same way, and the discrepancy is recorded in the limitations rather than smoothed over. No conclusion in this paper rests on which rule was used.")

# ============================================================ DISCUSSION
E("4.1 heading",
  "### 4.1 What the corrected analysis supports",
  "### 4.1 The two traits share genetic architecture; their systemic patterns cannot be separated yet")

E("4.1 - correction paragraph -> biology",
  "The correction that produces this statement acts on one arm of every comparison rather than on the comparison itself, which is why it changed the conclusion while leaving each PCOS marginal estimate unchanged in significance. It enlarged the PCOS arm, and where that arm pointed the same way as the ANM arm, as it did for the two skeletal outcomes, the difference it had supported contracted. A single-direction correction can therefore move conclusions in both directions.\n\nThe results that survive are specific. The skeletal signature of the ANM arm is coherent in the primary instrument across the whole correlation grid, and does not survive in the alternative instrument once signs are carried. Two hormonal endpoints, estradiol and LH, separate the exposures in opposite directions and hold across the entire covariance range; FSH does not. FSHB is the only locus in the top colocalization tier.",
  "What the comparison does return is one domain in which the two exposures behave differently and reproducibly so. The skeletal signature of the ANM arm is coherent in the primary instrument across the whole correlation grid, and does not survive in the alternative instrument once the signs of the endpoints are carried into the combination. Two hormonal endpoints, estradiol and LH, separate the exposures in opposite directions and hold across the entire covariance range, while FSH does not. At locus resolution FSHB is the only entry in the top colocalization tier. Everything outside those results is bounded rather than null.")

E("4.2 - causal phrasing",
  "PCOS liability being associated with higher LH while ANM liability is associated with lower LH therefore places the two exposures at different points of the same axis rather than at different magnitudes of one shared effect.",
  "PCOS liability being associated with higher LH while ANM liability is associated with lower LH is therefore compatible with the two exposures sitting at different points of the same axis rather than at different magnitudes of one shared effect.")

E("4.3 heading and opening",
  "### 4.3 What this would mean if the pattern resolved\n\nThe question posed in the introduction has a practical form.",
  "### 4.3 What this changes\n\nThe question posed in the introduction has a practical form.")

E("4.3 - closing, add action",
  "The one exception worth pursuing is the gonadotropin contrast, because it is directional rather than merely present and because it survives the full covariance range: if it replicates in a better-powered PCOS exposure, it would place the two traits at distinguishable points on the hypothalamic-pituitary-ovarian axis and would open a specific hypothesis rather than a general one.",
  "The one exception worth pursuing is the gonadotropin contrast, because it is directional rather than merely present and because it survives the full covariance range: if it replicates in a better-powered PCOS exposure, it would place the two traits at distinguishable points on the hypothalamic-pituitary-ovarian axis and would open a specific hypothesis rather than a general one. Until then the practical reading is a caution against the reverse inference: a systemic association reported for PCOS should not be treated as evidence about reproductive timing, nor a reproductive-timing association as evidence about PCOS, because in this design the two cannot be separated for any of the nine outcomes tested. That is a statement about what the current instrument can resolve, and it is also a specification for the study that would settle it: a PCOS instrument strong enough to exclude an ANM-sized systemic effect would adjudicate the attribution directly.")

E("4.4 heading and body",
  "### 4.4 Strengths\n\nThe instrument is auditable at the variant level, with per-variant provenance for every design, and every estimate in the package was independently re-derived from the harmonised matrices to below 1 x 10^-15. The scale conversion is derived rather than assumed, its direction is stated algebraically, and it is covered by a unit test. The comparison is internally matched, so an inter-exposure difference cannot be an inter-dataset difference. The outcome family and the sensitivity grids were fixed before the corrected estimates were computed. The domain combination carries signs. The multivariable covariance is bounded rather than asserted, and it is the bound that removes the multivariable claim rather than an argument about it. The package is self-contained, and its reproducibility claim is conditional on a smoke test that passes.",
  "### 4.4 What supports the comparison\n\nThree features of the design carry its conclusions. The comparison is internally matched, one outcome dataset per difference, so an inter-exposure difference cannot be an inter-dataset difference. The outcome family, the primary dataset per outcome and the sensitivity grids are fixed in a dated analysis plan, so the family is not chosen around the result. And the scale conversion is derived algebraically and covered by a unit test rather than assumed, which matters because it is the step that decides the answer.")

E("4.6 conclusion",
  "Their systemic association patterns differ for individual outcomes, but the frozen primary family establishes no formal difference between them at the current PCOS instrument strength, and the analysis is bounded by power rather than by scale: it could not detect an ANM-sized effect for any of the nine outcomes.",
  "Their systemic association patterns differ from outcome to outcome, but the pre-specified family establishes no formal difference between them at the current PCOS instrument strength, and the analysis is bounded by power rather than by scale: it could not detect an ANM-sized effect for any of the nine outcomes.")

# ============================================================ FIGURE LEGENDS (v31_docs_extra.py)
F("figlegend 2",
  '''**Figure 2. The liability-scale conversion, both directions.** Panel A plots m(K) (blue), which
converts a SNP-exposure coefficient, and 1/m(K) (red), which converts an MR ratio, over the
plausible prevalence range, with the point at which the ratio multiplier was previously assumed
to be 1 marked. Panel B plots the corrected difference-test P value against PCOS prevalence for
five outcomes, showing that no outcome crosses alpha at any point of the grid.''',
  '''**Figure 2. The liability-scale conversion, both directions.** Panel A plots m(K) (blue), the
factor that converts a SNP-exposure coefficient to the liability scale, and 1/m(K) (red), the
factor that converts an MR ratio, over the plausible prevalence range; the horizontal line marks
a multiplier of 1, which neither conversion uses. Panel B plots the difference-test P value
against PCOS prevalence for five outcomes; no outcome crosses alpha at any point of the grid.''')

F("figlegend 3",
  '''**Figure 3. The corrected primary family and its covariance sensitivity.** Panel A shows the
nine difference estimates with 95% intervals at rho = 0, with the previously shipped values as
crosses; no outcome is marked as passing, because none does. Panel B shows the corrected P value
against the assumed correlation rho over [-1, +1]; no curve crosses alpha anywhere in the grid.''',
  '''**Figure 3. The primary family and its covariance sensitivity.** Panel A shows the nine
difference estimates with 95% intervals at rho = 0; no outcome is marked as passing, because
none does. Panel B shows the P value against the assumed correlation rho over [-1, +1]; no curve
crosses alpha anywhere in the grid.''')

F("figlegend 4",
  '''**Figure 4. Skeletal domain evidence with the signed combination.** Panel A shows the seven
polarity-aligned ANM skeletal endpoints in the primary instrument. Panel B compares the signed
Stouffer result with the previous unsigned result at the same rho grid; the unsigned version
overstates every design with mixed endpoint directions, and it is the unsigned value that made
A2 look like a domain-level replication.''',
  '''**Figure 4. Skeletal domain evidence with a signed combination.** Panel A shows the seven
polarity-aligned ANM skeletal endpoints in the primary instrument. Panel B contrasts the signed
Stouffer combination with an unsigned one at the same rho grid: the signed statistic is the one
the stated hypothesis requires, and it is the difference between the two that keeps the
alternative ANM instrument from reading as a domain-level replication.''')

F("figlegend 5",
  '''**Figure 5. Multivariable instrument strength and the corrected detection limit.** Panel A plots
the conditional F statistics for both exposures at four positions in the covariance bound; the
prespecified gate of 10 is drawn, and the interval in which both gates pass is not the whole
band. Panel B plots the corrected minimum detectable effect against the ANM-sized effect for
each outcome, with the smaller (incorrect) MDEs alongside.''',
  '''**Figure 5. Multivariable instrument strength and the detection limit.** Panel A plots the
conditional F statistics for both exposures at four positions in the covariance bound; the
pre-specified gate of 10 is drawn, and the interval in which both gates pass is not the whole
band. Panel B plots the minimum detectable effect at 80% power against the ANM-sized effect for
each outcome.''')

F("figlegend 6",
  '''**Figure 6. FSHB evidence and its tier.** Panel A shows every PCOS-ANM locus with a COLOCALISED
verdict at the primary prior, their PP.H4 before and after LD pruning, and their evidence tier.
Panel B keeps the four PP4 quantities apart: the primary-prior value, the minimum over the prior
grid, the LD-pruned value, and the 0.75 threshold.''',
  '''**Figure 6. FSHB evidence and its tier.** Panel A shows every PCOS-ANM locus with a colocalised
verdict at the primary prior, its PP.H4 before and after LD pruning, and its evidence tier.
Panel B keeps four posterior quantities apart: the primary-prior value, the minimum over the
prior grid, the LD-pruned value, and the 0.75 tier threshold.''')

# the legends move into the manuscript, which is where the journal wants them
F("legends into the manuscript",
  '    man = D.build_manuscript(T)\n    D.W(os.path.join(OUT_MAN, "V3_1_manuscript.md"), man)\n    supplement(F, T)',
  '    supplement(F, T)\n    man = D.build_manuscript(T)\n'
  '    # Springer requires each figure caption in the text file of the manuscript, so the six\n'
  '    # legends are placed ahead of the reference list rather than only in the supplement.\n'
  '    man = man.replace("\\n## References\\n",\n'
  '                      "\\n## Figure legends\\n\\n" + LEGEND_BODY + "\\n\\n## References\\n", 1)\n'
  '    if "## Figure legends" not in man:\n'
  '        raise SystemExit("figure legends were not inserted into the manuscript")\n'
  '    D.W(os.path.join(OUT_MAN, "V3_1_manuscript.md"), man)')

F("legends global",
  '    W(os.path.join(OUT_SUPP, "Supplementary_Figure_Legends.md"), legs)',
  '    global LEGEND_BODY\n'
  '    LEGEND_BODY = legs.split("\\n\\n", 1)[1].rstrip()\n'
  '    W(os.path.join(OUT_SUPP, "Supplementary_Figure_Legends.md"), legs)')


def apply(path, pairs, label):
    src = io.open(path, encoding="utf-8").read()
    for tag, old, new in pairs:
        n = src.count(old)
        if n != 1:
            raise SystemExit("PATCH ABORT [%s]: matched %d times (expected 1)\n--- anchor ---\n%s"
                             % (tag, n, old[:400]))
        src = src.replace(old, new, 1)
        print("  ok  %s" % tag)
    ast.parse(src) if path.endswith(".py") else None
    io.open(path, "w", encoding="utf-8", newline="\n").write(src)
    print("  -> %s (%s)" % (label, os.path.basename(path)))


if __name__ == "__main__":
    print("V3.2 patch B - narrative")
    apply(TEMPLATE, EDITS, "manuscript template")
    apply(EXTRA, FIG, "figure legends + injection")
    print("done: %d template edits, %d generator edits" % (len(EDITS), len(FIG)))
