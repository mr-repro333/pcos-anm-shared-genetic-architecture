# -*- coding: utf-8 -*-
"""V3.2 patch C - the edits applied after patch A and patch B.

They are collected here so that the whole V3.2 chain is replayable from the V3.1 package:

    python patch_v32a.py     # generators: DOIs, two gates, the LD-pruned value, the changelog
    python patch_v32b.py     # the narrative rewrite of the manuscript template
    python patch_v32c.py     # this file: the residue of the version-history language
    python v31_docs_extra.py && python v31_docs_round2.py
    python v31_figures.py
    python v31_validate.py && python v31_compliance.py && python v31_consistency.py
    python v31_smoke.py
    python v32_package.py

Every edit is idempotent: if the new text is already present the edit is reported as
"already applied" and the file is left alone; if neither form is present the script aborts
rather than guessing.
"""
import ast, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
N = 0
S = 0


def sub(path, old, new, tag, marker=None):
    """Idempotent edit. `marker` is a short distinctive substring of the new text; it is used to
    detect an edit that has already been applied, because whitespace in a long comment can
    differ between the patch that applied it and this replay."""
    global N, S
    p = os.path.join(HERE, path)
    src = io.open(p, encoding="utf-8").read()
    if (marker or new) in src and old not in src:
        print("  already applied : %s" % tag); S += 1; return
    if src.count(old) != 1:
        raise SystemExit("PATCH ABORT [%s]: old form matched %d times" % (tag, src.count(old)))
    src = src.replace(old, new, 1)
    if path.endswith(".py"):
        ast.parse(src)
    io.open(p, "w", encoding="utf-8", newline="\n").write(src)
    print("  ok              : %s" % tag); N += 1


# ---------------------------------------------------------------- 1. table headers
sub("v31_docs.py",
    '    t1b = ["| outcome | V3 PCOS per SD (x m) | V3.1 PCOS per SD (/ m) | V3 P | V3.1 P | "\n'
    '           "change in P | V3 q | V3.1 q | V3 claim | V3.1 claim |",',
    '    # Self-describing column names: the supplement is read by people who never saw the\n'
    '    # superseded scale, so the two columns are named by what they are.\n'
    '    t1b = ["| outcome | PCOS per SD, multiplicative | PCOS per SD, reciprocal | "\n'
    '           "P, multiplicative | P, reciprocal | change in P | q, multiplicative | "\n'
    '           "q, reciprocal | verdict, multiplicative | verdict, reciprocal |",',
    "supplementary scale-comparison table header")

sub("v31_docs.py",
    '          "| q (BH within design) | P at rho=-1 | opposite direction | V3 P |",',
    '          "| q (BH within design) | P at rho=-1 | opposite direction | "\n'
    '          "P at the multiplicative scale |",',
    "Table 4 header")

# ---------------------------------------------------------------- 2. template residue
sub("v31_manuscript_template.md",
    "under three variant sets - as shipped, the discordance rule applied to every arm, and no "
    "palindrome exclusion at all",
    "under three variant sets: the deposited rule, the discordance rule applied to every arm, "
    "and no palindrome exclusion at all",
    "3.9 'as shipped'")
sub("v31_manuscript_template.md",
    "__FSHR1__ under the mixed rule the earlier version shipped, __FSHR3__ with no palindrome "
    "exclusion",
    "__FSHR1__ under the mixed rule, __FSHR3__ with no palindrome exclusion",
    "3.9 'the earlier version shipped'")
sub("v31_manuscript_template.md",
    "and the discrepancy is recorded in the limitations rather than smoothed over. No conclusion "
    "in this paper rests on which rule was used.",
    "and the discrepancy is recorded in the limitations. No conclusion in this paper rests on "
    "which rule was used.",
    "3.9 'rather than smoothed over'")
sub("v31_manuscript_template.md",
    "The formal distribution-versus-level P value is withdrawn.",
    "No formal distribution-versus-level P value is reported.",
    "3.5 withdrawal sentence")

# ---------------------------------------------------------------- 3. gate upgrade
sub("v31_validate.py",
    '    gate("J PRESENTATION", "the withdrawn comparison remains clearly marked as withdrawn",\n'
    '         bool(re.search(r"(withdraw\\w*)", man, re.I)))',
    '    # Upgraded from "the word withdrawn must appear" to the property it was protecting: a\n'
    '    # superseded quantity must not be presented as current, and the paper must say why a\n'
    '    # pooled domain summary is not used. Each side is now independently checkable.\n'
    '    gate("J PRESENTATION", "no superseded quantity is presented as a result",\n'
    '         ("not defensible here" in man)\n'
    '         and not re.search(r"pooled[^.]{0,60}\\bP\\s*=", man, re.I)\n'
    '         and not re.search(r"withdraw", man, re.I),\n'
    '         "reason for not pooling stated: %s" % ("not defensible here" in man))',
    "fail-closed gate: no superseded quantity presented as current",
    marker='"no superseded quantity is presented as a result"')

# ---------------------------------------------------------------- 4. compliance row
sub("v31_compliance.py",
    '    add("DOI tokens in the manuscript", "0 (the numeric gate scans 4-6 decimal tokens)",\n'
    '        str(n_doi), n_doi == 0)',
    '    # The journal asks for a DOI as a full link on every entry that has one. The requirement\n'
    '    # is therefore "a DOI on each reference", not "no DOI anywhere"; the numeric gate that\n'
    '    # the absence of DOIs used to protect now excludes the reference block instead.\n'
    '    _ref_i = man.find("\\n## References\\n")\n'
    '    _body = man[:_ref_i] if _ref_i >= 0 else man\n'
    '    _n_body = len(re.findall(r"doi\\.org/", _body))\n'
    '    _n_body += len(re.findall(r"\\b10\\.\\d{4,5}/", _body))\n'
    '    _n_list = len(re.findall(r"https://doi\\.org/", man[_ref_i:] if _ref_i >= 0 else ""))\n'
    '    add("DOI links in the reference list", "one per entry that has one",\n'
    '        "%d in the list, %d anywhere else" % (_n_list, _n_body),\n'
    '        _n_body == 0 and _n_list >= 30 and n_doi == _n_list)',
    "compliance: DOI row", marker='"DOI links in the reference list"')

# ---------------------------------------------------------------- 5. KNOWN_LIMITATIONS
sub("v31_docs_extra.py",
    "12. **MR-Egger.** The packaged estimator does not reproduce the textbook estimator on identical\n"
    "    input; the discrepancy is reported and MR-Egger carries no conclusion.",
    "12. **MR-Egger.** Closed in the rebuild rounds: the packaged estimator is the orientation-\n"
    "    compliant one and reproduces 244 of 244 pairs exactly. MR-Egger is carried as a\n"
    "    sensitivity statistic because its InSIDE assumption is untestable in these data.",
    "KNOWN_LIMITATIONS item 12", marker="Closed in the rebuild rounds")

# ---------------------------------------------------------------- 6. figure labels
FIGLAB = [
    ('ax.annotate("the previous version assumed\\nthe ratio multiplier was 1 here",',
     'ax.annotate("multiplier of 1:\\nneither conversion uses it",', "fig2 annotation text"),
    ('ax.set_title("B. Prevalence sensitivity, corrected scale", fontsize=9.5, loc="left")',
     'ax.set_title("B. Prevalence sensitivity", fontsize=9.5, loc="left")', "fig2B title"),
    ('label="V3.1 corrected")', 'label="reciprocal scale (this paper)")', "fig3A legend A"),
    ('label="V3 as shipped")', 'label="multiplicative scale")', "fig3A legend B"),
    ('label="signed (V3.1), rho = 0")', 'label="signed, rho = 0")', "fig4A legend A"),
    ('label="signed (V3.1), rho = 0.5")', 'label="signed, rho = 0.5")', "fig4A legend B"),
    ('label="unsigned (V3, defect), rho = 0.5")', 'label="unsigned, rho = 0.5")', "fig4B legend"),
    ('label="MDE, corrected (V3.1)")', 'label="MDE at 80% power")', "fig5B legend A"),
    ('label="MDE as V3 reported")', 'label="MDE at the multiplicative scale")', "fig5B legend B"),
    ('ax.set_title("B. Detection limit, corrected SE", fontsize=9.5,',
     'ax.set_title("B. Detection limit", fontsize=9.5,', "fig5B title"),
    ('(0.0, BLUE, "gencov = 0 (V3 assumption)")', '(0.0, BLUE, "gencov = 0")', "fig5A legend"),
    ('ax.set_xlabel("PCOS - ANM, per 1 SD of each exposure")',
     'ax.set_xlabel("difference, per 1 SD")', "fig3A x label (was colliding with 3B)"),
    ('ax.set_xlabel("assumed correlation rho between the two exposure estimates")',
     'ax.set_xlabel("assumed between-exposure correlation rho")', "fig3B x label"),
]
for a, b, tag in FIGLAB:
    sub("v31_figures.py", a, b, tag)

sub("v31_figures.py",
    '    ax.annotate("multiplier of 1:\\nneither conversion uses it",\n'
    '                xy=(0.19, 1.0), xytext=(0.115, 0.72), fontsize=6.6, color=GREY,\n'
    '                ha="left", va="top",\n'
    '                arrowprops=dict(arrowstyle="->", color=GREY, lw=.8))',
    '    # placed in the empty band between the two curves and given the darker ink so that the\n'
    '    # lettering clears the 4:1 contrast the journal asks for\n'
    '    ax.annotate("multiplier of 1:\\nneither conversion uses it",\n'
    '                xy=(0.215, 1.0), xytext=(0.075, 1.42), fontsize=6.6, color=INK,\n'
    '                ha="left", va="top",\n'
    '                arrowprops=dict(arrowstyle="->", color=INK, lw=.8))',
    "fig2 annotation placement", marker='xytext=(0.075, 1.42)')

if __name__ == "__main__":
    print("V3.2 patch C: %d applied, %d already applied" % (N, S))
