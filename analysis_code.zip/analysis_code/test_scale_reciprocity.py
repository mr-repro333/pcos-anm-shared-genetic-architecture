# -*- coding: utf-8 -*-
"""V3.1 PRIORITY 0, item 10 - unit test for the reciprocal-scale law.

Establishes, both algebraically and numerically, that rescaling an exposure
coefficient by c rescales an MR ratio by 1/c, and therefore that:

  * a SNP-exposure association on the log-OR scale is converted to the liability scale
    by *multiplying* by m(K)  (beta_L = m beta_logOR), and
  * an MR *ratio* expressed per unit log-OR is converted to per-SD-of-liability by
    *dividing* by m(K)        (theta_L = theta_logOR / m).

Run: python test_scale_reciprocity.py     (exit code 0 = all pass)

Regression guard: the third block replays V3's shipped transformation on the frozen
V3 inputs and shows it is wrong by exactly m(K)^2.
"""
import math
import os
import sys

import numpy as np
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import liability_multiplier, mr_ratio_to_liability, snp_exposure_to_liability

FAILS = []


def check(name, ok, detail=""):
    print(("PASS  " if ok else "FAIL  ") + name + ("   " + detail if detail else ""))
    if not ok:
        FAILS.append(name)


# ---------------------------------------------------------------- 1. algebraic proof
# Theorem. Let beta_X scale by c: beta_X' = c beta_X, with beta_Y fixed. Then
#   theta = beta_Y / beta_X  ->  theta' = beta_Y / (c beta_X) = theta / c.  QED
def test_algebraic():
    K = 0.10
    m = liability_multiplier(K)
    beta_Y = 0.043
    for beta_X in (0.02, 0.05, 0.13, 0.31):
        theta = beta_Y / beta_X
        theta_scaled = beta_Y / (beta_X * m)          # exposure coefficient rescaled by m
        check("algebra c=m, beta_X=%.2f : theta' = theta/m" % beta_X,
              abs(theta_scaled - theta / m) < 1e-15)
        check("algebra c=m, beta_X=%.2f : NOT theta*m" % beta_X,
              abs(theta_scaled - theta * m) > 1e-3)


# ------------------------------------------------------------- 2. numerical (IVW) test
def test_numerical_ivw():
    rng = np.random.default_rng(20260925)
    for trial in range(200):
        k = int(rng.integers(3, 40))
        bx = rng.uniform(0.01, 0.4, k)
        bxse = bx / rng.uniform(4, 12, k)
        by = rng.normal(0, 0.05, k)
        byse = rng.uniform(0.002, 0.05, k)
        c = float(rng.uniform(0.3, 3.0))
        w = 1.0 / (byse ** 2 / bx ** 2)
        theta = float(np.sum(w * (by / bx)) / np.sum(w))
        w2 = 1.0 / (byse ** 2 / (bx * c) ** 2)
        theta2 = float(np.sum(w2 * (by / (bx * c))) / np.sum(w2))
        se = float(math.sqrt(1.0 / np.sum(w)))
        se2 = float(math.sqrt(1.0 / np.sum(w2)))
        if abs(theta2 - theta / c) > 1e-10 * max(1.0, abs(theta)) or \
           abs(se2 - se / c) > 1e-10 * max(1.0, abs(se)):
            check("IVW trial %d" % trial, False, "theta=%.6g theta2=%.6g c=%.4f" % (theta, theta2, c))
            return
    check("numerical IVW, 200 random instrument vectors: theta' = theta/c and SE' = SE/c",
          True)


# ------------------------------------------------- 3. regression guard against V3's bug
def test_v3_regression_guard():
    K = 0.10
    m = liability_multiplier(K)
    # frozen V3 numbers for T2D (D1 vs A1)
    theta_logOR, se_logOR = 0.129547, 0.069768
    v31_b, v31_s, _ = mr_ratio_to_liability(theta_logOR, se_logOR, K)
    v3_b_wrong = theta_logOR * m       # what V3 shipped
    ratio = v31_b / v3_b_wrong
    check("V3's shipped per-SD value is too small by exactly 1/m^2",
          abs(ratio - 1.0 / m ** 2) < 1e-9, "ratio = %.6f, 1/m^2 = %.6f" % (ratio, 1.0 / m ** 2))
    check("V3.1 T2D per-SD PCOS effect = %.6f (V3 shipped %.6f)" % (v31_b, v3_b_wrong),
          v31_b > v3_b_wrong)
    check("reciprocal round-trip: (m * b) / m == b",
          abs(snp_exposure_to_liability(theta_logOR, se_logOR, K)[0] * 1.0 / m
              - (theta_logOR * m) / m) < 1e-15)


# --------------------------------------------- 4. consistency with the closed form
def test_closed_form_consistency():
    # the probit approximation: m(K) ~ 1/(1.702 * z / (K(1-K))) ; check monotone and in band
    ms = [liability_multiplier(K) for K in (0.05, 0.10, 0.20)]
    check("m(K) in (0,1) and increasing in K over [0.05,0.20]",
          all(0 < x < 1 for x in ms) and ms == sorted(ms), "m = %s" % ["%.4f" % x for x in ms])
    t = stats.norm.ppf(1 - 0.10)
    check("m(0.10) reproduces the V3 frozen value 0.512825",
          abs(liability_multiplier(0.10) - 0.512825) < 5e-7,
          "%.6f" % liability_multiplier(0.10))


if __name__ == "__main__":
    print("=" * 78)
    print("V3.1 unit test: rescaling an exposure coefficient by c rescales an MR ratio 1/c")
    print("=" * 78)
    test_algebraic()
    test_numerical_ivw()
    test_v3_regression_guard()
    test_closed_form_consistency()
    print("-" * 78)
    if FAILS:
        print("FAILED: %d" % len(FAILS)); sys.exit(1)
    print("ALL CHECKS PASSED")
