# -*- coding: utf-8 -*-
"""V3.1 - the Claim-Evidence Matrix, reclassified from the corrected results.

No V3 grade is inherited. Every claim below is graded against the V3.1 numbers, and the
manual's rule is applied as written: a claim may not be graded above the evidence its own
family supports.

Grading vocabulary (unchanged from V3 so that the two matrices are comparable):
ROBUST / PROMISING_NEEDS_VALIDATION / EXPLORATORY / UNRESOLVED / WITHDRAWN.

The specific reclassifications V3.1 forces:

* "The two exposures' systemic profiles differ"  ROBUST -> WITHDRAWN
  (0 of 9 survive BH-FDR after the reciprocal correction)
* "The ANM skeletal signature is coherent"       ROBUST -> ROBUST for A1, UNRESOLVED for A2
  (the signed Stouffer leaves A1 significant at rho = 0.5 and takes A2 to P = 0.057)
* "Three of five hormonal endpoints separate"    ROBUST -> two of five (estradiol, LH)
* "FSHB carries a shared causal signal"          ROBUST -> TIER-BOUNDED, associational, and
  reworded to ladder tier 2
* "A shared gonadotropic mechanism at FSHB"      PROMISING -> WITHDRAWN as a mechanism
* "MVMR direct effects"                          UNRESOLVED -> UNRESOLVED and demoted out of
  the biological headline
* "The PCOS arm had adequate power"              ROBUST -> REVERSED (zero of nine)
"""
import io, os, sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, LOGD, PREV_PRIMARY, ALPHA, liability_multiplier, HORMONAL_LABEL
from v31_diff import load_master


def fmt(x, nd=4):
    return ("%%.%dg" % nd) % x


def main():
    log = io.open(os.path.join(LOGD, "v31_claims.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    d = pd.read_csv(os.path.join(RES, "V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv"), sep="\t")
    sk = pd.read_excel(os.path.join(RES, "V3_1_SKELETAL_EVIDENCE.xlsx"),
                       sheet_name="DOMAIN_SUMMARY").set_index("exposure_design")
    hor = pd.read_csv(os.path.join(RES, "V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv"), sep="\t")
    mde = pd.read_csv(os.path.join(RES, "V3_1_POWER_MDE_CORRECTED.tsv"), sep="\t")
    fshb = pd.read_excel(os.path.join(RES, "V3_1_FSHB_EVIDENCE_AUDIT.xlsx"),
                         sheet_name="PP4_FACTS")
    fshb = dict(zip(fshb["quantity"], fshb["value"]))
    mv = pd.read_csv(os.path.join(RES, "V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv"), sep="\t")
    adg = pd.read_excel(os.path.join(RES, "V3_1_ADIPOSITY_EVIDENCE.xlsx"),
                        sheet_name="HYPOTHESIS_GRADING")

    m = liability_multiplier(PREV_PRIMARY)
    n_fdr = int(d["fdr_pass"].sum())
    minp = d["p_rho0"].min(); minq = d["q_BH_primary"].min()
    sep = hor[hor["fdr_pass_within_design"]].groupby("endpoint_label").size()
    sep_names = sorted(sep.index)
    notsep = sorted(set(hor["endpoint_label"]) - set(sep_names))
    n_power = int(mde["anm_effect_detectable_corrected"].sum())
    a1 = sk.loc["A1"]; a2 = sk.loc["A2"]
    mvmr0 = mv[np.isclose(mv["tau"], 0.0)]
    mvmr_n = int(mvmr0["gate_both"].sum()); mvmr_tot = int(len(mvmr0))

    def hormonal_summary(names):
        g = hor[hor["endpoint_label"].isin(names)]
        return "; ".join("%s P = %s" % (n, fmt(g[g["endpoint_label"] == n]["p_rho0_corrected"].min(), 3))
                         for n in names) or "(none)"

    rows = [
        dict(claim="PCOS genetic liability is associated with later ANM",
             value="+0.434 years per log-odds (95% CI +0.230 to +0.638; P = 3.05e-05; 19 "
                   "variants). Unaffected by the V3.1 correction: this is an MR association "
                   "between a log-OR exposure and a per-year outcome and contains no "
                   "per-SD conversion.",
             multiplicity_pass="yes (pre-specified core, unchanged from V1)",
             scale_assumption="log-OR of PCOS liability, NOT per SD",
             outcome_covariance_accounted="not applicable (single exposure)",
             sample_overlap_status="both exposures UK-Biobank-heavy; magnitude unknown",
             primary_or_sensitivity="primary", mechanistic_or_associational="associational",
             safe_for_abstract="YES", grade="ROBUST",
             note="described only as an MR association of PCOS genetic liability with later "
                  "ANM. Never as PCOS causing later menopause."),
        dict(claim="ANM is associated with PCOS liability (the reverse direction)",
             value="beta = +0.0953 (95% CI +0.067 to +0.124; P = 8.14e-11; 207 variants); "
                   "odds ratio 1.100 per year with 95% CI 1.069 to 1.132 on the OR scale",
             multiplicity_pass="yes (pre-specified core)",
             scale_assumption="per year of genetically predicted ANM",
             outcome_covariance_accounted="not applicable",
             sample_overlap_status="shared",
             primary_or_sensitivity="primary", mechanistic_or_associational="associational",
             safe_for_abstract="YES", grade="ROBUST",
             note="NOT interpreted as later menopause temporally causing PCOS. ANM occurs "
                  "decades after the window in which PCOS liability is expressed, so this is "
                  "read as shared reproductive genetic architecture and/or horizontal "
                  "(correlated) pleiotropy, not as a temporal exposure acting on an outcome. "
                  "The CI is reported on the odds-ratio scale: V3 printed the log-OR interval "
                  "(+0.067 to +0.124) beside an odds ratio, which is a scale mismatch."),
        dict(claim="PCOS liability and ANM share genetic architecture",
             value="LDSC r_g = +0.329 (SE 0.042; P = 2.9e-15); bidirectional MR association",
             multiplicity_pass="n/a", scale_assumption="n/a",
             outcome_covariance_accounted="n/a", sample_overlap_status="shared",
             primary_or_sensitivity="primary", mechanistic_or_associational="associational",
             safe_for_abstract="YES", grade="ROBUST",
             note="this is the manuscript's core claim and is unaffected by all three repairs."),
        dict(claim="No formal systemic difference between the two exposures is established",
             # The separability claim is withdrawn; what stands is the null, and the null is
             # what the corrected family actually reports.
             value="0 of the 9 primary difference tests survive BH-FDR. Smallest P = %.4f "
                   "(%s); smallest q = %.4f. Under V3's incorrect multiplication 4 of 9 "
                   "appeared to pass." % (minp, d.loc[d["p_rho0"].idxmin(), "outcome_label"], minq),
             multiplicity_pass="NO - and reported as NO",
             scale_assumption="PCOS arm theta_L = theta_logOR / m(K), m = %.6f at K = %.2f"
                              % (m, PREV_PRIMARY),
             outcome_covariance_accounted="full rho grid in [-1, +1]; the tests are null "
                                          "across the whole grid",
             sample_overlap_status="shared; rho >= 0 assumed plausible",
             primary_or_sensitivity="primary", mechanistic_or_associational="associational",
             safe_for_abstract="YES", grade="ROBUST",
             note="V3 claimed separable systemic correlates for four outcomes (ROBUST). That "
                  "claim is WITHDRAWN: after the reciprocal correction zero of the nine tests "
                  "survive BH-FDR. What now stands, and is graded ROBUST, is the null itself - "
                  "together with the power statement that explains it. The manuscript may not "
                  "say 'systemic decoupling', 'established systemic differences', 'separable "
                  "systemic profiles' or 'neither trait should be used as a proxy for the "
                  "systemic risk of the other'."),
        dict(claim="The PCOS arm could detect an ANM-sized systemic effect",
             value="0 of 9 outcomes had 80%% power to detect the effect the ANM arm shows for "
                   "the same outcome. Power range %.2f-%.2f. Under V3's SE the same table "
                   "claimed 2 of 9." % (mde["power_to_detect_ANM_effect_corrected"].min(),
                                        mde["power_to_detect_ANM_effect_corrected"].max()),
             multiplicity_pass="n/a", scale_assumption="per-SD liability, reciprocal SE",
             outcome_covariance_accounted="n/a", sample_overlap_status="n/a",
             primary_or_sensitivity="primary (design property)",
             mechanistic_or_associational="methodological",
             safe_for_abstract="YES", grade="ROBUST",
             note="this REVERSES V3's power claim, which used the multiplicatively scaled SE. "
                  "It is the single most important statement about what the PCOS nulls do and "
                  "do not exclude: they exclude very little."),
        dict(claim="The ANM skeletal signature is coherent (primary ANM instrument A1)",
             value="A1: 6 of 7 polarity-aligned endpoints favourable, 4 pass endpoint-level "
                   "BH-FDR; SIGNED correlation-robust Stouffer P = %.4g at rho = 0 and %.4g at "
                   "rho = 0.5 (V3's unsigned implementation gave %.4g at rho = 0.5)"
                   % (a1["stouffer_p_signed_rho000"], a1["stouffer_p_signed_rho050"],
                      a1["stouffer_p_V3unsigned_rho050"]),
             multiplicity_pass="yes at endpoint level; the combination is reported over a "
                               "correlation grid",
             scale_assumption="per-year ANM x SD_ANM 3.8 yr",
             outcome_covariance_accounted="signed Stouffer over rho in {0, .25, .5, .75, .9}; "
                                          "the naive pooled P (%.3g) is WITHDRAWN"
                                          % a1["naive_meta_p_withdrawn"],
             sample_overlap_status="outcome datasets overlap the exposure GWAS",
             primary_or_sensitivity="primary", mechanistic_or_associational="associational",
             safe_for_abstract="YES", grade="ROBUST",
             note="stated per endpoint tier: primary eBMD, primary fracture, osteoporosis and "
                  "site-specific fracture evidence are reported separately and never pooled. "
                  "No causal reading is attached."),
        dict(claim="The ANM skeletal signature replicates in the alternative ANM instrument (A2)",
             value="A2: 5 of 7 favourable, 2 pass endpoint-level FDR, but the SIGNED Stouffer "
                   "gives P = %.3g at rho = 0.5 and %.3g at rho = 0.9 (V3's unsigned version "
                   "reported %.3g at rho = 0.5)"
                   % (a2["stouffer_p_signed_rho050"], a2["stouffer_p_signed_rho090"],
                      a2["stouffer_p_V3unsigned_rho050"]),
             multiplicity_pass="NO at rho >= 0.5",
             scale_assumption="per-year ANM x SD_ANM 3.8 yr",
             outcome_covariance_accounted="signed Stouffer over the same grid",
             sample_overlap_status="shared",
             primary_or_sensitivity="sensitivity (alternative ANM instrument)",
             mechanistic_or_associational="associational",
             safe_for_abstract="NO", grade="UNRESOLVED",
             note="DOWNGRADED from V3. The two endpoint-level primary results (eBMD and "
                  "forearm fracture) survive, but the domain-level coherence does not once "
                  "the signs are carried into the combination."),
        dict(claim="ANM is associated with lower gonadotropins and higher gonadal steroids",
             value="FSH -0.1747 (P = 1.8e-11); LH -0.0780 (P = 3.8e-10); estradiol +0.0217 "
                   "(P = 2.4e-04); testosterone +0.0147 (P = 5.6e-03); all four survive "
                   "correction within the five-endpoint family. Progesterone +0.0057 (P = 0.54) "
                   "is a documented null.",
             multiplicity_pass="yes within the five analysable endpoints of the six planned",
             scale_assumption="per-year ANM (continuous exposure, no liability conversion)",
             outcome_covariance_accounted="not applicable",
             sample_overlap_status="hormone GWAS overlap the ANM GWAS",
             primary_or_sensitivity="secondary, pre-specified domain",
             mechanistic_or_associational="associational",
             safe_for_abstract="YES", grade="ROBUST",
             note="unaffected by the V3.1 scale correction, which touches only the PCOS arm. "
                  "The family is five endpoints, not six: see the endpoint accounting."),
        dict(claim="The two exposures' HORMONAL profiles are separable",
             value="%d of 5 endpoints separate the exposures with a difference surviving BH "
                   "within the design: %s. NOT separating: %s. Under V3's multiplication three "
                   "endpoints appeared to separate; FSH no longer does "
                   "(P %.3g-%.3g after correction, from P %.1e-%.1e before)."
                   % (len(sep_names), hormonal_summary(sep_names), "; ".join(notsep),
                      hor[hor["endpoint_label"] == "FSH"]["p_rho0_corrected"].min(),
                      hor[hor["endpoint_label"] == "FSH"]["p_rho0_corrected"].max(),
                      hor[hor["endpoint_label"] == "FSH"]["p_rho0_V3"].min(),
                      hor[hor["endpoint_label"] == "FSH"]["p_rho0_V3"].max()),
             multiplicity_pass="yes within the five-endpoint, fifteen-test matched family",
             scale_assumption="PCOS theta_L = theta_logOR / m(K); ANM x SD_ANM 3.8 yr",
             outcome_covariance_accounted="same rho grid as the systemic panel; holds to "
                                          "rho = -1",
             sample_overlap_status="hormone GWAS overlap both exposure GWAS",
             primary_or_sensitivity="secondary, pre-specified domain",
             mechanistic_or_associational="associational",
             safe_for_abstract="YES", grade="ROBUST",
             note="CORRECTED from 'three of five' to two of five. The surviving pair is "
                  "estradiol and LH, and both are opposite in direction, so the "
                  "opposite-direction statement survives while the FSH statement does not."),
        dict(claim="PCOS liability is associated with lower FSH",
             value="D1 -0.1870 (P = 0.033); D3 -0.2246 (P = 0.038); F4 q = 0.067 and 0.063",
             multiplicity_pass="NO", scale_assumption="per log-OR of PCOS liability",
             outcome_covariance_accounted="not applicable",
             sample_overlap_status="shared",
             primary_or_sensitivity="secondary", mechanistic_or_associational="associational",
             safe_for_abstract="NO", grade="EXPLORATORY",
             note="DOWNGRADED from PROMISING_NEEDS_VALIDATION. The direction still replicates "
                  "across two instrument designs, but the matched between-exposure difference "
                  "at FSH is null after the corrected scale, so FSH no longer supports a "
                  "between-exposure statement."),
        dict(claim="FSHB carries a shared PCOS-ANM causal signal",
             value="single-signal colocalization PP.H4 = %.6f at the primary prior "
                   "(p12 = 1e-5); %.6f at the least favourable point of the prior grid; "
                   "%.6f after LD pruning; tier %s. This is a claim about the evidence tier: "
                   "DENND1A (%.6f) and IRF1 (%.6f) are also COLOCALISED at the primary prior."
                   % (float(fshb["pp4_primary_prior"]), float(fshb["pp4_min_over_prior_grid"]),
                      float(fshb["pp4_after_LD_pruning"]), fshb["evidence_tier"],
                      0.987840, 0.924456),
             multiplicity_pass="colocalization family uses tiered verdicts, not p-values",
             scale_assumption="not applicable",
             outcome_covariance_accounted="LD pruning stress test reported",
             sample_overlap_status="summaries overlap",
             primary_or_sensitivity="secondary, locus-resolved",
             mechanistic_or_associational="associational", safe_for_abstract="YES",
             grade="PROMISING_NEEDS_VALIDATION",
             note="DOWNGRADED from ROBUST and reworded to the allowed ladder. Permitted: "
                  "'shared FSHB-region signal', 'likely shared causal signal under the "
                  "single-signal colocalization model'. NOT permitted: fine-mapped shared "
                  "signal, the same causal variant as a resolved fact, FSH-mediated shared "
                  "causal variant. PCOS-ANM single-signal colocalization at FSHB is NOT the "
                  "same analysis as PCOS-FSH or ANM-FSH locus-specific colocalization, and no "
                  "such analysis exists here."),
        dict(claim="A shared gonadotropic mechanism at FSHB",
             value="no evidence tier supports a mechanism: Layer 3 (variant-level resolution) "
                   "failed its own diagnostics and was withdrawn; the signed Stouffer removed "
                   "the FSH between-exposure difference",
             multiplicity_pass="n/a", scale_assumption="n/a",
             outcome_covariance_accounted="n/a", sample_overlap_status="n/a",
             primary_or_sensitivity="mechanistic hypothesis",
             mechanistic_or_associational="mechanistic hypothesis only",
             safe_for_abstract="NO", grade="WITHDRAWN",
             note="SuSiE was NOT re-run to obtain a positive result. The failed diagnostics "
                  "are retained: Lambda 0.986-1.000, singleton credible sets, reference LD "
                  "explaining at most 28% of the association profile."),
        dict(claim="PCOS liability acts preferentially on adipose distribution rather than level",
             value="primary design D1: UNSUPPORTED (sign replication and endpoint FDR both fail); "
                   "SUGGESTIVE only in the expanded designs",
             multiplicity_pass="n/a - the formal contrast is withdrawn",
             scale_assumption="external trait SDs assumed; the PCOS multiplier cancels in a "
                              "within-arm ratio, so the V3.1 correction does not change this "
                              "table",
             outcome_covariance_accounted="withdrawn: repeated releases of the same traits were "
                                          "pooled as if independent",
             sample_overlap_status="n/a", primary_or_sensitivity="pre-specified hypothesis",
             mechanistic_or_associational="associational", safe_for_abstract="NO",
             grade="WITHDRAWN",
             note="unchanged from V3; the V3.1 correction does not touch it, and that is "
                  "verified rather than asserted."),
        dict(claim="PCOS or ANM has a direct systemic effect after conditioning on the other",
             value="no direct effect is interpretable. The rebuilt restricted design passes "
                   "the conditional-F gate for both exposures at gencov = 0 (13.83 / 12.02) "
                   "but fails BOTH gates for any covariance below tau = -0.33 (9.26 / 9.22 at "
                   "tau = -0.5; 6.96 / 7.48 at tau = -1.0). Q_A is significant in nearly every "
                   "model.",
             multiplicity_pass="n/a", scale_assumption="per log-OR",
             outcome_covariance_accounted="bounded, not estimated: gencov = tau * se1 * se2 "
                                          "with tau in [-1, +1] from Cauchy-Schwarz",
             sample_overlap_status="shared; the sampling covariance is a phenotypic overlap "
                                   "quantity the deposits do not contain",
             primary_or_sensitivity="design / sensitivity analysis ONLY",
             mechanistic_or_associational="associational",
             safe_for_abstract="NO", grade="UNRESOLVED",
             note="MOVED OUT OF THE BIOLOGICAL HEADLINE. The attenuation of ANM -> BMD in the "
                  "conditioned model is NOT described as mediation or as sharing with PCOS. No "
                  "MVMR outcome was added."),
    ]

    mx = pd.DataFrame(rows)
    mx["safe_for_abstract"] = mx["safe_for_abstract"].map(
        lambda x: "YES" if str(x).upper().startswith("YES") else "NO")

    with pd.ExcelWriter(os.path.join(RES, "V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"),
                        engine="openpyxl") as w:
        mx.to_excel(w, sheet_name="CLAIM_EVIDENCE_MATRIX_V31", index=False)
        mx[mx["safe_for_abstract"] == "YES"].to_excel(w, sheet_name="SAFE_FOR_ABSTRACT",
                                                      index=False)
        # the explicit V3 -> V3.1 grade changes
        chg = pd.DataFrame([
            dict(claim="Two exposures' systemic profiles differ for skeletal and glycaemic "
                       "outcomes", v3_grade="ROBUST", v31_grade="WITHDRAWN",
                 trigger="reciprocal-scale correction: 4/9 -> 0/9 survive BH-FDR"),
            dict(claim="ANM skeletal signature coherent", v3_grade="ROBUST (single row)",
                 v31_grade="ROBUST for A1 / UNRESOLVED for A2",
                 trigger="signed Stouffer: A2 moves from P = 0.0072 to P = 0.0566 at rho = 0.5"),
            dict(claim="Three of five hormonal endpoints separate the exposures",
                 v3_grade="ROBUST", v31_grade="two of five (estradiol, LH)",
                 trigger="FSH matched difference 1.7e-07 -> 0.130 after the reciprocal "
                         "correction"),
            dict(claim="FSHB carries a shared PCOS-ANM causal signal", v3_grade="ROBUST",
                 v31_grade="PROMISING_NEEDS_VALIDATION, associational, ladder tier 2",
                 trigger="'only shared signal' is a tier statement, not a raw-posterior "
                         "statement; DENND1A and IRF1 also colocalise"),
            dict(claim="A shared gonadotropic mechanism at FSHB",
                 v3_grade="PROMISING_NEEDS_VALIDATION", v31_grade="WITHDRAWN",
                 trigger="Layer 3 failed; no FSH-region colocalization exists"),
            dict(claim="The PCOS arm had adequate power", v3_grade="ROBUST",
                 v31_grade="REVERSED - 0 of 9 outcomes",
                 trigger="the SE must transform with the same reciprocal scale as the effect"),
            dict(claim="PCOS has a direct systemic effect after conditioning on ANM",
                 v3_grade="UNRESOLVED", v31_grade="UNRESOLVED, demoted out of the headline",
                 trigger="the conditional-F gate flips inside the permitted covariance band"),
            dict(claim="PCOS to FSH", v3_grade="PROMISING_NEEDS_VALIDATION",
                 v31_grade="EXPLORATORY",
                 trigger="the matched FSH difference is null after the correction"),
        ])
        chg.to_excel(w, sheet_name="V3_TO_V31_GRADE_CHANGES", index=False)
        pd.DataFrame([
            dict(column="Multiplicity_pass", meaning="does the claim survive the correction "
                                                     "for the family it belongs to?"),
            dict(column="Scale_assumption", meaning="what exposure scale is the number on - and, "
                                                    "where a liability conversion is involved, "
                                                    "in which direction"),
            dict(column="Outcome_covariance_accounted", meaning="is the correlation between "
                                                                "endpoints, or between the two "
                                                                "exposure estimates, handled?"),
            dict(column="Sample_overlap_status", meaning="how much do the contributing GWAS "
                                                         "overlap?"),
            dict(column="Primary_or_sensitivity", meaning="is this a primary or a sensitivity "
                                                          "analysis?"),
            dict(column="Mechanistic_or_associational", meaning="does the claim assert a "
                                                                "mechanism?"),
            dict(column="Safe_for_abstract", meaning="only YES claims may appear in the "
                                                     "Abstract conclusion"),
            dict(column="grade", meaning="ROBUST / PROMISING_NEEDS_VALIDATION / EXPLORATORY / "
                                         "UNRESOLVED / WITHDRAWN"),
        ]).to_excel(w, sheet_name="COLUMN_DEFINITIONS", index=False)

    L("=== V3.1 claim matrix ===")
    L(mx[["claim", "grade", "safe_for_abstract"]].to_string(index=False))
    L("\nclaims by grade:")
    L(mx["grade"].value_counts().to_string())
    L("\nsafe for abstract: %d of %d" % (int((mx["safe_for_abstract"] == "YES").sum()), len(mx)))
    log.close()

    print(mx[["claim", "grade", "safe_for_abstract"]].to_string(index=False))
    print()
    print(mx["grade"].value_counts().to_string())
    print("\ncounts: claims=%d  safe_for_abstract=%d"
          % (len(mx), int((mx["safe_for_abstract"] == "YES").sum())))
    return mx, chg


if __name__ == "__main__":
    main()
