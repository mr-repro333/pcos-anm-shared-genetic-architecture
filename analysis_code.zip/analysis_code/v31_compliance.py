# -*- coding: utf-8 -*-
"""Journal compliance measurement for the rebuilt manuscript.

Reads the finished manuscript and the live result files; writes
08_QC/SUBMISSION_COMPLIANCE.md. It duplicates no gate logic from v31_validate.py - it measures
and reports, and the fail-closed audit remains the authority on pass/fail.
"""
import io, os, re, sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import SELF, RES
from v31_refs import REFS

MAN = os.path.join(SELF, "01_MANUSCRIPT", "V3_1_manuscript.md")
QC = os.path.join(SELF, "08_QC")


def wc(s):
    return len(re.findall(r"\b[A-Za-z0-9][A-Za-z0-9\.\-]*\b", s))


def main():
    man = io.open(MAN, encoding="utf-8").read()
    rows = []

    def add(req, limit, measured, ok):
        rows.append(dict(requirement=req, limit=limit, measured=measured,
                         result="PASS" if ok else "**FAIL**"))

    ab = re.search(r"## Abstract(.*?)\n---", man, re.S)
    ab = ab.group(1) if ab else ""
    n_abs = wc(ab)
    add("Abstract length", "150-250 words", "%d words" % n_abs, 150 <= n_abs <= 250)

    kw = man.split("**Keywords:**")[1].split("\n")[0] if "**Keywords:**" in man else ""
    n_kw = len([k for k in re.split(r"[;,]", kw) if k.strip()])
    add("Keywords", "4-6", "%d keywords" % n_kw, 4 <= n_kw <= 6)

    title = man.splitlines()[0].lstrip("# ").strip()
    add("Title word count", "no explicit limit", "%d words" % wc(title), True)
    add("Title states an unresolved, not absent, signature",
        "must not assert indistinguishability",
        title[:120], ("unresolved" in title.lower()
                      and not re.search(r"indistinguishable|not distinguishable", title, re.I)))

    n_ref = len(REFS)
    add("Reference list", "present, name-year", "%d entries" % n_ref, n_ref >= 20 and
        man.count("\n## References\n") == 1)
    n_cite = len(re.findall(r"\((?:[A-Z][^()]{0,70}?, (?:19|20)\d\d)\)", man))
    add("In-text citations", "present", "%d citation instances" % n_cite, n_cite >= 20)

    n_doi = len(re.findall(r"\b10\.\d{4,5}/", man))   # DOI-shaped tokens, body + list
    # The journal asks for a DOI as a full link on every entry that has one. The requirement is
    # therefore "a DOI on each reference", not "no DOI anywhere"; the numeric gate that the
    # absence of DOIs used to protect now excludes the reference block instead (v31_validate.py).
    _ref_i = man.find("\n## References\n")
    _body = man[:_ref_i] if _ref_i >= 0 else man
    _n_body = len(re.findall(r"doi\.org/", _body))
    _n_body += len(re.findall(r"\b10\.\d{4,5}/", _body))
    _n_list = len(re.findall(r"https://doi\.org/", man[_ref_i:] if _ref_i >= 0 else ""))
    add("DOI links in the reference list", "one per entry that has one",
        "%d in the list, %d anywhere else" % (_n_list, _n_body),
        _n_body == 0 and _n_list >= 30 and n_doi == _n_list)

    figs = [i for i in range(1, 7) if ("Figure %d" % i) in man]
    add("Figures cited in the text", "6 of 6", "%d of 6 -> %s" % (len(figs), figs),
        len(figs) == 6)
    add("Tables in the main text", "reduced from 9 to 6",
        "%d table captions" % len(re.findall(r"\*\*Table \d+\.", man)),
        len(re.findall(r"\*\*Table \d+\.", man)) == 6)
    add("Statements and Declarations", "after the reference list",
        "after the reference list" if re.search(
            r"## References\b.*?## Statements and Declarations", man, re.S) else "not after",
        bool(re.search(r"## References\b.*?## Statements and Declarations", man, re.S)))
    add("Large-language-model use documented", "required by Springer",
        "present" if re.search(r"(large language model|ChatGPT)", man, re.I) else "absent",
        bool(re.search(r"(large language model|ChatGPT)", man, re.I)))
    add("Target-journal / version working header", "must not be left in the file", "absent",
        "Target journal:" not in man and "V3.1 - final validity repair" not in man)
    add("Data availability names the outcome registry", "present",
        "present" if "Supplementary Table S14" in man else "absent",
        "Supplementary Table S14" in man)
    _out_acc = ["GCST90002244", "GCST008999", "GCST90239664", "GCST90239652",
                "GCST90132314", "GCST90029004", "GCST90281273", "FinnGen R12"]
    _have = [a for a in _out_acc if a in man]
    add("Every primary outcome release named with its source", "8 of 8",
        "%d of 8" % len(_have), len(_have) == 8)
    _bmd_s = [s for s in re.split(r"(?<=[.;])\s+", man) if "GCST90029004" in s]
    add("The heel-eBMD release is not attributed to a study", "no attribution",
        "no attribution" if (bool(_bmd_s) and not any("Morris" in s for s in _bmd_s))
        else "attributed",
        bool(_bmd_s) and not any("Morris" in s for s in _bmd_s))
    add("Releases without a primary study publication disclosed", "present",
        "present" if "no primary study publication" in man else "absent",
        "no primary study publication" in man)

    ffa = os.path.join(QC, "V3_1_FINAL_FAILCLOSED_AUDIT.md")
    gates = passes = None
    if os.path.exists(ffa):
        t = io.open(ffa, encoding="utf-8").read()
        m = re.search(r"(\d+) gates; (\d+) passed; \*\*(\d+) failed\*\*", t)
        if m:
            gates, passes = int(m.group(1)), int(m.group(2))
    add("Fail-closed audit", "all gates pass",
        "%s of %s gates" % (passes, gates) if gates else "not available",
        bool(gates) and passes == gates)

    df = pd.DataFrame(rows)
    md = ["# SUBMISSION_COMPLIANCE.md (V3.1, rebuilt)", "",
          "Requirements for a Human Genetics (Springer) research article, measured against the",
          "rebuilt manuscript. This file reports; the fail-closed audit in",
          "`V3_1_FINAL_FAILCLOSED_AUDIT.md` decides. Both are generated, neither is typed.", "",
          "| requirement | limit | measured | result |", "|---|---|---|---|"]
    for _, r in df.iterrows():
        md.append("| %s | %s | %s | %s |" % (r["requirement"], r["limit"], r["measured"],
                                             r["result"]))
    md += ["", "**%d of %d checks pass.**" % (int((df["result"] == "PASS").sum()), len(df))]
    io.open(os.path.join(QC, "SUBMISSION_COMPLIANCE.md"), "w", encoding="utf-8",
            newline="\n").write("\n".join(md) + "\n")
    print(df.to_string(index=False, max_colwidth=58))
    n_fail = int((df["result"] != "PASS").sum())
    print("\ncompliance checks: %d  pass: %d  fail: %d" % (len(df), len(df) - n_fail, n_fail))
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
