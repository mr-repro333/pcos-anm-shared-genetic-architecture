# -*- coding: utf-8 -*-
"""V3.1 - the programmatic consistency audit.

The rule the package holds itself to: a quantity that is stated in more than one place must be
stated the *same* way in every place, and a withdrawn quantity must not be asserted anywhere.
This module enumerates the quantities and their documents, derives each canonical value from
the result file that owns it, and then searches the emitted documents for it.

It is deliberately independent of the document generator: it reads the finished documents and
the result files, not the generator's variables.

Locations audited (the list the repair was asked for)
  Abstract, main Results, Discussion, main tables, figures/source data, supplement,
  MASTER_RESULTS, difference tables, hormonal tables, power tables, Claim-Evidence Matrix,
  README.

Exit code 0 = every check passed.
"""
import io, os, re, sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, LOGD, SELF, PREV_PRIMARY, SD_ANM_PRIMARY, liability_multiplier

MAN = os.path.join(SELF, "01_MANUSCRIPT")
SUPP = os.path.join(SELF, "06_SUPPLEMENT")
RMS = os.path.join(SELF, "00_README")
QC = os.path.join(SELF, "08_QC")
FIG = os.path.join(SELF, "05_FIGURES")

# withdrawn phrasings that must not be ASSERTED anywhere
BANNED = [
    (r"systemic decoupling", "systemic decoupling"),
    (r"established systemic differences", "established systemic differences"),
    (r"separable systemic profiles", "separable systemic profiles"),
    (r"neither trait should be used as a proxy for the systemic risk", "proxy-for-the-other"),
    (r"three of the five endpoints separate", "three-of-five hormonal (old count)"),
    (r"three of five separate the two exposures", "three-of-five hormonal (old count)"),
    (r"FSH-mediated", "FSH-mediated"),
    (r"mechanistic mediator", "mechanistic mediator"),
    (r"resolved causal variant as", "resolved causal variant"),
]
# phrases whose presence is allowed only in a withdrawal or ladder context
CONTEXTUAL = [
    (r"FSHB mechanism established", r"(ladder|not permitted|NOT ALLOWED|withdraw|banned)"),
    (r"fine-mapped shared signal", r"(ladder|not permitted|NOT ALLOWED|withdraw|banned)"),
]


def read_texts():
    T = {}
    for base in (MAN, SUPP, RMS, QC):
        for fn in sorted(os.listdir(base)):
            if fn.endswith(".md"):
                T[os.path.join(os.path.basename(base), fn)] = io.open(
                    os.path.join(base, fn), encoding="utf-8").read()
    for fn in sorted(os.listdir(FIG)):
        pass
    src = os.path.join(FIG, "source_data")
    if os.path.isdir(src):
        for fn in sorted(os.listdir(src)):
            T["figure_source/" + fn] = io.open(os.path.join(src, fn), encoding="utf-8").read()
    # results tables as text
    for fn in sorted(os.listdir(RES)):
        if fn.endswith(".tsv"):
            T["result/" + fn] = io.open(os.path.join(RES, fn), encoding="utf-8").read()
    # claim matrix as text
    try:
        cm = pd.read_excel(os.path.join(RES, "V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"),
                           sheet_name="CLAIM_EVIDENCE_MATRIX_V31")
        T["claim_matrix"] = cm.to_csv(index=False)
        T["claim_matrix_safe"] = pd.read_excel(
            os.path.join(RES, "V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"),
            sheet_name="SAFE_FOR_ABSTRACT").to_csv(index=False)
    except Exception as e:
        T["claim_matrix"] = ""
    T["figures_source"] = "\n".join(v for k, v in T.items() if k.startswith("figure_source/"))
    return T


def g(x, nd=4):
    if isinstance(x, str):
        return x
    a = abs(x)
    if a == 0:
        return "0"
    if 1e-3 <= a < 1e4:
        return ("%%.%df" % nd) % x
    m_, e = ("%.*e" % (nd - 1, x)).split("e")
    return "%s x 10^%d" % (m_, int(e))


def main():
    T = read_texts()
    m = liability_multiplier(PREV_PRIMARY)
    d = pd.read_csv(os.path.join(RES, "V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv"), sep="\t")
    hor = pd.read_csv(os.path.join(RES, "V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv"), sep="\t")
    mde = pd.read_csv(os.path.join(RES, "V3_1_POWER_MDE_CORRECTED.tsv"), sep="\t")
    sk = pd.read_excel(os.path.join(RES, "V3_1_SKELETAL_EVIDENCE.xlsx"),
                       sheet_name="DOMAIN_SUMMARY").set_index("exposure_design")
    fshb = dict(zip(*pd.read_excel(os.path.join(RES, "V3_1_FSHB_EVIDENCE_AUDIT.xlsx"),
                                  sheet_name="PP4_FACTS").values.T))
    claims = pd.read_excel(os.path.join(RES, "V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"),
                           sheet_name="CLAIM_EVIDENCE_MATRIX_V31")
    mv = pd.read_csv(os.path.join(RES, "V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv"), sep="\t")
    mv0 = mv[np.isclose(mv["tau"], 0.0)]
    B0 = mv0[mv0["pair"] == "BMD"]

    n_fdr = int(d["fdr_pass"].sum())
    minp = float(d["p_rho0"].min())
    minq = float(d["q_BH_primary"].min())
    n_power = int(mde["anm_effect_detectable_corrected"].sum())
    sep = sorted(set(hor.loc[hor["fdr_pass_within_design"], "endpoint_label"]))

    # (check name, tokens that MUST appear, tokens that must appear in a sensible subset)
    checks = []

    def add(name, tokens, must_files=None, min_hits=1):
        checks.append(dict(name=name, tokens=tokens, must_files=must_files or [], min_hits=min_hits))

    add("FDR-positive count of nine is zero",
        ["0 of the nine tests survive", "Zero of the nine primary difference tests",
         "0 of 9 primary difference tests", "0 of 9 survive"])
    add("smallest corrected P", ["0.0343", "0.03433"])
    add("smallest corrected q", ["0.1651", "0.16506"])
    add("multiplier at K = 0.10", ["0.512825", "0.5128"])
    add("reciprocal 1/m", ["1.9500", "1.950"])
    add("the factor by which V3's values were too small", ["3.802", "3.8024"])
    add("power: none of nine", ["0 of the nine outcomes", "0 of 9 outcomes"])
    add("PP4 primary prior", ["0.998960"])
    add("PP4 grid minimum", ["0.989699"])
    add("surviving hormonal endpoints", ["Estradiol, LH", "estradiol and LH"])
    add("instrument display names are used in the documents",
        ["primary 19-locus (1 Mb)", "alternative ANM 77-locus"])
    add("every primary outcome release is identified in a shipped file",
        ["GCST90002244", "GCST008999", "GCST90029004", "GCST90281273", "GCST90239664",
         "GCST90239652", "GCST90132314"])
    add("every secondary outcome release is identified in a shipped file",
        ["GCST90025974", "GCST90691576", "GCST008994", "GCST90029037"])
    add("the heel-eBMD release is marked as having no primary study publication",
        ["no primary study publication"])
    add("the unused heel-eBMD atlas is named so the conflation cannot recur",
        ["GCST006979"])
    add("the accession non-resolution is recorded", ["ACCESSION_RESOLUTION_AUDIT"])
    add("the title states an unresolved signature", ["unresolved systemic signature"])

    # required to co-occur in the same document
    required_pairs = [
        ("PP4 primary and grid minimum together in the abstract",
         r"V3_1_manuscript\.md", [r"0\.998960", r"0\.989699"]),
        ("PP4 primary and grid minimum together in the supplementary tables",
         r"Supplementary_Tables\.md", [r"0\.998960", r"0\.989699"]),
        ("PP4 primary and grid minimum together in the supplementary methods",
         r"Supplementary_Methods\.md", [r"0\.998960", r"0\.989699"]),
        ("PP4 primary and grid minimum together in the README",
         r"README_FIRST\.md", [r"0\.998960", r"0\.989699"]),
        ("PP4 primary and grid minimum together in the claim matrix",
         r"claim_matrix", [r"0\.998960", r"0\.989699"]),
        ("ANM->PCOS CI on the OR scale in the manuscript",
         r"V3_1_manuscript\.md", [r"1\.069 to 1\.132"]),
        ("the outcome registry is cited in the Methods and the Data availability statement",
         r"V3_1_manuscript\.md", [r"Supplementary Table S14", r"ACCESSION_RESOLUTION_AUDIT"]),
        ("the heel-eBMD accession and the unattributed disclosure appear in the same document",
         r"V3_1_manuscript\.md", [r"GCST90029004", r"no primary study publication"]),
        ("the HbA1c accession appears with the publication that resolves it",
         r"V3_1_manuscript\.md", [r"GCST90002244", r"Chen et al\., 2021"]),
        ("the WHRadjBMI accession appears in the Methods",
         r"V3_1_manuscript\.md", [r"GCST008999", r"Pulit et al\., 2019"]),
        ("the corrected attribution reaches the supplement registry",
         r"Supplementary_Tables\.md", [r"GCST006979", r"no primary study publication"]),
        ("every primary outcome accession appears in the supplementary registry",
         r"Supplementary_Tables\.md",
         [r"GCST90002244", r"GCST008999", r"GCST90029004", r"GCST90281273",
          r"GCST90239664", r"GCST90239652", r"GCST90132314"]),
        ("every secondary outcome accession appears in the supplementary registry",
         r"Supplementary_Tables\.md",
         [r"GCST90025974", r"GCST90691576", r"GCST008994", r"GCST90029037"]),
        ("the registry marks the heel-eBMD release as unattributed",
         r"V3_1_OUTCOME_DATASET_REGISTRY\.tsv",
         [r"GCST90029004", r"no primary study publication", r"GCST006979"]),
        ("claim counts stated once in the README",
         r"README_FIRST\.md", [r"%d claims" % len(claims),
                               r"%d are\s+graded ROBUST" % int((claims["grade"] == "ROBUST").sum()),
                               r"%d are safe for the abstract"
                               % int((claims["safe_for_abstract"] == "YES").sum())]),
    ]

    pairs = []
    for name, pat, toks in required_pairs:
        hit = [k for k in T if re.search(pat, k)]
        for k in hit:
            missing = [t for t in toks if not re.search(t, T[k])]
            pairs.append(dict(name="%s [%s]" % (name, k), ok=not missing,
                              detail="" if not missing else "missing %s" % missing))
        if not hit:
            pairs.append(dict(name=name, ok=False, detail="no document matched %s" % pat))

    # banned phrases must not be asserted: allowed only if the line also signals withdrawal
    banned_rows = []
    LINE_MARK = (r"(withdraw|banned|not permitted|NOT ALLOWED|may not|do not (appear|use)|"
                 r"is withdrawn|old count|previous|rebuilt around)")
    # a phrase is "asserted" only if no negation appears in the 80 characters that precede it
    NEG_BEFORE = (r"(not|never|nor|no longer|without|exclud\w*|banned|withdrawn|"
                  r"avoid\w*)\b[^.]{0,80}$")
    for pat, label in BANNED:
        for k, v in T.items():
            for line in v.splitlines():
                for m in re.finditer(pat, line, flags=re.I):
                    window = line[max(0, m.start() - 90):m.start()]
                    neg = bool(re.search(NEG_BEFORE, window, flags=re.I))
                    mark = bool(re.search(LINE_MARK, line, flags=re.I))
                    banned_rows.append(dict(doc=k, phrase=label, asserted=not (neg or mark),
                                            context=(window + "[" + m.group(0) + "]"
                                                     + line[m.end():m.end() + 90]).strip()[:220]))
    banned_df = pd.DataFrame(banned_rows)

    # token presence
    rows = []
    for c in checks:
        total = 0
        where = []
        for k, v in T.items():
            if any(tok in v for tok in c["tokens"]):
                total += 1
                where.append(k)
        rows.append(dict(check=c["name"], tokens=" | ".join(c["tokens"]), documents_containing=total,
                         where=";".join(where[:6]), ok=total >= c["min_hits"]))
    tok = pd.DataFrame(rows)
    pair_df = pd.DataFrame(pairs)
    ok = bool(tok["ok"].all()) and bool(pair_df["ok"].all()) and \
        not (len(banned_df) and banned_df["asserted"].any())

    with pd.ExcelWriter(os.path.join(RES, "V3_1_CONSISTENCY_AUDIT.xlsx"), engine="openpyxl") as w:
        tok.to_excel(w, sheet_name="QUANTITY_PRESENCE", index=False)
        pair_df.to_excel(w, sheet_name="CO_OCCURRENCE", index=False)
        banned_df.to_excel(w, sheet_name="WITHDRAWN_PHRASINGS", index=False)
        pd.DataFrame([
            dict(location="Abstract", covered="yes - n=0 FDR, min P, min q, power, PP4 pair, "
                                              "hormonal pair"),
            dict(location="main Results", covered="yes"),
            dict(location="Discussion", covered="yes"),
            dict(location="main tables", covered="yes - Tables 1, 1b, 2, 3, 3b, 4, 5, 6, 7"),
            dict(location="figures / source data", covered="yes - recomputed from the corrected "
                                                           "result files"),
            dict(location="supplement", covered="yes - 13 tables, methods"),
            dict(location="MASTER_RESULTS", covered="yes - V3_1_MASTER_RESULTS_long.tsv carries "
                                                    "both scales per pair"),
            dict(location="difference tables", covered="yes"),
            dict(location="hormonal tables", covered="yes"),
            dict(location="power tables", covered="yes"),
            dict(location="Claim-Evidence Matrix", covered="yes"),
            dict(location="README", covered="yes"),
        ]).to_excel(w, sheet_name="LOCATIONS", index=False)

    md = ["# INTERNAL_CONSISTENCY_AUDIT (V3.1)", "",
          "Programmatic. `04_CODE/v31_consistency.py` reads the finished documents and the",
          "result files, derives each canonical quantity from the file that owns it, and",
          "searches every document for it. It does not read the generator's variables.", "",
          "## Quantity presence", "",
          "| check | value tokens | documents containing | ok |", "|---|---|---|---|"]
    for _, r in tok.iterrows():
        md.append("| %s | %s | %d | %s |" % (r["check"], r["tokens"], r["documents_containing"],
                                             "PASS" if r["ok"] else "**FAIL**"))
    md += ["", "## Co-occurrence requirements", "", "| requirement | ok | detail |",
           "|---|---|---|"]
    for _, r in pair_df.iterrows():
        md.append("| %s | %s | %s |" % (r["name"], "PASS" if r["ok"] else "**FAIL**",
                                        r["detail"]))
    md += ["", "## Withdrawn phrasings", "",
           "%d occurrences of a withdrawn phrase were found; %d of them are asserted rather "
           "than named as withdrawn." % (len(banned_df),
                                         int(banned_df["asserted"].sum()) if len(banned_df) else 0),
           "", "## Locations audited", "",
           "Abstract; main Results; Discussion; main tables; figures and figure source data; "
           "supplement; MASTER_RESULTS; the difference tables; the hormonal tables; the power "
           "tables; the Claim-Evidence Matrix; the README.", "",
           "**Overall: %s**" % ("PASS" if ok else "FAIL")]
    io.open(os.path.join(QC, "INTERNAL_CONSISTENCY_AUDIT.md"), "w", encoding="utf-8",
            newline="\n").write("\n".join(md))

    print(tok[["check", "documents_containing", "ok"]].to_string(index=False))
    print()
    print("co-occurrence:")
    for _, r in pair_df.iterrows():
        print("  %-70s %s %s" % (r["name"][:70], "PASS" if r["ok"] else "FAIL", r["detail"]))
    print()
    print("withdrawn-phrase occurrences:", len(banned_df),
          "| asserted:", int(banned_df["asserted"].sum()) if len(banned_df) else 0)
    if len(banned_df):
        for _, r in banned_df[banned_df["asserted"]].head(10).iterrows():
            print("   ASSERTED in %s: %s :: %s" % (r["doc"], r["phrase"], r["context"]))
    print()
    print("OVERALL:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
