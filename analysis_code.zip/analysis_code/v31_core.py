# -*- coding: utf-8 -*-
"""V3.1 core: configuration and the corrected liability-scale algebra.

V3.1 is a *validity repair* of V3, not a new version. It changes no endpoint, no
instrument, no outcome release and no family membership. It corrects three classes of
error (the reciprocal-scale error in the binary-exposure MR transformation, an unsigned
Stouffer implementation, and an unjustified MVMR covariance assumption) and makes the
package self-contained.

DATA_ROOT
---------
Every path is resolved relative to ``DATA_ROOT``, which is read from the environment
variable ``PCOS_ANM_DATA_ROOT`` and otherwise defaults to the project root. Relative
paths inside the shipped package therefore work from the package root, and an auditor
who has the raw deposits elsewhere can point ``PCOS_ANM_DATA_ROOT`` at them.

See ``03_RESULTS/V3_1_INPUT_MANIFEST.tsv`` for what the shipped package actually contains
and which inputs still have to be supplied from DATA_ROOT.
"""
import os

DATA_ROOT = os.environ.get(
    "PCOS_ANM_DATA_ROOT", r"E:\PCOS_ANM_Genetic_Decoupling")

V3 = os.path.join(DATA_ROOT, "V3_2026")
V2 = os.path.join(DATA_ROOT, "V2_2026")
# V3.1 lives beside V3 so that DATA_ROOT stays the single knob.
# The code tree is resolved from the location of THIS file, not from DATA_ROOT, so that a
# clean-environment run against a restored data root still writes its outputs next to the
# shipped code (and so that the smoke test can redirect them independently).
SELF = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

HARM_V2 = os.path.join(V2, "06_HARMONIZED")
MRV2 = os.path.join(V2, "07_MR_RESULTS_V2")
INS_V2 = os.path.join(V2, "05_INSTRUMENTS")
INS_ROOT = os.path.join(DATA_ROOT, "05_INSTRUMENTS")
COLOCC = os.path.join(DATA_ROOT, "09_COLOCALIZATION")
LDSC = os.path.join(DATA_ROOT, "16_LOGS")
MVMR_V1 = os.path.join(DATA_ROOT, "08_MVMR_RESULTS")

V3_RES = os.path.join(V3, "03_RESULTS")
V3_FIG = os.path.join(V3, "05_FIGURES")
V3_FSHB = os.path.join(V3, "09_FSHB")
V3_MVMR = os.path.join(V3, "08_MVMR_V3")

_OUT = os.environ.get("PCOS_ANM_V31_OUT", SELF)
RES = os.path.join(_OUT, "03_RESULTS")
LOGD = os.path.join(_OUT, "07_LOGS")
FIG = os.path.join(_OUT, "05_FIGURES")
INP = os.path.join(SELF, "10_INPUTS")
for _d in (RES, LOGD, FIG, INP, os.path.join(FIG, "source_data")):
    os.makedirs(_d, exist_ok=True)

# --------------------------------------------------------------- design constants
# Frozen in V3 and unchanged in V3.1.
SD_ANM_PRIMARY = 3.8
SD_ANM_GRID = [3.5, 3.8, 4.2]
PREV_PRIMARY = 0.10
PREV_GRID = [0.05, 0.06, 0.08, 0.10, 0.12, 0.15, 0.20]
RHO_GRID = [-1.0, -0.75, -0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0]
ALPHA = 0.05

PANEL9 = ["T2D", "HbA1c_MAGIC", "BMI_FINNGEN", "WHRadjBMI_Pulit_dense_combined",
          "TG", "HDL", "CAD", "BMD", "Fracture"]
PANEL9_LABEL = {
    "T2D": "Type 2 diabetes", "HbA1c_MAGIC": "HbA1c", "BMI_FINNGEN": "Body mass index",
    "WHRadjBMI_Pulit_dense_combined": "Waist-to-hip ratio adjusted for BMI",
    "TG": "Triglycerides", "HDL": "HDL cholesterol", "CAD": "Coronary artery disease",
    "BMD": "Heel bone mineral density", "Fracture": "Forearm fracture",
}

# The six endpoints that were pre-specified for the hormonal domain. All six stay
# visible in V3.1 whether or not they entered the tested family.
HORMONAL_PLANNED = ["FSH_FEMALE", "LH_FEMALE", "E2_FEMALE", "PROG_FEMALE",
                    "TESTO_FEMALE_ALT", "SHBG_FEMALE"]
HORMONAL_LABEL = {"FSH_FEMALE": "FSH", "LH_FEMALE": "LH", "E2_FEMALE": "Estradiol",
                  "PROG_FEMALE": "Progesterone", "TESTO_FEMALE_ALT": "Testosterone",
                  "SHBG_FEMALE": "SHBG"}

SKELETAL = {"BMD": +1, "Osteoporosis_FINNGEN": -1, "Fracture": -1,
            "Fracture_forearm_FINNGEN": -1, "Fracture_femur_FINNGEN": -1,
            "Fracture_lowerleg_FINNGEN": -1, "Fracture_lumbarspine_FINNGEN": -1}
SKELETAL_PRIMARY = ["BMD", "Fracture"]
SKELETAL_ALT = ["Osteoporosis_FINNGEN", "Fracture_forearm_FINNGEN",
                "Fracture_femur_FINNGEN", "Fracture_lowerleg_FINNGEN",
                "Fracture_lumbarspine_FINNGEN"]

DESIGNS = {
    "D1": dict(alias=["PCOS_EUR_1Mb"], window=1000,
               source="GCST90570579 (European, age-adjusted)", role="primary", n_loci=19),
    "D2": dict(alias=["PCOS_EUR_10Mb", "PCOS_EUR_GCST90570579"], window=10000,
               source="GCST90570579 (European, age-adjusted)", role="V1-comparable sensitivity",
               n_loci=18),
    "D3": dict(alias=["PCOS_ALT_Venkatesh_1Mb"], window=1000,
               source="GCST90483500 (European, Venkatesh 2025)",
               role="alternative-study sensitivity", n_loci=25),
    "D4": dict(alias=["PCOS_UNION_D4_1Mb"], window=1000,
               source="D1 union D3, jointly re-clumped",
               role="union-of-studies power sensitivity", n_loci=29),
    "D5": dict(alias=["PCOS_ALL_1Mb"], window=1000,
               source="GCST90570580 (all-ancestry, age-adjusted)", role="ancestry sensitivity",
               n_loci=22),
    "D6": dict(alias=["PCOS_ALL_GCST90570580"], window=10000,
               source="GCST90570580 (all-ancestry, age-adjusted)",
               role="V1-window all-ancestry sensitivity (excluded from V3/V3.1 inference)",
               n_loci=20),
    "A1": dict(alias=["ANM_RUTH2021"], window=10000,
               source="Ruth 2021 (reprogen.org)", role="primary ANM", n_loci=213),
    "A2": dict(alias=["ANM_UKB_GCST90029037"], window=10000,
               source="GCST90029037", role="alternative ANM", n_loci=77),
}
ALIAS2CANON = {a: c for c, v in DESIGNS.items() for a in v["alias"]}


# ------------------------------------------------------------------ scale algebra
def liability_multiplier(K):
    """m(K) = K(1-K) / phi(Phi^-1(1-K)), the *SNP-exposure* multiplier.

    Under the liability-threshold model the per-allele log-odds coefficient b and the
    per-allele shift of the latent liability beta_L satisfy

        b = phi(t) beta_L / (K(1-K)),   t = Phi^-1(1-K)

    so that beta_L = m(K) * b. Keeping the two directions apart matters, because the
    multiplier is applied to a SNP-exposure association and never to an MR ratio.
    """
    from scipy import stats
    t = stats.norm.ppf(1 - K)
    return K * (1 - K) / stats.norm.pdf(t)


def snp_exposure_to_liability(beta_logOR, se_logOR, K):
    """SNP-exposure association: log-OR scale -> per-SD-of-liability scale. MULTIPLY.

    beta_X,L = m(K) * beta_X,logOR. This is the only place a multiplication by m(K)
    is admissible. Returns (beta_L, se_L, m).
    """
    m = liability_multiplier(K)
    return beta_logOR * m, se_logOR * m, m


def mr_ratio_to_liability(theta_logOR, se_logOR, K):
    """MR ratio (outcome per unit log-OR of exposure) -> outcome per 1 SD of liability.

    The MR ratio is theta = beta_Y / beta_X. Rescaling the exposure coefficient by c
    rescales the ratio by 1/c. Here the exposure coefficient is rescaled by m(K), so

        theta_L = theta_logOR / m(K)      SE(theta_L) = SE(theta_logOR) / m(K)

    An MR ratio is *divided* by m(K). Multiplying it - which is what V3 did - is the
    reciprocal of the correct transformation and is wrong by a factor of m(K)^2.
    Returns (theta_L, se_L, m).
    """
    m = liability_multiplier(K)
    return theta_logOR / m, se_logOR / m, m


def ratio_rescale_check(bx, bxse, by, byse, c):
    """Algebraic/numerical check used by the unit test.

    Recomputes a single-instrument-vector IVW ratio under the raw exposure scale and
    under an exposure rescaled by ``c``; returns (theta, theta_rescaled, ratio_of_ratios)
    so that a caller can assert ratio_of_ratios == 1/c (exposure-rescaled) which is
    equivalent to theta_scaled = theta / c.
    """
    import numpy as np
    bx = np.asarray(bx, float); bxse = np.asarray(bxse, float)
    by = np.asarray(by, float); byse = np.asarray(byse, float)
    w = 1.0 / (byse ** 2 / bx ** 2)
    r = by / bx
    theta = float(np.sum(w * r) / np.sum(w))
    bx2, bxse2 = bx * c, bxse * c
    w2 = 1.0 / (byse ** 2 / bx2 ** 2)
    r2 = by / bx2
    theta2 = float(np.sum(w2 * r2) / np.sum(w2))
    return theta, theta2, theta2 / theta
