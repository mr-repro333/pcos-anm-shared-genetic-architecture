# -*- coding: utf-8 -*-
"""V3.1 PRIORITY 0 - the corrected formal PCOS-vs-ANM comparison.

WHAT WAS WRONG IN V3
--------------------
V3 derived the SNP-exposure conversion correctly,

    beta_L = m(K) * beta_logOR ,   m(K) = K(1-K) / phi(Phi^-1(1-K)) ~ 0.513 at K = 0.10,

and then applied it to the wrong object. For an MR ratio

    theta_logOR = beta_Y / beta_X,logOR      and     beta_X,L = m * beta_X,logOR

so the liability-scale ratio is

    theta_L = beta_Y / beta_X,L = theta_logOR / m(K) ,      SE(theta_L) = SE(theta_logOR) / m(K).

V3 multiplied the ratio and its SE by m(K) instead of dividing, i.e. it applied the correct
multiplier in the wrong direction. The shipped per-SD effect is therefore too small by
m(K)^2 = 3.80 at K = 0.10, and - the property that actually matters for the paper - the
*change* is not a uniform rescaling of the difference test, because only one arm of the
comparison is affected.

WHAT V3.1 DOES
--------------
Reruns the identical frozen family with

    PCOS arm : MR estimate / m(K)      (primary K = 0.10; grid 0.05-0.20)
    ANM arm  : per-year MR estimate * SD_ANM   (primary 3.8 yr; grid 3.5-4.2)

and nothing else changed: same nine outcomes, same primary dataset per outcome (D1 for
PCOS, A1 for ANM), same rho grid, same BH procedure, same family. Alternative releases stay
demoted to replication/sensitivity. No outcome was added, removed or re-assigned.
"""
import io, json, math, os, sys

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import (RES, LOGD, V3_RES, MRV2, PANEL9, PANEL9_LABEL, DESIGNS, ALIAS2CANON,
                      SD_ANM_PRIMARY, SD_ANM_GRID, PREV_PRIMARY, PREV_GRID, RHO_GRID, ALPHA,
                      liability_multiplier, mr_ratio_to_liability)


def zp(z):
    return float(2 * stats.norm.sf(abs(z)))


def bh(p):
    p = np.asarray(p, float)
    out = np.full_like(p, np.nan)
    ok = np.isfinite(p)
    pv = p[ok]; n = len(pv)
    if n == 0:
        return out
    o = np.argsort(pv); r = pv[o]
    q = r * n / (np.arange(n) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    t = np.empty(n); t[o] = np.clip(q, 0, 1)
    out[ok] = t
    return out


def load_master():
    m = pd.read_csv(os.path.join(MRV2, "_MR_MASTER_SUMMARY.tsv"), sep="\t")
    m["exposure_raw"] = m["pair"].str.split("__").str[0]
    m["outcome"] = m["pair"].str.split("__").str[1]
    m["design"] = m["exposure_raw"].map(ALIAS2CANON)
    m = m[m["design"].notna()].copy()
    rank = {a: i for c, v in DESIGNS.items() for i, a in enumerate(v["alias"])}
    m["alias_rank"] = m["exposure_raw"].map(rank)
    m = m.sort_values(["design", "outcome", "alias_rank", "pair"])
    return m.drop_duplicates(subset=["design", "outcome"], keep="first")


def difference_row(master, outcome, pcos_design, anm_design, K, sd_anm, transform):
    """transform: 'reciprocal' (V3.1, correct) or 'multiplicative' (V3, wrong)."""
    def rec(d):
        r = master[(master["design"] == d) & (master["outcome"] == outcome)]
        return None if r.empty else r.iloc[0]
    p, a = rec(pcos_design), rec(anm_design)
    if p is None or a is None:
        return None
    m = liability_multiplier(K)
    if transform == "reciprocal":
        bP, sP, _ = mr_ratio_to_liability(float(p["ivw"]), float(p["ivw_se"]), K)
        arm = "theta_L = theta_logOR / m(K)   [V3.1, correct]"
    else:
        bP, sP = float(p["ivw"]) * m, float(p["ivw_se"]) * m
        arm = "theta_L = theta_logOR * m(K)   [V3, incorrect]"
    bA, sA = float(a["ivw"]) * sd_anm, float(a["ivw_se"]) * sd_anm
    d = bP - bA
    se0 = math.sqrt(sP ** 2 + sA ** 2)
    row = dict(outcome=outcome, outcome_label=PANEL9_LABEL.get(outcome, outcome),
               pcos_design=pcos_design, anm_design=anm_design,
               n_snp_pcos=int(p["nsnp"]), n_snp_anm=int(a["nsnp"]),
               pcos_logOR=float(p["ivw"]), pcos_logOR_se=float(p["ivw_se"]),
               p_pcos_logOR=float(p["ivw_p"]),
               pcos_perSD=bP, pcos_perSD_se=sP,
               anm_per_year=float(a["ivw"]), anm_per_year_se=float(a["ivw_se"]),
               p_anm_per_year=float(a["ivw_p"]),
               anm_perSD=bA, anm_perSD_se=sA,
               difference=d, se_rho0=se0, p_rho0=zp(d / se0),
               ci_lower_rho0=d - 1.96 * se0, ci_upper_rho0=d + 1.96 * se0,
               multiplier=m, K=K, sd_anm=sd_anm, arm_transform=arm)
    dz = abs(d) / stats.norm.ppf(1 - ALPHA / 2)
    num = sP ** 2 + sA ** 2 - dz ** 2
    row["rho_star_for_significance"] = num / (2 * sP * sA) if sP * sA > 0 else np.nan
    row["p_rho_minus1"] = zp(d / (sP + sA))
    row["p_rho_plus1"] = zp(d / abs(sP - sA)) if abs(sP - sA) > 0 else 0.0
    for r in RHO_GRID:
        se = math.sqrt(sP ** 2 + sA ** 2 - 2 * r * sP * sA)
        row["se_rho_%+.2f" % r] = se
        row["p_rho_%+.2f" % r] = zp(d / se)
    row["holds_for_all_nonneg_rho"] = bool(row["p_rho0"] < ALPHA and
                                           row["rho_star_for_significance"] <= 0)
    return row


def verdict(r, qcol):
    if not (r[qcol] < ALPHA):
        if r["p_rho0"] < ALPHA:
            return "nominally different, NOT FDR-significant -> withdrawn"
        if r["p_rho_plus1"] >= ALPHA:
            return "no detectable difference (even at rho = +1)"
        return "no formal difference established"
    if r["holds_for_all_nonneg_rho"]:
        return "formal difference survives BH-FDR; holds for all rho >= 0"
    return "formal difference survives BH-FDR; conditional on rho >= rho* > 0"


def build_family(master, transform, K=PREV_PRIMARY, sd=SD_ANM_PRIMARY):
    rows = [difference_row(master, o, "D1", "A1", K, sd, transform) for o in PANEL9]
    df = pd.DataFrame([r for r in rows if r])
    df["q_BH_primary"] = bh(df["p_rho0"].values)
    df["nominal_pass"] = df["p_rho0"] < ALPHA
    df["fdr_pass"] = df["q_BH_primary"] < ALPHA
    df["verdict"] = df.apply(lambda r: verdict(r, "q_BH_primary"), axis=1)
    return df


ALT = {"T2D_FINNGEN": "T2D", "HbA1c": "HbA1c_MAGIC", "HbA1c_PanUKB": "HbA1c_MAGIC",
       "BMI_combined": "BMI_FINNGEN", "BMI_females": "BMI_FINNGEN",
       "WHRadjBMI_yengo_combined": "WHRadjBMI_Pulit_dense_combined",
       "WHRadjBMI_yengo_females": "WHRadjBMI_Pulit_dense_combined",
       "CAD_FINNGEN": "CAD", "Osteoporosis_FINNGEN": "BMD",
       "Fracture_forearm_FINNGEN": "Fracture", "Fracture_femur_FINNGEN": "Fracture"}


def main():
    log = io.open(os.path.join(LOGD, "v31_diff.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    master = load_master()
    L("MR master records mapped to canonical designs: %d" % len(master))

    # ---------------------------------------------------------- corrected family
    v31 = build_family(master, "reciprocal")
    v3 = build_family(master, "multiplicative")
    assert len(v31) == 9 and len(v3) == 9, "frozen nine-test family changed size"

    # ------------------------------------------- side-by-side V3 vs V3.1
    side = []
    for _, a in v31.iterrows():
        b = v3[v3["outcome"] == a["outcome"]].iloc[0]
        side.append(dict(
            outcome=a["outcome"], outcome_label=a["outcome_label"],
            v3_pcos_perSD=b["pcos_perSD"], v31_pcos_perSD=a["pcos_perSD"],
            pcos_ratio_v31_over_v3=a["pcos_perSD"] / b["pcos_perSD"] if b["pcos_perSD"] else np.nan,
            v3_difference=b["difference"], v31_difference=a["difference"],
            delta_difference=a["difference"] - b["difference"],
            v3_se_rho0=b["se_rho0"], v31_se_rho0=a["se_rho0"],
            v3_p_rho0=b["p_rho0"], v31_p_rho0=a["p_rho0"],
            delta_p=a["p_rho0"] - b["p_rho0"],
            v3_q_BH=b["q_BH_primary"], v31_q_BH=a["q_BH_primary"],
            delta_q=a["q_BH_primary"] - b["q_BH_primary"],
            v3_fdr_pass=bool(b["fdr_pass"]), v31_fdr_pass=bool(a["fdr_pass"]),
            claim_status_change=("%s -> %s" % (
                "UPHELD" if b["fdr_pass"] else "not established",
                "UPHELD" if a["fdr_pass"] else "not established")),
            v3_verdict=b["verdict"], v31_verdict=a["verdict"]))
    side = pd.DataFrame(side)
    v31.to_csv(os.path.join(RES, "V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv"), sep="\t", index=False)
    v3.to_csv(os.path.join(RES, "V3_1_DIFFERENCE_PRIMARY9_V3METHOD_COMPARATOR.tsv"),
              sep="\t", index=False)
    side.to_csv(os.path.join(RES, "V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv"), sep="\t", index=False)

    L("\n=== V3.1 corrected primary family (theta_L = theta_logOR / m(K), K=0.10) ===")
    L(v31[["outcome", "pcos_perSD", "pcos_perSD_se", "anm_perSD", "anm_perSD_se", "difference",
           "se_rho0", "p_rho0", "q_BH_primary", "rho_star_for_significance", "fdr_pass"]]
      .to_string(index=False))
    L("\n=== side by side: what the correction does ===")
    L(side[["outcome", "v3_p_rho0", "v31_p_rho0", "delta_p", "v3_q_BH", "v31_q_BH",
            "v3_fdr_pass", "v31_fdr_pass", "claim_status_change"]].to_string(index=False))
    L("\nFDR-positive on the corrected scale: %d/9 ; on V3's scale: %d/9"
      % (int(v31["fdr_pass"].sum()), int(v3["fdr_pass"].sum())))

    # ------------------------------------------------------------------ rho grid
    grid = []
    for _, r in v31.iterrows():
        for rho in RHO_GRID:
            grid.append(dict(outcome=r["outcome"], outcome_label=r["outcome_label"], rho=rho,
                             se_difference=r["se_rho_%+.2f" % rho],
                             p_difference=r["p_rho_%+.2f" % rho],
                             significant=bool(r["p_rho_%+.2f" % rho] < ALPHA)))
    pd.DataFrame(grid).to_csv(os.path.join(RES, "V3_1_RHO_SENSITIVITY_GRID.tsv"),
                              sep="\t", index=False)

    # -------------------------------------------------- prevalence sensitivity
    prevrows = []
    for K in PREV_GRID:
        for o in PANEL9:
            r = difference_row(master, o, "D1", "A1", K, SD_ANM_PRIMARY, "reciprocal")
            if r:
                prevrows.append(dict(outcome=o, outcome_label=r["outcome_label"], K=K,
                                     multiplier=r["multiplier"],
                                     pcos_perSD=r["pcos_perSD"], difference=r["difference"],
                                     se_rho0=r["se_rho0"], p_rho0=r["p_rho0"]))
    pv = pd.DataFrame(prevrows)
    pv["q_BH_within_K"] = np.nan
    for K, g in pv.groupby("K"):
        pv.loc[g.index, "q_BH_within_K"] = bh(g["p_rho0"].values)
    pv["fdr_pass"] = pv["q_BH_within_K"] < ALPHA
    pv.to_csv(os.path.join(RES, "V3_1_PREVALENCE_SENSITIVITY.tsv"), sep="\t", index=False)
    L("\n=== prevalence sensitivity: BH-positive count per K ===")
    L(pv.groupby("K")["fdr_pass"].sum().to_string())

    # ------------------------------------------------------- SD_ANM sensitivity
    sdrows = []
    for sd in SD_ANM_GRID:
        for o in PANEL9:
            r = difference_row(master, o, "D1", "A1", PREV_PRIMARY, sd, "reciprocal")
            if r:
                sdrows.append(dict(outcome=o, outcome_label=r["outcome_label"], sd_anm=sd,
                                   difference=r["difference"], p_rho0=r["p_rho0"]))
    sd = pd.DataFrame(sdrows)
    sd["q_BH_within_SD"] = np.nan
    for s, g in sd.groupby("sd_anm"):
        sd.loc[g.index, "q_BH_within_SD"] = bh(g["p_rho0"].values)
    sd["fdr_pass"] = sd["q_BH_within_SD"] < ALPHA
    sd.to_csv(os.path.join(RES, "V3_1_SD_ANM_SENSITIVITY.tsv"), sep="\t", index=False)
    L("\n=== SD_ANM sensitivity: BH-positive count per SD ===")
    L(sd.groupby("sd_anm")["fdr_pass"].sum().to_string())

    # ------------------------------------------------------- alternatives (rep.)
    altrows = []
    for a_name, parent in ALT.items():
        for design, role in [("D1", "primary exposure x alternative outcome release"),
                             ("D3", "alternative exposure x primary outcome"),
                             ("D4", "union exposure x primary outcome")]:
            r = difference_row(master, a_name, design, "A1", PREV_PRIMARY, SD_ANM_PRIMARY,
                               "reciprocal")
            if r:
                v3r = difference_row(master, a_name, design, "A1", PREV_PRIMARY, SD_ANM_PRIMARY,
                                     "multiplicative")
                r.update(parent_phenotype=parent, role=role,
                         family="replication_or_sensitivity_NOT_IN_PRIMARY_FAMILY",
                         v3_p_rho0=v3r["p_rho0"], v3_pcos_perSD=v3r["pcos_perSD"])
                altrows.append(r)
    alt = pd.DataFrame(altrows)
    alt["q_BH_within_alt_family"] = bh(alt["p_rho0"].values)
    alt.to_csv(os.path.join(RES, "V3_1_DIFFERENCE_ALTERNATIVES_SENSITIVITY.tsv"),
               sep="\t", index=False)

    # ------------------------------------------------------------ MDE / power
    za = stats.norm.ppf(1 - ALPHA / 2)
    zf = stats.norm.ppf(1 - 0.05 / 2 / len(PANEL9))
    zb = stats.norm.ppf(0.80)
    mrows = []
    m10 = liability_multiplier(PREV_PRIMARY)
    for o in PANEL9:
        p = master[(master["design"] == "D1") & (master["outcome"] == o)]
        a = master[(master["design"] == "A1") & (master["outcome"] == o)]
        if p.empty:
            continue
        p = p.iloc[0]
        se_correct = float(p["ivw_se"]) / m10      # corrected reciprocal SE
        se_v3 = float(p["ivw_se"]) * m10           # V3's SE
        row = dict(outcome=o, outcome_label=PANEL9_LABEL.get(o, o), pcos_design="D1",
                   n_snp=int(p["nsnp"]),
                   se_perSD_corrected=se_correct, se_perSD_v3=se_v3,
                   observed_perSD_corrected=float(p["ivw"]) / m10,
                   observed_perSD_v3=float(p["ivw"]) * m10,
                   observed_p_logOR=float(p["ivw_p"]),
                   MDE80_alpha005_corrected=(za + zb) * se_correct,
                   MDE80_alpha_family_corrected=(zf + zb) * se_correct,
                   MDE80_alpha005_v3=(za + zb) * se_v3,
                   MDE80_alpha_family_v3=(zf + zb) * se_v3)
        if not a.empty:
            a = a.iloc[0]
            bA = float(a["ivw"]) * SD_ANM_PRIMARY
            row["anm_effect_perSD"] = bA
            row["mde_ratio_corrected_over_v3"] = se_correct / se_v3
            row["anm_effect_detectable_corrected"] = bool(abs(bA) >= row["MDE80_alpha005_corrected"])
            row["power_to_detect_ANM_effect_corrected"] = float(
                stats.norm.cdf(abs(bA) / se_correct - za) +
                stats.norm.cdf(-abs(bA) / se_correct - za))
            row["power_to_detect_ANM_effect_v3"] = float(
                stats.norm.cdf(abs(bA) / se_v3 - za) + stats.norm.cdf(-abs(bA) / se_v3 - za))
        mrows.append(row)
    mde = pd.DataFrame(mrows)
    mde.to_csv(os.path.join(RES, "V3_1_POWER_MDE_CORRECTED.tsv"), sep="\t", index=False)
    L("\n=== MDE / power, corrected reciprocal SE ===")
    L(mde[["outcome", "se_perSD_corrected", "MDE80_alpha005_corrected", "anm_effect_perSD",
           "anm_effect_detectable_corrected", "power_to_detect_ANM_effect_corrected"]]
      .to_string(index=False))

    summary = dict(
        multiplier_at_K010=liability_multiplier(PREV_PRIMARY),
        multiplier_range=[liability_multiplier(min(PREV_GRID)),
                          liability_multiplier(max(PREV_GRID))],
        v3_multiplication_undershoot_factor=1.0 / liability_multiplier(PREV_PRIMARY) ** 2,
        n_primary=len(v31),
        n_fdr_pass_corrected=int(v31["fdr_pass"].sum()),
        n_fdr_pass_v3method=int(v3["fdr_pass"].sum()),
        fdr_pass_corrected=list(v31.loc[v31["fdr_pass"], "outcome"]),
        fdr_pass_v3method=list(v3.loc[v3["fdr_pass"], "outcome"]),
        min_q_corrected=float(v31["q_BH_primary"].min()),
        min_p_corrected=float(v31["p_rho0"].min()),
        fdr_positive_at_every_K_in_grid=bool(pv.groupby("K")["fdr_pass"].sum().gt(0).all()),
        fdr_positive_at_every_SD_in_grid=bool(sd.groupby("sd_anm")["fdr_pass"].sum().gt(0).all()))
    json.dump(summary, io.open(os.path.join(LOGD, "v31_diff_summary.json"), "w"), indent=2)
    print(json.dumps(summary, indent=2))
    log.close()


if __name__ == "__main__":
    main()
