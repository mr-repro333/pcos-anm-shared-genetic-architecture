# -*- coding: utf-8 -*-
"""V3.1 document generator.

Every document produced here is templated and every number in it is read from a V3.1
result file, so a document cannot drift from the analysis it describes. The consistency
audit in ``v31_consistency.py`` re-checks the same quantity list against the emitted files
independently of this generator.

Outputs
-------
01_MANUSCRIPT/V3_1_manuscript.md
06_SUPPLEMENT/Supplementary_Methods.md, Supplementary_Tables.md,
             Supplementary_Figure_Legends.md, READ_ME_SUPPLEMENT.md
00_README/README_FIRST.md, FINAL_EXECUTIVE_SUMMARY.md, V3_TO_V31_CHANGELOG.md,
         V3_TO_V31_CHANGELOG.json
02_ANALYSIS_PLAN/V31_REPAIR_PLAN_LOCKED.md, DECISION_LOG.md, DEVIATIONS_FROM_PLAN.md
08_QC/STATISTICAL_AUDIT.md, KNOWN_LIMITATIONS.md
09_REVIEWER_SIMULATION/*.md
"""
import io, json, os, sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import (RES, LOGD, SELF, PREV_PRIMARY, PREV_GRID, SD_ANM_PRIMARY, SD_ANM_GRID,
                      RHO_GRID, ALPHA, liability_multiplier, PANEL9, PANEL9_LABEL)
from v31_refs import C as REFC, render_references

OUT_MAN = os.path.join(SELF, "01_MANUSCRIPT")
OUT_SUPP = os.path.join(SELF, "06_SUPPLEMENT")
OUT_README = os.path.join(SELF, "00_README")
OUT_PLAN = os.path.join(SELF, "02_ANALYSIS_PLAN")
OUT_QC = os.path.join(SELF, "08_QC")
OUT_REV = os.path.join(SELF, "09_REVIEWER_SIMULATION")
for _d in (OUT_MAN, OUT_SUPP, OUT_README, OUT_PLAN, OUT_QC, OUT_REV):
    os.makedirs(_d, exist_ok=True)


def W(path, text):
    io.open(path, "w", encoding="utf-8", newline="\n").write(text)
    return path


def rd(n):
    return pd.read_csv(os.path.join(RES, n), sep="\t")


def xl(n, sheet):
    return pd.read_excel(os.path.join(RES, n), sheet_name=sheet)


def g(x, nd=4):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "n/a"
    a = abs(x)
    if a == 0:
        return "0"
    if 1e-3 <= a < 1e4:
        return ("%%.%df" % nd) % x
    m_, e = ("%.*e" % (nd - 1, x)).split("e")
    return "%s x 10^%d" % (m_, int(e))


def rho_star(x):
    """rho* is a correlation, so a value outside [-1, +1] means the test never reaches alpha.

    Printing 2.312 under a heading that calls the column a correlation is a defect: the reader
    is invited to read it as an attainable correlation. Values outside the range are marked.
    """
    if x is None or not np.isfinite(x):
        return "n/a"
    if x > 1.0:
        return ">+1 (unreachable)"
    if x < -1.0:
        return "<-1 (unreachable)"
    return "%+.3f" % x


RHO_STR = ", ".join(("%+.2f" % r).replace("+0.00", "0") for r in RHO_GRID)
PREV_STR = ", ".join(str(k) for k in PREV_GRID)
SD_STR = ", ".join(str(s) for s in SD_ANM_GRID)

# Display names for the instrument designs. The codes D1..A2 are kept in the result files
# (and in the per-variant provenance tables, where they are the primary key), but the
# documents name each instrument for its locus count and window so that a reader does not
# have to hold a code table in working memory.
DNAME_SHORT = {
    "D1": "primary 19-locus (1 Mb)",
    "D2": "10 Mb 18-locus",
    "D3": "second study 25-locus",
    "D4": "union 29-locus",
    "D5": "all-ancestry 22-locus",
    "D6": "all-ancestry 20-locus (excluded)",
    "A1": "primary ANM 213-locus",
    "A2": "alternative ANM 77-locus",
}
DNAME_CODE_NOTE = ("Instrument codes used in the result files and provenance tables: "
                   + "; ".join("%s = %s" % (k, v) for k, v in sorted(DNAME_SHORT.items())) + ".")

TPL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "v31_manuscript_template.md")


def _load_template():
    """The manuscript prose lives in v31_manuscript_template.md, not in this module."""
    return io.open(TPL_PATH, encoding="utf-8").read()





def build_tables():
    d = rd("V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv")
    side = rd("V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv").set_index("outcome")
    mde = rd("V3_1_POWER_MDE_CORRECTED.tsv").set_index("outcome")
    sk = xl("V3_1_SKELETAL_EVIDENCE.xlsx", "DOMAIN_SUMMARY").set_index("exposure_design")
    skp = xl("V3_1_SKELETAL_EVIDENCE.xlsx", "PER_ENDPOINT")
    hor = rd("V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv")
    acct = rd("V3_1_HORMONAL_ENDPOINT_ACCOUNTING.tsv")
    mv = rd("V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv")
    coloc = xl("V3_1_FSHB_EVIDENCE_AUDIT.xlsx", "ALL_COLOCALISED_PCOS_ANM")
    fshb = dict(zip(*xl("V3_1_FSHB_EVIDENCE_AUDIT.xlsx", "PP4_FACTS").values.T))

    t1 = ["| outcome | n SNP PCOS | n SNP ANM | PCOS per SD (corrected) | ANM per SD | "
          "difference | 95% CI (rho=0) | P (rho=0) | q (BH) | P at rho=-1 | rho* | passes BH? |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in d.iterrows():
        t1.append("| %s | %d | %d | %+.4f | %+.4f | %+.4f | %+.4f to %+.4f | %s | %s | %s | "
                  "%s | %s |" % (
                      PANEL9_LABEL.get(r["outcome"], r["outcome"]), r["n_snp_pcos"],
                      r["n_snp_anm"], r["pcos_perSD"], r["anm_perSD"], r["difference"],
                      r["ci_lower_rho0"], r["ci_upper_rho0"], g(r["p_rho0"]),
                      g(r["q_BH_primary"]), g(r["p_rho_minus1"]),
                      rho_star(r["rho_star_for_significance"]),
                      "yes" if r["fdr_pass"] else "**no**"))

    # Self-describing column names: the supplement is read by people who never saw the
    # superseded scale, so the two columns are named by what they are.
    t1b = ["| outcome | PCOS per SD, multiplicative | PCOS per SD, reciprocal | "
           "P, multiplicative | P, reciprocal | change in P | q, multiplicative | "
           "q, reciprocal | verdict, multiplicative | verdict, reciprocal |",
           "|---|---|---|---|---|---|---|---|---|---|"]
    for o in d["outcome"]:
        s = side.loc[o]
        t1b.append("| %s | %+.4f | %+.4f | %s | %s | %+.4f | %s | %s | %s | %s |" % (
            PANEL9_LABEL.get(o, o), s["v3_pcos_perSD"], s["v31_pcos_perSD"],
            g(s["v3_p_rho0"]), g(s["v31_p_rho0"]), s["delta_p"], g(s["v3_q_BH"]),
            g(s["v31_q_BH"]), "passed BH" if s["v3_fdr_pass"] else "not established",
            "passed BH" if s["v31_fdr_pass"] else "not established"))

    t2 = ["| outcome | n SNP | corrected SE | MDE (alpha=0.05) | MDE (alpha=0.05/9) | "
          "ANM effect (magnitude) | detectable? | power |",
          "|---|---|---|---|---|---|---|---|"]
    for o in PANEL9:
        r = mde.loc[o]
        t2.append("| %s | %d | %.5f | %.5f | %.5f | %.5f | %s | %.2f |" % (
            PANEL9_LABEL.get(o, o), r["n_snp"], r["se_perSD_corrected"],
            r["MDE80_alpha005_corrected"], r["MDE80_alpha_family_corrected"],
            abs(r["anm_effect_perSD"]),
            "yes" if r["anm_effect_detectable_corrected"] else "**no**",
            r["power_to_detect_ANM_effect_corrected"]))

    _t3h = ("| instrument | endpoints | direction consistency | endpoint-FDR passes | "
            "signed Stouffer P (rho=0) | (rho=0.5) | (rho=0.9) | unsigned P (rho=0.5) ")
    t3 = [_t3h + "|", "|---|---|---|---|---|---|---|---|"]
    t3f = [_t3h + "| withdrawn pooled P |", "|---|---|---|---|---|---|---|---|---|"]
    for dz in ["A1", "A2", "D1", "D2", "D3", "D4", "D5"]:
        r = sk.loc[dz]
        base = ("| %s | %d | %.2f | %d | %s | %s | %s | %s" % (
            DNAME_SHORT[dz], r["k"], r["direction_consistency"], r["n_fdr_pass"],
            g(r["stouffer_p_signed_rho000"]), g(r["stouffer_p_signed_rho050"]),
            g(r["stouffer_p_signed_rho090"]), g(r["stouffer_p_V3unsigned_rho050"])))
        t3.append(base + " |")
        t3f.append(base + " | %s |" % g(r["naive_meta_p_withdrawn"]))

    t3b = ["| tier | endpoint | n SNP | aligned beta | SE | P | endpoint-FDR | pass |",
           "|---|---|---|---|---|---|---|---|"]
    for stat, lab in [("primary", "1. primary eBMD / primary fracture"),
                      ("alternative", "3-4. osteoporosis and site-specific fracture")]:
        for _, r in skp[(skp["exposure_design"] == "A1") & (skp["status"] == stat)].iterrows():
            t3b.append("| %s | %s | %d | %+.4f | %.4f | %s | %s | %s |" % (
                lab, r["endpoint"], r["n_snp"], r["beta_aligned"], r["se"], g(r["p"]),
                g(r["FDR_within_skeletal"]), "yes" if r["fdr_pass"] else "no"))

    t4 = ["| endpoint | design | PCOS per SD (corrected) | ANM per SD | difference | P (rho=0) "
          "| q (BH within design) | P at rho=-1 | opposite direction | "
          "P at the multiplicative scale |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in hor.iterrows():
        t4.append("| %s | %s | %+.4f | %+.4f | %+.4f | %s | %s | %s | %s | %s |" % (
            r["endpoint_label"], DNAME_SHORT.get(r["pcos_design"], r["pcos_design"]),
            r["pcos_perSD_corrected"], r["anm_perSD"],
            r["difference_corrected"], g(r["p_rho0_corrected"]), g(r["q_BH_within_design"]),
            g(r["p_rho_minus1"]), "**yes**" if r["opposite_direction"] else "no",
            g(r["p_rho0_V3"])))

    t5 = ["| planned endpoint | accession | N | analysed | instruments "
          "(primary / second study / ANM) | in tested family | retrieval / QC |",
          "|---|---|---|---|---|---|---|"]
    for _, r in acct.iterrows():
        ins = ("%s/%s/%s" % (r["instruments_D1"], r["instruments_D3"], r["instruments_ANM"])
               if r["analysed"] == "YES" else "n/a")
        _qc = " ".join(str(r["retrieval_and_qc"]).split())
        _qc = ". ".join(s for s in _qc.split(". ")
                        if "build" not in s.lower())
        _qc = _qc[:190].rsplit(" ", 1)[0].rstrip(".,;") + "."
        t5.append("| %s | %s | %s | %s | %s | %s | %s |" % (
            r["planned_endpoint"], r["accession"], r["sample_size"], r["analysed"], ins,
            r["entered_tested_family"], _qc))

    t6 = ["| tau = Cov/(se1 se2) | min condF PCOS | max condF PCOS | min condF ANM | "
          "max condF ANM | models passing both gates |", "|---|---|---|---|---|---|"]
    for tau in sorted(mv["tau"].unique(), key=lambda x: -x):
        s = mv[np.isclose(mv["tau"], tau)]
        t6.append("| %+.2f | %.3f | %.3f | %.3f | %.3f | %d / %d |" % (
            tau, s["condF_PCOS"].min(), s["condF_PCOS"].max(), s["condF_ANM"].min(),
            s["condF_ANM"].max(), int(s["gate_both"].sum()), len(s)))

    t7 = ["| PCOS vs ANM locus | primary-prior PP.H4 | PP.H4 after LD pruning | underpowered? | "
          "tier |", "|---|---|---|---|---|"]
    for _, r in coloc.iterrows():
        t7.append("| %s | %.6f | %.6f | %s | %s |" % (
            r["nearest_gene"], float(r["PP.H4"]), float(r["PP.H4_pruned"]),
            "yes" if r["underpowered_flag"] else "no", r["evidence_tier"]))
    t7_note = ("FSHB: primary-prior PP.H4 = %.6f; minimum over the prior grid = %.6f; "
               "after LD pruning = %.6f. The grid minimum and the LD-pruned value are "
               "reported separately because they are different quantities." % (
                   float(fshb["pp4_primary_prior"]), float(fshb["pp4_min_over_prior_grid"]),
                   float(fshb["pp4_after_LD_pruning"])))

    return dict(T1="\n".join(t1), T1B="\n".join(t1b), T2="\n".join(t2), T3="\n".join(t3),
                T3F="\n".join(t3f), T3B="\n".join(t3b), T4="\n".join(t4),
                T5="\n".join(t5), T6="\n".join(t6), T7="\n".join(t7),
                T7NOTE=t7_note, DNAME_CODE_NOTE=DNAME_CODE_NOTE,
                d=d, side=side, mde=mde, sk=sk, skp=skp, hor=hor, acct=acct,
                mv=mv, coloc=coloc, fshb=fshb)


def build_manuscript(T):
    m = liability_multiplier(PREV_PRIMARY)
    inv_m = 1.0 / m
    d, side, mde, sk, hor = T["d"], T["side"], T["mde"], T["sk"], T["hor"]
    mv, fshb, coloc = T["mv"], T["fshb"], T["coloc"]
    inv = rd("V3_1_INPUT_MANIFEST.tsv")
    rec = rd("V3_1_HARMONIZATION_AUDIT_RECOUNT.tsv")
    divr = rd("V3_1_HORMONE_PATH_RULE_DIVERGENCE.tsv")
    A1, A2 = sk.loc["A1"], sk.loc["A2"]
    n_fdr = int(d["fdr_pass"].sum())
    minrow = d.loc[d["p_rho0"].idxmin()]
    minq = float(d["q_BH_primary"].min())
    n_power = int(mde["anm_effect_detectable_corrected"].sum())
    plo = float(mde["power_to_detect_ANM_effect_corrected"].min())
    phi = float(mde["power_to_detect_ANM_effect_corrected"].max())
    sep = sorted(set(hor.loc[hor["fdr_pass_within_design"], "endpoint_label"]))
    notsep = sorted(set(hor["endpoint_label"]) - set(sep))
    mv0 = mv[np.isclose(mv["tau"], 0.0)]
    mvm5 = mv[np.isclose(mv["tau"], -0.5)]
    mvm1 = mv[np.isclose(mv["tau"], -1.0)]
    B0 = mv0[mv0["pair"] == "BMD"]
    bmd_p_v3 = float(rd("V3_1_DIFFERENCE_PRIMARY9_V3METHOD_COMPARATOR.tsv")
                     .set_index("outcome").loc["BMD", "p_rho0"])
    frc_p_v3 = float(rd("V3_1_DIFFERENCE_PRIMARY9_V3METHOD_COMPARATOR.tsv")
                     .set_index("outcome").loc["Fracture", "p_rho0"])
    dd = d.set_index("outcome")
    rdiff = rd("V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv")
    fshrule = {r: (rdiff[(rdiff["endpoint"] == "FSH") & (rdiff["rule"] == r)]["p_rho0"].min(),
                    rdiff[(rdiff["endpoint"] == "FSH") & (rdiff["rule"] == r)]["p_rho0"].max())
               for r in ["AS_SHIPPED", "RULE_A_ALL", "NO_PAL_DROP"]}

    man = _load_template()

    rep = dict(
        __INVM__="%.4f" % inv_m, __M__="%.6f" % m, __UNDER__="%.3f" % (1 / m ** 2),
        __MINP__=g(minrow["p_rho0"]),
        __MINO__=PANEL9_LABEL.get(minrow["outcome"], minrow["outcome"]),
        __MINQ__=g(minq), __NPOWER__=str(n_power), __PLO__="%.2f" % plo, __PHI__="%.2f" % phi,
        __A1R00__=g(A1["stouffer_p_signed_rho000"]),
        __A2R00__=g(A2["stouffer_p_signed_rho000"]),
        __A2R09__=g(A2["stouffer_p_signed_rho090"]),
        __A1R05__=g(A1["stouffer_p_signed_rho050"]), __A1R09__=g(A1["stouffer_p_signed_rho090"]),
        __A2R05__=g(A2["stouffer_p_signed_rho050"]), __A2U05__=g(A2["stouffer_p_V3unsigned_rho050"]),
        __E2P__=g(hor[hor["endpoint_label"] == "Estradiol"]["p_rho0_corrected"].min()),
        __LHP__=g(hor[hor["endpoint_label"] == "LH"]["p_rho0_corrected"].min()),
        __FSHV3__=g(hor[hor["endpoint_label"] == "FSH"]["p_rho0_V3"].min()),
        __FSH31__=g(hor[(hor["endpoint_label"] == "FSH") & (hor["pcos_design"] == "D1")]
                    ["p_rho0_corrected"].iloc[0]),
        __FSH31D3__=g(hor[(hor["endpoint_label"] == "FSH") & (hor["pcos_design"] == "D3")]
                      ["p_rho0_corrected"].iloc[0]),
        __FSH31D4__=g(hor[(hor["endpoint_label"] == "FSH") & (hor["pcos_design"] == "D4")]
                      ["p_rho0_corrected"].iloc[0]),
        __PP4__="%.6f" % float(fshb["pp4_primary_prior"]),
        __PP4MIN__="%.6f" % float(fshb["pp4_min_over_prior_grid"]),
        __PP4PRUNED__="%.6f" % float(fshb["pp4_after_LD_pruning"]),
        __MLO__="%.6f" % liability_multiplier(min(PREV_GRID)),
        __MHI__="%.6f" % liability_multiplier(max(PREV_GRID)),
        __SDANM__=str(SD_ANM_PRIMARY), __SDSTR__=SD_STR, __RHOSTR__=RHO_STR,
        __NFDR__=str(n_fdr), __NSEP__=str(len(sep)), __SEPSTR__=", ".join(sep),
        __NOTSEPSTR__=", ".join(notsep),
        __BMDPV3__=g(bmd_p_v3), __BMDP31__=g(dd.loc["BMD", "p_rho0"]),
        __FRCPV3__=g(frc_p_v3), __FRCP31__=g(dd.loc["Fracture", "p_rho0"]),
        __NATK__=str(int(rd("V3_1_PREVALENCE_SENSITIVITY.tsv")
                        .groupby("K")["fdr_pass"].sum().max())),
        __NATSD__=str(int(rd("V3_1_SD_ANM_SENSITIVITY.tsv")
                         .groupby("sd_anm")["fdr_pass"].sum().max())),
        __PREVSTR__=PREV_STR,
        __F0PCOS__="%.2f" % B0["condF_PCOS"].iloc[0], __F0ANM__="%.2f" % B0["condF_ANM"].iloc[0],
        __FM5PCOS__="%.2f" % mvm5[mvm5["pair"] == "BMD"]["condF_PCOS"].iloc[0],
        __FM5ANM__="%.2f" % mvm5[mvm5["pair"] == "BMD"]["condF_ANM"].iloc[0],
        __FM1PCOS__="%.2f" % mvm1[mvm1["pair"] == "BMD"]["condF_PCOS"].iloc[0],
        __FM1ANM__="%.2f" % mvm1[mvm1["pair"] == "BMD"]["condF_ANM"].iloc[0],
        __NMV__=str(len(mv0)), __NMV0__=str(int(mv0["gate_both"].sum())),
        __NREC__=str(len(rec)), __NDROP__=str(int(rec["n_dropped"].sum())),
        __NPAL__=str(int(rec["n_dropped_palindromic_EAF_discordant"].sum())),
        __NDIS__=str(int(rec["rules_disagree_for_this_pair"].sum())),
        __NHORMDROP__=str(int(divr["n_dropped_by_rule_B_band"].sum())),
        __FSHR1__="%s-%s" % (g(fshrule["AS_SHIPPED"][0]), g(fshrule["AS_SHIPPED"][1])),
        __FSHR2__="%s-%s" % (g(fshrule["RULE_A_ALL"][0]), g(fshrule["RULE_A_ALL"][1])),
        __FSHR3__="%s-%s" % (g(fshrule["NO_PAL_DROP"][0]), g(fshrule["NO_PAL_DROP"][1])),
        __NINV__=str(len(inv)),
    )
    rep["__REFERENCES__"] = render_references()
    for _k, _c in REFC.items():
        rep["__C_%s__" % _k.upper()] = _c
    for k, v in T.items():
        if isinstance(v, str):
            rep["__%s__" % k] = v
    for k, v in rep.items():
        man = man.replace(k, v)
    import re as _re
    left = sorted(set(_re.findall(r"__[A-Za-z0-9_]+__", man)))
    if left:
        raise SystemExit("unsubstituted placeholders: %s" % left)
    return man
