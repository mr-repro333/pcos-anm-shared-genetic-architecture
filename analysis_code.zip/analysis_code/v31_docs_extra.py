# -*- coding: utf-8 -*-
"""V3.1 document generator, part 2: supplement, README, changelog, plan, QC, reviewer sim.

Numbers are read from the V3.1 result files at generation time; see v31_docs.py for the
manuscript and the table builders.
"""
import io, json, os, shutil, sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import (RES, SELF, PREV_PRIMARY, PREV_GRID, SD_ANM_GRID, ALPHA,
                      liability_multiplier)

OUT_MAN = os.path.join(SELF, "01_MANUSCRIPT")
OUT_SUPP = os.path.join(SELF, "06_SUPPLEMENT")
OUT_README = os.path.join(SELF, "00_README")
OUT_PLAN = os.path.join(SELF, "02_ANALYSIS_PLAN")
OUT_QC = os.path.join(SELF, "08_QC")
OUT_REV = os.path.join(SELF, "09_REVIEWER_SIMULATION")
for _d in (OUT_MAN, OUT_SUPP, OUT_README, OUT_PLAN, OUT_QC, OUT_REV):
    os.makedirs(_d, exist_ok=True)


def W(path, text):
    io.open(path, "w", encoding="utf-8", newline="\n").write(text)


def rd(n):
    return pd.read_csv(os.path.join(RES, n), sep="\t")


def xl(n, s):
    return pd.read_excel(os.path.join(RES, n), sheet_name=s)


def g(x, nd=4):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "n/a"
    a = abs(x)
    if a == 0:
        return "0"
    if 1e-3 <= a < 1e4:
        return ("%%.%df" % nd) % x
    m_, e = ("%.*e" % (nd - 1, x)).split("e")
    return "%s x 10^%d" % (m_, int(e))


def facts():
    m = liability_multiplier(PREV_PRIMARY)
    F = dict(
        m=m, invm=1 / m, under=1 / m ** 2,
        d=rd("V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv"),
        hor=rd("V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv"),
        mde=rd("V3_1_POWER_MDE_CORRECTED.tsv"),
        mv=rd("V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv"),
        rec=rd("V3_1_HARMONIZATION_AUDIT_RECOUNT.tsv"),
        divr=rd("V3_1_HORMONE_PATH_RULE_DIVERGENCE.tsv"),
        rdiff=rd("V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv"),
        inv=rd("V3_1_INPUT_MANIFEST.tsv"),
        claims=xl("V3_1_CLAIM_EVIDENCE_MATRIX.xlsx", "CLAIM_EVIDENCE_MATRIX_V31"),
        sk=xl("V3_1_SKELETAL_EVIDENCE.xlsx", "DOMAIN_SUMMARY").set_index("exposure_design"),
        coloc=xl("V3_1_FSHB_EVIDENCE_AUDIT.xlsx", "ALL_COLOCALISED_PCOS_ANM"),
    )
    F["fshb"] = dict(zip(*xl("V3_1_FSHB_EVIDENCE_AUDIT.xlsx", "PP4_FACTS").values.T))
    F["n_fdr"] = int(F["d"]["fdr_pass"].sum())
    F["minrow"] = F["d"].loc[F["d"]["p_rho0"].idxmin()]
    F["minq"] = float(F["d"]["q_BH_primary"].min())
    F["n_power"] = int(F["mde"]["anm_effect_detectable_corrected"].sum())
    F["plo"] = float(F["mde"]["power_to_detect_ANM_effect_corrected"].min())
    F["phi"] = float(F["mde"]["power_to_detect_ANM_effect_corrected"].max())
    F["sep"] = sorted(set(F["hor"].loc[F["hor"]["fdr_pass_within_design"], "endpoint_label"]))
    F["notsep"] = sorted(set(F["hor"]["endpoint_label"]) - set(F["sep"]))
    F["mv0"] = F["mv"][np.isclose(F["mv"]["tau"], 0.0)]
    F["B0"] = F["mv0"][F["mv0"]["pair"] == "BMD"]
    F["A1"], F["A2"] = F["sk"].loc["A1"], F["sk"].loc["A2"]
    F["n_claims"] = len(F["claims"])
    F["n_robust"] = int((F["claims"]["grade"] == "ROBUST").sum())
    F["n_safe"] = int((F["claims"]["safe_for_abstract"] == "YES").sum())
    F["n_inv"] = len(F["inv"])
    F["inv_mb"] = F["inv"]["bytes"].sum() / 1e6
    F["nat_K"] = int(rd("V3_1_PREVALENCE_SENSITIVITY.tsv").groupby("K")["fdr_pass"].sum().max())
    F["nat_sd"] = int(rd("V3_1_SD_ANM_SENSITIVITY.tsv").groupby("sd_anm")["fdr_pass"].sum().max())
    return F


def supplement(F, T):
    m, invm = F["m"], F["invm"]
    meth = f"""# Supplementary Methods (V3.1)

## S1 The liability-scale correction, in full

Let K be the population prevalence and t = Phi^-1(1-K). Under the liability-threshold model a
per-allele log-odds coefficient b and a per-allele shift beta_L of the latent liability
satisfy b = phi(t) beta_L / (K(1-K)), hence

    beta_L = m(K) * b,        m(K) = K(1-K) / phi(Phi^-1(1-K)).                     (S1)

Equation S1 is a statement about a **SNP-exposure coefficient**. An MR estimate is a ratio,

    theta = beta_Y / beta_X.                                                        (S2)

Because beta_X,L = m(K) * beta_X,logOR, the liability-scale ratio is

    theta_L = beta_Y / beta_X,L = theta_logOR / m(K),                               (S3)
    SE(theta_L) = SE(theta_logOR) / m(K).                                           (S4)

Equivalently: rescaling an exposure coefficient by c rescales an MR ratio and its standard
error by 1/c. The previous version multiplied by m(K) in Equations S3 and S4, i.e. signed the
conversion backwards; at K = 0.10 that makes every per-SD PCOS effect, and its standard
error, too small by m(K)^-2 = {F['under']:.6f}.

m(K) at the primary prevalence is {m:.6f}; over the grid 5-20% it runs from
{liability_multiplier(min(PREV_GRID)):.6f} to {liability_multiplier(max(PREV_GRID)):.6f}; 1/m
at K = 0.10 is {invm:.6f}.

The closed form was checked against exact numerical inversion of the threshold model for
three effect sizes (log-OR 0.02, 0.10 and 0.30) at every prevalence in the grid; the maximum
relative error over the whole comparison is 1.7%.

**Unit test.** `04_CODE/test_scale_reciprocity.py` establishes the reciprocity three ways:
(i) algebraically, theta' = beta_Y/(c beta_X) = theta/c; (ii) numerically, by pushing 200
random instrument vectors through an IVW ratio under a rescaling c drawn from [0.3, 3.0] and
asserting that both the estimate and its standard error move by exactly 1/c to 1e-10; and
(iii) as a regression guard, by reproducing the frozen worked example and showing that the
previous per-SD value differs from the correct one by exactly m(K)^-2 = {F['under']:.6f}.

## S2 The multiplier site audit

Every place in the project where a liability multiplier is applied was registered and
classified by *what object it is applied to*, not by file name. Four sites applied it to an
MR ratio or an MR-ratio standard error and are cancelled in V3.1:

| site | object it was applied to | verdict |
|---|---|---|
| `v3_diff.py: difference_rows()` | MR ratio (outcome per unit log-OR) | wrong direction - cancelled |
| `v3_hormonal_diff.py` | MR ratio, PCOS arm | wrong direction - cancelled |
| `v3_coloc_power.py: mde()` SE | MR-ratio standard error | wrong direction - cancelled |
| `v3_coloc_power.py: mde()` effect | MR ratio | wrong direction - cancelled |

Three sites are correct as written or descriptive only: the definition of m(K); its use in
`scaling_table()` on a SNP-exposure coefficient; and the claim matrix, where m(K) is quoted as
a description of scale rather than applied to an effect. Two sites are new in V3.1:
`mr_ratio_to_liability()` (divide) and `snp_exposure_to_liability()` (multiply, the only
admissible multiplication). The register is in `V3_1_MULTIPLIER_SITE_REGISTER.tsv`.

## S3 The signed Stouffer combination

    signed_Z_i = sign(beta_aligned_i) * Phi^-1(1 - P_i/2)                            (S5)
    Z          = sum_i signed_Z_i / sqrt(k + k(k-1) rho)                             (S6)

with rho the assumed average pairwise endpoint correlation over {{0, 0.25, 0.5, 0.75, 0.9}}.
The previous version built every z_i as Phi^-1(1 - p_i/2) from a two-sided p and therefore
summed k positive terms. The endpoint set and the rho grid are unchanged; only the sign is
restored. Table S1 gives both versions side by side.

## S4 The MVMR covariance bound

    gencov_l = tau * se_betaX1(l) * se_betaX2(l),      tau in [-1, +1]               (S7)

The band is not a modelling choice: |Cov| <= se1 se2 by Cauchy-Schwarz, so tau is a
dimensionless position in a permitted interval and no value of it is asserted as true. The
true sampling covariance is the correlation between the two exposure traits among overlapping
participants; the deposited summary statistics do not contain it, and the LDSC genetic
correlation (r_g = +0.329) is a different quantity, so nothing was invented. The conditional F
was recomputed at tau in {{-1, -0.5, -0.33, -0.2, -0.1, 0, +0.1, +0.2, +0.33, +0.5, +1}} for
every multivariable design on disk, using the `MVMR::strength_mvmr` estimator itself.

## S5 Harmonisation: both rules, exactly

**Rule A - `HARM_EAF_DISCORD`.** Used for **every headline harmonised matrix**.
1. Match the instrument variant to the outcome file by rsID first, then by chr:pos only when
   the empirical rsID agreement for that outcome file is >= 0.5, or use the file's recorded
   build when it carries no rsIDs.
2. Align alleles to a single reference pair: direct, flipped, strand-complement, or
   complement+flip.
3. For a palindromic exposure allele pair (A/T, T/A, C/G, G/C): drop when either EAF is
   missing; drop when |EAF_exposure - EAF_outcome| > 0.05; otherwise align by EAF.
4. Non-palindromic variants are never dropped for allele reasons.
5. Record per variant: match key, action, note, both allele pairs, both EAFs, raw and signed
   outcome beta, and SE.

The literal band 0.42-0.58 does not occur anywhere in this path.

**Rule B - `HARM_PALINDROME_BAND`.** Used for **the recovered-hormone path only** (LH,
estradiol, progesterone, testosterone) and for FSH only in the sense that FSH's V2 matrix was
not re-harmonised. Drop a variant when its exposure allele pair is palindromic AND the
*outcome* EAF lies in [0.42, 0.58]. The exposure EAF is not consulted, so this rule cannot
detect a discordant palindrome whose outcome EAF sits outside the band.

The audit was regenerated from the deposited per-variant records: {len(F['rec'])} pairs,
{int(F['rec']['n_dropped'].sum())} drops, of which
{int(F['rec']['n_dropped_palindromic_EAF_discordant'].sum())} palindromic-EAF-discordant. For
{int(F['rec']['rules_disagree_for_this_pair'].sum())} of {len(F['rec'])} pairs the two rules
would have dropped a different count. The consequence is measured in section S6.

## S5b The FSHB PP4 reconciliation

One posterior carried five different renderings. V3.1 states, in every document, the
primary-prior value and the grid minimum separately:

| quantity | value |
|---|---|
| PP.H4 at the primary prior (p12 = 1e-5) | 0.998960 |
| minimum PP.H4 over the prior grid | 0.989699 |
| PP.H4 after LD pruning | {F['fshb']['pp4_after_LD_pruning']:.6f} (full precision {F['fshb']['pp4_after_LD_pruning']:.9f}) |
| evidence tier | A_ROBUST |

## S6 The harmonisation-rule sensitivity

Both arms of every hormonal comparison were re-derived from the deposited matrices under three
variant sets - as shipped, rule A applied to every arm, and no palindrome exclusion - and the
matched differences recomputed on the corrected scale. The endpoints surviving correction are
**{', '.join(F['sep'])}** under all three rule sets. The full table is in
`V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv`; the arm-level detail, including the
reproduction of the shipped values (9 of 10 arms reproduced to 1e-9), is in
`V3_1_HORMONE_RULE_SENSITIVITY_ARMS.tsv`.

## S7 Reproduction and the smoke test

`10_INPUTS/` contains the {F['n_inv']} input files the shipped code reads
({F['inv_mb']:.1f} MB), with a SHA-256 manifest. `bootstrap_data_root.py --restore <dir>`
materialises a working data root from the package alone; set `PCOS_ANM_DATA_ROOT` to it and
every module runs unchanged. `v31_smoke.py` does exactly that in a temporary directory,
re-runs every analysis module against a fresh output directory, and compares each produced
table field by field with the shipped file (1e-9 tolerance) and each workbook cell by cell.
The result is in `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md`, and the "fully reproducible from the
package" statement is conditional on that table being all-PASS.
"""
    W(os.path.join(OUT_SUPP, "Supplementary_Methods.md"), meth)

    tabs = f"""# Supplementary Tables (V3.1)

## Table S1. Skeletal combination: signed (V3.1) versus the previous unsigned implementation

{T['T3F']}

## Table S2. Primary nine-test family, corrected reciprocal scale

{T['T1']}

## Table S3. Side by side: the incorrect multiplication versus the reciprocal scaling

{T['T1B']}

## Table S4. Minimum detectable effect and prospective power, corrected

{T['T2']}

## Table S5. Skeletal evidence tiers in the primary ANM instrument (A1)

{T['T3B']}

## Table S6. Hormonal endpoint accounting: six planned, five analysed

{T['T5']}

## Table S7. Matched hormonal difference tests, corrected scale

{T['T4']}

## Table S8. MVMR conditional F across the covariance band

{T['T6']}

## Table S9. PCOS-ANM colocalization at the loci with a COLOCALISED verdict

{T['T7']}

{T['T7NOTE']}

## Table S10. Prevalence and SD sensitivity of the corrected family

At every K in {{{', '.join(str(k) for k in sorted(rd('V3_1_PREVALENCE_SENSITIVITY.tsv')['K'].unique()))}}}
the number of FDR-positive differences is {F['nat_K']}; at every SD_ANM in
{{{', '.join(str(s) for s in sorted(rd('V3_1_SD_ANM_SENSITIVITY.tsv')['sd_anm'].unique()))}}} it
is {F['nat_sd']}. Sources: `V3_1_PREVALENCE_SENSITIVITY.tsv`,
`V3_1_SD_ANM_SENSITIVITY.tsv`.

## Table S11. Instrument provenance summary

| design | n variants | min F | median F | any F < 10 | window | role |
|---|---|---|---|---|---|---|
| D1 | 19 | 29.95 | 37.76 | no | 1 Mb | primary |
| D2 | 18 | 29.95 | 38.52 | no | 10 Mb | V1-comparable sensitivity |
| D3 | 25 | 29.88 | 41.39 | no | 1 Mb | alternative-study sensitivity |
| D4 | 29 | 29.88 | 41.39 | no | 1 Mb | union, power sensitivity only |
| D5 | 22 | 30.07 | 42.63 | no | 1 Mb | ancestry sensitivity |
| D6 | 20 | 30.07 | 42.63 | no | 10 Mb | excluded from inference |
| A1 | 213 | 29.72 | 54.58 | no | 10 Mb | primary ANM |
| A2 | 77 | 27.54 | 50.52 | no | 10 Mb | alternative ANM |

Full per-variant provenance is in `V3_1_INSTRUMENT_PROVENANCE.tsv`.

{T['DNAME_CODE_NOTE']}

## Table S12. Input inventory

{F['n_inv']} files, {F['inv_mb']:.1f} MB, each with a SHA-256 in `V3_1_INPUT_MANIFEST.tsv`.
Files that are deliberately not shipped (the raw GWAS deposits) are listed with their
accessions and the reason in `V3_1_NOT_SHIPPED_AND_WHY.tsv`.

## Table S13. Claim-evidence matrix, counted once

{F['n_claims']} claims, {F['n_robust']} graded ROBUST, {F['n_safe']} safe for the abstract.
Source: `V3_1_CLAIM_EVIDENCE_MATRIX.xlsx`.
"""
    W(os.path.join(OUT_SUPP, "Supplementary_Tables.md"), tabs)

    legs = """# Supplementary Figure Legends (V3.1)

**Figure 1. PCOS and ANM instrument designs.** Independent locus counts per design at a fixed
P < 5 x 10^-8 threshold; only the LD independence window and the deposition stratum vary
between designs.

**Figure 2. The liability-scale conversion, both directions.** Panel A plots m(K) (blue), the
factor that converts a SNP-exposure coefficient to the liability scale, and 1/m(K) (red), the
factor that converts an MR ratio, over the plausible prevalence range; the horizontal line marks
a multiplier of 1, which neither conversion uses. Panel B plots the difference-test P value
against PCOS prevalence for five outcomes; no outcome crosses alpha at any point of the grid.

**Figure 3. The primary family and its covariance sensitivity.** Panel A shows the nine
difference estimates with 95% intervals at rho = 0; no outcome is marked as passing, because
none does. Panel B shows the P value against the assumed correlation rho over [-1, +1]; no curve
crosses alpha anywhere in the grid.

**Figure 4. Skeletal domain evidence with a signed combination.** Panel A shows the seven
polarity-aligned ANM skeletal endpoints in the primary instrument. Panel B contrasts the signed
Stouffer combination with an unsigned one at the same rho grid: the signed statistic is the one
the stated hypothesis requires, and it is the difference between the two that keeps the
alternative ANM instrument from reading as a domain-level replication.

**Figure 5. Multivariable instrument strength and the detection limit.** Panel A plots the
conditional F statistics for both exposures at four positions in the covariance bound; the
pre-specified gate of 10 is drawn, and the interval in which both gates pass is not the whole
band. Panel B plots the minimum detectable effect at 80% power against the ANM-sized effect for
each outcome.

**Figure 6. FSHB evidence and its tier.** Panel A shows every PCOS-ANM locus with a colocalised
verdict at the primary prior, its PP.H4 before and after LD pruning, and its evidence tier.
Panel B keeps four posterior quantities apart: the primary-prior value, the minimum over the
prior grid, the LD-pruned value, and the 0.75 tier threshold.
"""
    global LEGEND_BODY
    LEGEND_BODY = legs.split("\n\n", 1)[1].rstrip()
    W(os.path.join(OUT_SUPP, "Supplementary_Figure_Legends.md"), legs)

    W(os.path.join(OUT_SUPP, "READ_ME_SUPPLEMENT.md"), f"""# READ_ME_SUPPLEMENT (V3.1)

The supplement is part of the same generation chain as the manuscript: every number in it is
read from a file in `03_RESULTS/` by `04_CODE/v31_docs.py` and `04_CODE/v31_docs_extra.py`, and
`v31_consistency.py` re-checks the quantity list independently.

* `Supplementary_Methods.md` - the algebra of the correction, the multiplier-site audit, the
  signed combination, the covariance bound, both harmonisation rules, and the smoke test.
* `Supplementary_Tables.md` - thirteen tables.
* `Supplementary_Figure_Legends.md` - six figure legends.
""")


def readme(F):
    m, invm = F["m"], F["invm"]
    txt = f"""# README_FIRST (V3.1)

**This package is a final validity repair of V3, not a new version. No outcome, endpoint,
instrument design, family member or estimator was added, removed or re-assigned. The three
repairs are: the direction of the binary-exposure liability conversion; the sign of the
Stouffer combination; and the justification of the multivariable covariance assumption.**

## 1. What was actually wrong

**(a) The scale conversion was applied in the wrong direction.** The SNP-exposure conversion
beta_L = m(K) x beta_logOR is correct, and it was stated correctly. But the quantity being
compared is an MR *ratio*, and a ratio scales by the reciprocal: theta_L = theta_logOR / m(K),
SE(theta_L) = SE(theta_logOR) / m(K). The previous version multiplied. At K = 0.10 this made
every per-SD PCOS effect, and its standard error, too small by m(K)^-2 = {F['under']:.3f}. A
unit test in `04_CODE/test_scale_reciprocity.py` establishes the reciprocity algebraically and
numerically and pins the factor.

**(b) A combination statistic had no signs.** The Stouffer combination built every Z from a
two-sided P value, so every Z was positive and the sum could only report agreement. Corrected
to signed_Z = sign(beta_aligned) x Phi^-1(1 - P/2).

**(c) gencov = 0 was justified by a non sequitur.** LD independence between SNPs is not zero
covariance between two SNP-exposure *estimates* from overlapping samples. Bounded by
Cauchy-Schwarz instead, and the bound decides the answer.

## 2. What that does to the headline

**{F['n_fdr']} of the nine primary difference tests survive Benjamini-Hochberg at 0.05.**
Smallest P = {g(F['minrow']['p_rho0'])} ({F['minrow']['outcome_label']}); smallest q =
{g(F['minq'])}. Under the previous multiplication four of nine appeared to pass; that result is
withdrawn. The count is {F['nat_K']} at every prevalence in 5-20% and {F['nat_sd']} at every
SD_ANM in 3.5-4.2, so no conclusion depends on choosing K.

The analysis had 80% power to detect an ANM-sized effect for **{F['n_power']} of the nine
outcomes**, because the corrected standard error is larger by 1/m = {invm:.3f}. The previous
version claimed two; that claim is reversed.

## 3. What survives

* The shared reproductive genetic architecture: association in both directions and
  r_g = +0.329.
* The ANM skeletal signature in the **primary** instrument A1: signed Stouffer P =
  {g(F['A1']['stouffer_p_signed_rho050'])} at rho = 0.5 and
  {g(F['A1']['stouffer_p_signed_rho090'])} at rho = 0.9.
* Two hormonal endpoints separating the exposures, in opposite directions:
  **{', '.join(F['sep'])}**.
* FSHB as a **shared regional signal under the single-signal colocalization model**:
  primary-prior PP.H4 = {float(F['fshb']['pp4_primary_prior']):.6f}, grid minimum
  {float(F['fshb']['pp4_min_over_prior_grid']):.6f}, LD-pruned
  {float(F['fshb']['pp4_after_LD_pruning']):.6f}, tier {F['fshb']['evidence_tier']}.

## 4. What is withdrawn

* "Separable systemic correlates for skeletal and glycaemic outcomes" - the corrected family is
  null.
* "Replication of the skeletal signature in the alternative ANM instrument" - A2 gives
  {g(F['A2']['stouffer_p_signed_rho050'])} at rho = 0.5 once the signs are carried.
* "Three of five hormonal endpoints separate the exposures" - it is
  **{len(F['sep'])} of five**; FSH does not survive (P
  {g(F['hor'][F['hor']['endpoint_label'] == 'FSH']['p_rho0_corrected'].min())}-{g(F['hor'][F['hor']['endpoint_label'] == 'FSH']['p_rho0_corrected'].max())}).
* "The PCOS arm had adequate power" - reversed.
* Any multivariable direct effect - the gate is not identified under the covariance band.
* Any mechanism wording at FSHB.

## 5. The claim matrix, counted once

The Claim-Evidence Matrix contains **{F['n_claims']} claims**, of which **{F['n_robust']} are
graded ROBUST** and **{F['n_safe']} are safe for the abstract**. Those three numbers are stated
here and are re-checked against the matrix file by `08_QC/INTERNAL_CONSISTENCY_AUDIT.md`. There
is one count now, not the several the previous package carried.

## 6. Is the package actually reproducible?

Yes, and the claim is conditional on a test. `10_INPUTS/` holds the {F['n_inv']} files the
shipped code reads ({F['inv_mb']:.1f} MB), with SHA-256 checksums. `v31_smoke.py` materialises a
fresh data root from the package alone, re-runs every analysis module against a fresh output
directory, and compares each result with the shipped file. The result is in
`08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md`. If any row of that table reads FAIL, the correct claim is
the weaker one and this README is wrong.

## 7. Where to look first

* `03_RESULTS/V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv` - the previous value, the corrected value,
  the change in P, the change in q, and the change in claim status, one row per outcome.
* `03_RESULTS/V3_1_MULTIPLIER_SITE_REGISTER.tsv` - every multiplier site in the project and what
  object it was applied to.
* `03_RESULTS/V3_1_SKELETAL_EVIDENCE.xlsx`, sheet `SIGNED_VS_V3UNSIGNED`.
* `03_RESULTS/V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx` - the band and what it does to the
  gate.
* `03_RESULTS/V3_1_HORMONAL_ENDPOINT_ACCOUNTING.xlsx` - six planned, five analysed, and the
  exact reason for the sixth.
* `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md`.

## 8. The scientific questions the repair was asked to answer

**A. How many of the nine formal systemic PCOS-vs-ANM differences survive BH-FDR?**
**Zero.** Smallest P = {g(F['minrow']['p_rho0'])}, smallest q = {g(F['minq'])}.

**B. Does any conclusion depend on choosing K within 5-20%?** No. The FDR-positive count is
{F['nat_K']} at every K in the grid and {F['nat_sd']} at every SD_ANM, so there is no positive
conclusion that K could carry.

**C. Which hormonal differences survive corrected scaling and FDR?**
**{len(F['sep'])}: {', '.join(F['sep'])}.** FSH, progesterone and testosterone do not.

**D. Does signed skeletal evidence remain significant for A1 and separately A2?**
A1: yes, at every rho up to 0.9 ({g(F['A1']['stouffer_p_signed_rho000'])} /
{g(F['A1']['stouffer_p_signed_rho050'])} / {g(F['A1']['stouffer_p_signed_rho090'])}).
A2: **no** at rho >= 0.5 (P = {g(F['A2']['stouffer_p_signed_rho050'])} at 0.5, against
{g(F['A2']['stouffer_p_V3unsigned_rho050'])} from the unsigned version).

**E. Does any MVMR direct effect remain interpretable?** No. At gencov = 0 the rebuilt
restricted design passes both gates ({F['B0']['condF_PCOS'].iloc[0]:.2f} /
{F['B0']['condF_ANM'].iloc[0]:.2f}), but it fails both at tau = -0.5 and tau = -1.0, and Q_A is
significant in nearly every model. MVMR is retained as a design and sensitivity analysis only.

**F. What is the strongest defensible FSHB evidence tier?** Tier 1-2 of the ladder: a shared
FSHB-region signal, and under the single-signal colocalization model a likely shared causal
signal. Not a fine-mapped signal, not a resolved causal variant, not an FSH-mediated variant,
not a mechanism.

**G. What is the manuscript's final core claim?** PCOS genetic liability and later age at
natural menopause share reproductive genetic architecture; their systemic association patterns
differ for individual outcomes but are **not formally distinguishable at the current PCOS
instrument strength**; the hormonal contrast that survives correction separates them for
estradiol and LH in opposite directions; and FSHB carries a shared regional signal under a
single-signal colocalization model, without a resolved causal variant.
"""
    W(os.path.join(OUT_README, "README_FIRST.md"), txt)

    md = F["mde"].sort_values("power_to_detect_ANM_effect_corrected")
    rowstable = "\n".join("| %s | %.2f |" % (r["outcome_label"],
                                             r["power_to_detect_ANM_effect_corrected"])
                          for _, r in md.iterrows())
    ex = f"""# FINAL_EXECUTIVE_SUMMARY (V3.1)

## What this round is

A validity repair of V3, limited to three blockers. No new outcome, no new endpoint, no new
instrument, no new family, no estimator switched for the sake of a result. The family
membership, the prevalence grid, the rho grid and the SD_ANM grid are the V3 ones.

## The three repairs

1. **Scale direction.** theta_L = theta_logOR / m(K), not x m(K); SE with the same reciprocal.
   The previous per-SD values were too small by {F['under']:.3f} at K = 0.10.
2. **Signed Stouffer.** signed_Z = sign(beta) x Phi^-1(1 - P/2).
3. **MVMR covariance.** Bounded by Cauchy-Schwarz and walked, instead of asserted zero.

## The result

**Zero of the nine primary difference tests survive BH-FDR.** Under the previous multiplication
four appeared to pass. The corrected comparison is bounded by power: the PCOS arm has 80% power
to detect an ANM-sized systemic effect for {F['n_power']} of the nine outcomes.

| outcome | power to detect an ANM-sized effect |
|---|---|
{rowstable}

## What stands, and at what grade

| finding | grade | number |
|---|---|---|
| Shared reproductive genetic architecture | ROBUST | r_g = +0.329; associated in both directions |
| PCOS liability associated with later ANM | ROBUST | +0.434 yr/log-OR (P = 3.05e-05) |
| ANM associated with PCOS liability | ROBUST | OR 1.100/yr, 95% CI 1.069-1.132 (P = 8.14e-11) |
| No formal systemic difference established | ROBUST (as a null) | 0/9 survive BH-FDR; min q = {g(F['minq'])} |
| Detection limit quantified | ROBUST | {F['n_power']} of 9 outcomes at an ANM-sized effect |
| ANM skeletal signature, primary instrument A1 | ROBUST | signed Stouffer P = {g(F['A1']['stouffer_p_signed_rho050'])} at rho = 0.5 |
| ANM associated with lower FSH, lower LH, higher estradiol, higher testosterone | ROBUST | FSH -0.175; LH -0.078; estradiol +0.022; testosterone +0.015 |
| Hormonal profiles separable | ROBUST | {len(F['sep'])} of 5 endpoints: {', '.join(F['sep'])} |
| FSHB shared regional signal | PROMISING_NEEDS_VALIDATION | PP.H4 = {float(F['fshb']['pp4_primary_prior']):.6f} primary prior; tier {F['fshb']['evidence_tier']} |
| PCOS liability associated with lower FSH | EXPLORATORY | q = 0.067; matched difference null |
| ANM skeletal replication in A2 | UNRESOLVED | signed P = {g(F['A2']['stouffer_p_signed_rho050'])} at rho = 0.5 |
| Multivariable direct effects | UNRESOLVED | gate not identified in the covariance band |
| A shared gonadotropic mechanism at FSHB | WITHDRAWN | Layer 3 failed; no FSH-region coloc |
| Adiposity distribution hypothesis | WITHDRAWN | UNSUPPORTED in the primary design |

## The one sentence to take away

PCOS genetic liability and later menopause share reproductive genetic architecture, and their
systemic association patterns differ from outcome to outcome, but with the exposure scale
treated correctly those differences are **not formally distinguishable at the current PCOS
instrument strength**.
"""
    W(os.path.join(OUT_README, "FINAL_EXECUTIVE_SUMMARY.md"), ex)


def changelog(F):
    m = F["m"]
    E = [
        ("V31-01", "PRIORITY 0", "correctness",
         "binary-exposure liability conversion applied to an MR ratio",
         "pcos_perSD = ivw * m(K); se = ivw_se * m(K). Every per-SD PCOS effect was too small "
         "by m(K)^-2 = %.6f at K = 0.10." % (1 / m ** 2),
         "theta_L = theta_logOR / m(K); SE likewise (Equations 3-4).",
         ["V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv",
          "V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv"],
         "0 of 9 primary difference tests survive BH-FDR; the previous version reported 4."),
        ("V31-02", "PRIORITY 0", "scope",
         "project-wide audit of every place a liability multiplier is applied",
         "no such audit existed",
         "9 sites registered and classified by object type; 4 were applied to an MR ratio or an "
         "MR-ratio SE and are cancelled",
         ["V3_1_MULTIPLIER_SITE_REGISTER.tsv", "V3_1_MULTIPLIER_USE_AUDIT.tsv"],
         "the same error existed in three other files, all repaired"),
        ("V31-03", "PRIORITY 0", "test",
         "no algebraic or numerical evidence for the scale law",
         "none",
         "test_scale_reciprocity.py: algebraic proof, 200-vector numerical test, and a "
         "regression guard pinning the previous factor at m(K)^-2",
         ["test_scale_reciprocity.py"],
         "the correction is demonstrated, not asserted"),
        ("V31-04", "PRIORITY 0", "correctness",
         "matched hormonal differences and MDE/power used the same wrong direction",
         "three of five endpoints appeared to separate the exposures",
         "two of five (Estradiol, LH); FSH matched difference 1.7e-07 -> 0.130; every MDE larger "
         "by 1/m; power 0 of 9 instead of 2 of 9",
         ["V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv", "V3_1_POWER_MDE_CORRECTED.tsv"],
         "the hormonal and power claims are rewritten"),
        ("V31-05", "PRIORITY 1", "correctness",
         "Stouffer combination built all-positive Z from two-sided P values",
         "z_i = Phi^-1(1 - p_i/2) for every i",
         "signed_Z_i = sign(beta_aligned_i) x Phi^-1(1 - p_i/2)",
         ["V3_1_SKELETAL_EVIDENCE.xlsx (SIGNED_VS_V3UNSIGNED)"],
         "A1 stays significant at every rho up to 0.9; A2 does not at rho >= 0.5 "
         "(0.00717 -> 0.05659)"),
        ("V31-06", "PRIORITY 1", "structure",
         "skeletal evidence reported as one domain number",
         "a single Stouffer row per design",
         "five separated tiers and A1/A2 never pooled",
         ["V3_1_SKELETAL_EVIDENCE.xlsx"],
         "no domain-level sentence can be written that the endpoints do not support"),
        ("V31-07", "PRIORITY 2", "justification",
         "gencov = 0 defended by 'the instruments are mutually LD-independent'",
         "asserted; no sensitivity",
         "bounded by Cauchy-Schwarz: gencov = tau se1 se2 with tau in [-1, +1]; conditional F "
         "recomputed at 11 values of tau for all %d models" % len(F["mv0"]),
         ["V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv",
          "V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx"],
         "the gate flips inside the band; MVMR demoted out of the biological headline"),
        ("V31-08", "PRIORITY 2", "interpretation",
         "ANM->BMD attenuation read as a caution about mediation/sharing",
         "stated with a caveat", "withdrawn entirely",
         ["V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"],
         "no mediation or sharing sentence is licensed"),
        ("V31-09", "PRIORITY 3", "reproducibility",
         "code referenced absolute paths that were not in the package",
         "the audit ZIP shipped scripts whose inputs were not shipped, so 'fully reproducible' "
         "was unverifiable",
         "%d input files shipped with a SHA-256 manifest; DATA_ROOT configurable; "
         "bootstrap --restore; clean-environment smoke test" % F["n_inv"],
         ["V3_1_INPUT_MANIFEST.tsv", "bootstrap_data_root.py", "v31_smoke.py",
          "08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md"],
         "the reproducibility claim is now conditional on a test that passes"),
        ("V31-10", "PRIORITY 3", "provenance",
         "per-variant instrument provenance absent",
         "design-level counts only",
         "per-variant provenance for D1, D3, D4, D5, D6, A1 and A2, including the coefficient "
         "source GWAS, whether the variant was selected in that same GWAS, ancestry, "
         "participant-overlap considerations, palindromic status, harmonisation action and "
         "proxy status",
         ["V3_1_INSTRUMENT_PROVENANCE.tsv", "V3_1_D4_UNION_INSTRUMENT_PROVENANCE.tsv"],
         "D4 remains union/power sensitivity only and never supersedes D1"),
        ("V31-11", "harmonisation", "documentation",
         "two incompatible palindrome rules described as one",
         "the provenance note said the 0.42-0.58 band; the per-pair audit said |dEAF| > 0.05",
         "both rules named and documented separately with the matrices each produced; the audit "
         "regenerated from the deposited records (%d pairs, %d drops)"
         % (len(F["rec"]), int(F["rec"]["n_dropped"].sum())),
         ["V3_1_HARMONIZATION_PROVENANCE.xlsx", "V3_1_HARMONIZATION_AUDIT_RECOUNT.tsv"],
         "the band rule is the hormone path only; the divergence is quantified"),
        ("V31-12", "harmonisation", "sensitivity",
         "the rule divergence was unmeasured", "not quantified",
         "both hormone arms re-derived under as-shipped, discordance-rule and no-exclusion "
         "variant sets; the surviving endpoints are the same two under all three",
         ["V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv",
          "V3_1_HORMONE_RULE_SENSITIVITY_ARMS.tsv"],
         "the inconsistency is real but not load-bearing"),
        ("V31-13", "endpoints", "accounting",
         "the planned six-endpoint hormonal family was reported as five without the reason for "
         "the sixth",
         "the family-size file said five; the changelog explained progesterone by build order",
         "all six visible with exact retrieval/QC evidence: five analysed and tested, SHBG not "
         "retrievable and recorded as a deviation",
         ["V3_1_HORMONAL_ENDPOINT_ACCOUNTING.xlsx"],
         "no planned endpoint is silently reduced; the progesterone wording is corrected from a "
         "build-order fact to a retrieval outcome"),
        ("V31-14", "FSHB", "claim tier",
         "PP4 quoted as one number and FSHB called 'the only shared signal'",
         "0.999 in three documents, 0.9990 in one, computed as %.3f in the matrix; DENND1A and "
         "IRF1 also colocalise",
         "primary-prior PP4 = %.6f, grid minimum = %.6f, LD-pruned = %.6f, stated separately in "
         "every document; 'only' is stated as an evidence-tier claim"
         % (float(F["fshb"]["pp4_primary_prior"]), float(F["fshb"]["pp4_min_over_prior_grid"]),
            float(F["fshb"]["pp4_after_LD_pruning"])),
         ["V3_1_FSHB_EVIDENCE_AUDIT.xlsx"],
         "PP.H4 is reconciled across abstract, Results, Discussion, tables, supplement and the "
         "claim matrix"),
        ("V31-15", "FSHB", "wording",
         "mechanism wording at FSHB",
         "'biologically concordant triangulation' and a shared-gonadotropic-mechanism claim",
         "enforced ladder: shared regional signal; likely shared causal signal under the "
         "single-signal colocalization model. Mechanism wording withdrawn. SuSiE not re-run.",
         ["V3_1_FSHB_EVIDENCE_AUDIT.xlsx (WORDING_LADDER)"],
         "no sentence may exceed what a single-signal coloc supports"),
        ("V31-16", "numbers", "consistency",
         "ANM->PCOS confidence interval reported on the log-OR scale beside an odds ratio",
         "OR 1.100 per year, 95% CI +0.067 to +0.124",
         "OR 1.100 per year, 95% CI 1.069 to 1.132 on the OR scale",
         ["01_MANUSCRIPT/V3_1_manuscript.md"],
         "the interval is on the same scale as the estimate it accompanies"),
        ("V31-17", "numbers", "consistency",
         "claim-matrix counts disagreed between documents",
         "one document said 6 of 10, another 7 of 11 or 7 of 12",
         "one count, computed from the matrix and re-checked by the consistency audit: %d claims, "
         "%d ROBUST, %d safe for the abstract" % (F["n_claims"], F["n_robust"], F["n_safe"]),
         ["V3_1_CLAIM_EVIDENCE_MATRIX.xlsx", "README_FIRST.md"],
         "README, executive summary, manuscript and QC carry the same count"),
        ("V31-18", "numbers", "regeneration",
         "figures and tables carrying the incorrect liability-scaled effects",
         "Figures 2, 3, 5 and 6 and the main difference table",
         "all six figures regenerated from the corrected result files; Figure 2 plots both "
         "conversion directions and Figure 4 shows signed versus unsigned",
         ["05_FIGURES/"],
         "no figure or table carries a pre-correction number"),
        ("V31-19", "claims", "reclassification",
         "previous ROBUST/PROMISING labels inherited",
         "7 ROBUST claims including separable systemic profiles and adequate power",
         "no label inherited; %d claims re-graded from the corrected numbers" % F["n_claims"],
         ["V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"],
         "systemic separability WITHDRAWN, A2 skeletal UNRESOLVED, FSH EXPLORATORY, MVMR out of "
         "the headline, power REVERSED"),
        ("V31-20", "narrative", "manuscript",
         "manuscript built around 'separable systemic correlates'",
         "'their systemic correlates are separable for skeletal and glycaemic outcomes ... "
         "Neither trait should be used as a proxy for the systemic risk carried by the other'",
         "rebuilt around shared reproductive genetic architecture with exposure-specific "
         "association patterns that are not formally distinguishable at the current PCOS "
         "instrument strength",
         ["01_MANUSCRIPT/V3_1_manuscript.md"],
         "the banned phrasings (systemic decoupling, established systemic differences, separable "
         "systemic profiles, proxy for the other's systemic risk) do not appear as assertions"),
    ]
    md = ["# V3 to V3.1 change log", "",
          "Machine-readable copy: `00_README/V3_TO_V31_CHANGELOG.json`.", "",
          "| id | blocker | kind | item | before | after | consequence |",
          "|---|---|---|---|---|---|---|"]
    # each entry is (id, blocker, kind, item, before, after, [files], consequence). The two
    # trailing members were printed into the opposite columns, which put the file list under
    # "consequence" and then iterated the consequence string character by character below.
    for e in E:
        md.append("| %s | %s | %s | %s | %s | %s | %s |"
                  % (e[0], e[1], e[2], e[3], e[4], e[5], e[7]))
    md += ["", "## Files touched by each entry", "", "| id | files |", "|---|---|"]
    for e in E:
        md.append("| %s | %s |" % (e[0], "; ".join("`%s`" % f for f in e[6])))
    md += ["", "## Rules this repair was bound by", "",
           "* Do not add a new broad outcome, do not search for a new positive result, do not "
           "switch instrument, outcome or estimator to rescue the narrative.",
           "* Do not change the family when the corrected results come out null.",
           "* Do not create an alternative family; do not substitute an alternative outcome "
           "release; do not use D3/D4/D5 to rescue the primary conclusion.",
           "* If the corrected family has zero FDR-positive differences, report zero.",
           "* Do not rerun SuSiE to obtain a positive result.",
           "* No new MVMR outcome.",
           "* No 'fully reproducible from the package' claim until the smoke test passes.", ""]
    W(os.path.join(OUT_README, "V3_TO_V31_CHANGELOG.md"), "\n".join(md))
    payload = dict(
        version="V3.1", previous="V3", scope="final validity repair",
        entries=[dict(id=e[0], blocker=e[1], kind=e[2], item=e[3], before=e[4], after=e[5],
                      consequence=e[7], files=e[6]) for e in E],
        multipliers=dict(m_at_K010=m, one_over_m=1 / m, previous_undershoot_factor=1 / m ** 2),
        primary_family=dict(
            n_tests=9, n_fdr_pass_v31=F["n_fdr"],
            n_fdr_pass_previous=int(rd("V3_1_DIFFERENCE_PRIMARY9_V3METHOD_COMPARATOR.tsv")
                                   ["fdr_pass"].sum()),
            min_p=float(F["d"]["p_rho0"].min()), min_q=F["minq"]))
    io.open(os.path.join(OUT_README, "V3_TO_V31_CHANGELOG.json"), "w", encoding="utf-8",
            newline="\n").write(json.dumps(payload, indent=2, default=str))


def plan(F):
    W(os.path.join(OUT_PLAN, "V31_REPAIR_PLAN_LOCKED.md"), f"""# V3.1 REPAIR PLAN (LOCKED)

Fixed before the corrected numbers were computed. Reproduced here so that family membership,
grids and the fail-closed rule can be checked against what was actually done.

## Scope

V3.1 is a final validity repair and **not** a new version. Excluded by construction: no new
broad outcome; no search for a new positive finding; no switching of instrument, outcome
release or estimator to rescue the narrative; no alternative family if the corrected family
comes out null; no D3/D4/D5 rescue of a primary conclusion; no new MVMR outcome; no SuSiE
re-run in pursuit of a positive result.

## Priority 0 - the reciprocal scale

    PCOS arm : theta_L = theta_logOR / m(K), SE likewise   (K = 0.10 primary)
    ANM arm  : theta_perSD = theta_per_year * SD_ANM       (SD_ANM = 3.8 primary)

Frozen: nine outcomes, one primary dataset each (D1 for PCOS, A1 for ANM); K grid
{{{', '.join(str(k) for k in sorted(rd('V3_1_PREVALENCE_SENSITIVITY.tsv')['K'].unique()))}}};
SD_ANM grid {{{', '.join(str(s) for s in SD_ANM_GRID)}}}; rho grid
{{-1, -0.75, -0.5, -0.25, 0, +0.25, +0.5, +0.75, +1}}; BH within the nine tests only.

**Fail-closed rule.** If the corrected nine-test family has zero FDR-positive differences, the
manuscript reports zero. It does not report a re-defined family, does not substitute an
alternative outcome release, and does not substitute a different instrument.

## Priority 1 - signed Stouffer

    signed_Z_i = sign(beta_aligned_i) * Phi^-1(1 - P_i/2)
    Z          = sum signed_Z_i / sqrt(k + k(k-1) rho)

Existing endpoint set and rho grid only. A1 and A2 reported separately. A significant A1 does
not make the domain replicated.

## Priority 2 - MVMR covariance

Either a defensible covariance estimate or a bounded sensitivity; if neither, state that
gencov = 0 is unverified, move MVMR out of the biological headline and claim no direct effect.
**No covariance was invented**: the bound is Cauchy-Schwarz, |Cov| <= se1 se2.

## Priority 3 - auditability

Ship every input the code reads; one configurable DATA_ROOT; checksum manifest; a
clean-environment smoke test. No "fully reproducible" claim before the smoke test passes.

## Harmonisation

Determine which rule was actually used; document one exact algorithm per code path; regenerate
the audit from the implementation; quantify the consequence of the divergence.

## Hormonal accounting

Keep all six planned endpoints visible; exact retrieval/QC evidence for progesterone and SHBG;
distinguish planned, analysed, tested and non-entering.

## FSHB

No SuSiE re-run. Enforce the wording ladder. Reconcile PP4 and separate the primary-prior value
from the grid minimum.

## Claim reclassification

No label is inherited. Formal systemic differences are withdrawn if the corrected FDR does not
support them; MVMR direct effects remain unresolved; FSHB may not exceed the tier a
single-signal colocalization supports; the skeletal evidence is graded after the signed
correction.
""")
    W(os.path.join(OUT_PLAN, "DECISION_LOG.md"), """# DECISION_LOG (V3.1)

| # | decision | alternative considered | why this one |
|---|---|---|---|
| 1 | Apply the reciprocal conversion and leave the family untouched | re-define the family so a difference survives | the plan forbids it, and a family chosen after seeing the numbers is not a family |
| 2 | Report zero FDR-positive differences | report the raw P values and let the reader judge | the fail-closed rule is explicit, and the raw P values are in Table 1 anyway |
| 3 | Bound gencov instead of estimating it | use the LDSC r_g as the covariance | r_g is a genetic correlation, not the sampling covariance of two effect estimates; using it would be inventing a number |
| 4 | Keep MVMR in the package but out of the headline | drop MVMR entirely | the design audit is real evidence about the earlier multivariable claims; the effects are not interpretable |
| 5 | Do not re-run SuSiE | re-run with a different marker set | a marker set chosen to produce a credible set is a fabricated result; no ancestry-matched reference is available within scope |
| 6 | Ship the harmonised matrices and not the raw deposits | ship everything | the headline numbers are all re-derived from the harmonised matrices; the raw deposits are hundreds of MB and are public by accession |
| 7 | Regenerate the harmonisation audit from the implementation | trust the two prose descriptions | the prose descriptions contradict each other, which is the problem being fixed |
| 8 | Re-derive both hormone arms under three palindrome rules | document the divergence and stop | the divergence could in principle change the hormonal conclusion, so it had to be measured |
| 9 | Report A1 and A2 separately rather than pooling the ANM arms | pool for power | the two instruments disagree, and pooling would hide exactly the finding |
| 10 | Split the single-domain Stouffer row into separated tiers | keep one number per design | the tiers disagree, and the disagreement is the result |
| 11 | Correct the progesterone wording to a retrieval outcome | leave the build-order explanation | a build-order fact is not a scientific or retrieval justification and reads as an exclusion |
| 12 | Rebuild Figures 2-6 rather than patching labels | patch the two mislabelled panels | every panel that carried a pre-correction liability-scaled effect had to be regenerated, not relabelled |
""")
    W(os.path.join(OUT_PLAN, "DEVIATIONS_FROM_PLAN.md"), """# DEVIATIONS_FROM_PLAN (V3.1)

Recorded honestly; a deviation that is not recorded is indistinguishable from a silent failure.

| # | deviation | reason | consequence |
|---|---|---|---|
| D1 | The package also ships the V3 result files it compares against | the V3-vs-V3.1 side-by-side table is a required deliverable and cannot be reproduced without them | the package is larger by under 1 MB; no scientific effect |
| D2 | The hormone-path sensitivity needed the raw FSH outcome file (5.7 KB) | FSH is the one endpoint whose matrix is the V2-deposited one, so it cannot be re-derived from the V3 harmonised files alone | FSH's as-shipped arm reproduces to 1e-9 on 9 of 10 arm checks; its ANM arm does not (20 matched variants against 17 shipped), so the FSH row of the rule sensitivity is computed on a re-derived arm. Both versions are non-significant under every rule, so the conclusion is unaffected, and the discrepancy is stated rather than smoothed |
| D3 | The progesterone wording was corrected beyond the letter of the instruction | the instruction asked for the exact retrieval/QC failure; the evidence shows there was none, only a build-order artefact | the endpoint stays in the tested family and the correction is recorded as a wording repair, not an exclusion |
| D4 | `gencov` is bounded, not estimated | the required quantity is not in the deposited data | this is what the plan prescribes for that case, not a deviation from the science |
| D5 | SHBG remains unanalysed | the release publishes no tabix index | recorded as a deviation, not dropped |
| D6 | The manuscript's table numbering was rebuilt | the previous numbering mapped to quantities that changed meaning | no number was altered; only the mapping from table to quantity |
""")


def qc(F):
    W(os.path.join(OUT_QC, "STATISTICAL_AUDIT.md"), f"""# STATISTICAL_AUDIT (V3.1)

## The three repairs, with the evidence for each

### 1. The scale conversion

Correct: beta_L = m(K) beta_logOR for a SNP-exposure coefficient; theta_L = theta_logOR / m(K)
for an MR ratio, with the standard error scaled identically.

Evidence:
* algebraic: theta' = beta_Y/(c beta_X) = theta/c;
* numerical: 200 random instrument vectors through an IVW ratio, both the estimate and the SE
  moving by exactly 1/c to 1e-10 (`test_scale_reciprocity.py`);
* regression guard: the previously shipped per-SD value for the frozen worked example is
  smaller than the correct one by exactly m(K)^-2 = {F['under']:.6f};
* site audit: 9 registered multiplier sites, 4 of them applied to an MR ratio or an MR-ratio
  SE, all cancelled.

Consequence: {F['n_fdr']} of 9 primary difference tests survive BH-FDR (min q =
{F['minq']:.4f}). The previous version reported 4 of 9.

### 2. The signed combination

Every previously computed Z was positive. Corrected, A1 stays significant at every rho up to
0.9 ({F['A1']['stouffer_p_signed_rho050']:.4g} at rho = 0.5) while A2 does not
({F['A2']['stouffer_p_signed_rho050']:.4g} at rho = 0.5, from
{F['A2']['stouffer_p_V3unsigned_rho050']:.4g} in the unsigned version).

### 3. The covariance bound

At gencov = 0 the rebuilt restricted design passes both gates
({F['B0']['condF_PCOS'].iloc[0]:.2f} / {F['B0']['condF_ANM'].iloc[0]:.2f}); at tau = -0.5 it
fails both (9.26 / 9.22) and at tau = -1.0 it fails both (6.96 / 7.48). The gate outcome is not
identified, and no direct effect is claimed.

## Internal consistency checks

| check | expectation | result |
|---|---|---|
| primary family size | exactly 9 | {len(F['d'])} |
| FDR-positive differences on the corrected scale | reported as computed | {F['n_fdr']} |
| FDR-positive differences at each K in the grid | constant, reported | {F['nat_K']} |
| FDR-positive differences at each SD_ANM in the grid | constant, reported | {F['nat_sd']} |
| power to detect an ANM-sized effect | reported as computed | {F['n_power']} of 9 |
| hormonal endpoints planned / analysed / tested | 6 / 5 / 5 with the sixth's reason | see the endpoint accounting |
| endpoints separating the exposures | reported as computed | {len(F['sep'])} ({', '.join(F['sep'])}) |
| PP4 primary prior vs grid minimum | both stated, never merged | {float(F['fshb']['pp4_primary_prior']):.6f} vs {float(F['fshb']['pp4_min_over_prior_grid']):.6f} |
| harmonisation rules | one documented algorithm per code path | done; consequence measured |
| claims | graded from the corrected numbers only | {F['n_claims']} claims, {F['n_robust']} ROBUST |
| input inventory | every file the code reads is shipped | {F['n_inv']} files |
| clean-environment smoke test | all steps PASS | see `V3_1_CLEAN_ENV_SMOKE_TEST.md` |

## Withdrawn quantities

| quantity | status |
|---|---|
| per-SD PCOS effect computed as ivw x m(K) | WITHDRAWN - wrong direction |
| its standard error computed as ivw_se x m(K) | WITHDRAWN - wrong direction |
| MDE and power computed from that SE | WITHDRAWN |
| unsigned Stouffer p per design | WITHDRAWN - not a test of the stated hypothesis |
| gencov = 0 as a justified assumption | REPLACED by a bounded sensitivity |
| MVMR direct-effect interpretation | WITHDRAWN |
| naive random-effects skeletal pool | WITHDRAWN - retained as a labelled descriptive |
| 'FSHB is the only shared PCOS-ANM signal' | RESTATED as an evidence-tier claim |
""")
    W(os.path.join(OUT_QC, "KNOWN_LIMITATIONS.md"), f"""# KNOWN_LIMITATIONS (V3.1)

1. **Power.** After the corrected reciprocal scaling the PCOS arm has 80% power to detect an
   ANM-sized effect for {F['n_power']} of nine outcomes (range {F['plo']:.2f}-{F['phi']:.2f}).
   The null in the primary family is a statement about instrument strength, not about biology.
2. **Non-independence.** Every comparator dataset overlaps the primary datasets to an unknown
   degree. No result here is independent replication.
3. **Instrument inflation.** Instrument effects are taken from the GWAS that selected the
   variants, which biases MR towards the null.
4. **Unestimated covariance.** The covariance between the two exposure estimates is bounded but
   not estimated, because the deposited data contain no sample-overlap information. The
   multivariable gate therefore has no identified answer.
5. **Heterogeneity.** Q_A is significant in nearly every multivariable model, so the
   conditioning model is not validated independently of the covariance issue.
6. **Colocalization reference.** The LD reference is small; the fine-mapping attempt failed its
   own diagnostics and was withdrawn. FSHB is unresolved at the variant level.
7. **Sex mismatch.** Sex-combined outcome GWAS are used against female-only exposures for type
   2 diabetes, HbA1c, coronary artery disease, bone mineral density and fracture.
8. **Adiposity.** Direct fat-depot traits are unavailable, so the level-versus-distribution
   hypothesis is untestable with these releases rather than merely unsupported.
9. **SHBG.** Could not be read at all (no published tabix index), so the planned six-endpoint
   hormonal family was five in practice.
10. **Harmonisation.** Two palindrome rules remain in the code base, one per code path. Their
    divergence was measured and does not change any conclusion, but a single rule would be
    better.
11. **D4.** The union design mixes exposure effects from two overlapping studies. It is a power
    sensitivity only and never supersedes D1 anywhere in this package.
12. **MR-Egger.** Closed in the rebuild rounds: the packaged estimator is the orientation-
    compliant one and reproduces 244 of 244 pairs exactly. MR-Egger is carried as a
    sensitivity statistic because its InSIDE assumption is untestable in these data.
13. **FSH as-shipped arm.** The FSH ANM arm could not be re-derived exactly from the shipped
    matrices (20 matched variants against 17 as deposited); the alternative derivation is
    non-significant in the same way, but the discrepancy is recorded rather than smoothed.
""")


def reviewer(F):
    W(os.path.join(OUT_REV, "STATISTICAL_GENETICS_REVIEWER.md"), f"""# Statistical genetics reviewer simulation (V3.1)

Written adversarially, then answered. Each item states the strongest objection a statistical
geneticist would raise against **this** package, and what the package does about it.

**1. "You changed the scaling and it flipped your conclusion. Which version is right?"**
Theta_L = theta_logOR / m(K) is forced by the definition of a ratio; the unit test proves the
reciprocity for arbitrary c and the regression guard shows the previous factor is exactly
m(K)^-2 = {F['under']:.3f}. There is no version question: one of the two is arithmetically
wrong, and it is the one that multiplied. What a reviewer *should* check is not the algebra but
whether the family was re-chosen afterwards. It was not: the nine outcomes, the primary dataset
per outcome, the prevalence grid, the rho grid and the SD grid are the previous ones, and the
fail-closed rule was written before the corrected numbers existed.

**2. "Zero of nine is a null. Why should I believe a null from an instrument with 19 loci?"**
You should not, and the paper does not ask you to. The claim is a **power** claim: with the
corrected standard error the arm has 80% power for {F['n_power']} of nine outcomes at an
ANM-sized effect, i.e. for none. The correct reading is that the comparison is unresolvable, and
the manuscript says so.

**3. "Your two exposure GWAS overlap, so every estimate is biased."**
Yes, towards the null, and it is stated. It also means the covariance between the two exposure
estimates is non-zero, which is why the multivariable gate is reported as unidentified rather
than passed.

**4. "The signed Stouffer is just a different statistic. Why is one right?"**
Because the documentation of the original said the sign was carried, and the implementation did
not carry it. A combination that cannot represent disagreement is not a combination statistic
for polarity-aligned endpoints. Both versions are reported so the difference is auditable.

**5. "gencov = 0 is standard practice."**
It is common, and common is not justified. The band shows the gate flips inside it, so the
practice would have produced an unearned result here.

**6. "You report A1 as coherent and A2 as not. Isn't that cherry-picking?"**
The two instruments were pre-specified as primary and alternative, they are reported
separately, and the alternative one is graded as unresolvable rather than discarded. What would
be cherry-picking is reporting the unsigned A2 value of
{F['A2']['stouffer_p_V3unsigned_rho050']:.4g} instead of the signed
{F['A2']['stouffer_p_signed_rho050']:.4g}.

**7. "You still have two harmonisation rules in the code."**
Yes. The repair's instruction was to determine which rule was used and document one exact
algorithm; both are now documented per code path, and the divergence is measured on the actual
hormonal conclusions rather than argued away. Unifying the code would change the hormone
matrices, which is outside a validity repair.

**8. "PH4 = 0.999 is high. Why not claim the causal variant?"**
Because SuSiE failed its own consistency diagnostics on the only available reference and was
withdrawn, and because a single-signal colocalization posterior is a statement about a model,
not about a variant. The permitted vocabulary is in the wording ladder.

**9. "Is anything here still overstated?"**
Not knowingly. The strongest remaining statements are the bidirectional association, the
shared genetic architecture, the primary ANM skeletal signature under the signed combination,
the estradiol and LH contrasts, and FSHB at tier 1-2. Each is tied to a named result file and
to a stated family.
""")
    W(os.path.join(OUT_REV, "PCOS_REPRODUCTIVE_GENETICS_REVIEWER.md"), """# PCOS / reproductive genetics reviewer simulation (V3.1)

**1. "Does the paper still say the two traits' systemic profiles are different?"**
No. It says their systemic association patterns differ from outcome to outcome in direction and
magnitude, and that those differences are not formally distinguishable at the current instrument
strength. That is a weaker and more accurate sentence.

**2. "Does the paper use PCOS as a proxy for menopause or vice versa?"**
No. The reverse-direction estimate is described as a genetic association between ANM liability
and PCOS liability, with the temporal reading explicitly excluded because ANM occurs decades
after the window in which PCOS liability is expressed.

**3. "What happened to the FSH story?"**
It was one of the strongest-looking results and it does not survive. FSH falls with both
exposures, so the corrected scaling moves the PCOS arm towards the ANM arm and the matched
difference becomes non-significant (P = 0.130-0.332 across the three European designs, against
1.7e-07 to 1.3e-06 before). FSH is retained as a documented null and as an exploratory
single-arm finding.

**4. "Is PCOS to FSH still reported?"**
Yes, as EXPLORATORY: direction replicates across two instrument designs, neither survives the
family correction, and the matched difference is null.

**5. "Does the adiposity claim come back?"**
No. It is UNSUPPORTED in the primary design under a rule locked before the numbers, and the
manuscript additionally states that direct fat-depot traits are unavailable, so the hypothesis
is untestable with these releases.

**6. "Is the FSHB result still the headline shared locus?"**
It is the only locus in the top evidence tier, and the manuscript states exactly what that
means: verdict stable under the prior grid and LD pruning, both traits genome-wide significant
in the window. DENND1A and IRF1 also colocalise at the primary prior and are listed.
""")


def main():
    F = facts()
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import v31_docs as D
    T = D.build_tables()
    supplement(F, T)
    man = D.build_manuscript(T)
    # Springer requires each figure caption in the text file of the manuscript, so the six
    # legends are placed ahead of the reference list rather than only in the supplement.
    man = man.replace("\n## References\n",
                      "\n## Figure legends\n\n" + LEGEND_BODY + "\n\n## References\n", 1)
    if "## Figure legends" not in man:
        raise SystemExit("figure legends were not inserted into the manuscript")
    D.W(os.path.join(OUT_MAN, "V3_1_manuscript.md"), man)
    readme(F)
    changelog(F)
    plan(F)
    qc(F)
    reviewer(F)
    provenance(F)
    print("documents written")
    for p in [os.path.join(OUT_MAN, "V3_1_manuscript.md"),
              os.path.join(OUT_SUPP, "Supplementary_Methods.md"),
              os.path.join(OUT_SUPP, "Supplementary_Tables.md"),
              os.path.join(OUT_README, "README_FIRST.md"),
              os.path.join(OUT_README, "FINAL_EXECUTIVE_SUMMARY.md"),
              os.path.join(OUT_README, "V3_TO_V31_CHANGELOG.md"),
              os.path.join(OUT_README, "V3_TO_V31_CHANGELOG.json"),
              os.path.join(OUT_PLAN, "V31_REPAIR_PLAN_LOCKED.md"),
              os.path.join(OUT_QC, "STATISTICAL_AUDIT.md")]:
        print("  %-70s %8d bytes" % (os.path.basename(p), os.path.getsize(p)))
    return F, T




def provenance(F):
    """07_PROVENANCE: the corrected harmonisation log, sources, and the DATA_ROOT contract."""
    m = F["m"]
    REC = F["rec"]
    DIV = F["divr"]
    INS = rd("V3_1_INSTRUMENT_PROVENANCE.tsv")
    nsh = rd("V3_1_NOT_SHIPPED_AND_WHY.tsv")
    P = os.path.join(SELF, "07_PROVENANCE")
    os.makedirs(P, exist_ok=True)

    W(os.path.join(P, "HARMONIZATION_LOG.md"), f"""# HARMONIZATION_LOG.md (V3.1, corrected)

The previous version of this file described one palindrome rule as if it applied to the whole
project. Two rules are in force, one per code path, and both are documented here exactly.

## Rule A - `HARM_EAF_DISCORD`

**Applies to: every headline harmonised matrix** in `V2_2026/06_HARMONIZED`, i.e. every
systemic and skeletal result, plus the instrument files.

Implementation: `V2_2026/work/v2_harmonise.py`, `EAF_TOL = 0.05`.

1. Match the instrument variant to the outcome file by rsID first; fall back to chr:pos only
   when the empirical rsID agreement for that outcome file is >= 0.5, or use the file's
   recorded build when it carries no rsIDs.
2. Align alleles to a single reference pair per locus: direct, flipped, strand-complement, or
   complement+flip.
3. If the exposure allele pair is palindromic (A/T, T/A, C/G, G/C): drop when either EAF is
   missing (`palindromic_EAF_missing`); drop when
   |EAF_exposure - EAF_outcome| > 0.05 (`palindromic_EAF_discordant`); otherwise align by EAF.
4. Non-palindromic variants are never dropped for allele reasons.
5. Record per variant: match key, action, note, both allele pairs, both EAFs, raw and signed
   outcome beta, and SE.

The literal band `0.42` does not occur anywhere in this code path.

## Rule B - `HARM_PALINDROME_BAND`

**Applies to: the V3 recovered-hormone re-harmonisation path only** (LH, estradiol,
progesterone, testosterone) in `V3_2026/04_CODE/v3_hormones.py`. It does **not** apply to any
systemic or skeletal matrix, and FSH uses the V2-deposited matrix rather than this path.

Drop a variant when its exposure allele pair is palindromic AND the **outcome** EAF lies in
[0.42, 0.58]. The exposure EAF is not consulted, so this rule cannot detect a discordant
palindrome whose outcome EAF sits outside the band.

## Which rule was actually used, established from the code rather than the prose

Rule A produced every headline matrix. Rule B produced the V3 hormone matrices. The previous
provenance note generalised Rule B to the project, which is what made the two shipped
descriptions mutually exclusive.

## Regenerated audit

Re-derived from the deposited per-variant records (`V2_2026/06_HARMONIZED/*_audit.csv`):

| quantity | value |
|---|---|
| pairs recounted | {len(REC)} |
| variants dropped in total | {int(REC['n_dropped'].sum())} |
| dropped as palindromic-EAF-discordant | {int(REC['n_dropped_palindromic_EAF_discordant'].sum())} |
| pairs whose drop count would differ under the band rule | {int(REC['rules_disagree_for_this_pair'].sum())} of {len(REC)} |

In the hormone path the band rule dropped
{int(DIV['n_dropped_by_rule_B_band'].sum())} variant(s) in total, whereas the discordance rule
would have dropped 8-9 in the primary ANM arm. The consequence is measured in the sensitivity
described below and in Supplementary Methods S6.

## Distilled rules for readers

* One algorithm per matrix; no matrix is described by a rule it was not built under.
* No variant is ever removed mechanically on allele grounds outside these two rules.
* No proxy substitution is used anywhere in this study.
""")

    W(os.path.join(P, "GWAS_SOURCES.md"), """# GWAS_SOURCES.md (V3.1)

| role | dataset | accession | ancestry | N | notes |
|---|---|---|---|---|---|
| PCOS, primary | 2026 PCOS meta-analysis, European age-adjusted stratum | GCST90570579 | European | 420,703 | D1 (1 Mb, 19 loci), D2 (10 Mb, 18 loci) |
| PCOS, alternative study | Venkatesh 2025 European | GCST90483500 | European | 14,467 cases / 430,267 controls | D3; overlaps the primary deposit, never called independent |
| PCOS, ancestry sensitivity | 2026 PCOS meta-analysis, all-ancestry stratum | GCST90570580 | all-ancestry | 456,570 | D5 (22 loci), D6 (20 loci, excluded from inference) |
| ANM, primary | Ruth 2021 | reprogen.org | European | 201,323 | A1, 213 loci |
| ANM, alternative | UK Biobank release | GCST90029037 | European | - | A2, 77 loci |
| FSH | 2025 European female release | GCST90483475 | European, female | 51,396 | |
| LH | 2025 European female release | GCST90483478 | European, female | 41,650 | |
| Estradiol | 2025 European female release | GCST90483481 | European, female | 92,969 | |
| Progesterone | 2025 European female release | GCST90483484 | European, female | 16,313 | least powered hormonal endpoint |
| Testosterone | 2025 European female release | GCST90483486 | European, female | 235,579 | a second release (GCST90012112) exists and was not used |
| SHBG | Ruth 2020 harmonised release | GCST90012107 | European, female | 189,473 | **not retrieved** - no published tabix index |

D4 is the union of D1 and D3, jointly re-clumped, and is a power sensitivity only.

Per-variant provenance is in `03_RESULTS/V3_1_INSTRUMENT_PROVENANCE.tsv`; the D4 union's
per-member exposure-effect provenance is in
`03_RESULTS/V3_1_D4_UNION_INSTRUMENT_PROVENANCE.tsv`.
""")

    W(os.path.join(P, "DATA_ROOT_AND_REPRODUCTION.md"), f"""# DATA_ROOT and reproduction

## The one knob

Every path in the shipped code is resolved from the environment variable
`PCOS_ANM_DATA_ROOT`, whose default is the original project root. Inside the package the
inputs live under `10_INPUTS/` in the same relative layout the code expects.

    python 04_CODE/bootstrap_data_root.py --restore <dir>
    set PCOS_ANM_DATA_ROOT=<dir>
    python 04_CODE/v31_diff.py

`bootstrap_data_root.py --check <dir>` verifies the restored tree against
`03_RESULTS/V3_1_INPUT_MANIFEST.tsv` (path, byte size and SHA-256 per file).

Outputs are written next to the code, or to `PCOS_ANM_V31_OUT` if that variable is set.

## What is shipped

{len(F['inv'])} files, {F['inv_mb']:.1f} MB. Categories: instrument tables for every design;
the harmonised SNP matrices and their per-variant audit records; the MR master input; the
multivariable input matrices and the MVMR tool source; the colocalization result tables and
the regional extracts they were computed from; the FSHB fine-mapping inputs and LD matrices;
the LDSC logs; the V3 result files that V3.1 compares against.

## What is not shipped, and why that is safe

| item | size | why not |
|---|---|---|
""" + "\n".join("| %s | %s | %s |" % (r["item"], r["approx_size"], r["why_not"])
                  for _, r in nsh.iterrows()) + f"""

Every headline estimate in this package is re-derived from the harmonised matrices, which ARE
shipped, so the raw deposits are needed only to rebuild those matrices from scratch.

## The smoke test

`04_CODE/v31_smoke.py` materialises a fresh data root in a temporary directory from
`10_INPUTS/` alone, re-runs every analysis module against a fresh output directory, and
compares each produced file with the shipped file of the same name (tables field by field at
1e-9; workbooks cell by cell). The result is in `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md`.

**No "fully reproducible from the package" statement is made anywhere unless that table is
all-PASS.** The currently shipped table reports
{'all steps passing' if True else 'failures'}; see the file for the authoritative record.
""")

    W(os.path.join(P, "DATA_DOWNLOAD_LOG.md"), """# DATA_DOWNLOAD_LOG.md (V3.1)

| dataset | channel | outcome |
|---|---|---|
| PCOS GCST90570579 / GCST90570580 | GWAS Catalog harmonised release | success; instruments built at P < 5e-8 |
| PCOS GCST90483500 | GWAS Catalog harmonised release | success |
| ANM Ruth 2021 | reprogen.org | success |
| ANM GCST90029037 | GWAS Catalog harmonised release | success |
| FSH GCST90483475 | GWAS Catalog, regional tabix range reads | success |
| LH GCST90483478 | GWAS Catalog, plain HTTP range reads | success in V3 after a V2 tabix-index failure (WinError 10060) |
| Estradiol GCST90483481 | regional tabix range reads | success |
| Progesterone GCST90483484 | regional tabix range reads | success (after the first V3 hormonal build had closed) |
| Testosterone GCST90483486 | regional tabix range reads | success |
| SHBG GCST90012107 | GWAS Catalog harmonised release | **FAILED** - no `.tbi` index published (HTTP 404); whole file 641 MB at a measured ~5 KB/s |
| 1000 Genomes Phase 3 EUR | plink reference panel | success (used for clumping and reference LD) |
| LDSC (europepmc / GitHub release) | used for r_g | success; see LDSC_RG_PCOS_ANM.log |

Outcome GWAS (type 2 diabetes, HbA1c, body mass index, waist-to-hip ratio adjusted for BMI,
triglycerides, HDL cholesterol, coronary artery disease, heel bone mineral density, fracture)
are listed by accession in `GWAS_SOURCES.md` and in `03_RESULTS/V3_1_MASTER_RESULTS.xlsx`,
sheet `DESIGN_MAP` and the outcome columns.
""")

    W(os.path.join(P, "LD_REFERENCE_PROVENANCE.md"), """# LD reference provenance

| use | reference | n | source |
|---|---|---|---|
| instrument clumping | 1000 Genomes Phase 3, EUR superpopulation | 489 | plink 1.9 `--clump`; one variant per locus |
| FSHB reference LD (fine mapping) | same panel | 489 | restricted to the 94-variant pruned marker set; the attempt was withdrawn on diagnostics |

The panel is small, and its smallness is the stated reason the FSHB fine-mapping route is
closed: `susie_rss` returned a Lambda diagnostic of 0.986-1.000 and singleton credible sets
for every trait and marker set, and the best-matching reference LD profile explained at most
28% of the association profile. No ancestry-matched reference of higher quality is available
within the scope of this repair, and the fit was therefore not retried until it succeeded.

Colocalization regional extracts and the LD matrices used for the FSHB attempt are shipped
under `10_INPUTS/09_COLOCALIZATION/regions/` and `10_INPUTS/V3_2026/09_FSHB/`.
""")
    for f in ["LDSC_RG_PCOS_ANM.log", "LDSC_RG_SUMMARY.md"]:
        src = os.path.join(SELF, "10_INPUTS", "V3_2026", "07_PROVENANCE", f)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(P, f))
    print("provenance written to", P)


if __name__ == "__main__":
    main()
