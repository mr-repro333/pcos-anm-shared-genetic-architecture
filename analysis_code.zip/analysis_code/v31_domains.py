# -*- coding: utf-8 -*-
"""V3.1 PRIORITY 1 - the skeletal domain with a correctly signed Stouffer combination.

WHAT WAS WRONG IN V3
--------------------
``v3_domains.stouffer_corr`` documented that "the sign is carried by the aligned effect"
and then built every Z from a two-sided P value:

    z_i = Phi^{-1}(1 - p_i / 2)          ->  z_i > 0 for every i

so the combination summed k positive numbers and could only ever report a one-sided
excess. With endpoints that are aligned for polarity, a domain in which three endpoints
move one way and four the other was scored as if all seven agreed. The reported P values
are therefore not P values for the stated hypothesis.

WHAT V3.1 DOES
--------------
    signed_Z_i = sign(beta_aligned_i) * Phi^{-1}(1 - P_i / 2)
    Z          = sum(signed_Z_i) / sqrt(k + k(k-1) rho)

recomputed for exactly the endpoint set and the exact rho grid V3 used. No endpoint was
added or removed. A1 and A2 are reported separately and are never pooled. The naive
random-effects pool is retained only as an explicitly withdrawn historical quantity.

The domain evidence is kept in five separated tiers rather than as one number:
primary eBMD, primary fracture, alternative osteoporosis, site-specific fracture
evidence, and evidence from the alternative ANM instrument.
"""
import io, math, os, sys

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import (RES, LOGD, RES, MRV2, DESIGNS, ALIAS2CANON, SKELETAL,
                      SKELETAL_PRIMARY, SKELETAL_ALT, ALPHA)
from v31_diff import bh, load_master

RHO_ENDPOINT_GRID = [0.0, 0.25, 0.5, 0.75, 0.9]
ADIP_SD = {"level": dict(value=4.8, lo=4.0, hi=5.5, unit="kg/m^2",
                         note="BMI, European adults (GIANT/UKB; ~4.8 kg/m^2)"),
           "distribution": dict(value=0.070, lo=0.055, hi=0.085, unit="dimensionless",
                                note="WHRadjBMI, European adults (Pulit 2019 / Yengo 2018; ~0.07)")}
ADIPOSITY_LEVEL = {"BMI_FINNGEN": "primary", "BMI_combined": "alternative",
                   "BMI_females": "alternative"}
ADIPOSITY_DIST = {"WHRadjBMI_Pulit_dense_combined": "primary",
                  "WHRadjBMI_Pulit_dense_females": "alternative",
                  "WHRadjBMI_yengo_combined": "alternative",
                  "WHRadjBMI_yengo_females": "alternative",
                  "WHRadjBMI_combined": "alternative", "WHRadjBMI_women": "alternative"}


# ----------------------------------------------------------------- signed Stouffer
def signed_z(beta, p):
    """signed_Z = sign(beta) * Phi^{-1}(1 - P/2). V3.1 PRIORITY 1."""
    p = min(max(float(p), 1e-300), 1 - 1e-16)
    z = float(stats.norm.isf(p / 2))
    return math.copysign(z, -1.0 if float(beta) < 0 else 1.0)


def stouffer_signed(betas, pvals, rho):
    """Correlation-robust Stouffer on SIGNED Z. Returns (Z, p, n_effective)."""
    z = np.array([signed_z(b, p) for b, p in zip(betas, pvals)], float)
    k = len(z)
    v = k + k * (k - 1) * rho
    if v <= 0:
        return np.nan, np.nan, k / (1 + (k - 1) * rho) if rho < 1 else 1.0
    Z = float(np.sum(z) / math.sqrt(v))
    return Z, float(2 * stats.norm.sf(abs(Z))), k / (1 + (k - 1) * rho) if rho < 1 else 1.0


def stouffer_v3_unsigned(pvals, rho):
    """V3's shipped (broken) version, retained only to quantify the change."""
    z = np.array([float(stats.norm.isf(min(max(p, 1e-300), 1 - 1e-16) / 2)) for p in pvals], float)
    k = len(z)
    v = k + k * (k - 1) * rho
    Z = float(np.sum(z) / math.sqrt(v))
    return Z, float(2 * stats.norm.sf(abs(Z)))


def effective_k(k, rho):
    return k / (1 + (k - 1) * rho) if rho < 1 else 1.0


def meta_naive(b, se):
    """Withdrawn descriptive only; its p-value is never used for inference."""
    b, se = np.asarray(b, float), np.asarray(se, float)
    w = 1 / se ** 2
    bf = float(np.sum(w * b) / np.sum(w))
    Q = float(np.sum(w * (b - bf) ** 2)); df = len(b) - 1
    C = float(np.sum(w) - np.sum(w ** 2) / np.sum(w))
    tau2 = max(0.0, (Q - df) / C) if df > 0 and C > 0 else 0.0
    wr = 1 / (se ** 2 + tau2)
    be = float(np.sum(wr * b) / np.sum(wr)); see = float(math.sqrt(1 / np.sum(wr)))
    return dict(fixed=bf, random=be, se_random=see,
                p_random=2 * stats.norm.sf(abs(be / see)), Q=Q, Q_df=df,
                Q_p=float(stats.chi2.sf(Q, df)) if df > 0 else np.nan,
                I2=float(max(0.0, (Q - df) / Q) * 100) if Q > 0 else 0.0, tau2=tau2)


# ------------------------------------------------------------------ skeletal table
def skeletal_endpoints(master):
    rows = []
    for (design, out), g in master[master["outcome"].isin(SKELETAL)].groupby(
            ["design", "outcome"]):
        r = g.iloc[0]
        pol = SKELETAL[out]
        rows.append(dict(exposure_design=design, endpoint=out, polarity=pol,
                         status="primary" if out in SKELETAL_PRIMARY else "alternative",
                         n_snp=int(r["nsnp"]),
                         beta_raw=float(r["ivw"]), beta_aligned=float(r["ivw"]) * pol,
                         se=float(r["ivw_se"]), p=float(r["iwv_p"] if "iwv_p" in r else r["ivw_p"]),
                         signed_Z=signed_z(float(r["ivw"]) * pol, float(r["ivw_p"])),
                         wm=float(r["wm"]) * pol, wm_p=float(r["wm_p"]),
                         wmode=float(r["wmode"]) * pol, wmode_p=float(r["wmode_p"]),
                         egger=float(r["egger"]) * pol, egger_p=float(r["egger_p"]),
                         egger_int=float(r["egger_int"]), egger_int_p=float(r["egger_int_p"]),
                         q_p=float(r["q_p"])))
    d = pd.DataFrame(rows)
    d["FDR_within_skeletal"] = np.nan
    for design, g in d.groupby("exposure_design"):
        d.loc[g.index, "FDR_within_skeletal"] = bh(g["p"].values)
    d["robust_agreement"] = np.where(
        (np.sign(d["wm"]) == np.sign(d["beta_aligned"])) &
        (np.sign(d["wmode"]) == np.sign(d["beta_aligned"])), "sign-agree", "sign-disagree")
    d["nominal"] = d["p"] < ALPHA
    d["fdr_pass"] = d["FDR_within_skeletal"] < ALPHA
    return d.sort_values(["exposure_design", "status", "endpoint"])


def skeletal_summary(d):
    rows = []
    for design, g in d.groupby("exposure_design"):
        b = g["beta_aligned"].values
        p = g["p"].values
        npos = int((b > 0).sum())
        prim = g[g["status"] == "primary"]
        alt = g[g["status"] == "alternative"]
        row = dict(
            exposure_design=design, role=DESIGNS[design]["role"], k=len(g),
            direction_consistency=float(npos / len(g)), n_favourable=npos,
            n_unfavourable=int((b < 0).sum()),
            n_nominal=int(g["nominal"].sum()), n_fdr_pass=int(g["fdr_pass"].sum()),
            endpoints_fdr_pass=";".join(g.loc[g["fdr_pass"], "endpoint"]),
            robust_estimator_sign_agreement=int((g["robust_agreement"] == "sign-agree").sum()),
            signed_stouffer_Z_rho050=stouffer_signed(b, p, 0.5)[0],
            stouffer_p_signed_rho000=stouffer_signed(b, p, 0.0)[1],
            stouffer_p_signed_rho025=stouffer_signed(b, p, 0.25)[1],
            stouffer_p_signed_rho050=stouffer_signed(b, p, 0.5)[1],
            stouffer_p_signed_rho075=stouffer_signed(b, p, 0.75)[1],
            stouffer_p_signed_rho090=stouffer_signed(b, p, 0.9)[1],
            stouffer_p_V3unsigned_rho000=stouffer_v3_unsigned(p, 0.0)[1],
            stouffer_p_V3unsigned_rho050=stouffer_v3_unsigned(p, 0.5)[1],
            stouffer_p_V3unsigned_rho090=stouffer_v3_unsigned(p, 0.9)[1],
            effective_k_rho050=effective_k(len(g), 0.5),
            tier1_primary_eBMD=";".join("%s=%.4f(p=%.3g)" % (r.endpoint, r.beta_aligned, r.p)
                                        for r in prim[prim["endpoint"] == "BMD"].itertuples()),
            tier2_primary_fracture=";".join("%s=%.4f(p=%.3g)" % (r.endpoint, r.beta_aligned, r.p)
                                            for r in prim[prim["endpoint"] == "Fracture"].itertuples()),
            tier3_osteoporosis=";".join("%s=%.4f(p=%.3g)" % (r.endpoint, r.beta_aligned, r.p)
                                        for r in alt[alt["endpoint"].str.startswith("Osteoporosis")].itertuples()),
            tier4_site_specific_fracture=";".join("%s=%.4f(p=%.3g)" % (r.endpoint, r.beta_aligned, r.p)
                                                  for r in alt[alt["endpoint"].str.startswith("Fracture_")].itertuples()),
            naive_fixed_meta_withdrawn=meta_naive(b, g["se"].values)["fixed"],
            naive_random_meta_withdrawn=meta_naive(b, g["se"].values)["random"],
            naive_meta_p_withdrawn=meta_naive(b, g["se"].values)["p_random"],
            naive_meta_I2_withdrawn=meta_naive(b, g["se"].values)["I2"],
            naive_meta_status="WITHDRAWN - correlated endpoints, non-commensurable units",
            unit_commensurability="NOT commensurable: eBMD vs fracture log-OR vs osteoporosis log-OR")
        rows.append(row)
    s = pd.DataFrame(rows)
    s["signed_stouffer_significant_rho050"] = s["stouffer_p_signed_rho050"] < ALPHA
    s["signed_stouffer_significant_rho090"] = s["stouffer_p_signed_rho090"] < ALPHA
    return s


# -------------------------------------------------------------------- adiposity
def adiposity(master):
    rows = []
    for (design, out), g in master[master["outcome"].isin(
            list(ADIPOSITY_LEVEL) + list(ADIPOSITY_DIST))].groupby(["design", "outcome"]):
        r = g.iloc[0]
        klass = "level" if out in ADIPOSITY_LEVEL else "distribution"
        rows.append(dict(exposure_design=design, endpoint=out, klass=klass,
                         status=ADIPOSITY_LEVEL.get(out) or ADIPOSITY_DIST.get(out),
                         n_snp=int(r["nsnp"]), beta=float(r["ivw"]), se=float(r["ivw_se"]),
                         p=float(r["ivw_p"]), q_p=float(r["q_p"])))
    d = pd.DataFrame(rows)
    d["FDR_within_adiposity"] = np.nan
    for design, g in d.groupby("exposure_design"):
        d.loc[g.index, "FDR_within_adiposity"] = bh(g["p"].values)
    d["perSD_note"] = ("ratio within one exposure arm, so the PCOS liability multiplier "
                       "m(K) cancels; the V3.1 scale correction does not change this table")
    d["beta_perSD_of_trait_main"] = d.apply(lambda r: r["beta"] / ADIP_SD[r["klass"]]["value"], axis=1)
    d["beta_perSD_lo_assumption"] = d.apply(lambda r: r["beta"] / ADIP_SD[r["klass"]]["hi"], axis=1)
    d["beta_perSD_hi_assumption"] = d.apply(lambda r: r["beta"] / ADIP_SD[r["klass"]]["lo"], axis=1)
    d["nominal"] = d["p"] < ALPHA
    d["fdr_pass"] = d["FDR_within_adiposity"] < ALPHA
    return d.sort_values(["exposure_design", "klass", "status", "endpoint"])


def adiposity_pair(d):
    rows = []
    for design, g in d.groupby("exposure_design"):
        lv = g[(g["klass"] == "level") & (g["status"] == "primary")]
        di = g[(g["klass"] == "distribution") & (g["status"] == "primary")]
        if lv.empty or di.empty:
            continue
        lv, di = lv.iloc[0], di.iloc[0]
        rows.append(dict(exposure_design=design, level_endpoint=lv["endpoint"],
                         level_beta=lv["beta"], level_p=lv["p"],
                         distribution_endpoint=di["endpoint"], distribution_beta=di["beta"],
                         distribution_p=di["p"],
                         perSD_difference_main=di["beta_perSD_of_trait_main"] - lv["beta_perSD_of_trait_main"],
                         perSD_difference_lower_bound_assumption=di["beta_perSD_lo_assumption"] - lv["beta_perSD_hi_assumption"],
                         perSD_difference_upper_bound_assumption=di["beta_perSD_hi_assumption"] - lv["beta_perSD_lo_assumption"],
                         distribution_endpoint_fdr_pass=bool(di["fdr_pass"])))
    return pd.DataFrame(rows)


def adiposity_replication(d):
    rows = []
    primary_dist = "WHRadjBMI_Pulit_dense_combined"
    for design, g in d.groupby("exposure_design"):
        gp = g[g["endpoint"] == primary_dist]
        if gp.empty:
            continue
        ref = float(gp.iloc[0]["beta"])
        alts = g[(g["klass"] == "distribution") & (g["endpoint"] != primary_dist)]
        n_same = int((np.sign(alts["beta"]) == np.sign(ref)).sum()) if len(alts) else 0
        rows.append(dict(exposure_design=design, reference_endpoint=primary_dist,
                         reference_beta=ref, n_alternative_distribution_releases=len(alts),
                         n_same_sign=n_same,
                         alternatives=";".join("%s=%.4f" % (r.endpoint, r.beta)
                                               for r in alts.itertuples()),
                         sign_replication_satisfied=bool(len(alts) > 0 and n_same == len(alts))))
    return pd.DataFrame(rows)


def grade_adiposity(pair, rep, d):
    out = []
    for _, r in pair.iterrows():
        dl = r["exposure_design"]
        reps = rep[rep["exposure_design"] == dl]
        b_ok = bool(reps["sign_replication_satisfied"].iloc[0]) if len(reps) else False
        a_ok = bool(r["perSD_difference_main"] > 0 and
                    r["perSD_difference_lower_bound_assumption"] > 0 and
                    r["perSD_difference_upper_bound_assumption"] > 0)
        c_ok = bool(r["distribution_endpoint_fdr_pass"] and dl == "D1")
        g = d[d["exposure_design"] == dl]
        dis = g[g["klass"] == "distribution"]["beta_perSD_of_trait_main"].values
        lev = g[g["klass"] == "level"]["beta_perSD_of_trait_main"].values
        d_ok = bool(len(dis) >= 2 and len(lev) >= 2 and np.sum(dis[:, None] > lev[None, :]) >= 2)
        if a_ok and b_ok and c_ok and d_ok:
            grade = "SUPPORTED"
        elif b_ok and d_ok:
            grade = "SUGGESTIVE"
        else:
            grade = "UNSUPPORTED"
        out.append(dict(exposure_design=dl, criterion_a_perSD_magnitude=a_ok,
                        criterion_b_sign_replication=b_ok,
                        criterion_c_endpoint_FDR_primary_design=c_ok,
                        criterion_d_not_single_endpoint=d_ok, hypothesis_grade=grade,
                        decision_note="grading rule unchanged and applied mechanically; "
                                      "unaaffected by the V3.1 scale correction because the "
                                      "multiplier cancels in a within-arm ratio"))
    return pd.DataFrame(out)


def main():
    log = io.open(os.path.join(LOGD, "v31_domains.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    master = load_master()
    sk = skeletal_endpoints(master)
    sks = skeletal_summary(sk)
    ad = adiposity(master)
    adp = adiposity_pair(ad)
    adr = adiposity_replication(ad)
    adg = grade_adiposity(adp, adr, ad)

    # ---- the signed vs unsigned comparison, explicitly ----
    cmp = sks[["exposure_design", "k", "direction_consistency",
               "stouffer_p_V3unsigned_rho000", "stouffer_p_signed_rho000",
               "stouffer_p_V3unsigned_rho050", "stouffer_p_signed_rho050",
               "stouffer_p_V3unsigned_rho090", "stouffer_p_signed_rho090"]].copy()
    cmp["unsigned_was_inflated_at_rho050"] = cmp["stouffer_p_signed_rho050"] > cmp["stouffer_p_V3unsigned_rho050"]

    with pd.ExcelWriter(os.path.join(RES, "V3_1_SKELETAL_EVIDENCE.xlsx"), engine="openpyxl") as w:
        sk.to_excel(w, sheet_name="PER_ENDPOINT", index=False)
        sks.to_excel(w, sheet_name="DOMAIN_SUMMARY", index=False)
        cmp.to_excel(w, sheet_name="SIGNED_VS_V3UNSIGNED", index=False)
        pd.DataFrame([
            dict(item="V3 stouffer_corr sign handling", status="DEFECT CORRECTED",
                 reason="V3 built every Z as Phi^-1(1-p/2) from a two-sided p, so all Z were "
                        "positive and the sum could only ever report agreement. V3.1 uses "
                        "signed_Z = sign(beta_aligned) * Phi^-1(1-p/2)."),
            dict(item="Endpoint set", status="UNCHANGED", reason="same seven skeletal endpoints, "
                                                                  "same rho grid {0, 0.25, 0.5, 0.75, 0.9}"),
            dict(item="A1 vs A2", status="REPORTED SEPARATELY", reason="never pooled; A2 is the "
                                                                       "alternative ANM instrument and is "
                                                                       "graded as such"),
            dict(item="Naive random-effects pool", status="WITHDRAWN", reason="correlated endpoints "
                                                                              "and non-commensurable units; retained "
                                                                              "in DOMAIN_SUMMARY as naive_*_withdrawn only"),
        ]).to_excel(w, sheet_name="WHAT_CHANGED", index=False)

    with pd.ExcelWriter(os.path.join(RES, "V3_1_ADIPOSITY_EVIDENCE.xlsx"), engine="openpyxl") as w:
        ad.to_excel(w, sheet_name="PER_ENDPOINT", index=False)
        adp.to_excel(w, sheet_name="PRIMARY_PAIR", index=False)
        adr.to_excel(w, sheet_name="DIRECTIONAL_REPLICATION", index=False)
        adg.to_excel(w, sheet_name="HYPOTHESIS_GRADING", index=False)

    L("=== skeletal DOMAIN_SUMMARY, signed Stouffer (V3.1) vs signed-ignored (V3) ===")
    L(sks[["exposure_design", "k", "direction_consistency", "n_fdr_pass",
           "stouffer_p_V3unsigned_rho050", "stouffer_p_signed_rho050",
           "stouffer_p_signed_rho090", "naive_meta_p_withdrawn"]].to_string(index=False))
    L("\n=== A1 detail (primary ANM instrument) ===")
    L(sk[sk["exposure_design"] == "A1"][["endpoint", "status", "polarity", "n_snp",
                                         "beta_aligned", "se", "p", "signed_Z",
                                         "FDR_within_skeletal", "fdr_pass"]].to_string(index=False))
    L("\n=== A2 detail (alternative ANM instrument) ===")
    L(sk[sk["exposure_design"] == "A2"][["endpoint", "status", "polarity", "n_snp",
                                         "beta_aligned", "se", "p", "signed_Z",
                                         "FDR_within_skeletal", "fdr_pass"]].to_string(index=False))
    L("\n=== adiposity grading ===")
    L(adg.to_string(index=False))
    log.close()

    print(sks[["exposure_design", "k", "direction_consistency", "n_fdr_pass",
               "stouffer_p_V3unsigned_rho000", "stouffer_p_signed_rho000",
               "stouffer_p_V3unsigned_rho050", "stouffer_p_signed_rho050",
               "stouffer_p_V3unsigned_rho090", "stouffer_p_signed_rho090"]]
          .round(6).to_string(index=False))
    print()
    print(adg[["exposure_design", "hypothesis_grade"]].to_string(index=False))


if __name__ == "__main__":
    main()
