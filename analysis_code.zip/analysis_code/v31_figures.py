# -*- coding: utf-8 -*-
"""Figures - every panel built from the result files.

The module docstring below records what each panel shows and why the panels are drawn this way.
Version labels that used to appear on the panels themselves have been replaced by
self-describing ones: a reader of the paper has not seen an earlier scale, so "V3" on an axis
legend is meaningless to them.

What changed relative to V3's figures:

* Figure 2 now plots both directions of the conversion, m(K) for a SNP-exposure
  coefficient and 1/m(K) for an MR ratio, because V3's single curve invited exactly the
  mistake V3 made.
* Figure 3 plots the corrected difference tests and the corrected rho grid, and marks
  that none of the nine survives BH-FDR.
* Figure 4's correlation-robust panel uses the SIGNED Stouffer values and shows A1 and A2
  separately, with the V3 unsigned values alongside so the defect is visible.
* Figure 5's power panel uses the corrected reciprocal SE, so every MDE is 1.95x larger,
  and the MVMR panel shows the covariance bound band.
* Figure 6 separates the primary-prior PP4 from the grid minimum.

No number is typed by hand; every panel reads a V3.1 result file.
"""
import os, sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, FIG, PANEL9_LABEL, PREV_PRIMARY, liability_multiplier
from v31_core import RHO_GRID, ALPHA
from v31_docs import DNAME_SHORT

plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "figure.dpi": 200, "savefig.dpi": 200, "font.family": "DejaVu Sans"})
INK = "#1a1a1a"; RED = "#c0392b"; BLUE = "#1f6fb4"; GREY = "#8a8a8a"


def rd(n):
    return pd.read_csv(os.path.join(RES, n), sep="\t")


def save(fig, name, src=None):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(FIG, "%s.%s" % (name, ext)), bbox_inches="tight")
    plt.close(fig)
    if src is not None:
        src.to_csv(os.path.join(FIG, "source_data", "%s.csv" % name), index=False)


def fig2():
    lo, hi = 0.02, 0.25
    Ks = np.linspace(lo, hi, 300)
    m = np.array([liability_multiplier(k) for k in Ks])
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.7))
    ax = axes[0]
    ax.plot(Ks, m, color=BLUE, lw=2, label=r"$m(K)$ - multiply a SNP-exposure coefficient")
    ax.plot(Ks, 1 / m, color=RED, lw=2,
            label=r"$1/m(K)$ - divide an MR ratio (outcome per log-OR)")
    ax.axhline(1.0, color=GREY, ls=":", lw=1)
    # placed in the empty band between the two curves and given the darker ink so that the
    # lettering clears the 4.5:1 contrast the journal asks for
    ax.annotate("multiplier of 1:\nneither conversion uses it",
                xy=(0.215, 1.0), xytext=(0.075, 1.42), fontsize=6.6, color=INK,
                ha="left", va="top",
                arrowprops=dict(arrowstyle="->", color=INK, lw=.8))
    for k in (0.05, 0.10, 0.20):
        ax.plot([k], [liability_multiplier(k)], "o", color=BLUE, ms=4)
        ax.plot([k], [1 / liability_multiplier(k)], "o", color=RED, ms=4)
    ax.set_xlabel("PCOS population prevalence K")
    ax.set_ylabel("multiplier")
    ax.set_title("A. Both conversion directions", fontsize=9.5, loc="left")
    ax.legend(fontsize=6.4, frameon=False, loc="upper right")

    ax = axes[1]
    s = rd("V3_1_PREVALENCE_SENSITIVITY.tsv")
    for out, col in [("T2D", BLUE), ("HbA1c_MAGIC", "#7a4fa3"), ("BMD", "#e07b39"),
                     ("Fracture", RED), ("BMI_FINNGEN", GREY)]:
        g = s[s["outcome"] == out].sort_values("K")
        ax.plot(g["K"], -np.log10(g["p_rho0"]), "o-", ms=3, lw=1.2, color=col,
                label=PANEL9_LABEL.get(out, out))
    ax.axhline(-np.log10(ALPHA), color=INK, ls="--", lw=1)
    ax.text(0.052, -np.log10(ALPHA) - .16, "alpha = 0.05", fontsize=7, color=INK)
    ax.set_xlabel("PCOS prevalence K")
    ax.set_ylabel(r"-$\log_{10}$ P(difference)")
    ax.set_title("B. Prevalence sensitivity", fontsize=9.5, loc="left")
    ax.legend(fontsize=6.4, frameon=False, ncol=2)
    ax.set_ylim(0, 2.4)
    fig.tight_layout()
    save(fig, "Figure2_liability_scale", s)


def fig3():
    d = rd("V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv").sort_values("difference")
    v3 = rd("V3_1_DIFFERENCE_PRIMARY9_V3METHOD_COMPARATOR.tsv").set_index("outcome")
    rho = rd("V3_1_RHO_SENSITIVITY_GRID.tsv")
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.5), gridspec_kw=dict(width_ratios=[1.15, 1]))
    ax = axes[0]
    y = np.arange(len(d))
    ax.errorbar(d["difference"], y, xerr=1.96 * d["se_rho0"], fmt="o", ms=4, lw=1,
                color=INK, ecolor=GREY, capsize=2, label="reciprocal scale (this paper)")
    v3d = [v3.loc[o, "difference"] for o in d["outcome"]]
    ax.plot(v3d, y, "x", ms=5, color=RED, label="multiplicative scale")
    ax.axvline(0, color=GREY, lw=.8, ls=":")
    ax.set_yticks(y)
    ax.set_yticklabels([PANEL9_LABEL.get(o, o) for o in d["outcome"]], fontsize=7.6)
    ax.set_xlabel("difference, per 1 SD")
    ax.set_title("A. Primary family: 0 of 9 pass BH-FDR", fontsize=9.5, loc="left")
    ax.legend(fontsize=7, frameon=False, loc="lower right")

    ax = axes[1]
    for out, col in [("Fracture", RED), ("BMD", "#e07b39"), ("HbA1c_MAGIC", "#7a4fa3"),
                     ("T2D", BLUE), ("BMI_FINNGEN", GREY)]:
        g = rho[rho["outcome"] == out]
        ax.plot(g["rho"], -np.log10(g["p_difference"]), "o-", ms=3, lw=1.2, color=col,
                label=PANEL9_LABEL.get(out, out))
    ax.axhline(-np.log10(ALPHA), color=INK, ls="--", lw=1)
    ax.text(-0.98, -np.log10(ALPHA) + .07, "alpha = 0.05", fontsize=7.5)
    ax.axvspan(0, 1, color="#f0f5fa", zorder=0)
    ax.text(0.5, 1.15, "plausible range (rho >= 0)", fontsize=7, ha="center", va="top",
            color=GREY)
    ax.set_xlabel("assumed between-exposure correlation rho")
    ax.set_ylabel(r"-$\log_{10}$ P(difference)")
    ax.set_title("B. Covariance sensitivity", fontsize=9.5, loc="left")
    ax.legend(fontsize=6.6, frameon=False, ncol=2)
    ax.set_ylim(0, 1.5)
    fig.tight_layout()
    save(fig, "Figure3_difference_tests", d)


def fig4():
    sk = pd.read_excel(os.path.join(RES, "V3_1_SKELETAL_EVIDENCE.xlsx"),
                       sheet_name="PER_ENDPOINT")
    su = pd.read_excel(os.path.join(RES, "V3_1_SKELETAL_EVIDENCE.xlsx"),
                       sheet_name="DOMAIN_SUMMARY")
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw=dict(width_ratios=[1, 1.1]))
    ax = axes[0]
    order = ["BMD", "Fracture", "Fracture_forearm_FINNGEN", "Osteoporosis_FINNGEN",
             "Fracture_femur_FINNGEN", "Fracture_lumbarspine_FINNGEN",
             "Fracture_lowerleg_FINNGEN"]
    for i, e in enumerate(order):
        r = sk[(sk["exposure_design"] == "A1") & (sk["endpoint"] == e)]
        if r.empty:
            continue
        r = r.iloc[0]
        ax.errorbar(r["beta_aligned"], i, xerr=1.96 * r["se"], fmt="o", ms=4, lw=1,
                    color=RED if r["fdr_pass"] else GREY, ecolor="#cccccc", capsize=2)
        ax.plot([r["beta_aligned"]], [i], marker="|", ms=9, color=BLUE, mew=1.2)
    ax.axvline(0, color=INK, ls=":", lw=.8)
    ax.set_yticks(range(len(order))); ax.set_yticklabels(order, fontsize=7)
    ax.set_xlabel("aligned effect (positive = better bone)")
    ax.set_title("A. ANM skeletal endpoints, primary ANM instrument", fontsize=9.5,
                 loc="left")

    ax = axes[1]
    su = su.set_index("exposure_design").loc[["A1", "A2", "D1", "D2", "D3", "D4", "D5"]]
    x = np.arange(len(su))
    w = 0.26
    ax.bar(x - w, -np.log10(su["stouffer_p_signed_rho000"]), w, color="#9ec9e8",
           label="signed, rho = 0")
    ax.bar(x, -np.log10(su["stouffer_p_signed_rho050"]), w, color=BLUE,
           label="signed, rho = 0.5")
    ax.bar(x + w, -np.log10(su["stouffer_p_V3unsigned_rho050"]), w, color="#dddddd",
           label="unsigned, rho = 0.5")
    ax.axhline(-np.log10(ALPHA), color=RED, ls="--", lw=1)
    ax.text(-0.45, -np.log10(ALPHA) + .1, "alpha = 0.05", color=RED, fontsize=7)
    ax.set_xticks(x)
    ax.set_xticklabels([DNAME_SHORT.get(k, k).replace(" (1 Mb)", "") for k in su.index],
                       fontsize=7.2, rotation=30, ha="right")
    ax.set_ylabel(r"-$\log_{10}$ P")
    ax.set_title("B. Skeletal combination, signed vs unsigned", fontsize=9.5, loc="left")
    ax.legend(fontsize=6.2, frameon=False, loc="upper left")
    ax.set_ylim(0, max(3.0, ax.get_ylim()[1]))
    fig.tight_layout()
    save(fig, "Figure4_domains", pd.concat(
        [sk.assign(panel="skeletal"),
         su.reset_index().assign(panel="summary")], ignore_index=True))


def fig5():
    d = rd("V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv")
    mde = rd("V3_1_POWER_MDE_CORRECTED.tsv")
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0))
    ax = axes[0]
    for tau, col, lab in [(0.0, BLUE, "gencov = 0"),
                          (-0.5, RED, "tau = -0.5"),
                          (-1.0, "#7a1f16", "tau = -1.0 (bound)"),
                          (0.33, "#9ec9e8", "tau = +0.33")]:
        s = d[np.isclose(d["tau"], tau)]
        ax.scatter(s["condF_PCOS"], s["condF_ANM"], s=16, color=col, label=lab,
                   edgecolor=INK if tau == 0 else "none",
                   linewidth=.6 if tau == 0 else 0)
    ax.axvline(10, color=RED, ls="--", lw=1); ax.axhline(10, color=RED, ls="--", lw=1)
    ax.text(10.4, 1.0, "gate = 10", color=RED, fontsize=7)
    ax.set_xlabel("conditional F, PCOS"); ax.set_ylabel("conditional F, ANM")
    ax.set_title("A. Conditional F vs the covariance bound", fontsize=9.5, loc="left")
    ax.legend(fontsize=6.0, frameon=False, loc="lower right", labelspacing=.25)
    ax.set_xlim(0, 40); ax.set_ylim(0, 40)

    ax = axes[1]
    m = mde.sort_values("MDE80_alpha005_corrected")
    y = np.arange(len(m))
    ax.barh(y, m["MDE80_alpha005_corrected"], color=RED, height=.5,
            label="MDE at 80% power")
    ax.barh(y, m["MDE80_alpha005_v3"], color="#dddddd", height=.5,
            label="MDE at the multiplicative scale")
    ax.scatter(np.abs(m["anm_effect_perSD"]), y, color=INK, s=16, zorder=3,
               label="|ANM effect| for the same outcome")
    ax.set_yticks(y); ax.set_yticklabels(m["outcome_label"], fontsize=7)
    ax.set_xlabel("outcome units per 1 SD of exposure")
    ax.set_title("B. Detection limit", fontsize=9.5,
                 loc="left")
    ax.legend(fontsize=6.2, frameon=False, loc="lower right")
    fig.tight_layout()
    save(fig, "Figure5_mvmr_power", pd.concat(
        [d.assign(panel="mvmr"), mde.assign(panel="mde")], ignore_index=True))


def fig6():
    d = pd.read_excel(os.path.join(RES, "V3_1_FSHB_EVIDENCE_AUDIT.xlsx"),
                      sheet_name="PP4_FACTS")
    facts = dict(zip(d["quantity"], d["value"]))
    col = pd.read_excel(os.path.join(RES, "V3_1_FSHB_EVIDENCE_AUDIT.xlsx"),
                        sheet_name="ALL_COLOCALISED_PCOS_ANM")
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    ax = axes[0]
    x = np.arange(len(col))
    ax.bar(x, col["PP.H4"].astype(float), .5, color=RED, label="primary-prior PP.H4")
    ax.bar(x, col["PP.H4_pruned"].astype(float), .22, color=BLUE, label="after LD pruning")
    for i, r in enumerate(col.itertuples()):
        ax.text(i, float(col["PP.H4"].iloc[i]) + .02, col["evidence_tier"].iloc[i], ha="center", fontsize=6.2, color=GREY)
    ax.set_xticks(x)
    ax.set_xticklabels([str(g) for g in col["nearest_gene"]], fontsize=7.5)
    ax.axhline(0.75, color=INK, ls="--", lw=1)
    ax.text(-0.45, 0.78, "PP.H4 = 0.75", fontsize=7)
    ax.set_ylim(0, 1.18); ax.set_ylabel("PP.H4")
    ax.set_title("A. COLOCALISED PCOS-ANM loci", fontsize=9.5, loc="left")
    ax.legend(fontsize=6.5, frameon=False, loc="lower right")

    ax = axes[1]
    labs = ["FSHB\nprimary prior\n(p12 = 1e-5)", "FSHB\ngrid minimum",
            "FSHB\nafter LD pruning", "FSHB\nPP.H4 = 0.75\nthreshold"]
    vals = [float(facts["pp4_primary_prior"]), float(facts["pp4_min_over_prior_grid"]),
            float(facts["pp4_after_LD_pruning"]), 0.75]
    cols = [RED, "#e07b39", BLUE, GREY]
    ax.bar(range(4), vals, color=cols, width=.6)
    for i, v in enumerate(vals):
        ax.text(i, v + .015, "%.4f" % v, ha="center", fontsize=7.5)
    ax.set_xticks(range(4)); ax.set_xticklabels(labs, fontsize=6.4)
    ax.set_ylim(0, 1.12); ax.set_ylabel("PP.H4")
    ax.set_title("B. PP4 quantities kept apart", fontsize=9.5, loc="left")
    fig.tight_layout()
    save(fig, "Figure6_fshb", col)


def fig1():
    # Read the design table from the result workbook instead of typing it. The codes stay the
    # key; the labels shown are the reader-facing names used by the manuscript.
    dm = pd.read_excel(os.path.join(RES, "V3_1_MASTER_RESULTS.xlsx"), sheet_name="DESIGN_MAP")
    dm = dm[dm["role"].str.contains("primary", case=False)
            | dm["alias"].str.contains("1Mb|10Mb", case=False)]
    keep = ["D1", "D2", "D3", "D4", "D5"]
    dm = dm.set_index("design").loc[[k for k in keep if k in set(dm["design"])]].reset_index()
    d = pd.DataFrame(dict(
        design=[DNAME_SHORT.get(k, k) for k in dm["design"]],
        role=dm["role"],
        loci=dm["n_loci_declared"].astype(int),
        window=[("%g Mb" % (w / 1000.0)) if isinstance(w, (int, float)) else str(w)
                for w in dm["window_kb"]]))
    fig, ax = plt.subplots(figsize=(6.6, 2.5))
    y = np.arange(len(d))[::-1]
    ax.barh(y, d["loci"], color=[RED if r == "primary" else GREY for r in d["role"]], height=.55)
    for yy, r in zip(y, d.itertuples()):
        ax.text(r.loci + .4, yy, "%d loci . %s . %s" % (r.loci, r.window, r.role),
                va="center", fontsize=8)
    ax.axvline(213, color=BLUE, ls="--", lw=1)
    ax.text(213, len(d) - .3, "ANM instrument: 213 loci", color=BLUE, fontsize=8, ha="right")
    ax.set_yticks(y); ax.set_yticklabels(d["design"])
    ax.set_xlabel("independent instrument loci"); ax.set_xlim(0, 250)
    ax.set_title("PCOS and ANM instrument designs (P < 5e-8 in every design)", fontsize=10,
                 loc="left")
    save(fig, "Figure1_design", d)


def main():
    fig1(); fig2(); fig3(); fig4(); fig5(); fig6()
    print("figures written to", FIG)
    for f in sorted(os.listdir(FIG)):
        print("  ", f)


if __name__ == "__main__":
    main()
