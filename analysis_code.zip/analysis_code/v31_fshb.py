# -*- coding: utf-8 -*-
"""V3.1 - FSHB evidence tier, PP4 reconciliation, and the enforced wording ladder.

THE PP4 PROBLEM
---------------
One number, the posterior probability of a shared causal variant between PCOS and ANM at
FSHB under the primary prior (p12 = 1e-5), is quoted in five places. It is 0.998960 in the
result table. It was quoted as "0.999" in the abstract, the README and the executive
summary, "0.9990" in the manuscript's Table 7, and computed as "%.3f" in the claim matrix.
Those agree to three decimals but the documents do not distinguish the primary-prior value
from the minimum over the prior grid (0.989699), so the two quantities were being carried
by one number in some places and by two in others. V3.1 states both explicitly and
separately everywhere.

THE "ONLY SHARED SIGNAL" PROBLEM
--------------------------------
Three PCOS-ANM loci carry a COLOCALISED verdict at the primary prior: FSHB (0.998960),
DENND1A (0.987840) and IRF1 (0.924456). FSHB is the only one that simultaneously survives
the prior grid, survives LD pruning, and has both traits genome-wide significant in the
window. "The only shared signal" is therefore a statement about the evidence *tier*, not
about the raw posteriors, and V3.1 says which.

THE WORDING LADDER
------------------
Allowed:
  1. shared FSHB-region signal between PCOS and ANM
  2. likely shared causal signal under the SINGLE-SIGNAL colocalization model
Not allowed (no valid evidence establishes any of these):
  fine-mapped shared signal / the same causal variant as a resolved fact /
  FSH-mediated shared causal variant / mechanistic mediator / FSHB mechanism established.
And: PCOS-ANM single-signal colocalization at FSHB is NOT the same analysis as PCOS-FSH or
ANM-FSH locus-specific colocalization.
"""
import io, os, sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, LOGD, V3, V3_RES, DATA_ROOT, COLOCC, V3_FSHB, ALPHA

BANNED = ["fine-mapped shared signal", "same causal variant as a resolved fact",
          "FSH-mediated shared causal variant", "mechanistic mediator",
          "FSHB mechanism established", "fine-mapped", "resolved causal variant",
          "FSH-mediated"]
ALLOWED = ["shared FSHB-region signal",
           "likely shared causal signal under the single-signal colocalization model",
           "stress-tested single-signal colocalization"]
LADDER = [
    dict(tier=1, claim="Shared FSHB-region signal between PCOS and ANM",
         status="ALLOWED", evidence="coloc.abf PP.H4 = 0.998960 at the primary prior "
                                     "(p12 = 1e-5); COLOCALISED; stable under LD pruning "
                                     "(PP.H4 = 1.0000); both traits genome-wide significant "
                                     "in the window; 5 of 5 grid points with PP.H4 >= 0.75",
         source="09_COLOCALIZATION/COLOC_RESULTS.tsv, COLOC_EVIDENCE_TIERS.tsv, "
                "COLOC_PRUED_SENSITIVITY.tsv"),
    dict(tier=2, claim="Likely shared causal signal under the SINGLE-SIGNAL colocalization "
                       "model",
         status="ALLOWED, with the model named",
         evidence="tier 1 plus: the region is a single-signal colocalization only; a second "
                  "independent peak exists in at least one trait "
                  "(multisignal_either_trait = True at FSHB), so a single-causal-variant "
                  "model is not established as the true model",
         source="COLOC_EVIDENCE_TIERS.tsv (multisignal_either_trait), MULTISIGNAL_SCREEN.tsv"),
    dict(tier=3, claim="Fine-mapped shared signal / a resolved single causal variant",
         status="NOT ALLOWED",
         evidence="susie_rss was attempted on an identifiable 94-variant marker set and "
                  "WITHDRAWN: Lambda 0.986-1.000 for every trait and marker set, every "
                  "credible set a singleton with purity 1, best-matching reference LD profile "
                  "explaining at most 28% of the association profile, and the top-PIP variant "
                  "changing with the marker set",
         source="V3_FSHB_SUSIE_DIAGNOSTICS.tsv, FSHB_MULTISIGNAL_RESULTS.xlsx"),
    dict(tier=4, claim="FSH-mediated shared causal variant / mechanistic mediator / FSHB "
                       "mechanism established", status="NOT ALLOWED",
         evidence="Layer 3 failed, so the signal was never localised to a variant and the "
                  "mediator hypothesis was never tested. In addition, PCOS-ANM single-signal "
                  "colocalization at FSHB is NOT the same analysis as PCOS-FSH or ANM-FSH "
                  "locus-specific colocalization; no FSH-region colocalization was performed.",
         source="project-wide: no PCOS-FSH or ANM-FSH regional colocalization exists in this "
                "package"),
]


def load():
    r = pd.read_csv(os.path.join(COLOCC, "COLOC_RESULTS.tsv"), sep="\t")
    pri = pd.read_csv(os.path.join(COLOCC, "COLOC_PRIOR_SENSITIVITY.tsv"), sep="\t")
    pru = pd.read_csv(os.path.join(COLOCC, "COLOC_PRUNED_SENSITIVITY.tsv"), sep="\t")
    tie = pd.read_csv(os.path.join(COLOCC, "COLOC_EVIDENCE_TIERS.tsv"), sep="\t")
    return r, pri, pru, tie


def pp4_facts():
    r, pri, pru, tie = load()
    f = r[(r["trait1"] == "PCOS") & (r["trait2"] == "ANM")
          & (r["locus"].astype(str).str.startswith("L02"))]
    if f.empty:
        raise SystemExit("FSHB row not found")
    f = f.iloc[0]
    g = pri[(pri["locus"] == f["locus"]) & (pri["trait1"] == "PCOS") & (pri["trait2"] == "ANM")]
    p = pru[(pru["locus"] == f["locus"]) & (pru["trait1"] == "PCOS") & (pru["trait2"] == "ANM")]
    t = tie[(tie["locus"] == f["locus"]) & (tie["trait1"] == "PCOS") & (tie["trait2"] == "ANM")]
    return dict(
        locus=f["locus"], gene="FSHB", nsnp_coloc=int(f["nsnp_coloc"]),
        pp4_primary_prior=float(f["PP.H4"]),
        pp3_primary_prior=float(f["PP.H3"]),
        pp4_min_over_prior_grid=float(g["PP.H4"].min()),
        pp4_max_over_prior_grid=float(g["PP.H4"].max()),
        n_prior_grid_points=int(len(g)),
        n_prior_grid_points_pp4_ge_075=int((g["PP.H4"] >= 0.75).sum()),
        pp4_after_LD_pruning=float(p["PP.H4"].iloc[0]),
        verdict=f["verdict"], verdict_after_pruning=p["verdict_pruned"].iloc[0],
        both_traits_genome_wide_significant=bool(not f["underpowered_flag"]),
        multisignal_either_trait=bool(t["multisignal_either_trait"].iloc[0]),
        evidence_tier=t["evidence_tier"].iloc[0],
        top_snp=f["top_snp"], top_snp_pp4=float(f["top_snp_PP_H4"]))


def all_pcos_anm_colocalised():
    r, _, _, tie = load()
    sub = tie[(tie["trait1"] == "PCOS") & (tie["trait2"] == "ANM")
              & (tie["verdict"] == "COLOCALISED")].copy()
    sub = sub.sort_values("PP.H4", ascending=False)
    return sub[["locus", "nearest_gene", "PP.H4", "verdict", "verdict_pruned",
                "PP.H4_pruned", "underpowered_flag", "multisignal_either_trait",
                "evidence_tier"]]


def location_table(facts):
    """Every document that carries the FSHB PP4, with the value V3.1 requires it to carry."""
    return pd.DataFrame([
        dict(location="Abstract", v3_value_quoted="0.999",
             quantity="primary-prior PP4, rounded to 3 dp",
             v31_required="PP.H4 = 0.9990 at the primary prior (p12 = 1e-5); 0.9897 at the "
                          "least favourable point of the prior grid",
             status="CORRECTED - both quantities now named"),
        dict(location="Main Results section 3.8",
             v3_value_quoted="PP.H4 = 0.9990; range over the prior grid 0.9897-0.9999",
             quantity="primary-prior PP4 and grid minimum/maximum",
             v31_required="0.998960 (primary prior); grid minimum 0.989699; grid maximum "
                          "0.999896",
             status="CORRECTED to the exact values in the result table"),
        dict(location="Table 7 (FSHB colocalization stress tests)",
             v3_value_quoted="0.9990 / 0.9897-0.9999 / 1.0000",
             quantity="as above plus the LD-pruned PP4",
             v31_required=("0.998960 / 0.989699-0.999896 / %.6f (full precision %.9f)"
                          % (facts["pp4_after_LD_pruning"], facts["pp4_after_LD_pruning"])),
             status="CORRECTED; the LD-pruned value is 0.999999989 (printed 1.0000 before)"),
        dict(location="Supplement",
             v3_value_quoted="0.999", quantity="primary-prior PP4",
             v31_required="0.998960 primary prior; 0.989699 grid minimum",
             status="CORRECTED"),
        dict(location="Claim-Evidence Matrix",
             v3_value_quoted="%.3f -> 0.999", quantity="primary-prior PP4 read from "
                                                       "COLOC_RESULTS.tsv",
             v31_required="0.998960 primary prior; 0.989699 grid minimum; both stated",
             status="CORRECTED - the cell now carries both quantities"),
        dict(location="README / executive summary",
             v3_value_quoted="0.999", quantity="primary-prior PP4",
             v31_required="0.9990 primary prior, with the grid minimum 0.9897 named",
             status="CORRECTED"),
    ])


def main():
    log = io.open(os.path.join(LOGD, "v31_fshb.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    facts = pp4_facts()
    coloc = all_pcos_anm_colocalised()
    loc = location_table(facts)
    diag = pd.read_csv(os.path.join(V3_RES, "V3_FSHB_SUSIE_DIAGNOSTICS.tsv"), sep="\t") \
        if os.path.exists(os.path.join(V3_RES, "V3_FSHB_SUSIE_DIAGNOSTICS.tsv")) else pd.DataFrame()

    with pd.ExcelWriter(os.path.join(RES, "V3_1_FSHB_EVIDENCE_AUDIT.xlsx"),
                        engine="openpyxl") as w:
        pd.DataFrame([facts]).T.reset_index().rename(
            columns={"index": "quantity", 0: "value"}).to_excel(
            w, sheet_name="PP4_FACTS", index=False)
        loc.to_excel(w, sheet_name="PP4_BY_DOCUMENT", index=False)
        coloc.to_excel(w, sheet_name="ALL_COLOCALISED_PCOS_ANM", index=False)
        pd.DataFrame(LADDER).to_excel(w, sheet_name="WORDING_LADDER", index=False)
        pd.DataFrame([dict(banned_phrase=b, status="BANNED unless new valid evidence exists")
                      for b in BANNED]).to_excel(w, sheet_name="BANNED_PHRASES", index=False)
        if len(diag):
            diag.to_excel(w, sheet_name="SUSIE_DIAGNOSTICS", index=False)
        pd.DataFrame([
            dict(question="Is PCOS-ANM colocalization at FSHB the same analysis as "
                          "PCOS-FSH colocalization?", answer="NO",
                 detail="they are different trait pairs. Only PCOS vs ANM was run at this "
                        "region; no locus-specific PCOS-FSH or ANM-FSH regional colocalization "
                        "exists anywhere in this package."),
            dict(question="Is FSHB the only colocalised PCOS-ANM locus?",
                 answer="NO at the primary prior; YES in the top evidence tier",
                 detail="DENND1A (PP.H4 = 0.987840) and IRF1 (PP.H4 = 0.924456) also carry a "
                        "COLOCALISED verdict at the primary prior. FSHB is the only locus whose "
                        "verdict additionally survives the prior grid, survives LD pruning "
                        "(DENND1A flips to INCONCLUSIVE) and has both traits genome-wide "
                        "significant in the window (IRF1 is flagged underpowered). The claim is "
                        "therefore a tier claim and is worded as one."),
            dict(question="Does V3.1 re-run SuSiE to obtain a positive result?",
                 answer="NO", detail="the failed diagnostics are retained. No ancestry-matched "
                                     "LD reference is available without expanding the scope of "
                                     "V3.1, so the fine-mapping route stays closed."),
        ]).to_excel(w, sheet_name="AUDIT_ANSWERS", index=False)

    L("=== FSHB PP4 facts (read from the result files) ===")
    for k, v in facts.items():
        L("  %-38s %s" % (k, v))
    L("\n=== every COLOCALISED PCOS-ANM locus at the primary prior ===")
    L(coloc.to_string(index=False))
    L("\n=== PP4 by document ===")
    L(loc[["location", "v3_value_quoted", "status"]].to_string(index=False))
    log.close()

    print("FSHB PP.H4 primary prior : %.6f" % facts["pp4_primary_prior"])
    print("grid minimum             : %.6f" % facts["pp4_min_over_prior_grid"])
    print("after LD pruning         : %.6f" % facts["pp4_after_LD_pruning"])
    print("evidence tier            : %s" % facts["evidence_tier"])
    print()
    print(coloc.to_string(index=False))
    return facts, coloc, loc


if __name__ == "__main__":
    main()
