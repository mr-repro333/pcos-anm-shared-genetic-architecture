# -*- coding: utf-8 -*-
"""V3.1 - does the harmonisation-rule divergence change any hormonal result?

The two rules (see v31_harmonization.py) disagree about 162 of 247 V2 matrix pairs, and in
the V3 hormone path they would drop a different variant set. This module closes that
inconsistency the only honest way available: it re-derives both hormone arms from the
deposited matrices under each rule and reports whether the hormonal conclusions move.

Validation first. The V3-shipped A1 arm is reproduced exactly (LH -0.078031 / 0.012457,
estradiol +0.021667 / 0.005897, testosterone +0.014670 / 0.005297) and the progesterone arm
is reproduced once rule B's single band drop is applied, which is what identifies rule B as
the rule actually in force. Only then are the alternative rule sets evaluated.

Variant sets compared, per arm:
  * AS_SHIPPED   - rule B for the V3-reharmonised hormones, rule A for the V2 matrices
  * RULE_A_ALL   - rule A (|dEAF| > 0.05 among palindromes) applied on every arm
  * NO_PAL_DROP  - palindromes retained and aligned by EAF (a worst-case bound)
"""
import io, os, sys

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import (RES, LOGD, V2, V3, DATA_ROOT, INS_V2, INS_ROOT, PREV_PRIMARY,
                      SD_ANM_PRIMARY, RHO_GRID, ALPHA, HORMONAL_LABEL, liability_multiplier)

from v31_diff import bh, zp

COMP = {"A": "T", "T": "A", "C": "G", "G": "C"}
PAL = {"AT", "TA", "CG", "GC"}
EAF_TOL = 0.05
BAND = (0.42, 0.58)

HORMONE_FILES = {
    "FSH_FEMALE": (os.path.join(V2, "06_RAW_OUTCOMES", "FSH_FEMALE.tsv"), "V2_deposited"),
    "LH_FEMALE": (os.path.join(V3, "02_HARMONIZED", "LH_FEMALE.tsv"), "V3_reharmonised"),
    "E2_FEMALE": (os.path.join(V3, "02_HARMONIZED", "E2_FEMALE.tsv"), "V3_reharmonised"),
    "PROG_FEMALE": (os.path.join(V3, "02_HARMONIZED", "PROG_FEMALE.tsv"), "V3_reharmonised"),
    "TESTO_FEMALE_ALT": (os.path.join(V3, "02_HARMONIZED", "TESTO_FEMALE_ALT.tsv"),
                         "V3_reharmonised"),
}
INS_FILES = {
    "D1": os.path.join(INS_V2, "PCOS_EUR_1Mb_instruments.tsv"),
    "D3": os.path.join(INS_V2, "PCOS_ALT_Venkatesh_1Mb_instruments.tsv"),
    "D4": os.path.join(INS_V2, "PCOS_UNION_D4_1Mb_instruments.tsv"),
    "A1": os.path.join(INS_ROOT, "ANM_RUTH2021_instruments.tsv"),
}


def align(R, O, ea, oa, beta, eaf):
    ea, oa = str(ea).upper(), str(oa).upper()
    R, O = str(R).upper(), str(O).upper()
    if ea == R and oa == O:
        return beta, eaf
    if ea == O and oa == R:
        return -beta, 1 - eaf
    ce, co = COMP.get(ea, ""), COMP.get(oa, "")
    if ce == R and co == O:
        return beta, eaf
    if ce == O and co == R:
        return -beta, 1 - eaf
    return np.nan, np.nan


def ivw(bx, bxse, by, byse):
    bx, bxse, by, byse = map(lambda a: np.asarray(a, float), (bx, bxse, by, byse))
    r = by / bx
    w = 1.0 / (byse ** 2 / bx ** 2)
    b = float(np.sum(w * r) / np.sum(w))
    q = float(np.sum(w * (r - b) ** 2)); df = len(r) - 1
    se = float(np.sqrt(1.0 / np.sum(w)) * np.sqrt(q / df)) if df > 0 else float(np.sqrt(1.0 / np.sum(w)))
    return b, se, float(2 * stats.norm.sf(abs(b / se))), len(r)


def prepared(endpoint, design):
    f, kind = HORMONE_FILES[endpoint]
    if not os.path.exists(f):
        return None, kind
    o = pd.read_csv(f, sep="\t")
    if not {"rsid", "ea", "oa", "eaf", "beta", "se"}.issubset(o.columns):
        return None, kind
    ins = pd.read_csv(INS_FILES[design], sep="\t")
    ins = ins.rename(columns={c: c + "_exp" for c in
                              ["ea", "oa", "eaf", "beta", "se", "p", "n", "key", "chr", "pos"]})
    m = ins.merge(o, on="rsid")
    if m.empty:
        return None, kind
    rec = []
    for r in m.itertuples():
        b, _ = align(r.ea_exp, r.oa_exp, r.ea, r.oa, r.beta, r.eaf)
        pal = (str(r.ea_exp).upper() + str(r.oa_exp).upper()) in PAL
        de = abs(float(r.eaf) - float(r.eaf_exp)) if pd.notna(r.eaf) and pd.notna(r.eaf_exp) else np.nan
        rec.append(dict(rsid=r.rsid, beta_out=b, se_out=r.se, beta_exp=r.beta_exp,
                        se_exp=r.se_exp, eaf_out=r.eaf, eaf_exp=r.eaf_exp,
                        palindromic=pal, d_eaf=de,
                        drop_ruleB=bool(pal and pd.notna(r.eaf) and BAND[0] <= float(r.eaf) <= BAND[1]),
                        drop_ruleA=bool(pal and (pd.isna(de) or de > EAF_TOL))))
    d = pd.DataFrame(rec).dropna(subset=["beta_out"])
    return d, kind


def arm_estimate(d, rule):
    if rule == "AS_SHIPPED":
        x = d[~d["drop_ruleB"]]
    elif rule == "RULE_A_ALL":
        x = d[~d["drop_ruleA"]]
    elif rule == "NO_PAL_DROP":
        x = d
    else:
        raise ValueError(rule)
    if len(x) < 3:
        return None
    b, se, p, n = ivw(x.beta_exp.values, x.se_exp.values, x.beta_out.values, x.se_out.values)
    return dict(ivw=b, se=se, p=p, n=n, n_dropped=len(d) - len(x))


def main():
    log = io.open(os.path.join(LOGD, "v31_harmone_rule.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    m = liability_multiplier(PREV_PRIMARY)
    v3f4 = pd.read_csv(os.path.join(V3, "03_RESULTS", "V3_HORMONAL_RESULTS_F4.tsv"), sep="\t")

    # ---- 1. validation: AS_SHIPPED must reproduce the shipped V3 arms ----
    val = []
    for ep in HORMONE_FILES:
        for dz in ["D1", "A1"]:
            d, kind = prepared(ep, dz)
            if d is None:
                continue
            e = arm_estimate(d, "AS_SHIPPED")
            r = v3f4[(v3f4["endpoint_key"] == ep) & (v3f4["exposure_design"] == dz)]
            if e is None or r.empty:
                continue
            r = r.iloc[0]
            val.append(dict(endpoint=HORMONAL_LABEL.get(ep, ep), design=dz, source_kind=kind,
                            v3_n=e["n"], v31_n=e["n"], shipped_n=int(r["n_instruments"]),
                            v3_ivw=float(r["ivw"]), v31_ivw=e["ivw"],
                            abs_diff=abs(e["ivw"] - float(r["ivw"])),
                            reproduced=bool(abs(e["ivw"] - float(r["ivw"])) < 1e-9
                                            and e["n"] == int(r["n_instruments"]))))
    val = pd.DataFrame(val)
    L("=== validation: AS_SHIPPED reproduction of the shipped V3 arms ===")
    L(val.to_string(index=False))
    L("reproduced exactly: %d of %d" % (int(val["reproduced"].sum()), len(val)))

    # ---- 2. rule sensitivity on both arms ----
    rows = []
    for ep in HORMONE_FILES:
        for dz in ["D1", "D3", "D4", "A1"]:
            d, kind = prepared(ep, dz)
            if d is None:
                continue
            line = dict(endpoint=HORMONAL_LABEL.get(ep, ep), endpoint_key=ep, design=dz,
                        source_kind=kind, n_matched=len(d),
                        n_palindromic=int(d["palindromic"].sum()),
                        n_ruleB_drops=int(d["drop_ruleB"].sum()),
                        n_ruleA_drops=int(d["drop_ruleA"].sum()),
                        rules_select_different_set=bool(
                            set(d.loc[d["drop_ruleB"], "rsid"]) != set(d.loc[d["drop_ruleA"], "rsid"])))
            for rule in ["AS_SHIPPED", "RULE_A_ALL", "NO_PAL_DROP"]:
                e = arm_estimate(d, rule)
                if e is None:
                    continue
                line["ivw_" + rule] = e["ivw"]; line["se_" + rule] = e["se"]
                line["p_" + rule] = e["p"]; line["n_" + rule] = e["n"]
            rows.append(line)
    arms = pd.DataFrame(rows)
    arms.to_csv(os.path.join(RES, "V3_1_HORMONE_RULE_SENSITIVITY_ARMS.tsv"), sep="\t", index=False)

    # ---- 3. matched differences under each rule, with the CORRECTED scale ----
    dif = []
    for ep in arms["endpoint_key"].unique():
        for dz in ["D1", "D3", "D4"]:
            a = arms[(arms["endpoint_key"] == ep) & (arms["design"] == dz)]
            anm = arms[(arms["endpoint_key"] == ep) & (arms["design"] == "A1")]
            if a.empty or anm.empty:
                continue
            a, anm = a.iloc[0], anm.iloc[0]
            for rule in ["AS_SHIPPED", "RULE_A_ALL", "NO_PAL_DROP"]:
                if ("ivw_" + rule) not in a or ("ivw_" + rule) not in anm:
                    continue
                bP, sP = a["ivw_" + rule] / m, a["se_" + rule] / m
                bA, sA = anm["ivw_" + rule] * SD_ANM_PRIMARY, anm["se_" + rule] * SD_ANM_PRIMARY
                dd = bP - bA
                se0 = float(np.hypot(sP, sA))
                dif.append(dict(endpoint=HORMONAL_LABEL.get(ep, ep), pcos_design=dz, rule=rule,
                                pcos_perSD=bP, anm_perSD=bA, difference=dd, se_rho0=se0,
                                p_rho0=zp(dd / se0), p_rho_minus1=zp(dd / (sP + sA))))
    dif = pd.DataFrame(dif)
    dif["q_BH_within_design_rule"] = np.nan
    for (dz, rule), g in dif.groupby(["pcos_design", "rule"]):
        dif.loc[g.index, "q_BH_within_design_rule"] = bh(g["p_rho0"].values)
    dif["fdr_pass"] = dif["q_BH_within_design_rule"] < ALPHA
    dif.to_csv(os.path.join(RES, "V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv"),
               sep="\t", index=False)

    pivot = dif.pivot_table(index=["endpoint", "pcos_design"], columns="rule",
                            values="p_rho0").reset_index()
    concl = dif.groupby("rule")["fdr_pass"].sum().rename("n_fdr_pass")
    sep_ep = dif[dif["fdr_pass"]].groupby("rule")["endpoint"].apply(
        lambda s: ";".join(sorted(set(s))))

    L("\n=== rule sensitivity: matched-difference P (corrected scale) ===")
    L(pivot.to_string(index=False))
    L("\n=== endpoints surviving BH under each rule ===")
    L(sep_ep.to_string())
    L("\n=== number of FDR-positive matched tests per rule ===")
    L(concl.to_string())

    log.close()
    print(val[["endpoint", "design", "v3_n", "shipped_n", "v3_ivw", "v31_ivw", "reproduced"]]
          .round(6).to_string(index=False))
    print("\nreproduced exactly: %d of %d" % (int(val["reproduced"].sum()), len(val)))
    print("\n=== endpoints surviving BH per rule ===")
    print(sep_ep.to_string())
    print()
    print(pivot.round(6).to_string(index=False))
    return arms, dif


if __name__ == "__main__":
    main()
