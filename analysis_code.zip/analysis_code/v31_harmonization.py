# -*- coding: utf-8 -*-
"""V3.1 - resolve the conflicting palindrome rules and regenerate the harmonization audit.

THE CONFLICT
------------
The V3 package shipped two statements:

  * ``07_PROVENANCE/HARMONIZATION_LOG.md`` rule 3: "Palindromic variants (A/T, C/G) with an
    exposure or outcome effect-allele frequency between 0.42 and 0.58 are dropped."
  * ``07_PROVENANCE/SNP_HARMONIZATION_LOG.xlsx`` METHOD: "palindromic variants dropped only
    when exposure and outcome EAF differ by more than 0.05", and the per-pair summaries
    carry drop reasons of the form ``palindromic_EAF_discordant(d=0.938)``.

These are not the same rule, and they are mutually exclusive descriptions.

WHAT WAS ACTUALLY USED (established from the code, not from the prose)
---------------------------------------------------------------------
Two code paths, two rules:

  A. ``V2_2026/work/v2_harmonise.py`` - the engine that produced **every headline
     harmonised matrix** in ``V2_2026/06_HARMONIZED``, i.e. every matrix behind every
     systemic and skeletal result. EAF_TOL = 0.05; a palindromic variant is dropped only
     when |EAF_exposure - EAF_outcome| > 0.05 (reason ``palindromic_EAF_discordant``),
     and dropped for a missing EAF (``palindromic_EAF_missing``). The string "0.42" does
     not occur anywhere in the V2 code tree.
  B. ``V3_2026/04_CODE/v3_hormones.py`` - the V3 hormone re-harmonisation path only. It
     drops a palindromic variant when the OUTCOME EAF lies in [0.42, 0.58], and never
     compares the exposure EAF.

So the 0.42-0.58 band is a real rule in this project, but it belongs to one secondary path,
and ``HARMONIZATION_LOG.md`` generalised it to the whole project. The V2 rule A is the one
the headline matrices used, and it is the one ``SNP_HARMONIZATION_LOG.xlsx`` describes.

WHAT V3.1 DOES
--------------
1. Names both algorithms, documents each one exactly, and states which matrices each
   produced. One algorithm per matrix; no matrix is described by a rule it was not built
   under.
2. Re-derives the audit from the deposited implementation output and cross-checks the
   counts, so the audit is regenerated from the implementation rather than restated.
3. Quantifies the cost of the divergence: how many variants in the hormone path would
   have been treated differently under rule A, and whether any hormone headline result
   depends on the choice. This is the honest way to close the inconsistency without
   silently re-running a secondary path.
"""
import io, os, re, sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import (RES, LOGD, V2, V3, DATA_ROOT, HARM_V2, INS_V2, INS_ROOT, DESIGNS,
                      PANEL9)
from v31_diff import load_master

EAF_TOL_V2 = 0.05
PAL_BAND = (0.42, 0.58)
PAL = {"AT", "TA", "CG", "GC"}

INSTRUMENT_FILES = {
    "D1": (os.path.join(INS_V2, "PCOS_EUR_1Mb_instruments.tsv"), "GCST90570579", "European"),
    "D2": (os.path.join(INS_V2, "PCOS_EUR_10Mb_instruments.tsv"), "GCST90570579", "European"),
    "D3": (os.path.join(INS_V2, "PCOS_ALT_Venkatesh_1Mb_instruments.tsv"), "GCST90483500",
           "European"),
    "D4": (os.path.join(INS_V2, "PCOS_UNION_D4_1Mb_instruments.tsv"), "GCST90570579 + GCST90483500",
           "European"),
    "D5": (os.path.join(INS_V2, "PCOS_ALL_1Mb_instruments.tsv"), "GCST90570580", "all-ancestry"),
    "D6": (os.path.join(INS_ROOT, "PCOS_ALL_GCST90570580_instruments.tsv"), "GCST90570580",
           "all-ancestry"),
    "A1": (os.path.join(INS_ROOT, "ANM_RUTH2021_instruments.tsv"), "Ruth 2021", "European"),
    "A2": (os.path.join(INS_ROOT, "ANM_UKB_GCST90029037_instruments.tsv"), "GCST90029037",
           "European"),
}
# which GWAS supplies each design's SNP-exposure coefficient, and whether the instrument was
# selected in that same GWAS
COEFF_SOURCE = {
    "D1": dict(gwas="GCST90570579 (European, age-adjusted stratum of the 2026 PCOS meta-analysis)",
               selected_in_same=True, n_cases="see source", ancestry="European"),
    "D2": dict(gwas="GCST90570579", selected_in_same=True, ancestry="European"),
    "D3": dict(gwas="GCST90483500 (Venkatesh 2025 European)", selected_in_same=True,
               ancestry="European"),
    "D4": dict(gwas="D1's members from GCST90570579, D3's members from GCST90483500",
               selected_in_same=True, ancestry="European, two studies"),
    "D5": dict(gwas="GCST90570580 (all-ancestry stratum)", selected_in_same=True,
               ancestry="all-ancestry"),
    "D6": dict(gwas="GCST90570580", selected_in_same=True, ancestry="all-ancestry"),
    "A1": dict(gwas="Ruth 2021 (reprogen.org)", selected_in_same=True, ancestry="European"),
    "A2": dict(gwas="GCST90029037", selected_in_same=True, ancestry="European"),
}
OVERLAP_NOTE = (
    "UK Biobank contributes to the PCOS deposits, to both ANM releases and to most outcome "
    "GWAS, so participant overlap exists throughout and its magnitude is unknown. Overlapping "
    "samples inflate the correlation between the two exposure estimates (the rho grid) and "
    "inflate instrument effects, biasing MR towards the null; neither can be corrected from "
    "summary statistics. No result in this package is described as independent replication.")


def norm_alleles(row, ea_col="ea", oa_col="oa"):
    ea, oa = str(row[ea_col]).upper(), str(row[oa_col]).upper()
    return (ea + oa) in PAL


def instrument_table(design):
    path, acc, anc = INSTRUMENT_FILES[design]
    if not os.path.exists(path):
        return pd.DataFrame()
    d = pd.read_csv(path, sep="\t")
    d["design"] = design
    d["gwas"] = COEFF_SOURCE[design]["gwas"]
    d["selected_in_same_gwas_as_coefficient"] = COEFF_SOURCE[design]["selected_in_same"]
    d["ancestry"] = COEFF_SOURCE[design]["ancestry"]
    d["genome_wide_significance_status"] = np.where(
        pd.to_numeric(d["p"], errors="coerce") < 5e-8,
        "P < 5e-8 (instrument threshold met)", "P >= 5e-8 - NOT an instrument")
    d["ld_independent"] = ("YES - clumped at the design window against 1000G Phase 3 EUR "
                           "(n=489); one variant per locus")
    d["f_statistic"] = d["F_stat"] if "F_stat" in d.columns else np.nan
    d["F_below_10"] = pd.to_numeric(d["f_statistic"], errors="coerce") < 10
    d["palindromic_status"] = np.where(d.apply(norm_alleles, axis=1), "PALINDROMIC (A/T or C/G)",
                                       "non-palindromic")
    d["harmonization_action"] = ("aligned to the outcome reference allele by rsID-first "
                                 "matching in v2_harmonise.py; action recorded per variant in "
                                 "the companion *_audit.csv (direct / flipped / "
                                 "complement / complement+flip / DROP)")
    d["proxy_status"] = ("NONE - no proxy substitution was used anywhere in this study; "
                         "variants absent from an outcome file are dropped, never proxied")
    d["participant_overlap_consideration"] = OVERLAP_NOTE
    d["rule_applied"] = ("HARM_EAF_DISCORD (rule A)" if design not in ("A1", "A2")
                         else "HARM_EAF_DISCORD (rule A) - variant universe identical")
    return d


def union_d4_provenance():
    """D4 is the only design whose members come from two different studies; label each."""
    p = INSTRUMENT_FILES["D4"][0]
    if not os.path.exists(p):
        return pd.DataFrame()
    d = pd.read_csv(p, sep="\t")
    if "source" not in d.columns:
        d["source"] = "unknown"
    d["d4_member_source"] = d["source"]
    d["d4_member_gwas"] = d["source"].map(
        lambda s: "GCST90570579 (D1 member)" if "GCST90570579" in str(s)
        else ("GCST90483500 (D3 member)" if "GCST90483500" in str(s) else "unknown"))
    d["d4_role"] = "UNION / POWER SENSITIVITY ONLY - never supersedes D1"
    d["d4_note"] = ("D4's D3 members take their exposure effect from a study whose participants "
                    "overlap the D1 deposit, so D4 is a power instrument and never the primary "
                    "design; every D4-based statement in this package is labelled as such.")
    return d


def audit_recount():
    """Re-derive the drop accounting from the deposited per-pair audit files."""
    rows = []
    for f in sorted(os.listdir(HARM_V2)):
        if not f.endswith("_audit.csv"):
            continue
        p = os.path.join(HARM_V2, f)
        try:
            d = pd.read_csv(p, sep="\t")
        except Exception:
            continue
        if d.empty or "action" not in d.columns:
            continue
        n = len(d)
        n_drop = int((d["action"] == "DROP").sum())
        notes = d.loc[d["action"] == "DROP", "note"] if "note" in d.columns else pd.Series(dtype=str)
        n_pal_drop = int(notes.astype(str).str.startswith("palindromic_EAF").sum())
        n_missing_eaf = int(notes.astype(str).str.contains("palindromic_EAF_missing").sum())
        # how many matched pairs are palindromic at all, and what the band rule would have done
        pal = d.apply(lambda r: (str(r.get("ea_exp", "")).upper()
                                 + str(r.get("oa_exp", "")).upper()) in PAL, axis=1)
        n_pal = int(pal.sum())
        band_drop = 0
        if n_pal and "eaf_out" in d.columns:
            eo = pd.to_numeric(d["eaf_out"], errors="coerce")
            band_drop = int((pal & eo.between(PAL_BAND[0], PAL_BAND[1], inclusive="both")).sum())
        rows.append(dict(pair=f[:-len("_audit.csv")], n_matched=n, n_usable=n - n_drop,
                         n_dropped=n_drop, n_palindromic_matched=n_pal,
                         n_dropped_palindromic_EAF_discordant=n_pal_drop - n_missing_eaf,
                         n_dropped_palindromic_EAF_missing=n_missing_eaf,
                         rule_A_drop_estimate=n_pal_drop,
                         rule_B_band_drop_if_used_instead=band_drop,
                         rules_disagree_for_this_pair=bool(band_drop != n_pal_drop)))
    return pd.DataFrame(rows)


def hormone_rule_divergence():
    """Measure, on the harnessed hormone matrices, how many variants the two rules treat
    differently. This quantifies the cost of the divergence; it does not re-run anything."""
    rows = []
    hd = os.path.join(V3, "02_HARMONIZED")
    if not os.path.isdir(hd):
        return pd.DataFrame()
    for fn in sorted(os.listdir(hd)):
        if not fn.endswith(".tsv"):
            continue
        try:
            d = pd.read_csv(os.path.join(hd, fn), sep="\t")
        except Exception:
            continue
        if not {"ea", "oa", "eaf"}.issubset(d.columns):
            continue
        pal = d.apply(lambda r: (str(r["ea"]).upper() + str(r["oa"]).upper()) in PAL, axis=1)
        band = pal & pd.to_numeric(d["eaf"], errors="coerce").between(*PAL_BAND, inclusive="both")
        rows.append(dict(hormone_file=fn, n_variants=len(d),
                         n_palindromic=int(pal.sum()),
                         n_dropped_by_rule_B_band=int(band.sum()),
                         rule_B_uses_outcome_eaf_only=("YES - rule B tests the outcome EAF only "
                                                       "and never compares it with the "
                                                       "exposure EAF, so a discordant "
                                                       "palindrome outside the band is kept"),
                         rule_A_requires_exposure_and_outcome_eaf=("YES - rule A needs both EAFs "
                                                                   "and drops on |difference| > "
                                                                   "0.05 (or a missing EAF)")))
    return pd.DataFrame(rows)


def main():
    log = io.open(os.path.join(LOGD, "v31_harmonization.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    inst = pd.concat([instrument_table(d) for d in ["D1", "D3", "D4", "D5", "D1", "D2", "D3",
                                                    "D4", "D5", "D6", "A1", "A2"]],
                     ignore_index=True)
    # keep one row per (design, key)
    inst = inst.drop_duplicates(["design", "key"])
    d4 = union_d4_provenance()
    rec = audit_recount()
    div = hormone_rule_divergence()

    with pd.ExcelWriter(os.path.join(RES, "V3_1_HARMONIZATION_PROVENANCE.xlsx"),
                        engine="openpyxl") as w:
        pd.DataFrame([
            dict(rule_id="A_HARM_EAF_DISCORD",
                 used_for="EVERY headline harmonised matrix in V2_2026/06_HARMONIZED, i.e. "
                          "every systemic and skeletal result, plus the ANM instrument files",
                 implementation="V2_2026/work/v2_harmonise.py, EAF_TOL = 0.05",
                 exact_algorithm=(
                     "1. Match the instrument variant to the outcome file by rsID first, then by "
                     "chr:pos only when the empirical rsID agreement for that outcome file is "
                     ">= 0.5 (or the file's recorded build is used when it carries no rsIDs). "
                     "2. Align alleles to a single reference pair: direct, flipped, "
                     "strand-complement, or complement+flip. "
                     "3. If the exposure allele pair is palindromic (A/T, T/A, C/G, G/C): drop "
                     "when either EAF is missing, and drop when "
                     "|EAF_exposure - EAF_outcome| > 0.05; otherwise align by EAF. "
                     "4. Non-palindromic variants are never dropped for allele reasons. "
                     "5. Record per variant: match key, action, note, both allele pairs, both "
                     "EAFs, raw and signed outcome beta, and SE."),
                 string_0_42_occurrences_in_this_path="ZERO - the literal 0.42 does not appear "
                                                      "anywhere in the V2 code tree"),
            dict(rule_id="B_HARM_PALINDROME_BAND",
                 used_for="the V3 recovered-hormone re-harmonisation path ONLY "
                          "(V3_2026/04_CODE/v3_hormones.py), for LH, estradiol, progesterone "
                          "and testosterone; NOT used for FSH (V2-deposited matrix) and NOT "
                          "used for any systemic or skeletal matrix",
                 implementation="V3_2026/04_CODE/v3_hormones.py, band [0.42, 0.58]",
                 exact_algorithm=(
                     "Drop a variant when its exposure allele pair is palindromic AND the "
                     "OUTCOME EAF lies in [0.42, 0.58]. The exposure EAF is not consulted, so "
                     "this rule cannot detect a discordant palindrome whose outcome EAF sits "
                     "outside the band."),
                 string_0_42_occurrences_in_this_path="the band is the rule"),
        ]).to_excel(w, sheet_name="TWO_RULES_DECLARED", index=False)
        inst.to_excel(w, sheet_name="INSTRUMENT_PROVENANCE", index=False)
        if len(d4):
            d4.to_excel(w, sheet_name="D4_UNION_PROVENANCE", index=False)
        if len(rec):
            rec.to_excel(w, sheet_name="AUDIT_RECOUNT", index=False)
        if len(div):
            div.to_excel(w, sheet_name="HORMONE_PATH_DIVERGENCE", index=False)

    inst.to_csv(os.path.join(RES, "V3_1_INSTRUMENT_PROVENANCE.tsv"), sep="\t", index=False)
    if len(d4):
        d4.to_csv(os.path.join(RES, "V3_1_D4_UNION_INSTRUMENT_PROVENANCE.tsv"),
                  sep="\t", index=False)
    if len(rec):
        rec.to_csv(os.path.join(RES, "V3_1_HARMONIZATION_AUDIT_RECOUNT.tsv"),
                   sep="\t", index=False)
    if len(div):
        div.to_csv(os.path.join(RES, "V3_1_HORMONE_PATH_RULE_DIVERGENCE.tsv"),
                   sep="\t", index=False)

    L("=== instrument provenance rows by design ===")
    L(inst.groupby("design").agg(n=("key", "size"), min_F=("f_statistic", "min"),
                                 median_F=("f_statistic", "median"),
                                 any_F_below_10=("F_below_10", "any"),
                                 n_palindromic=("palindromic_status",
                                                lambda s: int((s.str.startswith("PAL")).sum()))
                                 ).to_string())
    L("\n=== audit recount (rule A, as implemented) ===")
    if len(rec):
        L("pairs recounted: %d ; total dropped: %d ; dropped as palindromic EAF discordant: %d"
          % (len(rec), rec["n_dropped"].sum(),
             rec["n_dropped_palindromic_EAF_discordant"].sum()))
        L("pairs where the band rule would have dropped a different number: %d of %d"
          % (int(rec["rules_disagree_for_this_pair"].sum()), len(rec)))
    L("\n=== hormone path rule divergence ===")
    if len(div):
        L(div.to_string(index=False))
    log.close()

    print(inst.groupby("design").agg(n=("key", "size"), min_F=("f_statistic", "min"),
                                     median_F=("f_statistic", "median")).round(2).to_string())
    print()
    if len(rec):
        print("audit pairs recounted:", len(rec),
              "| total dropped:", int(rec["n_dropped"].sum()),
              "| palindromic-EAF-discordant drops:",
              int(rec["n_dropped_palindromic_EAF_discordant"].sum()))
        print("pairs where the 0.42-0.58 band would drop a different count:",
              int(rec["rules_disagree_for_this_pair"].sum()), "of", len(rec))
    print()
    if len(div):
        print(div[["hormone_file", "n_variants", "n_palindromic",
                   "n_dropped_by_rule_B_band"]].to_string(index=False))
    return inst, rec, div


if __name__ == "__main__":
    main()
