# -*- coding: utf-8 -*-
"""V3.1 - corrected matched hormonal difference tests and the six-endpoint accounting.

Two things are repaired here.

(a) The same reciprocal-scale error. ``v3_hormonal_diff.py`` multiplied the PCOS arm by
    m(K); V3.1 divides it. The ANM arm is a continuous exposure and is unchanged.

(b) Endpoint accounting. Six hormonal endpoints were pre-specified. V3's family-size file
    reported five and the manuscript described the sixth (SHBG) as unrecoverable, but no
    file recorded *why* each of the six did or did not enter the tested family, and the
    progesterone wording in the changelog described an internal build-order event rather
    than a retrieval or QC outcome. V3.1 keeps all six visible and states, per endpoint,
    the exact retrieval/QC evidence and the reason it did or did not enter the family.

The tested family is the endpoints that were actually analysable and were run; it is not
silently shrunk and not silently grown. Its size is reported both per design and as the
pooled set of matched tests.
"""
import io, math, os, sys

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import (RES, LOGD, V3_RES, SD_ANM_PRIMARY, PREV_PRIMARY, RHO_GRID, ALPHA,
                      HORMONAL_PLANNED, HORMONAL_LABEL, liability_multiplier)
from v31_diff import bh, zp


def corrected_matched(f4):
    m = liability_multiplier(PREV_PRIMARY)
    rows = []
    for ep, g in f4.groupby("endpoint"):
        armA = g[g["exposure_design"] == "A1"]
        if armA.empty:
            continue
        arow = armA.iloc[0]
        bA, sA = float(arow["ivw"]) * SD_ANM_PRIMARY, float(arow["ivw_se"]) * SD_ANM_PRIMARY
        for design in ["D1", "D3", "D4"]:
            armP = g[g["exposure_design"] == design]
            if armP.empty:
                continue
            prow = armP.iloc[0]
            # V3.1: theta_L = theta_logOR / m(K)          V3: theta_logOR * m(K)
            bP31, sP31 = float(prow["ivw"]) / m, float(prow["ivw_se"]) / m
            bP3, sP3 = float(prow["ivw"]) * m, float(prow["ivw_se"]) * m
            d31, d3 = bP31 - bA, bP3 - bA
            se31 = math.sqrt(sP31 ** 2 + sA ** 2)
            se3 = math.sqrt(sP3 ** 2 + sA ** 2)
            dz = abs(d31) / stats.norm.ppf(1 - ALPHA / 2)
            row = dict(endpoint=ep, endpoint_label=HORMONAL_LABEL.get(ep, ep), pcos_design=design,
                       n_snp_pcos=int(prow["n_instruments"]), n_snp_anm=int(arow["n_instruments"]),
                       pcos_perSD_corrected=bP31, pcos_perSD_se_corrected=sP31,
                       pcos_perSD_V3=bP3, pcos_perSD_se_V3=sP3,
                       anm_perSD=bA, anm_perSD_se=sA,
                       difference_corrected=d31, se_rho0_corrected=se31,
                       p_rho0_corrected=zp(d31 / se31),
                       difference_V3=d3, se_rho0_V3=se3, p_rho0_V3=zp(d3 / se3),
                       delta_p=zp(d31 / se31) - zp(d3 / se3),
                       rho_star_for_significance=(sP31 ** 2 + sA ** 2 - dz ** 2) / (2 * sP31 * sA)
                       if sP31 * sA > 0 else np.nan,
                       same_direction=bool(np.sign(bP31) == np.sign(bA)),
                       opposite_direction=bool(np.sign(bP31) != np.sign(bA)),
                       p_rho_minus1=zp(d31 / (sP31 + sA)))
            for r in RHO_GRID:
                se = math.sqrt(sP31 ** 2 + sA ** 2 - 2 * r * sP31 * sA)
                row["p_rho_%+.2f" % r] = zp(d31 / se)
            row["holds_for_all_nonneg_rho"] = bool(row["p_rho0_corrected"] < ALPHA and
                                                   row["rho_star_for_significance"] <= 0)
            rows.append(row)
    out = pd.DataFrame(rows)
    out["q_BH_within_design"] = np.nan
    for tag, g in out.groupby("pcos_design"):
        out.loc[g.index, "q_BH_within_design"] = bh(g["p_rho0_corrected"].values)
    out["fdr_pass_within_design"] = out["q_BH_within_design"] < ALPHA
    out["q_BH_over_all_matched_tests"] = bh(out["p_rho0_corrected"].values)
    out["fdr_pass_all_tests"] = out["q_BH_over_all_matched_tests"] < ALPHA
    out["survives_correction"] = out["fdr_pass_within_design"]
    return out


def endpoint_accounting():
    """All six pre-specified endpoints stay visible, each with its exact disposition."""
    return pd.DataFrame([
        dict(planned_endpoint="FSH", planned_dataset="GCST90483475", accession="GCST90483475",
             sample_size=51396, sex="female",
             retrieval_and_qc="downloaded in V2; gzip/bgzf integrity verified; V2-deposited "
                              "aligned matrix reused and re-run in V3",
             analysed="YES", instruments_D1=8, instruments_D3=6, instruments_ANM=17,
             entered_tested_family="YES",
             reason_not_entered=""),
        dict(planned_endpoint="LH", planned_dataset="GCST90483478", accession="GCST90483478",
             sample_size=41650, sex="female",
             retrieval_and_qc="V2 failed with WinError 10060 against the remote tabix index "
                              "(recorded in the V2 fetch log); recovered in V3 by plain HTTP "
                              "range reads over the harmonised release; integrity verified",
             analysed="YES", instruments_D1=8, instruments_D3=9, instruments_ANM=66,
             entered_tested_family="YES", reason_not_entered=""),
        dict(planned_endpoint="Estradiol", planned_dataset="GCST90483481",
             accession="GCST90483481", sample_size=92969, sex="female",
             retrieval_and_qc="regional tabix range reads; 92 of 318 instrument alleles present "
                              "in the harmonised release; integrity verified",
             analysed="YES", instruments_D1=7, instruments_D3=9, instruments_ANM=60,
             entered_tested_family="YES", reason_not_entered=""),
        dict(planned_endpoint="Progesterone", planned_dataset="GCST90483484",
             accession="GCST90483484", sample_size=16313, sex="female",
             retrieval_and_qc="regional tabix range reads; 108 of 318 instrument alleles "
                              "present in the harmonised release; integrity verified. The "
                              "extraction completed after the first hormonal build had closed, "
                              "so the earlier build published four-endpoint tables; that is a "
                              "build-order fact and NOT a retrieval or QC failure. No endpoint "
                              "was withdrawn on scientific grounds.",
             analysed="YES", instruments_D1=8, instruments_D3=9, instruments_ANM=69,
             entered_tested_family="YES - as the fifth member of the tested family",
             reason_not_entered=""),
        dict(planned_endpoint="Testosterone", planned_dataset="GCST90483486",
             accession="GCST90483486", sample_size=235579, sex="female",
             retrieval_and_qc="regional tabix range reads; 92 of 318 instrument alleles "
                              "present; integrity verified. A second release (GCST90012112) "
                              "exists and was not used.",
             analysed="YES", instruments_D1=7, instruments_D3=9, instruments_ANM=59,
             entered_tested_family="YES", reason_not_entered=""),
        dict(planned_endpoint="SHBG", planned_dataset="GCST90012107 (Ruth 2020)",
             accession="GCST90012107", sample_size=189473, sex="female",
             retrieval_and_qc="the EBI harmonised release for this study publishes no .tbi "
                              "index (HTTP 404 on the index path), so tabix random access is "
                              "impossible; the whole file is 641 MB and the measured transfer "
                              "rate on this connection was ~5 KB/s, so whole-file download is "
                              "not feasible. File integrity could therefore not be verified "
                              "and no variant was retrieved.",
             analysed="NO", instruments_D1=np.nan, instruments_D3=np.nan, instruments_ANM=np.nan,
             entered_tested_family="NO",
             reason_not_entered="retrieval failure: no published tabix index, so the endpoint "
                                "could not be read at all. This is a data-availability failure, "
                                "not a negative result, and it is not evidence of absence."),
    ])


def family_size(corr, acct):
    analysed = [r.planned_endpoint for r in acct.itertuples() if r.analysed == "YES"]
    rows = []
    for design, g in corr.groupby("pcos_design"):
        rows.append(dict(exposure_design=design, n_planned_endpoints=len(HORMONAL_PLANNED),
                         n_successfully_analysed_endpoints=len(analysed),
                         n_entering_tested_family=len(g),
                         n_with_matched_difference_test=len(g),
                         n_surviving_BH= int(g["fdr_pass_within_design"].sum()),
                         endpoints=";".join(sorted(g["endpoint_label"])),
                         endpoints_surviving=";".join(sorted(
                             g.loc[g["fdr_pass_within_design"], "endpoint_label"])),
                         endpoint_not_entering="SHBG_FEMALE",
                         reason_not_entering="retrieval failure (no published tabix index)"))
    fam = pd.DataFrame(rows)
    fam_note = pd.DataFrame([dict(
        planned_endpoints=6,
        planned_endpoints_list=";".join(HORMONAL_LABEL[k] for k in HORMONAL_PLANNED),
        successfully_analysed=len(analysed),
        successfully_analysed_list=";".join(sorted(analysed)),
        entered_tested_family=5,
        multiplicity_family_actually_tested="five endpoints per European PCOS design (D1, D3, D4) "
                                            "x 3 designs = 15 matched difference tests; BH "
                                            "applied within each design (primary rule) and, as a "
                                            "secondary, across all 15",
        endpoints_not_entering=1,
        why_not_entering="SHBG: the harmonised release publishes no tabix index, so random access "
                         "is impossible and the endpoint could not be read. Recorded as a "
                         "deviation, not dropped silently.")])
    return fam, fam_note


def main():
    log = io.open(os.path.join(LOGD, "v31_hormonal.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    f4 = pd.read_csv(os.path.join(V3_RES, "V3_HORMONAL_RESULTS_F4.tsv"), sep="\t")
    corr = corrected_matched(f4)
    acct = endpoint_accounting()
    fam, fam_note = family_size(corr, acct)

    corr.to_csv(os.path.join(RES, "V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv"), sep="\t", index=False)
    acct.to_csv(os.path.join(RES, "V3_1_HORMONAL_ENDPOINT_ACCOUNTING.tsv"), sep="\t", index=False)

    # which endpoints separate the exposures after the correction
    sep = corr[corr["survives_correction"]].groupby("endpoint_label").agg(
        n_designs=("pcos_design", "size"),
        min_p=("p_rho0_corrected", "min"), max_p=("p_rho0_corrected", "max"),
        all_hold_at_rho_minus1=("p_rho_minus1", lambda s: bool((s < ALPHA).all())),
        opposite_direction=("opposite_direction", "all")).reset_index()
    V3_sep = corr[corr["p_rho0_V3"] < ALPHA].groupby("endpoint_label").size().rename("n_designs_V3")

    L("=== corrected matched hormonal difference tests (V3.1) ===")
    L(corr[["endpoint_label", "pcos_design", "pcos_perSD_corrected", "anm_perSD",
            "difference_corrected", "p_rho0_corrected", "q_BH_within_design",
            "fdr_pass_within_design", "p_rho_minus1", "opposite_direction",
            "p_rho0_V3", "delta_p"]].round(8).to_string(index=False))
    L("\n=== endpoints that separate the exposures after correction ===")
    L(sep.to_string(index=False))
    L("\n=== endpoints whose V3 nominal difference did NOT survive the correction ===")
    lost = corr[(corr["p_rho0_V3"] < ALPHA) & (~corr["survives_correction"])]
    L(lost[["endpoint_label", "pcos_design", "p_rho0_V3", "p_rho0_corrected",
            "q_BH_within_design"]].to_string(index=False) if len(lost) else "none")
    L("\n=== family size ===")
    L(fam.to_string(index=False))
    L(fam_note.to_string(index=False))
    log.close()

    with pd.ExcelWriter(os.path.join(RES, "V3_1_HORMONAL_ENDPOINT_ACCOUNTING.xlsx"),
                        engine="openpyxl") as w:
        acct.to_excel(w, sheet_name="SIX_PLANNED_ENDPOINTS", index=False)
        fam_note.to_excel(w, sheet_name="FAMILY_SIZE_ACCOUNTING", index=False)
        fam.to_excel(w, sheet_name="FAMILY_SIZE_PER_DESIGN", index=False)
        corr.to_excel(w, sheet_name="CORRECTED_MATCHED_DIFFERENCES", index=False)
        f4.to_excel(w, sheet_name="PER_ARM_F4_RESULTS", index=False)

    print(sep.to_string(index=False))
    print()
    print("separating endpoints after correction: %d" % len(sep))
    print("separating endpoints under V3's transformation: %d"
          % corr.loc[corr["p_rho0_V3"] < ALPHA, "endpoint_label"].nunique())
    print()
    print(fam_note.T.to_string())


if __name__ == "__main__":
    main()
