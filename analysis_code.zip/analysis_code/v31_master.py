# -*- coding: utf-8 -*-
"""V3.1 - the master results table, carrying both scales so nothing has to be inferred.

One row per (exposure design, outcome), with the per-exposure-unit estimate as deposited and
two derived per-SD columns: the corrected reciprocal value (V3.1) and the multiplicatively
scaled value the previous version shipped. Having both in one file is what makes the
correction auditable at the level of every pair rather than only at the headline.
"""
import io, os, sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, LOGD, V3_RES, DESIGNS, PREV_PRIMARY, SD_ANM_PRIMARY, liability_multiplier
from v31_diff import load_master


def main():
    m = load_master()
    mult = liability_multiplier(PREV_PRIMARY)
    d = m.copy()
    d["design_role"] = d["design"].map(lambda x: DESIGNS[x]["role"])
    d["design_source"] = d["design"].map(lambda x: DESIGNS[x]["source"])
    d["design_window_kb"] = d["design"].map(lambda x: DESIGNS[x]["window"])
    d = d.rename(columns={"nsnp": "n_instrument_variants", "ivw": "ivw_per_exposure_unit",
                          "ivw_se": "ivw_se_per_exposure_unit", "ivw_p": "ivw_p"})
    d["is_binary_exposure"] = d["design"].str.startswith(("D", "D6")) | d["design"].isin(
        ["D1", "D2", "D3", "D4", "D5", "D6"])
    d["perSD_corrected_reciprocal"] = np.where(d["is_binary_exposure"],
                                               d["ivw_per_exposure_unit"] / mult, np.nan)
    d["perSD_se_corrected_reciprocal"] = np.where(d["is_binary_exposure"],
                                                  d["ivw_se_per_exposure_unit"] / mult, np.nan)
    d["perSD_previous_multiplicative"] = np.where(d["is_binary_exposure"],
                                                  d["ivw_per_exposure_unit"] * mult, np.nan)
    d["perSD_se_previous_multiplicative"] = np.where(d["is_binary_exposure"],
                                                     d["ivw_se_per_exposure_unit"] * mult, np.nan)
    d["perSD_of_SD_ANM"] = np.where(~d["is_binary_exposure"],
                                    d["ivw_per_exposure_unit"] * SD_ANM_PRIMARY, np.nan)
    d["scale_note"] = np.where(
        d["is_binary_exposure"],
        "PCOS is binary: per-exposure-unit is a log-OR effect. perSD_corrected_reciprocal = "
        "ivw/m(K); perSD_previous_multiplicative = ivw*m(K) (V3, wrong direction).",
        "ANM is continuous in years: no liability conversion. perSD_of_SD_ANM = ivw*SD_ANM.")
    d["multiplier_used"] = np.where(d["is_binary_exposure"], mult, np.nan)
    d.to_csv(os.path.join(RES, "V3_1_MASTER_RESULTS_long.tsv"), sep="\t", index=False)

    with pd.ExcelWriter(os.path.join(RES, "V3_1_MASTER_RESULTS.xlsx"), engine="openpyxl") as w:
        d.to_excel(w, sheet_name="ALL_PAIRS", index=False)
        d.pivot_table(index="outcome", columns="design",
                      values="ivw_per_exposure_unit").to_excel(w, sheet_name="IVW_BY_DESIGN")
        d.pivot_table(index="outcome", columns="design",
                      values="perSD_corrected_reciprocal").to_excel(
            w, sheet_name="PER_SD_CORRECTED_BY_DESIGN")
        d.pivot_table(index="outcome", columns="design",
                      values="perSD_previous_multiplicative").to_excel(
            w, sheet_name="PER_SD_PREVIOUS_BY_DESIGN")
        pd.DataFrame([dict(design=k, alias="|".join(v["alias"]), window_kb=v["window"],
                           n_loci_declared=v["n_loci"], source=v["source"], role=v["role"])
                      for k, v in DESIGNS.items()]).to_excel(w, sheet_name="DESIGN_MAP",
                                                             index=False)
        pd.DataFrame([
            dict(column="ivw_per_exposure_unit", meaning="the deposited IVW estimate per unit of "
                                                          "the exposure as analysed (log-OR for "
                                                          "PCOS, years for ANM)"),
            dict(column="perSD_corrected_reciprocal", meaning="V3.1: ivw / m(K) for a binary "
                                                              "exposure. Equations 3-4."),
            dict(column="perSD_previous_multiplicative",
                 meaning="V3 as shipped: ivw * m(K). WRONG DIRECTION. Retained so that the "
                         "change is auditable pair by pair."),
            dict(column="perSD_of_SD_ANM", meaning="continuous exposure: ivw * SD_ANM, "
                                                   "SD_ANM = %.1f yr" % SD_ANM_PRIMARY),
        ]).to_excel(w, sheet_name="COLUMN_DEFINITIONS", index=False)

    print("master rows:", len(d), "designs:", sorted(d['design'].unique()))
    print("columns:", len(d.columns))


if __name__ == "__main__":
    main()
