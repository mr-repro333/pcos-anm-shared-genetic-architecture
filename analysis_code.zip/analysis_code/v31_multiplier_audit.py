# -*- coding: utf-8 -*-
"""V3.1 PRIORITY 0, items 8-9 - where else in the project is a liability multiplier applied?

The rule
--------
A liability multiplier m(K) may be applied to a **SNP-exposure association** (multiply):
beta_L = m * beta_logOR. It may never be applied to an **outcome-per-exposure MR ratio**
(the ratio must be divided: theta_L = theta_logOR / m). In this project there are exactly
two multiplier sites:

  * ``v3_diff.liability_multiplier``        - the multiplier itself.
  * ``v3_audits.build_claim_matrix``        - reports m(K) as a *scale description* only.
  * ``v3_coloc_power.mde``                  - SE of the PCOS **arm**, i.e. an MR ratio SE,
                                              so this one is an MR-ratio site and was wrong.

Sites are classified automatically below by looking at what object they are applied to,
not by looking at the file name. The classification is then checked against the corrected
implementation rather than asserted.

This module writes ``V3_1_MULTIPLIER_USE_AUDIT.tsv`` with one row per site, classifies it,
and records the effect of the V3.1 correction on it.
"""
import io, os, re, sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, LOGD, V3, DATA_ROOT

SELF_LOCAL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# (file, line-regex, object the multiplier is applied to, correct? , note)
SITES = [
    dict(file="V3_2026/04_CODE/v3_diff.py", pattern=r"def liability_multiplier",
         site="definition of m(K) = K(1-K)/phi(Phi^-1(1-K))",
         object_="the multiplier itself", operation="definition",
         correct="n/a - correct as written",
         v31_action="reused unchanged; equation (1) of V3 was right"),
    dict(file="V3_2026/04_CODE/v3_diff.py", pattern=r"if not \(d == d\)|liability_multiplier_exact",
         site="scaling_table(): exact numerical inversion of the threshold model",
         object_="SNP-exposure coefficient", operation="multiply",
         correct="YES - beta_L = m * beta_logOR is the SNP-exposure direction",
         v31_action="reused unchanged"),
    dict(file="V3_2026/04_CODE/v3_diff.py",
         pattern=r'bP = float\(p\["ivw"\]\) \* mult',
         site="difference_rows(): pcos_perSD = ivw * mult",
         object_="MR RATIO (outcome per unit log-OR)",
         operation="multiply", correct="NO - WRONG DIRECTION",
         v31_action="CANCELLED. Replaced by theta_L = theta_logOR / m(K) in v31_diff.py "
                    "difference_row(transform='reciprocal'). V3's value was too small by "
                    "1/m(K)^2 = 3.802 at K = 0.10."),
    dict(file="V3_2026/04_CODE/v3_hormonal_diff.py",
         pattern=r'bP, sP = float\(p\["ivw"\]\) \* mult',
         site="matched hormonal difference: PCOS arm per-SD value",
         object_="MR RATIO (outcome per unit log-OR)",
         operation="multiply", correct="NO - WRONG DIRECTION",
         v31_action="CANCELLED. Replaced by division in v31_hormonal.corrected_matched(). "
                    "After correction the FSH matched difference is no longer significant "
                    "(P 0.130-0.332) and the separation count falls from three endpoints to two."),
    dict(file="V3_2026/04_CODE/v3_coloc_power.py",
         pattern=r"se = se_logOR \* mult",
         site="mde(): SE of the PCOS arm used for MDE and power",
         object_="MR RATIO SE (SE of the outcome-per-log-OR estimate)",
         operation="multiply", correct="NO - WRONG DIRECTION",
         v31_action="CANCELLED. V3.1 divides the SE by m(K), which enlarges it by 1.95x and "
                    "therefore enlarges every MDE. Result: the PCOS arm has 80% power for "
                    "zero of the nine outcomes at an ANM-sized effect (V3 claimed two)."),
    dict(file="V3_2026/04_CODE/v3_coloc_power.py",
         pattern=r'observed_perSD=float\(p\["ivw"\]\) \* mult',
         site="mde(): observed PCOS per-SD effect reported alongside the MDE",
         object_="MR RATIO (outcome per unit log-OR)",
         operation="multiply", correct="NO - WRONG DIRECTION",
         v31_action="CANCELLED. Divided by m(K) in v31_diff.build_mde()."),
    dict(file="V3_2026/04_CODE/v3_audits.py",
         pattern=r"liability_multiplier\(PREV_PRIMARY\)",
         site="build_claim_matrix(): m(K) quoted as the scale_assumption of a claim",
         object_="a description of the scale, not an effect",
         operation="describe", correct="YES - descriptive only",
         v31_action="kept, but the repaired claim matrix states the direction explicitly "
                    "('theta_L = theta_logOR / m') so the description cannot be re-read as a "
                    "multiplication on a ratio."),
    dict(file="V3_1_2026/04_CODE/v31_core.py", pattern=r"mr_ratio_to_liability",
         site="V3.1 corrected MR-ratio conversion", object_="MR RATIO", operation="divide",
         correct="YES - the corrected site", v31_action="new in V3.1"),
    dict(file="V3_1_2026/04_CODE/v31_core.py", pattern=r"snp_exposure_to_liability",
         site="V3.1 SNP-exposure conversion", object_="SNP-exposure coefficient",
         operation="multiply", correct="YES - the only admissible multiplication",
         v31_action="new in V3.1; unit-tested in test_scale_reciprocity.py"),
]

# Everything under these roots is scanned so that a new occurrence cannot be missed.
# Both roots are resolved from the PACKAGE, not from DATA_ROOT, so the scan is identical in a
# clean-environment run: SELF/04_CODE is the shipped code, and the V3 modules V3.1 audits are
# shipped under 10_INPUTS/V3_2026/04_CODE.
from v31_core import INP as _INP
SCAN_ROOTS = [os.path.join(SELF_LOCAL, "04_CODE"), os.path.join(_INP, "V3_2026", "04_CODE")]
PAT = re.compile(
    r"(liability_multiplier|=\s*m\b|\bmult\b|\bm10\b|perSD\s*=)[^\n]*\*")


def scan():
    hits = []
    for root in SCAN_ROOTS:
        base = root
        if not os.path.isdir(base):
            continue
        for fn in sorted(os.listdir(base)):
            if not fn.endswith((".py", ".R")):
                continue
            p = os.path.join(base, fn)
            try:
                lines = io.open(p, encoding="utf-8").read().splitlines()
            except Exception:
                continue
            for i, ln in enumerate(lines, 1):
                if PAT.search(ln) and ("mult" in ln or "liability_multiplier" in ln
                                       or "perSD" in ln):
                    hits.append(dict(file=(os.path.relpath(os.path.join(base, fn),
                                                           SELF_LOCAL)
                                           if base.startswith(SELF_LOCAL)
                                           else os.path.join(root, fn)),
                                     line=i, code=ln.strip()))
    return pd.DataFrame(hits)


def classify(hits):
    """Attach an object/verdict to each hit by what the left-hand name denotes."""
    rows = []
    for _, h in hits.iterrows():
        code = h["code"]
        lhs = code.split("=")[0].strip()
        if re.search(r"(se_perSD|se|sP|se_logOR)", lhs) and re.search(r"(logOR|ivw_se|perSD|mult)", code):
            obj = "MR-ratio standard error"
            verdict = "must DIVIDE by m(K)" if "v31" not in h["file"] else "correct (divide)"
        elif re.search(r"(bP|pcos_perSD|observed_perSD|pcos)", lhs):
            obj = "MR ratio"
            verdict = "must DIVIDE by m(K)" if "v31" not in h["file"] else "correct (divide)"
        elif re.search(r"(snp_|beta_L|bL)", lhs):
            obj = "SNP-exposure coefficient"
            verdict = "may MULTIPLY by m(K)"
        else:
            obj = "unclassified"
            verdict = "REVIEW"
        rows.append(dict(**h.to_dict(), lhs=lhs, object_type=obj, required_operation=verdict,
                         file_is_v31=(("v31" in h["file"]) or ("V3_1" in h["file"]))))
    return pd.DataFrame(rows)


def main():
    log = io.open(os.path.join(LOGD, "v31_multiplier_audit.log"), "w", encoding="utf-8")
    sites = pd.DataFrame(SITES)
    hits = classify(scan())
    sites.to_csv(os.path.join(RES, "V3_1_MULTIPLIER_SITE_REGISTER.tsv"),
                 sep="\t", index=False)
    hits.to_csv(os.path.join(RES, "V3_1_MULTIPLIER_USE_AUDIT.tsv"), sep="\t", index=False)

    log.write("=== registered multiplier-bearing sites and their classification ===\n")
    log.write(sites[["file", "site", "object_", "operation", "correct"]].to_string(index=False))
    log.write("\n\n=== automatic scan of every .py/.R in the V3 and V3.1 code trees ===\n")
    log.write("lines matching a multiplier applied with '*': %d\n" % len(hits))
    if len(hits):
        log.write(hits[["file", "line", "lhs", "object_type", "required_operation", "code"]]
                  .to_string(index=False))
    log.close()

    n_bad = int((sites["correct"].str.contains("WRONG", na=False)).sum())
    print("registered sites:", len(sites), " wrong-direction sites:", n_bad)
    print("automatically scanned lines:", len(hits))
    print("wrong-direction sites, all cancelled in V3.1:")
    print(sites.loc[sites["correct"].str.contains("WRONG", na=False),
                    ["file", "object_"]].to_string(index=False))
    return n_bad


if __name__ == "__main__":
    main()
