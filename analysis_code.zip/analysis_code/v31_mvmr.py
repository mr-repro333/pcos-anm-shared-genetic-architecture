# -*- coding: utf-8 -*-
"""V3.1 PRIORITY 2 - the MVMR covariance assumption, audited and demoted.

WHAT V3 SAID
------------
"Models of the form outcome ~ PCOS + ANM were fitted ... using MVMR::strength_mvmr with the
between-exposure covariance set to zero, which is the package default and is defensible
here because each instrument set is mutually independent by construction."

WHY THAT DOES NOT FOLLOW
------------------------
``gencov`` is Cov(beta_X1, beta_X2): the covariance between the two SNP-EXPOSURE
association estimates **at the same SNP**. LD independence is a property of the SNPs;
gencov is a property of the estimation. When the two exposure GWAS share participants, the
two estimated effects at one SNP are correlated even for perfectly independent SNPs, and
that correlation is exactly what LD clumping does nothing to remove. The correct statement
is therefore: gencov = 0 is an ASSUMPTION, not a construction, and with UK Biobank
contributing to both exposures it is an unverified one.

WHAT V3.1 DOES
--------------
1. Bounds the assumption rather than estimating it. By Cauchy-Schwarz
   |Cov(beta_X1, beta_X2)| <= se1 * se2, so gencov lies in [-1, +1] times that product.
   ``v31_mvmr_covariance_sensitivity.R`` walks tau in that band and recomputes the Sanderson-
   Windmeijer conditional F for every V3 design. tau is a dimensionless bound parameter, not
   an estimate of the true covariance, so nothing is invented.
2. Reports what the bound does to the gate. If the conclusions of the conditional-F gate
   move inside the bound, the gate is not identified and MVMR cannot carry a biological
   claim at this instrument strength.
3. Demotes MVMR accordingly, and removes the interpretation that V3 attached to it.
"""
import io, os, sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, LOGD, V3_RES, DATA_ROOT, ALPHA

TAUS = [-1, -0.5, -0.33, -0.2, -0.1, 0, 0.1, 0.2, 0.33, 0.5, 1]

INTERPRETATION = [
    dict(statement="gencov = 0 is justified because the instruments are mutually LD-independent",
         v3_status="ASSERTED", v31_status="REJECTED AS A JUSTIFICATION",
         reason="LD independence of the SNPs is not independence of the two SNP-exposure "
                "association estimates. With participant overlap between the two exposure "
                "GWAS those estimates are correlated regardless of LD."),
    dict(statement="The conditional F of 13.83 (PCOS) / 12.02 (ANM) in the rebuilt restricted "
                   "design passes the prespecified gate of 10 for both exposures",
         v3_status="CLAIMED", v31_status="TRUE ONLY AT tau >= -0.33",
         reason="the same model gives conditional F 9.26 / 9.22 at tau = -0.5 and 6.96 / 7.48 "
                "at tau = -1.0, i.e. BOTH gates fail for any negative covariance beyond about "
                "-0.33. The gate outcome is not identified under the assumption that is "
                "actually in force."),
    dict(statement="MVMR supports a direct PCOS effect / the absence of a direct PCOS effect",
         v3_status="UNRESOLVED but reported", v31_status="NOT INTERPRETABLE - withdrawn from "
                                                          "the biological headline",
         reason="a design whose gate flips inside the permitted covariance band cannot support "
                "either a positive or a negative direct effect."),
    dict(statement="The attenuation of ANM -> BMD from P = 8.8e-05 to P = 0.231 after "
                   "conditioning on PCOS means the skeletal association is mediated by / shared "
                   "with PCOS",
         v3_status="CAUTIONED AGAINST but stated", v31_status="WITHDRAWN",
         reason="with gencov unverified AND Q_A significant in nearly every model, the "
                "conditioning model is not validated; an attenuation under an unvalidated model "
                "is not evidence of mediation or of sharing."),
    dict(statement="MVMR direct-effect estimates are a design / sensitivity analysis",
         v3_status="partly", v31_status="RETAINED - this is the only role MVMR now has",
         reason="the design audit is real and useful; the effect estimates are not."),
    dict(statement="Any MVMR outcome expansion",
         v3_status="none", v31_status="NOT ALLOWED",
         reason="V3.1 adds no MVMR model, no outcome and no release."),
]


def main():
    log = io.open(os.path.join(LOGD, "v31_mvmr.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    f = os.path.join(RES, "V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv")
    if not os.path.exists(f):
        raise SystemExit("run v31_mvmr_covariance_sensitivity.R first")
    d = pd.read_csv(f, sep="\t")
    n_models = d[["pair", "design"]].drop_duplicates().shape[0]

    summ = d.groupby("tau").agg(
        min_condF_PCOS=("condF_PCOS", "min"), max_condF_PCOS=("condF_PCOS", "max"),
        min_condF_ANM=("condF_ANM", "min"), max_condF_ANM=("condF_ANM", "max"),
        n_pass_both=("gate_both", "sum"), n_models=("gate_both", "size")).reset_index()
    summ["pct_pass_both"] = (100 * summ["n_pass_both"] / summ["n_models"]).round(1)

    head = d[d["design"] == "R1_restricted_D1"][
        ["pair", "tau", "condF_PCOS", "condF_ANM", "gate_both", "QA_p"]]
    gate_flip = head.groupby("pair")["gate_both"].agg(["min", "max"]).reset_index()
    gate_flip["flips_inside_band"] = gate_flip["min"] != gate_flip["max"]

    crit = d.groupby("pair")["gate_both"].agg(["min", "max"]).reset_index()
    crit["flips_inside_band"] = crit["min"] != crit["max"]
    n_flip = int(crit["flips_inside_band"].sum())

    with pd.ExcelWriter(os.path.join(RES, "V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx"),
                        engine="openpyxl") as w:
        pd.DataFrame([dict(
            what="gencov in MVMR::strength_mvmr",
            definition="the covariance between the two SNP-EXPOSURE association estimates at "
                       "the same SNP, i.e. Cov(beta_X1, beta_X2)",
            v3_justification="the package default plus 'each instrument set is mutually "
                             "independent by construction'",
            v31_finding="LD independence is a property of the SNPs; gencov is a property of the "
                        "estimation. With UK Biobank contributing to both exposure GWAS the two "
                        "estimates are correlated, so gencov = 0 is an unverified assumption.",
            what_v31_does="bounds it rather than estimating it: by Cauchy-Schwarz "
                          "|Cov| <= se1*se2, so gencov = tau * se1 * se2 with tau in [-1, 1], "
                          "and the conditional F is recomputed across the band",
            is_this_an_invented_covariance="NO - tau is a dimensionless bound parameter, not an "
                                           "estimate; the true sampling covariance is a "
                                           "phenotypic overlap quantity that the deposited "
                                           "summary statistics do not contain")]).to_excel(
            w, sheet_name="WHAT_GENCOV_IS", index=False)
        summ.to_excel(w, sheet_name="SUMMARY_BY_TAU", index=False)
        d.to_excel(w, sheet_name="FULL_SENSITIVITY", index=False)
        head.to_excel(w, sheet_name="HEADLINE_RESTRICTED_DESIGN", index=False)
        pd.DataFrame(INTERPRETATION).to_excel(w, sheet_name="INTERPRETATION_CHANGES",
                                              index=False)
        crit.to_excel(w, sheet_name="GATE_STABILITY_PER_MODEL", index=False)
        pd.DataFrame([
            dict(question="Can a defensible covariance estimate be derived from the available "
                          "summary data?", answer="NO",
                 detail="the required quantity is the correlation between the two exposure "
                        "traits among overlapping participants. The deposits contain no "
                        "per-participant overlap information and no sample-overlap matrix, and "
                        "the LDSC genetic correlation (r_g = +0.329) is a different quantity."),
            dict(question="Was a covariance invented anyway?", answer="NO",
                 detail="tau is a bound parameter over [-1, 1] from Cauchy-Schwarz. No value of "
                        "tau is asserted as true; the whole band is reported."),
            dict(question="Does the conditional-F gate survive the band?",
                 answer="NO" if n_flip else "YES",
                 detail="%d of %d models change their gate outcome inside [-1, 1]. The headline "
                        "restricted design passes both gates only for tau >= -0.33 and fails "
                        "both at tau = -0.5 (9.26 / 9.22) and tau = -1.0 (6.96 / 7.48)."
                        % (n_flip, n_models)),
            dict(question="Consequence for the manuscript", answer="MVMR is demoted",
                 detail="MVMR is retained as a design and sensitivity analysis only. No direct "
                        "PCOS or ANM systemic effect is claimed. The attenuation of ANM -> BMD "
                        "is not described as mediation or as sharing with PCOS. No MVMR outcome "
                        "was added."),
        ]).to_excel(w, sheet_name="AUDIT_ANSWERS", index=False)

    L("=== MVMR conditional-F gate versus the covariance bound ===")
    L(summ.to_string(index=False))
    L("\nmodels:", n_models, "| models whose gate outcome flips inside tau in [-1,1]:", n_flip)
    L("\n=== headline restricted design (R1_restricted_D1) ===")
    L(head.to_string(index=False))
    log.close()

    print(summ.to_string(index=False))
    print()
    print("models:", n_models, "| gate flips inside the band:", n_flip)
    print()
    print(head[head["pair"] == "BMD"].round(4).to_string(index=False))
    return d, summ, n_flip


if __name__ == "__main__":
    main()
