#!/usr/bin/env Rscript
# ==============================================================================
# V3.1 PRIORITY 2 - MVMR covariance-assumption audit.
#
# V3 justified `gencov = 0` by saying "each instrument set is mutually independent by
# construction". That is a non sequitur and V3.1 re-audits it:
#
#   * LD independence between the instruments is a statement about the SNPs.
#   * gencov is the covariance between the two SNP-EXPOSURE ASSOCIATION ESTIMATES at the
#     same SNP. With overlapping participants in the two exposure GWAS this covariance is
#     non-zero even for perfectly independent SNPs.
#
# We cannot recover the true covariance from summary statistics. What we CAN do is bound
# it: by Cauchy-Schwarz |Cov| <= se1 * se2, so the assumption gencov = 0 sits at one end
# of a bounded range. This script walks that range,
#
#   Cov_l(tau) = tau * se_betaX1(l) * se_betaX2(l),
#
# for tau in {-1, -0.5, -0.33, -0.2, -0.1, 0, 0.1, 0.2, 0.33, 0.5, 1}, where tau = 1 is
# the Cauchy-Schwarz maximum, and reports the conditional F for each exposure at each tau.
# tau = 0.33 is included because the LDSC genetic correlation between PCOS and ANM is
# +0.329; it is used as a *benchmark scale*, not as an estimate of the sampling covariance,
# which is a phenotypic overlap quantity that the deposited summary statistics do not
# contain.
#
# No outcome is added and no model is added: exactly the V3 designs already on disk.
# ==============================================================================
suppressPackageStartupMessages({library(data.table); library(MendelianRandomization)})

ROOT <- Sys.getenv("PCOS_ANM_DATA_ROOT", unset = "E:/PCOS_ANM_Genetic_Decoupling")
MVMRR <- file.path(ROOT, "15_CODE", "tools", "MVMR-master", "R")
for (f in list.files(MVMRR, pattern = "\\.R$", full.names = TRUE))
  try(suppressWarnings(suppressMessages(source(f))), silent = TRUE)
stopifnot(exists("format_mvmr"), exists("strength_mvmr"))

INDIR <- file.path(ROOT, "V3_2026", "08_MVMR_V3", "_input")
OUTROOT <- Sys.getenv("PCOS_ANM_V31_OUT", unset = file.path(ROOT, "V3_1_2026"))
OUTD  <- file.path(OUTROOT, "03_RESULTS")
dir.create(OUTD, showWarnings = FALSE, recursive = TRUE)

TAUS <- c(-1, -0.5, -0.33, -0.2, -0.1, 0, 0.1, 0.2, 0.33, 0.5, 1)

files <- list.files(INDIR, pattern = "\\.tsv$", full.names = TRUE)
res <- list()

for (f in files) {
  key <- sub("\\.tsv$", "", basename(f))
  pair <- sub("__.*$", "", key); design <- sub("^.*__", "", key)
  d <- fread(f)
  need <- c("betaYG","sebetaYG","betaX1","sebetaX1","betaX2","sebetaX2")
  if (!all(need %in% names(d)) || nrow(d) < 5) next

  bx <- as.matrix(d[, .(betaX1, betaX2)])
  bxse <- as.matrix(d[, .(sebetaX1, sebetaX2)])
  by <- d$betaYG; byse <- d$sebetaYG; k <- nrow(d); w <- 1 / byse^2

  fmt <- tryCatch(format_mvmr(BXGs = bx, BYG = by, seBXGs = bxse, seBYG = byse, RSID = d$SNP),
                  error = function(e) NULL)
  if (is.null(fmt)) next

  fit <- tryCatch(lm(by ~ -1 + bx[,1] + bx[,2], weights = w), error = function(e) NULL)
  QA <- NA_real_; QAp <- NA_real_; b1 <- NA_real_; s1 <- NA_real_; p1 <- NA_real_
  b2 <- NA_real_; s2 <- NA_real_; p2 <- NA_real_
  if (!is.null(fit)) {
    s <- summary(fit)$coef
    QA <- sum(w * residuals(fit)^2); QAp <- pchisq(QA, df = k - 2, lower.tail = FALSE)
    b1 <- s[1,1]; s1 <- s[1,2]; p1 <- s[1,4]
    b2 <- s[2,1]; s2 <- s[2,2]; p2 <- s[2,4]
  }

  for (tau in TAUS) {
    gc <- list()
    for (l in seq_len(k)) {
      m <- matrix(c(bxse[l,1]^2,                 tau * bxse[l,1] * bxse[l,2],
                    tau * bxse[l,1] * bxse[l,2], bxse[l,2]^2), nrow = 2)
      gc[[l]] <- m
    }
    cf1 <- NA_real_; cf2 <- NA_real_
    if (tau == 0) {
      cf <- tryCatch(suppressWarnings(strength_mvmr(fmt, gencov = 0)), error = function(e) NULL)
    } else {
      cf <- tryCatch(suppressWarnings(strength_mvmr(fmt, gencov = gc)), error = function(e) NULL)
    }
    if (!is.null(cf)) { cf1 <- as.numeric(cf[1,1]); cf2 <- as.numeric(cf[1,2]) }
    res[[length(res) + 1]] <- data.table(
      pair = pair, design = design, n_instruments = k, tau = tau,
      cov_model = ifelse(tau == 0, "gencov = 0 (V3 assumption)",
                         sprintf("gencov = %.2f * se1 * se2", tau)),
      condF_PCOS = cf1, condF_ANM = cf2,
      gate_PCOS = cf1 >= 10, gate_ANM = cf2 >= 10, gate_both = (cf1 >= 10 & cf2 >= 10),
      ivw_PCOS = b1, ivw_PCOS_se = s1, ivw_PCOS_p = p1,
      ivw_ANM = b2, ivw_ANM_se = s2, ivw_ANM_p = p2,
      QA = QA, QA_df = k - 2, QA_p = QAp)
  }
}

out <- rbindlist(res, fill = TRUE)
fwrite(out, file.path(OUTD, "V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv"), sep = "\t")

cat("=== MVMR covariance sensitivity (tau = Cov/(se1*se2)) ===\n")
cat("models:", length(unique(out$design)), "designs,", nrow(out), "rows\n\n")
sm <- out[, .(min_condF_PCOS = min(condF_PCOS, na.rm=TRUE),
              max_condF_PCOS = max(condF_PCOS, na.rm=TRUE),
              min_condF_ANM  = min(condF_ANM, na.rm=TRUE),
              max_condF_ANM  = max(condF_ANM, na.rm=TRUE),
              n_gate_both    = sum(gate_both, na.rm=TRUE),
              n_rows         = .N), by = tau]
print(sm)

cat("\n=== how many (design, outcome) models pass BOTH gates, by tau ===\n")
tot <- length(unique(paste(out$pair, out$design)))
for (t in TAUS) {
  s <- out[tau == t]
  cat(sprintf("tau=%+.2f : %d / %d models pass both gates (%.0f%%)\n",
              t, sum(s$gate_both, na.rm = TRUE), tot,
              100 * sum(s$gate_both, na.rm = TRUE) / tot))
}
cat("\n=== V3's headline restricted design, by tau ===\n")
print(out[design == "R1_restricted_D1",
          .(pair, tau, condF_PCOS, condF_ANM, gate_both, QA, QA_p)])
cat("\nwrote V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv\n")
