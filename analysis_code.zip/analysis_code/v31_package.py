# -*- coding: utf-8 -*-
"""V3.1 deliverable builder: the scale-correction audit workbook, Word renderings, and the
submission ZIP with its checksum manifest.

Deliverable 1 of the required list, ``V3_1_SCALE_CORRECTION_AUDIT.xlsx``, is assembled here
from the result files rather than typed, so it cannot drift from them.
"""
import glob, hashlib, io, os, re, shutil, subprocess, sys, zipfile

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, LOGD, SELF, PREV_PRIMARY, liability_multiplier, PANEL9_LABEL

MAN = os.path.join(SELF, "01_MANUSCRIPT")
SUPP = os.path.join(SELF, "06_SUPPLEMENT")


def rd(n):
    return pd.read_csv(os.path.join(RES, n), sep="\t")


def xl(n, s):
    return pd.read_excel(os.path.join(RES, n), sheet_name=s)


def build_scale_audit():
    m = liability_multiplier(PREV_PRIMARY)
    d = rd("V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv")
    v3 = rd("V3_1_DIFFERENCE_PRIMARY9_V3METHOD_COMPARATOR.tsv")
    side = rd("V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv")
    sites = rd("V3_1_MULTIPLIER_SITE_REGISTER.tsv")
    mde = rd("V3_1_POWER_MDE_CORRECTED.tsv")
    hor = rd("V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv")
    p = os.path.join(RES, "V3_1_SCALE_CORRECTION_AUDIT.xlsx")

    with pd.ExcelWriter(p, engine="openpyxl") as w:
        pd.DataFrame([
            dict(quantity="prevalence at the primary analysis", value=PREV_PRIMARY),
            dict(quantity="m(K) = K(1-K)/phi(Phi^-1(1-K))", value=m),
            dict(quantity="1/m(K)", value=1 / m),
            dict(quantity="factor by which the previous per-SD values were too small",
                 value=1 / m ** 2),
            dict(quantity="correct rule for a SNP-exposure coefficient",
                 value="beta_L = m(K) * beta_logOR  (multiply)"),
            dict(quantity="correct rule for an MR ratio",
                 value="theta_L = theta_logOR / m(K)  (divide), SE likewise"),
            dict(quantity="what the previous version did to the ratio",
                 value="multiplied by m(K) - the reciprocal of the correct transformation"),
        ]).to_excel(w, sheet_name="THE_CORRECTION", index=False)
        side.to_excel(w, sheet_name="SIDE_BY_SIDE_PRIMARY9", index=False)
        d.to_excel(w, sheet_name="CORRECTED_PRIMARY9", index=False)
        v3.to_excel(w, sheet_name="PREVIOUS_METHOD_PRIMARY9", index=False)
        sites.to_excel(w, sheet_name="MULTIPLIER_SITES", index=False)
        mde.to_excel(w, sheet_name="MDE_POWER_CORRECTED", index=False)
        hor.to_excel(w, sheet_name="HORMONAL_CORRECTED", index=False)
        pd.DataFrame([
            dict(outcome=PANEL9_LABEL.get(o, o),
                 previous_p=float(v3.set_index("outcome").loc[o, "p_rho0"]),
                 corrected_p=float(d.set_index("outcome").loc[o, "p_rho0"]),
                 delta_p=float(side.set_index("outcome").loc[o, "delta_p"]),
                 previous_q=float(v3.set_index("outcome").loc[o, "q_BH_primary"]),
                 corrected_q=float(d.set_index("outcome").loc[o, "q_BH_primary"]),
                 claim_change=("UPHELD" if side.set_index("outcome").loc[o, "v3_fdr_pass"]
                               else "not established")
                 + " -> " + ("UPHELD" if d.set_index("outcome").loc[o, "fdr_pass"]
                             else "not established"))
            for o in d["outcome"]]).to_excel(w, sheet_name="CLAIM_STATUS_CHANGE", index=False)
        pd.DataFrame([
            dict(item="Corrected FDR-positive differences", value="%d of 9"
                 % int(d["fdr_pass"].sum())),
            dict(item="Previous FDR-positive differences", value="%d of 9"
                 % int(v3["fdr_pass"].sum())),
            dict(item="Smallest corrected P", value=float(d["p_rho0"].min())),
            dict(item="Smallest corrected q", value=float(d["q_BH_primary"].min())),
            dict(item="Outcomes whose claim status changed",
                 value="; ".join(sorted(side.loc[side["v3_fdr_pass"] != side["v31_fdr_pass"],
                                                  "outcome"]))),
        ]).to_excel(w, sheet_name="SUMMARY", index=False)
    return p


# ------------------------------------------------------------------ markdown -> docx
def md_to_docx(md_path, docx_path, title=None):
    from docx import Document
    from docx.shared import Pt, RGBColor
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10.5)
    lines = io.open(md_path, encoding="utf-8").read().splitlines()

    def add_runs(par, text):
        # split on **bold** and `code`
        for tok in re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
            if not tok:
                continue
            if tok.startswith("**") and tok.endswith("**"):
                r = par.add_run(tok[2:-2]); r.bold = True
            elif tok.startswith("`") and tok.endswith("`"):
                r = par.add_run(tok[1:-1]); r.font.name = "Consolas"
            else:
                par.add_run(tok)

    i = 0
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if not s:
            i += 1; continue
        if s.startswith("|") and i + 1 < len(lines) and set(lines[i + 1].strip()) <= set("|-: "):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not (set(lines[i].strip()) <= set("|-: ")):
                    rows.append(cells)
                i += 1
            if rows:
                t = doc.add_table(rows=0, cols=len(rows[0]))
                t.style = "Light Grid Accent 1"
                for ri, row in enumerate(rows):
                    cells = t.add_row().cells
                    for ci, c in enumerate(row[:len(rows[0])]):
                        cells[ci].text = ""
                        add_runs(cells[ci].paragraphs[0], c)
                        for r in cells[ci].paragraphs[0].runs:
                            r.font.size = Pt(8)
                            if ri == 0:
                                r.bold = True
            continue
        if s.startswith("#"):
            lvl = len(s) - len(s.lstrip("#"))
            h = doc.add_heading("", level=min(lvl, 4))
            add_runs(h, s.lstrip("#").strip())
        elif s.startswith(">"):
            add_runs(doc.add_paragraph(), s.lstrip("> ").strip())
        elif s.startswith("- ") or s.startswith("* "):
            add_runs(doc.add_paragraph(style="List Bullet"), s[2:])
        elif re.match(r"^\d+\.\s", s):
            add_runs(doc.add_paragraph(style="List Number"), re.sub(r"^\d+\.\s", "", s))
        elif s.startswith("---"):
            doc.add_paragraph("")
        else:
            add_runs(doc.add_paragraph(), s)
        i += 1
    if title:
        doc.core_properties.title = title
    doc.save(docx_path)
    return docx_path


def build_zip():
    out = os.path.join(SELF, "99_PACKAGE", "PCOS_ANM_V3_1_FINAL_AUDIT_PACKAGE.zip")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    include = ["00_README", "01_MANUSCRIPT", "02_ANALYSIS_PLAN", "03_RESULTS", "04_CODE",
               "05_FIGURES", "06_SUPPLEMENT", "07_PROVENANCE", "08_QC",
               "09_REVIEWER_SIMULATION", "10_INPUTS", "07_LOGS"]
    rows = []
    if os.path.exists(out):
        os.replace(out, out + ".prev")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for d in include:
            base = os.path.join(SELF, d)
            if not os.path.isdir(base):
                continue
            for root, dirs, files in os.walk(base):
                for fn in sorted(files):
                    p = os.path.join(root, fn)
                    if fn.endswith((".prev", ".pyc")):
                        continue
                    rel = os.path.relpath(p, SELF)
                    z.write(p, os.path.join("PCOS_ANM_V3_1_FINAL_AUDIT_PACKAGE", rel))
    return out


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def write_manifest(zpath):
    rows = []
    with zipfile.ZipFile(zpath) as z:
        for n in sorted(z.namelist()):
            if n.endswith("/"):
                continue
            data = z.read(n)
            rows.append(dict(path=n, bytes=len(data),
                             sha256=hashlib.sha256(data).hexdigest()))
    df = pd.DataFrame(rows)
    zdir = os.path.dirname(zpath)
    df.to_csv(os.path.join(zdir, "SHA256SUMS.txt"), sep="\t", index=False, lineterminator="\n")
    df.to_csv(os.path.join(zdir, "MANIFEST.tsv"), sep="\t", index=False, lineterminator="\n")
    return df, zpath


def main():
    p1 = build_scale_audit()
    print("built", os.path.basename(p1))
    # Word renderings
    for src, dst in [(os.path.join(MAN, "V3_1_manuscript.md"),
                      os.path.join(MAN, "V3_1_manuscript.docx")),
                     (os.path.join(SUPP, "Supplementary_Tables.md"),
                      os.path.join(SUPP, "Supplementary_Tables.docx")),
                     (os.path.join(SUPP, "Supplementary_Methods.md"),
                      os.path.join(SUPP, "Supplementary_Methods.docx")),
                     (os.path.join(SELF, "00_README", "README_FIRST.md"),
                      os.path.join(SELF, "00_README", "README_FIRST.docx"))]:
        try:
            md_to_docx(src, dst)
            print("built", os.path.basename(dst), os.path.getsize(dst), "bytes")
        except Exception as e:
            print("DOCX FAILED for", os.path.basename(src), e)
    zp = build_zip()
    print("zip:", zp, os.path.getsize(zp), "bytes")
    df, _ = write_manifest(zp)
    print("manifest rows:", len(df))
    zpaths = os.path.join(os.path.dirname(zp), "SHA256SUMS.txt")
    print("SHA256SUMS:", zpaths)
    return zp, df


if __name__ == "__main__":
    main()
