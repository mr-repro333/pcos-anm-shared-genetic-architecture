# -*- coding: utf-8 -*-
"""V3.1 PRIORITY 3 - make the package self-contained and say exactly what it does not contain.

WHAT WAS WRONG IN V3
--------------------
The V3 audit ZIP shipped code that reads

    E:\\PCOS_ANM_Genetic_Decoupling\\V2_2026\\06_HARMONIZED
    E:\\PCOS_ANM_Genetic_Decoupling\\05_INSTRUMENTS
    E:\\PCOS_ANM_Genetic_Decoupling\\09_COLOCALIZATION
    ... and so on

and none of those files were inside the ZIP. An auditor could read the scripts but could not
run them; "fully reproducible from the package" was therefore not a defensible statement.

WHAT V3.1 DOES
--------------
* Copies every input the shipped code actually reads into ``10_INPUTS/``, preserving the
  relative layout, and writes a manifest with source path, byte size and SHA-256 per file.
* Documents a single configurable root: ``PCOS_ANM_DATA_ROOT`` (default the original project
  root). ``bootstrap_data_root.py --restore <dir>`` materialises a working data root from
  ``10_INPUTS/`` alone, so the shipped code runs unchanged against the package.
* States explicitly what is deliberately NOT in the package (the multi-hundred-megabyte raw
  GWAS deposits) and why the headline numbers do not depend on them: every headline estimate
  is re-derived from the harmonised matrices, which ARE included.
* ``v31_smoke.py`` performs the clean-environment test. No "fully reproducible" claim is made
  anywhere until that test passes.
"""
import csv, hashlib, io, os, shutil, sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import (DATA_ROOT, RES, LOGD, INP, V2, V3, SELF, INS_V2, INS_ROOT, HARM_V2,
                      MRV2, COLOCC, V3_FSHB, V3_MVMR, V3_RES)

# (source path relative to DATA_ROOT, destination path relative to 10_INPUTS)
COPY_SPEC = [
    # ---- instruments: every design used in V3.1 inference -------------------------
    ("V2_2026/05_INSTRUMENTS", "V2_2026/05_INSTRUMENTS"),
    ("05_INSTRUMENTS/ANM_RUTH2021_instruments.tsv", "05_INSTRUMENTS/ANM_RUTH2021_instruments.tsv"),
    ("05_INSTRUMENTS/ANM_UKB_GCST90029037_instruments.tsv",
     "05_INSTRUMENTS/ANM_UKB_GCST90029037_instruments.tsv"),
    ("05_INSTRUMENTS/PCOS_ALL_GCST90570580_instruments.tsv",
     "05_INSTRUMENTS/PCOS_ALL_GCST90570580_instruments.tsv"),
    ("05_INSTRUMENTS/ANM_RUTH2021_harmonization_audit.csv",
     "05_INSTRUMENTS/ANM_RUTH2021_harmonization_audit.csv"),
    ("05_INSTRUMENTS/PCOS_ALL_GCST90570580_harmonization_audit.csv",
     "05_INSTRUMENTS/PCOS_ALL_GCST90570580_harmonization_audit.csv"),
    ("05_INSTRUMENTS/PCOS_EUR_GCST90570579_harmonization_audit.csv",
     "05_INSTRUMENTS/PCOS_EUR_GCST90570579_harmonization_audit.csv"),
    # ---- harmonised SNP matrices: the actual inputs to every headline estimate ----
    ("V2_2026/06_HARMONIZED", "V2_2026/06_HARMONIZED"),
    ("V3_2026/02_HARMONIZED", "V3_2026/02_HARMONIZED"),
    ("V2_2026/06_RAW_OUTCOMES/FSH_FEMALE.tsv", "V2_2026/06_RAW_OUTCOMES/FSH_FEMALE.tsv"),
    # ---- the MR master used to build the V3.1 results ----------------------------
    ("V2_2026/07_MR_RESULTS_V2", "V2_2026/07_MR_RESULTS_V2"),
    # ---- the V3 result files V3.1 consumes and compares against ------------------
    ("V3_2026/03_RESULTS", "V3_2026/03_RESULTS"),
    ("V3_2026/04_CODE/v3_core.py", "V3_2026/04_CODE/v3_core.py"),
    ("V3_2026/04_CODE/v3_diff.py", "V3_2026/04_CODE/v3_diff.py"),
    ("V3_2026/04_CODE/v3_domains.py", "V3_2026/04_CODE/v3_domains.py"),
    ("V3_2026/04_CODE/v3_hormonal_diff.py", "V3_2026/04_CODE/v3_hormonal_diff.py"),
    ("V3_2026/04_CODE/v3_coloc_power.py", "V3_2026/04_CODE/v3_coloc_power.py"),
    ("V3_2026/04_CODE/v3_hormones.py", "V3_2026/04_CODE/v3_hormones.py"),
    # ---- MVMR: the exact input matrices plus the tool source ---------------------
    ("V3_2026/08_MVMR_V3/_input", "V3_2026/08_MVMR_V3/_input"),
    ("15_CODE/tools/MVMR-master/R", "15_CODE/tools/MVMR-master/R"),
    # ---- colocalization: results and the regional extracts they were computed from -
    ("09_COLOCALIZATION/COLOC_RESULTS.tsv", "09_COLOCALIZATION/COLOC_RESULTS.tsv"),
    ("09_COLOCALIZATION/COLOC_PRIOR_SENSITIVITY.tsv",
     "09_COLOCALIZATION/COLOC_PRIOR_SENSITIVITY.tsv"),
    ("09_COLOCALIZATION/COLOC_PRUNED_SENSITIVITY.tsv",
     "09_COLOCALIZATION/COLOC_PRUNED_SENSITIVITY.tsv"),
    ("09_COLOCALIZATION/COLOC_PRUNED_VS_PRIMARY.tsv",
     "09_COLOCALIZATION/COLOC_PRUNED_VS_PRIMARY.tsv"),
    ("09_COLOCALIZATION/COLOC_PRUNE_SETS.tsv", "09_COLOCALIZATION/COLOC_PRUNE_SETS.tsv"),
    ("09_COLOCALIZATION/COLOC_EVIDENCE_TIERS.tsv",
     "09_COLOCALIZATION/COLOC_EVIDENCE_TIERS.tsv"),
    ("09_COLOCALIZATION/COLOC_REGION_DIAGNOSTICS.tsv",
     "09_COLOCALIZATION/COLOC_REGION_DIAGNOSTICS.tsv"),
    ("09_COLOCALIZATION/COLOC_LEAD_SIGN_CONCORDANCE.tsv",
     "09_COLOCALIZATION/COLOC_LEAD_SIGN_CONCORDANCE.tsv"),
    ("09_COLOCALIZATION/MULTISIGNAL_SCREEN.tsv", "09_COLOCALIZATION/MULTISIGNAL_SCREEN.tsv"),
    ("09_COLOCALIZATION/LOCUS_GENE_ANNOTATION.tsv",
     "09_COLOCALIZATION/LOCUS_GENE_ANNOTATION.tsv"),
    ("09_COLOCALIZATION/REGION_QC.tsv", "09_COLOCALIZATION/REGION_QC.tsv"),
    ("09_COLOCALIZATION/regions", "09_COLOCALIZATION/regions"),
    # ---- FSHB: the inputs behind the withdrawn fine-mapping attempt ---------------
    ("V3_2026/09_FSHB", "V3_2026/09_FSHB"),
    # ---- LDSC ---------------------------------------------------------------------
    ("16_LOGS/ldsc_rg.log", "16_LOGS/ldsc_rg.log"),
    ("16_LOGS/ldsc_munge_PCOS_EUR.log", "16_LOGS/ldsc_munge_PCOS_EUR.log"),
    ("16_LOGS/ldsc_munge_ANM_RUTH2021.log", "16_LOGS/ldsc_munge_ANM_RUTH2021.log"),
    ("V3_2026/07_PROVENANCE/LDSC_RG_PCOS_ANM.log",
     "V3_2026/07_PROVENANCE/LDSC_RG_PCOS_ANM.log"),
]

# Inputs the code needs that are NOT shipped, with the reason and the accession.
NOT_SHIPPED = [
    dict(item="Raw PCOS GCST90570579 / GCST90570580 / GCST90483500 full summary statistics",
         approx_size="hundreds of MB",
         why_not="the harmonised instrument+outcome matrices derived from them are included, "
                 "so every headline estimate is re-derivable without them",
         where_to_get="GWAS Catalog, accession as named"),
    dict(item="Raw ANM Ruth 2021 and GCST90029037 full summary statistics",
         approx_size="hundreds of MB",
         why_not="as above - the harmonised matrices are included",
         where_to_get="reprogen.org (Ruth 2021); GWAS Catalog GCST90029037"),
    dict(item="Raw LH deposit GCST90483478 (V3_2026/01_RAW_NEW/GCST90483478.h.tsv.gz)",
         approx_size="108 MB",
         why_not="the harmonised regional hormone matrix is included; only whole-file "
                 "re-extraction needs the raw deposit",
         where_to_get="GWAS Catalog GCST90483478"),
    dict(item="SHBG GCST90012107 (Ruth 2020) harmonised release",
         approx_size="641 MB, no tabix index published",
         why_not="never retrieved - retrieval failed; see the endpoint accounting",
         where_to_get="EBI GWAS Catalog harmonised release (no .tbi index available)"),
    dict(item="1000 Genomes Phase 3 EUR reference panel (n = 489)",
         approx_size="~1 GB",
         why_not="used for clumping and reference LD only; the resulting instrument sets and "
                 "LD matrices are included",
         where_to_get="1000 Genomes Phase 3, EUR superpopulation"),
]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_spec():
    rows = []
    for src_rel, dst_rel in COPY_SPEC:
        src = os.path.join(DATA_ROOT, src_rel)
        dst = os.path.join(INP, dst_rel)
        if not os.path.exists(src):
            rows.append(dict(source_relpath=src_rel, dest_relpath=dst_rel, status="MISSING AT SOURCE",
                             n_files=0, bytes=0))
            continue
        if os.path.isdir(src):
            os.makedirs(dst, exist_ok=True)
            n = b = 0
            for root, dirs, files in os.walk(src):
                for fn in files:
                    s = os.path.join(root, fn)
                    r = os.path.relpath(s, src)
                    t = os.path.join(dst, r)
                    os.makedirs(os.path.dirname(t), exist_ok=True)
                    if (not os.path.exists(t)) or os.path.getsize(t) != os.path.getsize(s):
                        shutil.copy2(s, t)
                    n += 1; b += os.path.getsize(s)
            rows.append(dict(source_relpath=src_rel, dest_relpath=dst_rel, status="COPIED",
                             n_files=n, bytes=b))
        else:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            rows.append(dict(source_relpath=src_rel, dest_relpath=dst_rel, status="COPIED",
                             n_files=1, bytes=os.path.getsize(src)))
    return pd.DataFrame(rows)


def inventory():
    rows = []
    for root, dirs, files in os.walk(INP):
        for fn in sorted(files):
            p = os.path.join(root, fn)
            rows.append(dict(relative_path_in_package=os.path.join(
                "10_INPUTS", os.path.relpath(p, INP)).replace("\\", "/"),
                bytes=os.path.getsize(p), sha256=sha256(p)))
    return pd.DataFrame(rows).sort_values("relative_path_in_package")


def main():
    log = io.open(os.path.join(LOGD, "v31_provenance.log"), "w", encoding="utf-8")

    def L(*a):
        log.write(" ".join(str(x) for x in a) + "\n"); log.flush()

    spec = copy_spec()
    inv = inventory()
    spec.to_csv(os.path.join(RES, "V3_1_INPUT_COPY_SPEC.tsv"), sep="\t", index=False)
    inv.to_csv(os.path.join(RES, "V3_1_INPUT_MANIFEST.tsv"), sep="\t", index=False)
    pd.DataFrame(NOT_SHIPPED).to_csv(os.path.join(RES, "V3_1_NOT_SHIPPED_AND_WHY.tsv"),
                                     sep="\t", index=False)

    total = int(inv["bytes"].sum())
    L("=== copy spec ===")
    L(spec.to_string(index=False))
    L("\n=== inventory: %d files, %.2f MB ===" % (len(inv), total / 1e6))
    L(inv.head(15).to_string(index=False))
    L("\n=== deliberately not shipped ===")
    L(pd.DataFrame(NOT_SHIPPED)[["item", "approx_size"]].to_string(index=False))
    log.close()

    print(spec.to_string(index=False))
    print("\ninventory: %d files, %.2f MB" % (len(inv), total / 1e6))
    missing = spec[spec["status"] != "COPIED"]
    if len(missing):
        print("\nMISSING AT SOURCE:")
        print(missing.to_string(index=False))
    return spec, inv


if __name__ == "__main__":
    main()
