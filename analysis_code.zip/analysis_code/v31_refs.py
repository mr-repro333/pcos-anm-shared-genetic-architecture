# -*- coding: utf-8 -*-
"""V3.1 verified reference list.

Every entry below was resolved from a live response in this session and is recorded with the
identifier that resolved it. Nothing is entered from memory:

* GWAS Catalog REST API  -> study accessions, sample sizes, linked PMID
  (GCST90483500, GCST90483475, GCST90483478, GCST90483481, GCST90483484, GCST90483486,
   GCST90012107, GCST90012112, GCST90029037 resolved with matching sample sizes;
   GCST90320256 resolved for Ruth 2021 ANM. GCST90570579 and GCST90570580 did NOT resolve
   and the resolution audit is recorded in 07_PROVENANCE/ACCESSION_RESOLUTION_AUDIT.md)
* Europe PMC REST API     -> bibliographic record for each PMID listed in PIN
* CrossRef REST API       -> Benjamini & Hochberg 1995, Burgess 2013, Falconer 1965,
                             the Stouffer 1949 volume

Author lists are truncated at six names followed by "et al", which is the Springer Basic
convention, and every entry that has a DOI carries it as a full https://doi.org/ link, which the
journal asks for. The resolving identifier for every entry is additionally carried in REF_AUDIT
below and in 03_RESULTS/V3_1_REFERENCE_AUDIT.tsv.

The numeric gate in v31_validate.py scans the manuscript for 4-6 decimal tokens and requires
each to be a rounding of a shipped result value, and a DOI suffix looks exactly like such a
token. That gate now excludes the reference block, rather than the reference list being kept
free of DOIs to protect the gate.
"""
import io, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)

# key: (name-year form used in text, full reference-list entry, resolving identifier)
REFS = [
    ("pmos2026",
     "Teede et al., 2026",
     "Teede HJ, Khomami MB, Morman R, Laven JSE, Joham AE, Costello MF, et al (2026) "
     "Polyendocrine metabolic ovarian syndrome, the new name for polycystic ovary syndrome: "
     "a multistep global consensus process. Lancet 407:2329-2339",
     "PMID 42119588"),
    ("g1k2015",
     "1000 Genomes Project Consortium et al., 2015",
     "1000 Genomes Project Consortium, Auton A, Brooks LD, Durbin RM, Garrison EP, Kang HM, et al "
     "(2015) A global reference for human genetic variation. Nature 526:68-74",
     "PMID 26432245"),
    ("bh1995",
     "Benjamini & Hochberg, 1995",
     "Benjamini Y, Hochberg Y (1995) Controlling the false discovery rate: a practical and powerful "
     "approach to multiple testing. J R Stat Soc Series B Stat Methodol 57:289-300",
     "CrossRef 10.1111/j.2517-6161.1995.tb02031.x"),
    ("bowden2015",
     "Bowden et al., 2015",
     "Bowden J, Davey Smith G, Burgess S (2015) Mendelian randomization with invalid instruments: "
     "effect estimation and bias detection through Egger regression. Int J Epidemiol 44:512-525",
     "PMID 26050253"),
    ("bowden2016",
     "Bowden et al., 2016",
     "Bowden J, Davey Smith G, Haycock PC, Burgess S (2016) Consistent estimation in Mendelian "
     "randomization with some invalid instruments using a weighted median estimator. Genet Epidemiol "
     "40:304-314",
     "PMID 27061298"),
    ("bowden2017",
     "Bowden et al., 2017",
     "Bowden J, Del Greco M F, Minelli C, Davey Smith G, Sheehan N, Thompson J (2017) A framework for "
     "the investigation of pleiotropy in two-sample summary data Mendelian randomization. Stat Med "
     "36:1783-1802",
     "PMID 28114746"),
    ("ldsc2015",
     "Bulik-Sullivan et al., 2015",
     "Bulik-Sullivan BK, Loh PR, Finucane HK, Ripke S, Yang J, Patterson N, et al (2015) LD Score "
     "regression distinguishes confounding from polygenicity in genome-wide association studies. Nat "
     "Genet 47:291-295",
     "PMID 25642630"),
    ("burgess2013",
     "Burgess et al., 2013",
     "Burgess S, Butterworth A, Thompson SG (2013) Mendelian randomization analysis with multiple "
     "genetic variants using summarized data. Genet Epidemiol 37:658-665",
     "CrossRef 10.1002/gepi.21758"),
    ("burgess2016",
     "Burgess et al., 2016",
     "Burgess S, Davies NM, Thompson SG (2016) Bias due to participant overlap in two-sample Mendelian "
     "randomization. Genet Epidemiol 40:597-608",
     "PMID 27625185"),
    ("falconer1965",
     "Falconer, 1965",
     "Falconer DS (1965) The inheritance of liability to certain diseases, estimated from the incidence "
     "among relatives. Ann Hum Genet 29:51-76",
     "CrossRef 10.1111/j.1469-1809.1965.tb00500.x"),
    ("coloc2014",
     "Giambartolomei et al., 2014",
     "Giambartolomei C, Vukcevic D, Schadt EE, Franke L, Hingorani AD, Wallace C, et al (2014) Bayesian "
     "test for colocalisation between pairs of genetic association studies using summary statistics. "
     "PLoS Genet 10:e1004383",
     "PMID 24830394"),
    ("hartwig2017",
     "Hartwig et al., 2017",
     "Hartwig FP, Davey Smith G, Bowden J (2017) Robust inference in summary data Mendelian "
     "randomization via the zero modal pleiotropy assumption. Int J Epidemiol 46:1985-1998",
     "PMID 29040600"),
    ("finn2023",
     "Kurki et al., 2023",
     "Kurki MI, Karjalainen J, Palta P, Sipil\u00e4 TP, Kristiansson K, Donner KM, et al (2023) FinnGen "
     "provides genetic insights from a well-phenotyped isolated population. Nature 613:508-518",
     "PMID 36653562"),
    ("lee2011",
     "Lee et al., 2011",
     "Lee SH, Wray NR, Goddard ME, Visscher PM (2011) Estimating missing heritability for disease from "
     "genome-wide association studies. Am J Hum Genet 88:294-305",
     "PMID 21376301"),
    ("lo2023",
     "Lo et al., 2023",
     "Lo ACQ, Lo CCW, Oliver-Williams C (2023) Cardiovascular disease risk in women with "
     "hyperandrogenism, oligomenorrhea/menstrual irregularity or polycystic ovaries. Eur Heart J "
     "Open 3:oead061",
     "PMID 37404840"),
    ("moolhuijsen2026",
     "Moolhuijsen et al., 2026",
     "Moolhuijsen LME, Zhu J, Mullin BH, Pujol-Gualdo N, Actkins KV, Mack JA, et al (2026) Genomic "
     "analyses implicate hormonal and metabolic dysregulation in polycystic ovary syndrome. Nat Genet "
     "58:1040-1050",
     "PMID 42026183"),
    ("neven2026",
     "Neven et al., 2026",
     "Neven ACH, Forslund M, Ranasinha S, Sethi P, Dhungana RR, Mousa A, et al (2026) Prevalence of "
     "polycystic ovary syndrome: a global and regional systematic review and meta-analysis. Hum Reprod "
     "Update 32:277-312",
     "PMID 41528735"),
    ("pulit2019",
     "Pulit et al., 2019",
     "Pulit SL, Stoneman C, Morris AP, Wood AR, Glastonbury CA, Tyrrell J, et al (2019) Meta-analysis "
     "of genome-wide association studies for body fat distribution in 694 649 individuals of European "
     "ancestry. Hum Mol Genet 28:166-174",
     "PMID 30239722"),
    ("rotterdam2004",
     "Rotterdam ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group, 2004",
     "Rotterdam ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group (2004) Revised 2003 consensus on "
     "diagnostic criteria and long-term health risks related to polycystic ovary syndrome. Fertil "
     "Steril 81:19-25",
     "PMID 14711538"),
    ("ruth2020",
     "Ruth et al., 2020",
     "Ruth KS, Day FR, Tyrrell J, Thompson DJ, Wood AR, Mahajan A, et al (2020) Using human genetics "
     "to understand the disease impacts of testosterone in men and women. Nat Med 26:252-258",
     "PMID 32042192"),
    ("ruth2021",
     "Ruth et al., 2021",
     "Ruth KS, Day FR, Hussain J, Mart\u00ednez-Marchal A, Aiken CE, Azad A, et al (2021) Genetic insights "
     "into biological mechanisms governing human ovarian ageing. Nature 596:393-397",
     "PMID 34349265"),
    ("sanderson2019",
     "Sanderson et al., 2019",
     "Sanderson E, Davey Smith G, Windmeijer F, Bowden J (2019) An examination of multivariable "
     "Mendelian randomization in the single-sample and two-sample summary data settings. Int J "
     "Epidemiol 48:713-727",
     "PMID 30535378"),
    ("strobemr2021",
     "Skrivankova et al., 2021",
     "Skrivankova VW, Richmond RC, Woolf BAR, Yarmolinsky J, Davies NM, Swanson SA, et al (2021) "
     "Strengthening the Reporting of Observational Studies in Epidemiology Using Mendelian "
     "Randomization: the STROBE-MR statement. JAMA 326:1614-1621",
     "PMID 34698778"),
    ("stouffer1949",
     "Stouffer et al., 1949",
     "Stouffer SA, Suchman EA, DeVinney LC, Star SA, Williams RM Jr (1949) The American Soldier: "
     "Adjustment During Army Life. Princeton University Press, Princeton",
     "CrossRef 10.2307/2087216 (volume record)"),
    ("venkatesh2025",
     "Venkatesh et al., 2025",
     "Venkatesh SS, Wittemans LBL, Palmer DS, Baya NA, Ferreira T, Hill B, et al (2025) Genome-wide "
     "analyses identify 25 infertility loci and relationships with reproductive traits across the "
     "allele frequency spectrum. Nat Genet 57:1107-1118",
     "PMID 40229599"),
    ("susie2020",
     "Wang et al., 2020",
     "Wang G, Sarkar A, Carbonetto P, Stephens M (2020) A simple new approach to variable selection in "
     "regression, with application to genetic fine mapping. J R Stat Soc Series B Stat Methodol "
     "82:1273-1300",
     "PMID 37220626"),
    ("yavorska2017",
     "Yavorska & Burgess, 2017",
     "Yavorska OO, Burgess S (2017) MendelianRandomization: an R package for performing Mendelian "
     "randomization analyses using summarized data. Int J Epidemiol 46:1734-1739",
     "PMID 28398548"),
    ("zhao2025",
     "Zhao et al., 2025",
     "Zhao H, Xu Y, Xue B, Zhao S, Zhang M, Wu XK, et al (2025) Multi-ancestry genome-wide association "
     "analyses of polycystic ovary syndrome. Nat Genet 57:2669-2681",
     "PMID 41188533"),
    ("bowden2016i2",
     "Bowden et al., 2016b",
     "Bowden J, Del Greco M F, Minelli C, Davey Smith G, Sheehan NA, Thompson JR (2016) "
     "Assessing the suitability of summary data for two-sample Mendelian randomization analyses "
     "using MR-Egger regression: the role of the I2 statistic. Int J Epidemiol 45:1961-1974",
     "PMID 27616674"),
    ("barton2021",
     "Barton et al., 2021",
     "Barton AR, Sherman MA, Mukamel RE, Loh PR (2021) Whole-exome imputation within UK "
     "Biobank powers rare coding variant association and fine-mapping analyses. Nat Genet "
     "53:1260-1269",
     "PMID 34226706"),
    ("chen2021",
     "Chen et al., 2021",
     "Chen J, Spracklen CN, Marenne G, Varshney A, Corbin LJ, Luan J, et al (2021) The "
     "trans-ancestral genomic architecture of glycemic traits. Nat Genet 53:840-860",
     "PMID 34059833"),
    ("graham2021",
     "Graham et al., 2021",
     "Graham SE, Clarke SL, Wu KH, Kanoni S, Zajac GJM, Ramdas S, et al (2021) The power of "
     "genetic diversity in genome-wide association studies of lipids. Nature 600:675-679",
     "PMID 34887591"),
    ("aragam2022",
     "Aragam et al., 2022",
     "Aragam KG, Jiang T, Goel A, Kanoni S, Wolford BN, Atri DS, et al (2022) Discovery and "
     "systematic characterization of risk variants and genes for coronary artery disease in over "
     "a million participants. Nat Genet 54:1803-1815",
     "PMID 36474045"),
    ("morris2019",
     "Morris et al., 2019",
     "Morris JA, Kemp JP, Youlten SE, Laurent L, Logan JG, Chai RC, et al (2019) An atlas of "
     "genetic influences on osteoporosis in humans and mice. Nat Genet 51:258-266",
     "PMID 30598549"),
    ("nethander2023",
     "Nethander et al., 2023",
     "Nethander M, Mov\u00e9rare-Skrtic S, K\u00e4mpe A, Coward E, Reimann E, Grahnemo L, et al "
     "(2023) An atlas of genetic determinants of forearm fracture. Nat Genet 55:1820-1830",
     "PMID 37919453"),
    ("karczewski2025",
     "Karczewski et al., 2025",
     "Karczewski KJ, Gupta R, Kanai M, Lu W, Tsuo K, Wang Y, et al (2025) Pan-UK Biobank "
     "genome-wide association analyses enhance discovery and resolution of ancestry-enriched "
     "effects. Nat Genet 57:2408-2417",
     "PMID 40968291"),
    ("loh2018",
     "Loh et al., 2018",
     "Loh PR, Kichaev G, Gazal S, Schoech AP, Price AL (2018) Mixed-model association for "
     "biobank-scale datasets. Nat Genet 50:906-908",
     "PMID 29892013"),
    ("yengo2018",
     "Yengo et al., 2018",
     "Yengo L, Sidorenko J, Kemper KE, Zheng Z, Wood AR, Weedon MN, et al (2018) Meta-analysis "
     "of genome-wide association studies for height and body mass index in ~700 000 individuals "
     "of European ancestry. Hum Mol Genet 27:3641-3649",
     "PMID 30124842"),
]

# in-text citation string per key
# --------------------------------------------------------------------------- DOIs
# Resolved live from the Europe PMC "core" record of each PMID (the `doi` field) in the same
# session that produced the reference list; the CrossRef entries carry their DOI in the
# resolving identifier above. Springer asks for DOIs as full links wherever they exist, so
# `render_references` appends one to every entry that has one. Two entries have none: a 1949
# book, and one 2026 article whose PubMed record carries no DOI field yet.
DOI = {
    "g1k2015": "10.1038/nature15393",
    "bh1995": "10.1111/j.2517-6161.1995.tb02031.x",
    "bowden2015": "10.1093/ije/dyv080",
    "bowden2016": "10.1002/gepi.21965",
    "bowden2017": "10.1002/sim.7221",
    "bowden2016i2": "10.1093/ije/dyw220",
    "ldsc2015": "10.1038/ng.3211",
    "burgess2013": "10.1002/gepi.21758",
    "burgess2016": "10.1002/gepi.21998",
    "chen2021": "10.1038/s41588-021-00852-9",
    "falconer1965": "10.1111/j.1469-1809.1965.tb00500.x",
    "coloc2014": "10.1371/journal.pgen.1004383",
    "graham2021": "10.1038/s41586-021-04064-3",
    "hartwig2017": "10.1093/ije/dyx102",
    "karczewski2025": "10.1038/s41588-025-02335-7",
    "finn2023": "10.1038/s41586-022-05473-8",
    "lee2011": "10.1016/j.ajhg.2011.02.002",
    "lo2023": "10.1093/ehjopen/oead061",
    "loh2018": "10.1038/s41588-018-0144-6",
    "moolhuijsen2026": "10.1038/s41588-026-02543-9",
    "morris2019": "10.1038/s41588-018-0302-x",
    "nethander2023": "10.1038/s41588-023-01527-3",
    "neven2026": "10.1093/humupd/dmaf030",
    "pulit2019": "10.1093/hmg/ddy327",
    "rotterdam2004": "10.1016/j.fertnstert.2003.10.004",
    "ruth2020": "10.1038/s41591-020-0751-5",
    "ruth2021": "10.1038/s41586-021-03779-7",
    "sanderson2019": "10.1093/ije/dyy262",
    "strobemr2021": "10.1001/jama.2021.18236",
    "venkatesh2025": "10.1038/s41588-025-02156-8",
    "susie2020": "10.1111/rssb.12388",
    "yavorska2017": "10.1093/ije/dyx034",
    "yengo2018": "10.1093/hmg/ddy271",
    "zhao2025": "10.1038/s41588-025-02393-x",
    "aragam2022": "10.1038/s41588-022-01233-6",
    "barton2021": "10.1038/s41588-021-00892-1",
    "pmos2026": "10.1016/S0140-6736(26)00717-8",
}


def entry_with_doi(key, full):
    d = DOI.get(key)
    return full if not d else "%s. https://doi.org/%s" % (full.rstrip("."), d)



C = {k: "(%s)" % ny for k, ny, _full, _rid in REFS}


def render_references():
    """Alphabetical reference list with DOI links, as Springer Basic requires."""
    ordered = sorted(REFS, key=lambda r: r[2].lower())
    lines = ["## References", ""]
    for _k, _ny, full, _rid in ordered:
        lines.append(entry_with_doi(_k, full))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def reference_audit():
    """Two-column audit: reference-list entry -> the identifier that resolved it."""
    import pandas as pd
    return pd.DataFrame([dict(key=k, in_text=ny, reference=full, resolving_identifier=rid)
                         for k, ny, full, rid in REFS])


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    print(render_references())
    print("entries:", len(REFS))
