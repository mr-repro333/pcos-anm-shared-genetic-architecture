# -*- coding: utf-8 -*-
"""V3.1 PRIORITY 3 - the clean-environment smoke test.

The rule V3.1 holds itself to: no "fully reproducible from the package" claim until this
test passes.

What it does
------------
1. Creates a fresh temporary directory and restores DATA_ROOT there from ``10_INPUTS/``
   alone (no access to the original project tree).
2. Runs the shipped analysis modules with ``PCOS_ANM_DATA_ROOT`` pointed at that temporary
   root and ``PCOS_ANM_V31_OUT`` pointed at a fresh output directory, so nothing in the
   shipped package is touched.
3. Compares every file the rerun produces against the shipped file of the same name:
   byte-for-byte where the file is text, and numerically for the result tables.
4. Runs the unit test and reports per-module PASS/FAIL.

Exit code 0 means every module reproduced. Any mismatch is printed with the first
differing field, and the exit code is non-zero.
"""
import csv, io, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
SHIPPED_RES = os.path.join(PKG, "03_RESULTS")
PY = sys.executable

MODULES = ["v31_diff.py", "v31_domains.py", "v31_hormonal.py", "v31_fshb.py",
           "v31_harmonization.py", "v31_harmone_rule_sensitivity.py",
           "v31_multiplier_audit.py", "v31_master.py", "v31_claims.py"]
# files each module is expected to (re)produce in 03_RESULTS
EXPECT = {
    "v31_diff.py": ["V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv",
                    "V3_1_SCALE_CORRECTION_SIDE_BY_SIDE.tsv",
                    "V3_1_RHO_SENSITIVITY_GRID.tsv",
                    "V3_1_PREVALENCE_SENSITIVITY.tsv",
                    "V3_1_SD_ANM_SENSITIVITY.tsv",
                    "V3_1_POWER_MDE_CORRECTED.tsv",
                    "V3_1_DIFFERENCE_ALTERNATIVES_SENSITIVITY.tsv"],
    "v31_domains.py": ["V3_1_SKELETAL_EVIDENCE.xlsx"],
    "v31_hormonal.py": ["V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv",
                        "V3_1_HORMONAL_ENDPOINT_ACCOUNTING.tsv"],
    "v31_fshb.py": ["V3_1_FSHB_EVIDENCE_AUDIT.xlsx"],
    "v31_harmonization.py": ["V3_1_INSTRUMENT_PROVENANCE.tsv",
                             "V3_1_HARMONIZATION_AUDIT_RECOUNT.tsv"],
    "v31_harmone_rule_sensitivity.py": ["V3_1_HORMONE_RULE_SENSITIVITY_DIFFERENCES.tsv"],
    "v31_multiplier_audit.py": ["V3_1_MULTIPLIER_SITE_REGISTER.tsv",
                                "V3_1_MULTIPLIER_USE_AUDIT.tsv"],
    "v31_master.py": ["V3_1_MASTER_RESULTS_long.tsv"],
    "v31_claims.py": ["V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"],
}
NUMTOL = 1e-9


def numeric_diff(a, b):
    """Return '' if the two TSVs agree, else a description of the first difference."""
    try:
        with io.open(a, encoding="utf-8") as f1, io.open(b, encoding="utf-8") as f2:
            r1 = list(csv.reader(f1, delimiter="\t"))
            r2 = list(csv.reader(f2, delimiter="\t"))
    except Exception as e:
        return "unreadable: %s" % e
    if len(r1) != len(r2):
        return "row count %d vs %d" % (len(r1), len(r2))
    for i, (x, y) in enumerate(zip(r1, r2)):
        if len(x) != len(y):
            return "row %d column count %d vs %d" % (i, len(x), len(y))
        for j, (u, v) in enumerate(zip(x, y)):
            if u == v:
                continue
            try:
                if abs(float(u) - float(v)) <= NUMTOL:
                    continue
            except Exception:
                pass
            return "row %d col %d: %r vs %r" % (i, j, u[:40], v[:40])
    return ""


def xlsx_diff(a, b):
    """Compare two workbooks sheet by sheet on cell values (xlsx bytes are not stable)."""
    import pandas as pd
    try:
        xa = pd.read_excel(a, sheet_name=None)
        xb = pd.read_excel(b, sheet_name=None)
    except Exception as e:
        return "unreadable: %s" % e
    if sorted(xa) != sorted(xb):
        return "sheets %s vs %s" % (sorted(xa), sorted(xb))
    for k in xa:
        da, db = xa[k].fillna(""), xb[k].fillna("")
        if list(da.columns) != list(db.columns):
            return "%s columns differ" % k
        if len(da) != len(db):
            return "%s rows %d vs %d" % (k, len(da), len(db))
        for c in da.columns:
            sa = da[c].astype(str).tolist(); sb = db[c].astype(str).tolist()
            if sa != sb:
                for u, v in zip(sa, sb):
                    if u != v:
                        return "%s[%s]: %r vs %r" % (k, c, u[:50], v[:50])
    return ""


def main():
    tmp = tempfile.mkdtemp(prefix="v31_smoke_")
    root = os.path.join(tmp, "DATA_ROOT")
    out = os.path.join(tmp, "OUT")
    os.makedirs(root, exist_ok=True)
    os.makedirs(out, exist_ok=True)
    print("smoke root : %s" % root)
    print("smoke out  : %s" % out)

    r = subprocess.run([PY, os.path.join(HERE, "bootstrap_data_root.py"), "--restore", root],
                       capture_output=True, text=True)
    print(r.stdout.strip() or r.stderr.strip())
    if r.returncode != 0:
        print("BOOTSTRAP FAILED"); return 2

    env = dict(os.environ, PCOS_ANM_DATA_ROOT=root, PCOS_ANM_V31_OUT=out)
    results = []

    # unit test first
    ut = subprocess.run([PY, os.path.join(HERE, "test_scale_reciprocity.py")],
                        capture_output=True, text=True, env=env)
    results.append(("test_scale_reciprocity.py", ut.returncode == 0,
                    "ALL CHECKS PASSED" if ut.returncode == 0 else ut.stdout[-300:]))

    # the covariance-bound sensitivity uses the MVMR package itself, so the smoke test runs it
    rscript = r"C://Program Files//R//R-4.6.0//bin//Rscript.exe"
    if os.path.exists(rscript):
        pr = subprocess.run([rscript, os.path.join(HERE,
                                                   "v31_mvmr_covariance_sensitivity.R")],
                            capture_output=True, text=True, env=env, cwd=HERE)
        a = os.path.join(SHIPPED_RES, "V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv")
        b = os.path.join(out, "03_RESULTS", "V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv")
        if pr.returncode != 0:
            results.append(("v31_mvmr_covariance_sensitivity.R", False,
                            "exit %d: %s" % (pr.returncode, pr.stderr[-200:])))
        elif not os.path.exists(b):
            results.append(("v31_mvmr_covariance_sensitivity.R", False, "no output file"))
        else:
            dd = numeric_diff(a, b)
            results.append(("v31_mvmr_covariance_sensitivity.R", not dd,
                            dd or "reproduced"))
    else:
        results.append(("v31_mvmr_covariance_sensitivity.R", False,
                        "Rscript not found at %s" % rscript))

    for m in MODULES:
        p = subprocess.run([PY, os.path.join(HERE, m)], capture_output=True, text=True, env=env)
        if p.returncode != 0:
            results.append((m, False, "exit %d: %s" % (p.returncode, p.stderr[-300:])))
            continue
        bad = []
        for fn in EXPECT.get(m, []):
            a = os.path.join(SHIPPED_RES, fn)
            b = os.path.join(out, "03_RESULTS", fn)
            if not os.path.exists(b):
                bad.append("%s NOT PRODUCED" % fn); continue
            if fn.endswith(".xlsx"):
                d = xlsx_diff(a, b)
                if d:
                    bad.append("%s: %s" % (fn, d))
                continue
            d = numeric_diff(a, b)
            if d:
                bad.append("%s: %s" % (fn, d))
        results.append((m, not bad, "; ".join(bad) if bad else "reproduced"))

    # manifest self-consistency
    chk = subprocess.run([PY, os.path.join(HERE, "bootstrap_data_root.py"), "--check", root],
                         capture_output=True, text=True)
    results.append(("bootstrap --check", chk.returncode == 0, chk.stdout.strip().splitlines()[0]
                    if chk.stdout.strip() else chk.stderr.strip()[-200:]))

    w = io.open(os.path.join(PKG, "08_QC", "V3_1_CLEAN_ENV_SMOKE_TEST.md"), "w",
                encoding="utf-8")
    w.write("# V3.1 clean-environment smoke test\n\n")
    w.write("A fresh temporary data root was materialised from `10_INPUTS/` alone and every\n"
            "shipped analysis module was re-run against it with a fresh output directory.\n"
            "Each produced result file was then compared with the shipped file of the same\n"
            "name: text tables field by field with a 1e-9 numeric tolerance, workbooks by\n"
            "byte size.\n\n")
    w.write("| step | result | detail |\n|---|---|---|\n")
    for name, ok, detail in results:
        w.write("| `%s` | %s | %s |\n" % (name, "PASS" if ok else "**FAIL**", detail))
    npass = sum(1 for _, ok, _ in results if ok)
    w.write("\n**%d of %d steps passed.**\n\n" % (npass, len(results)))
    w.write("The \"fully reproducible from the package\" statement is allowed only while this\n"
            "table is all-PASS. If any row fails, the correct claim is the weaker one: the\n"
            "package contains the inputs, but a specific module did not reproduce.\n")
    w.close()

    print("\n%-34s %s" % ("step", "result"))
    for name, ok, detail in results:
        print("%-34s %-5s %s" % (name, "PASS" if ok else "FAIL", detail))
    print("\n%d of %d steps passed" % (npass, len(results)))
    print("wrote 08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md")
    return 0 if npass == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
