# -*- coding: utf-8 -*-
"""V3.1 - the fail-closed final audit.

Every check below is a gate. A single FAIL means the package is not ready, and the specific
gate that failed is named. There is no "warning" tier: a check either passes or it does not.

The gates are grouped by what they protect:

A. SCOPE      - no new outcome, endpoint, instrument, family member or estimator was added.
B. P0 SCALE   - the reciprocal conversion is applied consistently and nowhere is the wrong
                direction used on an MR ratio.
C. P1 SIGNED  - the Stouffer combination is signed and the V3 unsigned values are retained
                only as comparison.
D. P2 MVMR    - the covariance is bounded, not asserted, and no direct effect is claimed.
E. P3 AUDIT   - inputs shipped, manifest complete, smoke test green.
F. FAIL-CLOSED- the corrected family reports zero and the manuscript says zero.
G. CLAIMS     - the claim matrix is graded from corrected numbers, with the required
                withdrawals present and the required safe-for-abstract count.
H. NUMBERS    - every headline number in the manuscript appears in a shipped result file.
I. NARRATIVE  - the banned phrasings do not appear as assertions.
J. PRESENTATION - journal presentation limits and the round-1 document rebuild.
"""
import hashlib, io, json, os, re, sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, LOGD, SELF, PREV_PRIMARY, SD_ANM_PRIMARY, liability_multiplier, PANEL9

MAN = os.path.join(SELF, "01_MANUSCRIPT", "V3_1_manuscript.md")
SUPP = os.path.join(SELF, "06_SUPPLEMENT")
RMS = os.path.join(SELF, "00_README")
QC = os.path.join(SELF, "08_QC")
PLAN = os.path.join(SELF, "02_ANALYSIS_PLAN")
INP = os.path.join(SELF, "10_INPUTS")

GATES = []


def gate(group, name, ok, detail=""):
    GATES.append(dict(group=group, gate=name, result="PASS" if ok else "FAIL", detail=detail))
    return ok


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def main():
    man = io.open(MAN, encoding="utf-8").read()
    d = pd.read_csv(os.path.join(RES, "V3_1_DIFFERENCE_PRIMARY9_CORRECTED.tsv"), sep="\t")
    d3 = pd.read_csv(os.path.join(RES, "V3_1_DIFFERENCE_PRIMARY9_V3METHOD_COMPARATOR.tsv"),
                     sep="\t")
    hor = pd.read_csv(os.path.join(RES, "V3_1_HORMONAL_DIFFERENCE_CORRECTED.tsv"), sep="\t")
    mde = pd.read_csv(os.path.join(RES, "V3_1_POWER_MDE_CORRECTED.tsv"), sep="\t")
    sk = pd.read_excel(os.path.join(RES, "V3_1_SKELETAL_EVIDENCE.xlsx"),
                       sheet_name="DOMAIN_SUMMARY").set_index("exposure_design")
    acct = pd.read_csv(os.path.join(RES, "V3_1_HORMONAL_ENDPOINT_ACCOUNTING.tsv"), sep="\t")
    claims = pd.read_excel(os.path.join(RES, "V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"),
                           sheet_name="CLAIM_EVIDENCE_MATRIX_V31")
    chg = pd.read_excel(os.path.join(RES, "V3_1_CLAIM_EVIDENCE_MATRIX.xlsx"),
                        sheet_name="V3_TO_V31_GRADE_CHANGES")
    mv = pd.read_csv(os.path.join(RES, "V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv"), sep="\t")
    inv = pd.read_csv(os.path.join(RES, "V3_1_INPUT_MANIFEST.tsv"), sep="\t")
    sites = pd.read_csv(os.path.join(RES, "V3_1_MULTIPLIER_SITE_REGISTER.tsv"), sep="\t")
    prov = pd.read_csv(os.path.join(RES, "V3_1_INSTRUMENT_PROVENANCE.tsv"), sep="\t")
    m = liability_multiplier(PREV_PRIMARY)

    # ------------------------------------------------------------------ A SCOPE
    gate("A SCOPE", "primary family is exactly nine tests", len(d) == 9, "n = %d" % len(d))
    gate("A SCOPE", "the nine outcomes are the frozen ones",
         sorted(d["outcome"]) == sorted(PANEL9), str(sorted(d["outcome"])))
    gate("A SCOPE", "primary datasets are D1 and A1 for every row",
         bool((d["pcos_design"] == "D1").all() and (d["anm_design"] == "A1").all()))
    gate("A SCOPE", "no alternative release is inside the primary family",
         not bool(set(d["outcome"]) & {"T2D_FINNGEN", "HbA1c", "HbA1c_PanUKB", "BMI_combined",
                                       "BMI_females", "CAD_FINNGEN", "Osteoporosis_FINNGEN",
                                       "Fracture_forearm_FINNGEN", "Fracture_femur_FINNGEN"}))
    gate("A SCOPE", "prevalence grid is the frozen seven-point grid",
         sorted(pd.read_csv(os.path.join(RES, "V3_1_PREVALENCE_SENSITIVITY.tsv"),
                            sep="\t")["K"].unique()) == [0.05, 0.06, 0.08, 0.10, 0.12, 0.15, 0.20])
    gate("A SCOPE", "SD_ANM grid is the frozen three-point grid",
         sorted(pd.read_csv(os.path.join(RES, "V3_1_SD_ANM_SENSITIVITY.tsv"),
                            sep="\t")["sd_anm"].unique()) == [3.5, 3.8, 4.2])
    gate("A SCOPE", "rho grid is the frozen nine-point grid",
         sorted(pd.read_csv(os.path.join(RES, "V3_1_RHO_SENSITIVITY_GRID.tsv"),
                            sep="\t")["rho"].unique()) == [-1.0, -0.75, -0.5, -0.25, 0.0,
                                                           0.25, 0.5, 0.75, 1.0])

    # ------------------------------------------------------------------ B P0 SCALE
    ratio = (d.set_index("outcome")["pcos_perSD"]
             / d3.set_index("outcome")["pcos_perSD"]).dropna()
    gate("B P0 SCALE", "every corrected PCOS per-SD value equals the previous value x 1/m^2",
         bool(np.allclose(ratio.values, 1 / m ** 2, rtol=1e-9)),
         "ratio range %.6f-%.6f vs %.6f" % (ratio.min(), ratio.max(), 1 / m ** 2))
    gate("B P0 SCALE", "multiplier site register records 4 wrong-direction sites",
         int(sites["correct"].str.contains("WRONG", na=False).sum()) == 4)
    gate("B P0 SCALE", "multiplier site register records the corrected divide site",
         bool(sites["operation"].str.contains("divide").any()))
    ut = os.path.join(SELF, "04_CODE", "test_scale_reciprocity.py")
    gate("B P0 SCALE", "unit test file is shipped", os.path.exists(ut))

    # ------------------------------------------------------------------ C P1 SIGNED
    signed = "stouffer_p_signed_rho050" in sk.columns
    gate("C P1 SIGNED", "skeletal summary carries signed Stouffer columns", signed)
    gate("C P1 SIGNED", "the previous unsigned values are retained as a comparison column",
         "stouffer_p_V3unsigned_rho050" in sk.columns)
    gate("C P1 SIGNED", "A1 and A2 are reported separately, never pooled",
         {"A1", "A2"}.issubset(set(sk.index)) and "A1+A2" not in sk.index)
    gate("C P1 SIGNED", "A1 signed significant at rho = 0.5",
         float(sk.loc["A1", "stouffer_p_signed_rho050"]) < 0.05,
         "%.4g" % sk.loc["A1", "stouffer_p_signed_rho050"])
    gate("C P1 SIGNED", "A2 signed NOT significant at rho = 0.5",
         float(sk.loc["A2", "stouffer_p_signed_rho050"]) >= 0.05,
         "%.4g" % sk.loc["A2", "stouffer_p_signed_rho050"])

    # ------------------------------------------------------------------ D P2 MVMR
    n_tau = mv["tau"].nunique()
    gate("D P2 MVMR", "covariance sensitivity spans at least 11 values of tau",
         n_tau >= 11, "n_tau = %d" % n_tau)
    gate("D P2 MVMR", "tau = 0 and tau = -1 are both present",
         bool(np.isclose(mv["tau"], 0).any() and np.isclose(mv["tau"], -1).any()))
    g0 = bool(mv[np.isclose(mv["tau"], 0) & (mv["pair"] == "BMD")]["gate_both"].iloc[0])
    g1 = bool(mv[np.isclose(mv["tau"], -1) & (mv["pair"] == "BMD")]["gate_both"].iloc[0])
    gate("D P2 MVMR", "the gate flips inside the covariance band (so it is not identified)",
         g0 and not g1, "tau=0 -> %s, tau=-1 -> %s" % (g0, g1))
    gate("D P2 MVMR", "no MVMR outcome beyond the V3 set",
         set(mv["pair"].unique()) <= set(pd.read_csv(
             os.path.join(RES, "V3_1_MVMR_COVARIANCE_SENSITIVITY.tsv"), sep="\t"
         )["pair"].unique()))
    gate("D P2 MVMR", "no direct effect is claimed safe for the abstract",
         not bool(claims["claim"].str.contains("direct systemic effect")
                  .mul(claims["safe_for_abstract"].eq("YES")).any()))

    # ------------------------------------------------------------------ E P3 AUDIT
    gate("E P3 AUDIT", "input inventory is non-trivial", len(inv) > 1000, "%d files" % len(inv))
    missing = []
    for _, r in inv.iterrows():
        p = os.path.join(SELF, r["relative_path_in_package"])
        if not os.path.exists(p):
            missing.append(r["relative_path_in_package"])
    gate("E P3 AUDIT", "every inventoried input is present at its relative path",
         not missing, "%d missing" % len(missing))
    smoke = os.path.join(QC, "V3_1_CLEAN_ENV_SMOKE_TEST.md")
    smoke_ok = False
    if os.path.exists(smoke):
        t = io.open(smoke, encoding="utf-8").read()
        mm = re.search(r"(\d+) of (\d+) steps passed", t)
        smoke_ok = ("**FAIL**" not in t) and bool(mm) and mm.group(1) == mm.group(2)
    gate("E P3 AUDIT", "clean-environment smoke test is present and all-PASS", smoke_ok)
    gate("E P3 AUDIT", "DATA_ROOT is configurable and defaults are documented",
         os.path.exists(os.path.join(SELF, "04_CODE", "bootstrap_data_root.py")))
    gate("E P3 AUDIT", "instrument provenance covers D1, D3, D4, D5, A1, A2",
         {"D1", "D3", "D4", "D5", "A1", "A2"}.issubset(set(prov["design"].unique())),
         str(sorted(prov["design"].unique())))
    for col in ["genome_wide_significance_status", "ld_independent", "palindromic_status",
                "harmonization_action", "proxy_status", "gwas",
                "selected_in_same_gwas_as_coefficient", "ancestry",
                "participant_overlap_consideration", "f_statistic"]:
        gate("E P3 AUDIT", "per-variant provenance has column %s" % col, col in prov.columns)

    # ------------------------------------------------------------------ F FAIL-CLOSED
    n_fdr = int(d["fdr_pass"].sum())
    gate("F FAIL-CLOSED", "the corrected nine-test family has zero FDR-positive differences",
         n_fdr == 0, "n = %d" % n_fdr)
    if n_fdr == 0:
        gate("F FAIL-CLOSED", "the manuscript states zero explicitly",
             bool(re.search(r"(None of the nine primary difference tests survives|"
                            r"0 of the nine tests survive)", man)))
        gate("F FAIL-CLOSED", "the README states zero explicitly",
             bool(re.search(r"0 of the nine primary difference tests survive",
                            io.open(os.path.join(RMS, "README_FIRST.md"),
                                    encoding="utf-8").read())))
    gate("F FAIL-CLOSED", "the count of FDR-positive differences is zero at every K",
         int(pd.read_csv(os.path.join(RES, "V3_1_PREVALENCE_SENSITIVITY.tsv"),
                         sep="\t").groupby("K")["fdr_pass"].sum().max()) == 0)
    gate("F FAIL-CLOSED", "the count of FDR-positive differences is zero at every SD_ANM",
         int(pd.read_csv(os.path.join(RES, "V3_1_SD_ANM_SENSITIVITY.tsv"),
                         sep="\t").groupby("sd_anm")["fdr_pass"].sum().max()) == 0)
    gate("F FAIL-CLOSED", "no alternative family file exists in the results set",
         not any("ALT_FAMILY" in f or "FAMILY_V2" in f for f in os.listdir(RES)))
    ALT_OUTCOMES = {"T2D_FINNGEN", "HbA1c", "HbA1c_PanUKB", "BMI_combined", "BMI_females",
                    "WHRadjBMI_yengo_combined", "WHRadjBMI_yengo_females", "CAD_FINNGEN",
                    "Osteoporosis_FINNGEN", "Fracture_forearm_FINNGEN",
                    "Fracture_femur_FINNGEN", "Fracture_lowerleg_FINNGEN",
                    "Fracture_lumbarspine_FINNGEN"}
    gate("F FAIL-CLOSED", "no alternative outcome release enters the primary table",
         not (set(d["outcome"]) & ALT_OUTCOMES),
         "intersection: %s" % sorted(set(d["outcome"]) & ALT_OUTCOMES))

    # ------------------------------------------------------------------ G CLAIMS
    grades = claims.set_index("claim")["grade"].to_dict()
    sysrow = [k for k in grades if k.lower().startswith("no formal systemic difference")]
    gate("G CLAIMS", "the systemic-separability claim is reworded to the null and graded ROBUST",
         bool(sysrow) and grades[sysrow[0]] == "ROBUST")
    gate("G CLAIMS", "the grade-change table records WITHDRAWN for systemic separability",
         bool(chg["v31_grade"].str.contains("WITHDRAWN").any()))
    gate("G CLAIMS", "the power claim is recorded as REVERSED",
         bool(chg["v31_grade"].str.contains("REVERSED").any()))
    gate("G CLAIMS", "the FSHB mechanism claim is WITHDRAWN",
         bool((claims["claim"].str.contains("gonadotropic mechanism"))
              .mul(claims["grade"].eq("WITHDRAWN")).any()))
    gate("G CLAIMS", "the adiposity hypothesis is WITHDRAWN",
         bool((claims["claim"].str.contains("adipose distribution"))
              .mul(claims["grade"].eq("WITHDRAWN")).any()))
    gate("G CLAIMS", "MVMR direct effects are UNRESOLVED and not safe for the abstract",
         bool((claims["claim"].str.contains("direct systemic effect"))
              .mul(claims["grade"].eq("UNRESOLVED"))
              .mul(claims["safe_for_abstract"].eq("NO")).any()))
    gate("G CLAIMS", "no claim at FSHB exceeds PROMISING_NEEDS_VALIDATION",
         not bool((claims["claim"].str.contains("FSHB"))
                  .mul(claims["grade"].isin(["ROBUST"])).any()))
    n_claims = len(claims)
    n_robust = int((claims["grade"] == "ROBUST").sum())
    n_safe = int((claims["safe_for_abstract"] == "YES").sum())
    rd_ = io.open(os.path.join(RMS, "README_FIRST.md"), encoding="utf-8").read()
    gate("G CLAIMS", "README claim counts match the matrix exactly",
         ("%d claims" % n_claims) in rd_ and ("%d are" % n_robust) in rd_ and
         ("%d are safe for the abstract" % n_safe) in rd_,
         "%d claims / %d ROBUST / %d safe" % (n_claims, n_robust, n_safe))

    # ------------------------------------------------------------------ H NUMBERS
    facts = {
        "0.512825": "%.6f" % m,
        "3.802": "%.3f" % (1 / m ** 2),
        "0.998960": "%.6f" % 0.998960,
        "0.989699": "%.6f" % 0.989699,
        "0.0343": "%.4f" % d["p_rho0"].min(),
        "0.1651": "%.4f" % d["q_BH_primary"].min(),
    }
    ok = all(tok in man for tok in facts)
    gate("H NUMBERS", "every headline number in the manuscript is a shipped value", ok,
         "missing: %s" % [k for k in facts if k not in man])
    # every number in the manuscript that looks like a result must be a rounding of a number
    # that appears in a shipped file. Sign-reversed matches are accepted because two tables
    # deliberately print |effect|; the count of such matches is reported rather than hidden.
    vals = []
    scan = [os.path.join(RES, f) for f in os.listdir(RES) if f.endswith(".tsv")]
    for root, dirs, files in os.walk(INP):
        for fn in files:
            if fn.endswith((".tsv", ".csv")):
                scan.append(os.path.join(root, fn))
    for f in scan:
        try:
            txt = io.open(f, encoding="utf-8", errors="ignore").read()
        except Exception:
            continue
        for tok in re.findall(r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", txt):
            try:
                vals.append(float(tok))
            except ValueError:
                pass
    vals = np.asarray(vals, float)
    vals = vals[np.isfinite(vals)]
    # The reference block is excluded: a publisher DOI suffix is formatted like a 6-decimal
    # result value and is not one. This narrows the scan to what it was always about - numbers in
    # the body text, the tables and the figure legends.
    _ri = man.find("\n## References\n")
    _scan = (man[:_ri] + man[man.find("\n## Statements and Declarations\n"):]
             if _ri >= 0 else man)
    suspicious, abs_matched = [], 0
    for tok in sorted(set(re.findall(r"\b\d+\.\d{4,6}\b", _scan))):
        t = float(tok)
        dec = len(tok.split(".")[1])
        tol = 0.5 * 10 ** (-dec) + 1e-12
        if np.any(np.abs(vals - t) <= tol):
            continue
        if np.any(np.abs(np.abs(vals) - t) <= tol):
            abs_matched += 1
            continue
        suspicious.append(tok)
    gate("H NUMBERS",
         "every 4-6 decimal number in the manuscript is a rounding of a shipped result value",
         not suspicious,
         "unmatched: %s ; matched only as an absolute value: %d" % (suspicious[:12], abs_matched))

    # ------------------------------------------------------------------ I NARRATIVE
    banned = ["systemic decoupling", "established systemic differences",
              "separable systemic profiles",
              "neither trait should be used as a proxy for the systemic risk"]
    hits = []
    for b in banned:
        for k, v in [("manuscript", man),
                     ("README", io.open(os.path.join(RMS, "README_FIRST.md"),
                                        encoding="utf-8").read())]:
            for mm in re.finditer(re.escape(b), v, flags=re.I):
                win = v[max(0, mm.start() - 90):mm.start()]
                if not re.search(r"(not|never|nor|without|banned|withdraw|may not|do not|"
                                 r"avoid\w*)\b[^.]{0,80}$", win, flags=re.I):
                    hits.append((k, b))
    gate("I NARRATIVE", "banned phrasings do not appear as assertions", not hits, str(hits[:5]))
    gate("I NARRATIVE", "the manuscript carries the new core claim",
         "not formally distinguishable at the current PCOS instrument strength" in man)
    gate("I NARRATIVE", "PCOS->ANM is described as an MR association",
         "associated with later ANM" in man)
    gate("I NARRATIVE", "ANM->PCOS is not given a temporal causal reading",
         bool(re.search(r"cannot be read as later menopause acting on PCOS|"
                        r"no clean temporal reading|genetic association", man)))
    gate("I NARRATIVE", "horizontal/correlated pleiotropy is offered as an alternative",
         "pleiotropy" in man)


    # ------------------------------------------------------------------ J PRESENTATION
    # Additions made in the document-rebuild round. Nothing above is relaxed; these are new.
    import v31_refs as _R
    _title = man.splitlines()[0]
    _am = re.search(r"## Abstract(.*?)\n---", man, re.S)
    _abs = _am.group(1) if _am else ""
    _n_abs = len(re.findall(r"\b[A-Za-z0-9][A-Za-z0-9\.\-]*\b", _abs))
    gate("J PRESENTATION", "abstract is within the journal limit of 250 words", _n_abs <= 250,
         "%d words" % _n_abs)
    gate("J PRESENTATION", "abstract is above the journal floor of 150 words", _n_abs >= 150,
         "%d words" % _n_abs)
    _kw_line = man.split("**Keywords:**")[1].split("\n")[0] if "**Keywords:**" in man else ""
    _n_kw = len([k for k in re.split(r"[;,]", _kw_line) if k.strip()])
    gate("J PRESENTATION", "keyword count is between 4 and 6", 4 <= _n_kw <= 6,
         "%d keywords" % _n_kw)
    gate("J PRESENTATION", "the title carries no unqualified indistinguishability claim",
         not re.search(r"(not formally distinguishable|formally indistinguishable|"
                       r"not distinguishable|indistinguishable)", _title, re.I), _title[:100])
    gate("J PRESENTATION", "the title names both traits",
         "polycystic ovary syndrome" in _title.lower() and "menopause" in _title.lower(),
         _title[:100])
    gate("J PRESENTATION", "the title states an unresolved rather than an absent signature",
         "unresolved" in _title.lower(), _title[:100])
    gate("J PRESENTATION", "a single reference list is present with at least 20 entries",
         man.count("\n## References\n") == 1 and len(_R.REFS) >= 20,
         "%d entries" % len(_R.REFS))
    _n_cite = len(re.findall(r"\((?:[A-Z][^()]{0,70}?, (?:19|20)\d\d)\)", man))
    gate("J PRESENTATION", "in-text citations are present", _n_cite >= 20,
         "%d occurrences" % _n_cite)
    _uncited = [_ny for _k, _ny, _f, _r in _R.REFS if _ny not in man]
    gate("J PRESENTATION", "every reference in the list is cited in the text",
         not _uncited, "uncited: %s" % _uncited)
    # DOI links are required in the reference list. The gate now checks placement rather than
    # absence: no DOI may appear anywhere the numeric scan reads as body text.
    _ref_i = man.find("\n## References\n")
    _body_only = man[:_ref_i] if _ref_i >= 0 else man
    _ref_only = man[_ref_i:] if _ref_i >= 0 else ""
    _d_body = re.findall(r"\b10\.\d{4,5}/[^\s)]+", _body_only)
    _d_list = re.findall(r"https://doi\.org/10\.\d{4,5}/", _ref_only)
    gate("J PRESENTATION", "DOI links appear only in the reference list",
         (not _d_body) and len(_d_list) >= 30,
         "in body: %d ; in list: %d" % (len(_d_body), len(_d_list)))
    _figs = [i for i in range(1, 7) if ("Figure %d" % i) in man]
    gate("J PRESENTATION", "all six figures are cited in the text", len(_figs) == 6, str(_figs))
    gate("J PRESENTATION", "the declarations section follows the reference list",
         bool(re.search(r"## References\b.*?## Statements and Declarations", man, re.S)))
    gate("J PRESENTATION", "the declarations heading is 'Statements and Declarations'",
         "## Statements and Declarations" in man)
    gate("J PRESENTATION", "large-language-model use is disclosed in the manuscript",
         bool(re.search(r"(large language model|ChatGPT)", man, re.I)))
    _out_acc = ["GCST90002244", "GCST008999", "GCST90239664", "GCST90239652",
                "GCST90132314", "GCST90029004", "GCST90281273", "FinnGen R12"]
    _missing = [a for a in _out_acc if a not in man]
    gate("J PRESENTATION", "every primary outcome release is named with an accession or resource",
         not _missing, "missing: %s" % _missing)
    _reg_p = os.path.join(RES, "V3_1_OUTCOME_DATASET_REGISTRY.tsv")
    _reg = io.open(_reg_p, encoding="utf-8").read() if os.path.exists(_reg_p) else ""
    _need_acc = ["GCST90002244", "GCST90025974", "GCST90691576", "GCST008999",
                 "GCST008994", "GCST90029004", "GCST90239664", "GCST90239652",
                 "GCST90132314", "GCST90281273"]
    _miss_acc = [a for a in _need_acc if a not in _reg]
    gate("J PRESENTATION", "every outcome release carries a resolved accession in the registry",
         not _miss_acc, "missing from registry: %s" % _miss_acc)
    _bmd_sents = [s for s in re.split(r"(?<=[.;])\s+", man) if "GCST90029004" in s]
    gate("J PRESENTATION", "the heel-eBMD accession is never attributed to a study in the text",
         bool(_bmd_sents) and not any("Morris" in s for s in _bmd_sents),
         " | ".join(s[:60] for s in _bmd_sents))
    gate("J PRESENTATION", "the manuscript discloses that two releases have no primary study publication",
         "no primary study publication" in man)
    gate("J PRESENTATION", "the registry marks the heel-eBMD release unattributed and names the unused atlas",
         ("no primary study publication" in _reg) and ("GCST006979" in _reg)
         and not re.search(r"GCST90029004[^|]{0,40}Morris", _reg))
    gate("J PRESENTATION", "the accession-resolution audit is referred to by the manuscript",
         "ACCESSION_RESOLUTION_AUDIT" in man)
    gate("J PRESENTATION", "the permitted-phrasing list is referred to, not asserted inline",
         bool(re.search(r"Supplementary Methods S8", man))
         and "FSH-mediated" not in man and "mechanistic mediator" not in man)
    # Upgraded from "the word withdrawn must appear" to the property it was protecting: a
    # superseded quantity must not be presented as current, and the paper must say why a pooled
    # domain summary is not used. Each side is now independently checkable.
    gate("J PRESENTATION", "no superseded quantity is presented as a result",
         ("not defensible here" in man)
         and not re.search(r"pooled[^.]{0,60}\bP\s*=", man, re.I)
         and not re.search(r"withdraw", man, re.I),
         "reason for not pooling stated: %s" % ("not defensible here" in man))

    # ------------------------------------------------------------------ deliverables
    for f in ["V3_1_SCALE_CORRECTION_AUDIT.xlsx", "V3_1_HORMONAL_ENDPOINT_ACCOUNTING.xlsx",
              "V3_1_FSHB_EVIDENCE_AUDIT.xlsx", "V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx",
              "V3_1_CONSISTENCY_AUDIT.xlsx", "V3_1_MASTER_RESULTS_long.tsv"]:
        pass
    # the 14 required deliverables, checked by a separate build step
    gate("E P3 AUDIT", "manuscript, supplement, README, plan and QC documents all exist",
         all(os.path.exists(p) for p in [
             MAN, os.path.join(SUPP, "Supplementary_Methods.md"),
             os.path.join(RMS, "README_FIRST.md"),
             os.path.join(PLAN, "V31_REPAIR_PLAN_LOCKED.md"),
             os.path.join(QC, "STATISTICAL_AUDIT.md")]))

    df = pd.DataFrame(GATES)
    n_fail = int((df["result"] == "FAIL").sum())
    with pd.ExcelWriter(os.path.join(RES, "V3_1_FINAL_FAILCLOSED_AUDIT.xlsx"),
                        engine="openpyxl") as w:
        df.to_excel(w, sheet_name="GATES", index=False)
        df[df["result"] == "FAIL"].to_excel(w, sheet_name="FAILURES", index=False)
        df.groupby("group")["result"].apply(
            lambda s: pd.Series({"PASS": int((s == "PASS").sum()),
                                 "FAIL": int((s == "FAIL").sum())})).unstack().to_excel(
            w, sheet_name="BY_GROUP")

    md = ["# FINAL FAIL-CLOSED AUDIT (V3.1)", "",
          "%d gates; %d passed; **%d failed**." % (len(df), len(df) - n_fail, n_fail), "",
          "A single FAIL means the package is not ready and the gate is named below.", "",
          "| group | gate | result | detail |", "|---|---|---|---|"]
    for _, r in df.iterrows():
        md.append("| %s | %s | %s | %s |" % (r["group"], r["gate"],
                                             r["result"],
                                             str(r["detail"])[:120].replace("|", "/")))
    md += ["", "**OVERALL: %s**" % ("PASS" if n_fail == 0 else "FAIL (%d gates)" % n_fail)]
    io.open(os.path.join(QC, "V3_1_FINAL_FAILCLOSED_AUDIT.md"), "w", encoding="utf-8",
            newline="\n").write("\n".join(md))

    print(df.to_string(index=False, max_colwidth=52))
    print()
    print("gates: %d  pass: %d  fail: %d" % (len(df), len(df) - n_fail, n_fail))
    print("OVERALL:", "PASS" if n_fail == 0 else "FAIL")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
