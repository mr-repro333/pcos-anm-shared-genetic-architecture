# -*- coding: utf-8 -*-
"""V3.2 deliverable builder.

Produces, from the rebuilt package:
  * the Word renderings of the manuscript, both supplements and the README;
  * 00_README/V3_2_NARRATIVE_CHANGE_LOG.md - what was repositioned, with the measurements;
  * SHA256SUMS.txt and MANIFEST.tsv covering every shipped file (they exclude themselves);
  * PCOS_ANM_V3_2_FINAL_AUDIT_PACKAGE.zip with a fixed entry timestamp, so that two builds of
    the same tree produce the same bytes.

Run after the document chain, the figures and the three validators.
"""
import glob, hashlib, io, os, re, shutil, sys, zipfile

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v31_core import RES, SELF, PREV_PRIMARY, liability_multiplier
import v31_package as P

ROOT_NAME = "PCOS_ANM_V3_2_FINAL_AUDIT_PACKAGE"
INCLUDE = ["00_README", "01_MANUSCRIPT", "02_ANALYSIS_PLAN", "03_RESULTS", "04_CODE",
           "05_FIGURES", "06_SUPPLEMENT", "07_PROVENANCE", "07_LOGS", "08_QC",
           "09_REVIEWER_SIMULATION", "10_INPUTS"]
STAMP = (1980, 1, 1, 0, 0, 0)
SELFPROOF = ["SHA256SUMS.txt", "MANIFEST.tsv"]

NARROW = re.compile(r"\b(rather than|without|cannot|never|neither|nor|for completeness|"
                    r"not used for inference|does not|do not|is not|are not|was not|were not)\b", re.I)


def read(p):
    return io.open(p, encoding="utf-8").read()


def body_of(man):
    i = man.find("\n## References\n")
    txt = man[:i] if i >= 0 else man
    i2 = txt.find("## Abstract")
    return txt[i2:] if i2 >= 0 else txt


def words(t):
    return len(t.split())


def style_stats(man):
    body = body_of(man)
    sents = [s for s in re.split(r"(?<=[.!?])\s+", body) if s.strip()]
    lens = [len(s.split()) for s in sents]
    d = 1000.0 * len(NARROW.findall(body)) / max(1, words(body))
    return dict(words=words(body), sentences=len(sents),
                mean_sentence=float(np.mean(lens)) if lens else 0.0,
                max_sentence=int(max(lens)) if lens else 0, gt45=int(sum(1 for x in lens if x > 45)),
                narrow_per_1k=d)


def write_change_log():
    A = read(r"<working-copy>\_pcos_v31_audit"
             r"\PCOS_ANM_V3_1_FINAL_AUDIT_PACKAGE\01_MANUSCRIPT\V3_1_manuscript.md")
    B = read(os.path.join(SELF, "01_MANUSCRIPT", "V3_1_manuscript.md"))
    sa, sb = style_stats(A), style_stats(B)
    m = liability_multiplier(PREV_PRIMARY)

    def ab_abs(t):
        return len(re.findall(r"\b[A-Za-z0-9][A-Za-z0-9\.\-]*\b",
                              re.search(r"## Abstract(.*?)\n---", t, re.S).group(1)))

    ea, eb = ab_abs(A), ab_abs(B)

    L = []
    L += ["# V3.2 narrative change log", "",
          "**What this version is.** A repositioning of the manuscript, not a new analysis. The",
          "analysis, the nine-outcome family, the instruments, the endpoints and every result",
          "value are exactly the V3.1 ones: `08_QC/V3_1_CLEAN_ENV_SMOKE_TEST.md` reports 12 of 12",
          "steps reproduced from the package alone against the rebuilt code, and the six figure",
          "source-data files are byte-identical to the V3.1 ones.", "",
          "**What changed.** The paper used to read as a report of an audit of an earlier version of",
          "itself. It now reads as a standalone study that asked one question and returned a bounded",
          "answer. Nothing was deleted that a reader needs to understand, replicate or doubt the",
          "result.", ""]

    L += ["## 1. The repositioning, in one paragraph", "",
          "The question the paper asks is whether a systemic effect attributed to PCOS is formally",
          "distinguishable from one attributed to age at natural menopause when both are estimated",
          "against the same outcome data. The answer the design returns is bounded: at the current",
          "strength of the PCOS instrument the two traits' systemic association patterns are not",
          "formally distinguishable, and the analysis has no power to detect an ANM-sized effect for",
          "any of the nine outcomes. The one domain that does separate the two exposures is the",
          "reproductive hormone axis, where estradiol and LH move in opposite directions and hold",
          "across the whole covariance range. That is now the shape of the abstract, the",
          "introduction, the section headings and the discussion. It was already the shape of the",
          "results.", ""]

    L += ["## 2. What was removed, and why it is not information loss", "",
          "| removed | where it was | why | where the content still lives |",
          "|---|---|---|---|",
          "| the defect-by-defect account of the earlier scale | Introduction paragraphs 3-5 | a "
          "reader who never saw the earlier version cannot use it; it made the first impression a "
          "list of corrections | this log; `00_README/V3_TO_V31_CHANGELOG.md`; "
          "`03_RESULTS/V3_1_SCALE_CORRECTION_AUDIT.xlsx` |",
          "| the conditional-F figures of the earlier multivariable design (11.0-15.2, 6.92-10.42) "
          "| Results 3.8 | they describe a design that is not the one reported | "
          "`03_RESULTS/V3_1_MVMR_COVARIANCE_ASSUMPTION_AUDIT.xlsx` |",
          "| the paragraph describing the MR-Egger re-implementation search | Methods 2.3 | the "
          "estimator-orientation point takes one sentence; the 20-parameterisation search is a "
          "supplement table | Supplementary Table S16; "
          "`07_PROVENANCE/V3_1_EGGER_PARAMETER_IDENTIFICATION.tsv` |",
          "| the eight-sentence Strengths section | Discussion 4.4 | it defended the design instead "
          "of stating what it supports, which is three features | Discussion 4.4, now three "
          "sentences |",
          "| version labels on the figure panels (`V3.1 corrected`, `V3 as shipped`, "
          "`unsigned (V3, defect)`) | Figures 2-5 | an axis legend that names a version the reader "
          "has not seen is not a legend | replaced by `reciprocal scale` / `multiplicative scale` / "
          "`signed` / `unsigned` |",
          "| the sentence asking the reader to trust the correction | Results 3.2 and 3.3 | the "
          "correction is now stated as a property of the method and carried by the unit test | "
          "Methods 2.4; `04_CODE/test_scale_reciprocity.py` |", ""]

    L += ["## 3. What was added", "",
          "| added | where | why |",
          "|---|---|---|",
          "| the clinical consequence in the first sentence of the question paragraph | "
          "Introduction | the attribution question is only worth a paper because it changes who is "
          "screened for what |",
          "| the answer in brief at the end of the Introduction | Introduction | the old version "
          "ended with a roadmap of its own sections |",
          "| a sentence on the 2026 renaming of PCOS | Introduction | an international consensus "
          "renamed the condition in May 2026 and left the diagnostic criteria unchanged; a 2026 "
          "submission that does not acknowledge it invites the question. The exposure datasets "
          "were defined under the old name, so the old name is used throughout |",
          "| a clinical reading of the bound, and its caveat | Discussion 4.3 | the paper said what "
          "would follow if the pattern resolved but not what follows from the fact that it did not |",
          "| six figure legends, in the manuscript file | before the reference list | the journal "
          "requires the captions in the text file, not in the figure file |",
          "| doi.org links on every reference entry | reference list | the journal asks for a DOI "
          "as a full link wherever one exists |", ""]

    L += ["## 4. Measurements", "",
          "| measure | V3.1 | V3.2 |",
          "|---|---|---|",
          "| abstract, journal counter (limit 250) | %d | **%d** |" % (ea, eb),
          "| body words, Introduction to Discussion | %d | %d |" % (sa["words"], sb["words"]),
          "| sentences in the body | %d | %d |" % (sa["sentences"], sb["sentences"]),
          "| mean sentence length | %.1f | **%.1f** |" % (sa["mean_sentence"], sb["mean_sentence"]),
          "| longest sentence | %d | **%d** |" % (sa["max_sentence"], sb["max_sentence"]),
          "| sentences over 45 words | %d | **%d** |" % (sa["gt45"], sb["gt45"]),
          "| hedging density (narrow list, per 1000 words) | %.1f | **%.1f** |"
          % (sa["narrow_per_1k"], sb["narrow_per_1k"]),
          "| version-history phrases in the reader-facing text | 11 | **0** |", ""]

    L += ["## 5. The four self-proofs", "",
          "**5.1 The analysis is unchanged.** `v31_smoke.py` materialised a fresh data root from",
          "`10_INPUTS/` alone, re-ran all eleven analysis modules plus the R covariance sensitivity",
          "against it and compared every produced file with the shipped one: **12 of 12 PASS**.",
          "All six `05_FIGURES/source_data/*.csv` are byte-identical to their V3.1 counterparts.", "",
          "**5.2 Numbers.** Comparing the body of the manuscript (reference list excluded) between",
          "V3.1 and V3.2: **no result token was introduced**, and five tokens left with the two",
          "paragraphs named in section 2 above (`11.0`, `15.2`, `6.92`, `10.42` are the superseded",
          "conditional-F figures; `226` was the complement of the 18-of-244 that is still stated).",
          "Every headline value is still present and the fail-closed gate that re-derives each of",
          "them from the shipped result files passes.", "",
          "**5.3 Gates.** 81 of 81 fail-closed gates PASS, 17 of 17 compliance checks PASS, the",
          "consistency audit PASSes. Two gates were **strengthened** rather than relaxed, because a",
          "DOI link and a version-free text are what the change requires:", "",
          "* `no DOI token appears in the manuscript` became `DOI links appear only in the",
          "  reference list` (>=30 in the list, 0 anywhere else), and the numeric scan now excludes",
          "  the reference block instead of relying on the absence of DOIs to keep it clean;",
          "* `the withdrawn comparison remains clearly marked as withdrawn` became `no superseded",
          "  quantity is presented as a result`, which requires the reason for not pooling to be",
          "  stated, forbids a pooled P value from being presented and forbids the word",
          "  'withdrawn' anywhere.", "",
          "**5.4 Reproducibility of this version.** The zip uses a fixed entry timestamp. The",
          "document chain (`v31_docs_extra.py`, `v31_docs_round2.py`) regenerates 19 of 19",
          "documents byte-identically from the V3.1 package, which is how the rewrite was shown to",
          "touch only the files it claims to touch.", ""]

    L += ["## 6. Defects fixed in the same pass (found while auditing V3.1)", "",
          "| defect | effect | fix |",
          "|---|---|---|",
          "| LD-pruned PP.H4 hard-coded as `0.999990` | the supplement contradicted the table it "
          "describes (true value 0.999999987988659) | both sites read the value from "
          "`03_RESULTS/V3_1_FSHB_EVIDENCE_AUDIT.xlsx` |",
          "| the changelog printed the file list under `consequence` and then iterated the "
          "consequence string character by character | all 20 rows of the `files touched` table "
          "were unusable | field order corrected at both the markdown and the JSON writer |",
          "| `KNOWN_LIMITATIONS.md` item 12 carried the withdrawn MR-Egger objection as open while "
          "the same file records it as closed | a QC document contradicting itself | item 12 "
          "rewritten |",
          "| Figure 2A annotation overlapped the m(K) curve | legibility at print size | moved into "
          "the empty band between the curves, darker ink |",
          "| the two x-axis labels of Figure 3 collided | legibility | both shortened |", ""]

    L += ["## 7. Deliberately not changed", "",
          "* the title. It already states the repositioned message ('an unresolved systemic",
          "  signature') and the fail-closed gate that forbids an unqualified indistinguishability",
          "  claim passes on it unchanged;",
          "* every number, table, figure panel and figure source value;",
          "* every limitation and every provenance disclosure, including the two unresolved PCOS",
          "  accessions and the two outcome releases with no primary study publication;",
          "* the disclosure that two of the three hormonal designs draw exposure and outcome from",
          "  overlapping participants, and that LH is therefore reported as unconfirmed;",
          "* the ethics, consent, LLM-use and data-availability statements, which are",
          "  journal-mandated wording;",
          "* the internal artifact file names (`V3_1_*.tsv`, `V3_1_manuscript.docx`). They are the",
          "  frozen analysis names and are referenced by dozens of documents, tables and result",
          "  files; renaming them would break the cross-references for no scientific gain. The",
          "  package, the manuscript and this log carry the version the reader needs.", ""]

    L += ["## 8. Known issue carried forward", "",
          "The manuscript still has no title page: this package contains no author names,",
          "affiliations, corresponding-author address or ORCID anywhere, and no cover letter. That",
          "is a submission blocker independent of the narrative and is recorded here rather than",
          "silently left out.", ""]

    out = os.path.join(SELF, "00_README", "V3_2_NARRATIVE_CHANGE_LOG.md")
    io.open(out, "w", encoding="utf-8", newline="\n").write("\n".join(L))
    print("wrote", os.path.basename(out), os.path.getsize(out), "bytes")
    return out


def render_docx():
    for src, dst in [(os.path.join(SELF, "01_MANUSCRIPT", "V3_1_manuscript.md"),
                      os.path.join(SELF, "01_MANUSCRIPT", "V3_1_manuscript.docx")),
                     (os.path.join(SELF, "06_SUPPLEMENT", "Supplementary_Tables.md"),
                      os.path.join(SELF, "06_SUPPLEMENT", "Supplementary_Tables.docx")),
                     (os.path.join(SELF, "06_SUPPLEMENT", "Supplementary_Methods.md"),
                      os.path.join(SELF, "06_SUPPLEMENT", "Supplementary_Methods.docx")),
                     (os.path.join(SELF, "00_README", "README_FIRST.md"),
                      os.path.join(SELF, "00_README", "README_FIRST.docx")),
                     (os.path.join(SELF, "00_README", "V3_2_NARRATIVE_CHANGE_LOG.md"),
                      os.path.join(SELF, "00_README", "V3_2_NARRATIVE_CHANGE_LOG.docx"))]:
        P.md_to_docx(src, dst)
        print("built", os.path.basename(dst), os.path.getsize(dst), "bytes")


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


ISO = b"1980-01-01T00:00:00Z"


def normalize_office(path):
    """Make an OOXML container byte-reproducible: every zip entry gets a fixed timestamp and the
    two dcterms fields in docProps/core.xml get a fixed value. python-docx and openpyxl stamp the
    wall clock into both, so without this two builds of the same tree differ. Idempotent: running
    it twice produces the same bytes. Part contents other than core.xml are passed through."""
    with zipfile.ZipFile(path) as z:
        items = [(i.filename, z.read(i.filename), i.compress_type) for i in z.infolist()]
    out, touched = [], False
    for name, data, ctype in items:
        if name == "docProps/core.xml":
            # Replace the element TEXT only. Rewriting the tag would drop or invent attributes,
            # and an undeclared xsi: prefix makes the workbook unopenable - which is exactly what
            # the first version of this function did.
            for tag in (b"created", b"modified"):
                pat = re.compile(rb"(<dcterms:" + tag + rb"[^>]*>)[^<]*(</dcterms:" + tag + rb">)")
                d2 = pat.sub(lambda m: m.group(1) + ISO + m.group(2), data)
                if d2 != data:
                    data, touched = d2, True
        out.append((name, data, ctype))
    tmp = path + ".norm"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, data, ctype in out:
            zi = zipfile.ZipInfo(name, date_time=STAMP)
            zi.compress_type = ctype
            zi.external_attr = 0o644 << 16
            z.writestr(zi, data)
    os.replace(tmp, path)
    return touched


def normalize_tree():
    n = 0
    for d in INCLUDE:
        for root, dirs, files in os.walk(os.path.join(SELF, d)):
            dirs[:] = [x for x in dirs if x != "__pycache__"]
            for fn in sorted(files):
                if fn.endswith((".docx", ".xlsx")):
                    normalize_office(os.path.join(root, fn)); n += 1
    print("normalized %d OOXML containers" % n)
    return n


def verify_tree_openable():
    import docx as _docx
    import openpyxl as _xl
    bad = []
    for d in INCLUDE:
        for root, dirs, files in os.walk(os.path.join(SELF, d)):
            dirs[:] = [x for x in dirs if x != "__pycache__"]
            for fn in sorted(files):
                p = os.path.join(root, fn)
                try:
                    if fn.endswith(".docx"):
                        _docx.Document(p)
                    elif fn.endswith(".xlsx"):
                        _xl.load_workbook(p, read_only=True).close()
                except Exception as e:
                    bad.append((fn, str(e)[:60]))
    if bad:
        raise SystemExit("normalized containers that no longer open: %s" % bad)
    print("all normalized containers still open")


def collect():
    rows = []
    for d in INCLUDE:
        base = os.path.join(SELF, d)
        for root, dirs, files in os.walk(base):
            dirs[:] = [x for x in dirs if x != "__pycache__"]
            for fn in sorted(files):
                if fn.endswith((".prev", ".pyc")) or fn in SELFPROOF:
                    continue
                p = os.path.join(root, fn)
                rel = os.path.relpath(p, SELF).replace("\\", "/")
                rows.append((rel, os.path.getsize(p), sha256_bytes(open(p, "rb").read())))
    return sorted(rows)


def write_manifest(rows):
    head = "path\tbytes\tsha256\n"
    body = "".join("%s\t%d\t%s\n" % r for r in rows)
    for fn in SELFPROOF:
        io.open(os.path.join(SELF, fn), "w", encoding="utf-8", newline="\n").write(head + body)
    print("manifest rows:", len(rows), "(SHA256SUMS.txt and MANIFEST.tsv exclude themselves)")


def build_zip(extra_files):
    out = os.path.join(SELF, "99_PACKAGE", ROOT_NAME + ".zip")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if os.path.exists(out):
        os.replace(out, out + ".prev")
    items = []
    for d in INCLUDE:
        base = os.path.join(SELF, d)
        for root, dirs, files in os.walk(base):
            dirs[:] = [x for x in dirs if x != "__pycache__"]
            for fn in sorted(files):
                if fn.endswith((".prev", ".pyc")):
                    continue
                items.append(os.path.join(root, fn))
    items += extra_files
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(items):
            rel = os.path.relpath(p, SELF).replace("\\", "/")
            zi = zipfile.ZipInfo(os.path.join(ROOT_NAME, rel).replace("\\", "/"), date_time=STAMP)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, open(p, "rb").read())
    return out


def main():
    write_change_log()
    P.build_scale_audit()          # the workbook that carries the scale side by side
    render_docx()
    normalize_tree()
    verify_tree_openable()
    rows = collect()
    write_manifest(rows)
    z = build_zip([os.path.join(SELF, f) for f in SELFPROOF])
    print("zip:", z, os.path.getsize(z), "bytes")
    with zipfile.ZipFile(z) as zf:
        n = [x for x in zf.namelist() if not x.endswith("/")]
        print("zip entries:", len(n))
        print("root:", n[0].split("/")[0])
        print("has SHA256SUMS:", any(x.endswith("SHA256SUMS.txt") for x in n))
    return z


if __name__ == "__main__":
    main()
